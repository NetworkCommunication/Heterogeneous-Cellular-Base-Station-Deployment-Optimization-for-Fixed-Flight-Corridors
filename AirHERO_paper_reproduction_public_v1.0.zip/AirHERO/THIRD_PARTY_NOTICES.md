# Third-party sources and attribution

## Map-derived data

**©OpenStreetMap contributors.** POI source fields identify OSM-style `gis_osm_*` layers. OpenStreetMap data is available under the [Open Data Commons Open Database License1.0](https://opendatacommons.org/licenses/odbl/1-0/). See the official [OpenStreetMap copyright and attribution page](https://www.openstreetmap.org/copyright). These upstream terms apply to OSM-derived content; this notice does not place the entire software package under ODbL.

The publisher confirmed authorization to distribute the included fixed data. Source labels, inferred-POI confidence fields and generated/proxy labels are retained. Exact original map vendor/edition and raw GeoPackage were not supplied, so that acquisition history is not fabricated. DATA.md describes the resulting scope limit.

## Baseline methods

Existing source comments and module READMEs retain paper references and adaptation notes for NSGA-II, MOEA/D, PSO-family, CSA, ImMOGWO and other included adapters. Required historical modules remain because the registry imports them. Their presence does not establish exact reproduction of a published algorithm. This packaging process found no separate project-level third-party code-license file and assigns no new license to copied source.

## Runtime dependencies

NumPy, Matplotlib, SciPy, scikit-learn, PyYAML, pytest and optional GIS/Excel tools retain their upstream licenses. This package lists tested versions but does not redistribute their installed runtimes, environments or caches.
