# Citation and version identification

Please cite the associated paper, **Heterogeneous Cellular Base Station Deployment Optimization for Fixed Flight Corridors**, using its author/publisher-approved bibliographic record.

For the code artifact, record **AirHERO Paper Reproduction Code, public release v1.0,2026-10-28**, together with the distributed ZIP SHA-256 and the per-file MANIFEST.csv. No DOI, final publication venue or author list is invented in this package. The manuscript PDF is obtained separately.
