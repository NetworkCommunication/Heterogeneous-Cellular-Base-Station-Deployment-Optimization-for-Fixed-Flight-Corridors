# Dependencies and tested versions

Validated runtime: Windows, CPython 3.11.4 (Anaconda), NumPy 1.24.3, Matplotlib 3.7.1, SciPy 1.10.1, scikit-learn 1.3.0, pytest 7.4.0, PyYAML 6.0. Exact observed versions are in `requirements-verified.txt`; these are an observed environment, not a newly solved or clean-install-tested lockfile. No runtime/virtual environment is distributed.

NumPy and Matplotlib are imported by the actual main runner. scikit-learn is needed for consistent K-means behavior: some generic code has a fallback when it is absent; its absence must not silently be treated as an equivalent experimental environment. SciPy is a scikit-learn dependency. pytest is test-only. PyYAML supports preserved historical YAML configuration workflows; the new launch configs use stdlib JSON. PDF utilities used during source review are not main experiment requirements. Other Python versions have not been validated for this release.

Optional GIS/map/Excel functionality has not been validated here. GeoPandas/Shapely/GDAL/QGIS, a complete original GeoPackage and possibly openpyxl may be needed by those separate tools; no exact compatible versions are asserted. The frozen CSV-based main model does not require them. Linux/macOS, other Python/NumPy versions, clean installation, full paper runs and the original GIS extraction remain unverified.

Test warnings from local joblib CPU detection and scikit-learn's Windows/MKL warning are retained in validation logs; no algorithm/RNG workaround was introduced.

The route60 supplement's original formal runner invokes the Git CLI to collect provenance metadata. Git must be available for that original run path; this repository has no commits, so a commit hash is not inferred. The added default input-check launcher performs no optimization. Its exact test environment is the same Python 3.11.4 environment above.
