# Verified60-corridor supplement

The saved supplementary experiment completed **15/15 units**: five methods × K5/10/15 × seed2026. It uses25 current and35 predicted routes,1800 samples,144 proxy existing stations,50 particles and150 iterations per stage for optimizers. K1/K2 is3/2,5/5,8/7; Greedy is non-iterative.

Entry: `scripts/tmc_rebuild/run_route60_historical_multioptimizer_extension.py`. Data: `artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_sensitivity/route60_extension/`. The folder contains selected route IDs, per-unit config/result/deployment records, summary/consistency/runtime tables and heatmap inputs. Historical parent CSV inputs required by its aggregation are retained.

The AirHERO branch calls `run_formal_true_sinr_height_constrained_zmax50_sensitivity.run_method` → `run_true_joint_response_v3_closed_loop_diagnostic_K15.run_closed_loop_true_joint_variant`. Stage II uses the **K-station configuration and all-route problem**. It is all-K joint refinement despite the historical name; it must not be described as K2-only.

| K | Supplement60 ASU | Main saved50 ASU |
|---|---:|---:|
|5|0.20117650091671468|0.19961047819194105|
|10|0.13486374562466252|0.1491944857460591|
|15|0.11034884840007983|0.09904364127782943|

The supplement seeds Stage-I slots in every particle, retaining one exact prefix and perturbing the others' XYZ with45m Gaussian noise. The main common runner instead uses four population groups plus future low-service anchors. Results remain separately identified; the50-row is not relabeled60. Likewise25/35 must not be silently changed to24/36. This is single-seed sensitivity evidence, not a multi-seed robustness estimate or a strict across-method Pareto-fairness claim.

```powershell
# Input / import sanity check only
python -B release_tools/run_route60.py --output artifacts/my_route60_check
# Explicit formal rerun, one unit; use a new directory
python -B release_tools/run_route60.py --run --k 10 --output artifacts/new_route60_K10
```

The original formal supplementary runner uses Git CLI for provenance collection. No source commit existed in the supplied project; a commit hash is not fabricated. This packaging run checked saved evidence and portable input loading and did not rerun15 formal units.
