"""Read-only probe of a fixed historical deployment in a requested checkout."""
from pathlib import Path
import argparse
import csv
import json
import os
import sys

p = argparse.ArgumentParser()
p.add_argument("--source-root", required=True)
p.add_argument("--output", required=True)
a = p.parse_args()
root = Path(a.source_root).resolve()
out = Path(a.output).resolve()
out.mkdir(parents=True, exist_ok=True)
os.chdir(root)
sys.path.insert(0, str(root))
os.environ["MPLCONFIGDIR"] = str(out / "_mplcache")
os.environ["AIRHERO_ALLK_OUTPUT_ROOT"] = str(out)
import numpy as np
from scripts.tmc_rebuild import airhero_allk_stage2_refinement_common as common
from src.experiments.asu_route_service_v2_sinr import evaluate_with_existing_context_sinr_asu_v2
common.configure_modules(2026)
all_problem, current_problem, future_problem, meta = common.build_problems()
deployment = root / "artifacts/tmc_rebuild/airhero_allk_main_candidate_zmax50/01_main_system/seed_2026/decoded_deployment.csv"
with deployment.open(encoding="utf-8-sig", newline="") as f:
    rows = list(csv.DictReader(f))
decision = np.asarray([[float(r[k]) for k in ["x", "y", "z", "station_type_index", "sector_direction_index"]] for r in rows])
pack = evaluate_with_existing_context_sinr_asu_v2(decisions=decision[None], problem=all_problem, config=all_problem.config, method_name="release_fixed_probe")
post = common.zmax.continuity_metrics(decision, all_problem)
sinr = common.zmax.point_sinr_db(decision, all_problem)
np.save(out / "sinr.npy", sinr)
result = {"objectives": np.asarray(pack.objectives).tolist(), "metrics": post["metrics"], "continuity": post["continuity"], "input_meta": meta,
          "objective_dimensions": int(pack.objectives.shape[1]), "probe_scope": "fixed saved deployment reevaluation; no optimization"}
(out / "probe.json").write_text(json.dumps(result, indent=2, default=lambda v: v.item() if isinstance(v, np.generic) else v.tolist()), encoding="utf-8")
print(json.dumps({"ASU": post["metrics"]["ASU"], "objective_dimensions": result["objective_dimensions"], "points": len(sinr)}))
