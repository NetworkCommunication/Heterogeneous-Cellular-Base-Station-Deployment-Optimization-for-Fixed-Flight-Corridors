"""Verify every payload file listed in MANIFEST.csv against SHA-256."""
from pathlib import Path
import csv
import hashlib
import os


def main() -> None:
    """Check hashes and reject symlinks; generated future outputs are not checked."""
    root = Path(__file__).resolve().parents[1]
    fsroot = Path("\\\\?\\" + str(root)) if os.name == "nt" else root
    with (root / "MANIFEST.csv").open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    errors = []
    for row in rows:
        file = fsroot / row["release_path"]
        if file.is_symlink() or not file.is_file():
            errors.append(row["release_path"])
            continue
        if hashlib.sha256(file.read_bytes()).hexdigest() != row["release_sha256"]:
            errors.append(row["release_path"])
    if errors:
        raise SystemExit("Hash/missing/symlink failures: " + repr(errors))
    print(f"Verified {len(rows)} payload SHA-256 values; MANIFEST.csv itself is protected by the ZIP SHA-256 sidecar")


if __name__ == "__main__":
    main()
