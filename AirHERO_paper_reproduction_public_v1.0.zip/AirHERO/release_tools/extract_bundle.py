"""Safely extract a ZIP, with Windows long-path support and no traversal."""
from pathlib import Path, PurePosixPath
import argparse
import os
import shutil
import zipfile


def main() -> None:
    """Extract into a new directory; reject traversal, symlinks, and overwrite."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("zip")
    p.add_argument("destination")
    a = p.parse_args()
    destination = Path(a.destination).resolve()
    if destination.exists():
        p.error("Destination must be new")
    fsroot = Path("\\\\?\\" + str(destination)) if os.name == "nt" else destination
    with zipfile.ZipFile(a.zip) as z:
        if z.testzip() is not None:
            raise RuntimeError("ZIP CRC failed")
        for info in z.infolist():
            rel = PurePosixPath(info.filename)
            if rel.is_absolute() or ".." in rel.parts or "\\" in info.filename or ":" in info.filename or (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Unsafe ZIP entry")
            target = fsroot.joinpath(*rel.parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as source, target.open("xb") as out:
                    shutil.copyfileobj(source, out)
    print("Extracted:", destination)


if __name__ == "__main__":
    main()
