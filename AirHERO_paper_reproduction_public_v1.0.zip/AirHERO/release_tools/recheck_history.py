"""Read historical CSV only and recompute archived summary arithmetic. No optimization."""
from pathlib import Path
import csv, json, math, statistics
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts/release_history_recheck'
OUT.mkdir(parents=True, exist_ok=True)
BASE=ROOT/'artifacts/tmc_rebuild'
FINAL=BASE/'airhero_allk_final_paper_ready_zmax50'
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as h:return list(csv.DictReader(h))
checks=[]
def check(section,key,metric,vals,stored,source):
 vals=[float(v) for v in vals]; m=statistics.mean(vals); sd=statistics.stdev(vals) if len(vals)>1 else 0.
 for stat,value in [('mean',m),('std',sd)]:
  want=stored.get(metric+'_'+stat)
  if want in [None,'']:continue
  delta=value-float(want)
  checks.append(dict(section=section,group=key,metric=metric,statistic=stat,n=len(vals),recomputed=value,stored=float(want),delta=delta,match=abs(delta)<=1e-10,source=source))
# Main-system complete table: separate original baseline, CLPSO and all-K AirHERO per-seed records.
raw=[]
for p in [BASE/'formal_K10_true_sinr_height_constrained_zmax50/height_constrained_zmax50_all_runs.csv',BASE/'formal_K10_true_sinr_height_constrained_zmax50_clpso_baseline/clpso_zmax50_full80_all_runs.csv',FINAL/'01_main_system/per_seed_results.csv']:
 for row in read(p):row['_source']=p.relative_to(ROOT).as_posix();raw.append(row)
for s in read(FINAL/'01_main_system/paper_ready_main_system_table.csv'):
 vals=[r for r in raw if r.get('method',r.get('method_key'))==s['method']]
 for met,field in [('ASU','ASU'),('Coverage@0','Coverage Utility@0'),('Coverage@10','Coverage Utility@10'),('CCU@0','Continuous Coverage Utility@0'),('CCU@10','Continuous Coverage Utility@10'),('runtime_seconds','runtime')]:
  tabfield='runtime' if met=='runtime_seconds' else met
  mean,sd=s[tabfield].split(' +/- ')
  ds={met+'_mean':mean,met+'_std':sd}
  vs=[r.get(met,r.get(field)) for r in vals]
  # Table has four-decimal rounding, record exact mean against hidden means separately below.
  if vals:
   m=statistics.mean(float(x) for x in vs); st=statistics.stdev(float(x) for x in vs) if len(vs)>1 else 0.
   checks.append(dict(section='main_rounded_table',group=s['method'],metric=met,statistic='mean/std',n=len(vs),recomputed=f'{m:.4f} +/- {st:.4f}',stored=s[tabfield],delta='',match=f'{m:.4f} +/- {st:.4f}'==s[tabfield],source=vals[0]['_source']))
# Ablation and density use unrounded stored summaries.
for section,rawpath,sumpath,key in [('ablation',FINAL/'02_ablation/per_seed_results.csv',FINAL/'02_ablation/ablation_summary.csv','variant_name'),('dense',FINAL/'04_dense_existing_sensitivity/dense_per_seed_results.csv',FINAL/'04_dense_existing_sensitivity/dense_summary.csv','method_key')]:
 data=read(rawpath)
 for s in read(sumpath):
  k=s.get(key,data[0].get(key,'')); rows=[r for r in data if r.get(key)==k]
  for m in ['ASU','Q_current','Q_future','Coverage@0','Coverage@10','CCU@0','CCU@10','handover_count','C_dep','runtime_seconds']:
   if rows:check(section,k,m,[r[m] for r in rows],s,rawpath.relative_to(ROOT).as_posix())
# Fair optimizer summary from historical per-seed metrics and runtime records.
fair=FINAL/'06_fair_optimizer_robustness_same_space'
ps=read(fair/'robustness_per_seed_metrics.csv'); runtime=read(fair/'per_seed_selected_solution_metrics.csv')
for s in read(fair/'robustness_summary.csv'):
 rows=[r for r in ps if r['method']==s['method']]
 for m in ['HV','GD','IGD','AN','nondominated_count']:check('fair_optimizer',s['method'],m,[r[m] for r in rows],s,(fair/'robustness_per_seed_metrics.csv').relative_to(ROOT).as_posix())
 rt=[r['runtime_seconds'] for r in runtime if r['method']==s['method']]
 check('fair_optimizer',s['method'],'runtime_seconds',rt,s,(fair/'per_seed_selected_solution_metrics.csv').relative_to(ROOT).as_posix())
with (OUT/'historical_summary_crosschecks.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(checks[0]));w.writeheader();w.writerows(checks)
# Paper textual claims; do not rewrite source tables.
sys={r['method']:r for r in read(FINAL/'01_main_system/paper_ready_main_system_table.csv')}
full=float(sys['airhero_allk_stage2_refinement_v1']['_ASU_mean']); rand=float(sys['random_current_then_future']['_ASU_mean']);csa=float(sys['csa_extended']['_ASU_mean'])
claim=[{'claim':'ASU relative improvement vs Random percent','recomputed':(full/rand-1)*100,'paper':'about 134%'},{'claim':'ASU relative improvement vs CSA percent','recomputed':(full/csa-1)*100,'paper':'36.97%'}]
for r in read(FINAL/'02_ablation/ablation_summary.csv'):
 if r['variant_name']=='full_airhero':continue
 v=float(r['ASU_mean']);claim.append({'claim':'ASU reduction '+r['variant_name']+' percent','recomputed':(1-v/full)*100,'paper':'compare Sec.V.C'})
(OUT/'paper_claim_arithmetic.json').write_text(json.dumps(claim,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'checks':len(checks),'passed':sum(bool(r['match']) for r in checks),'failed':[r for r in checks if not r['match']],'claims':claim},ensure_ascii=False,indent=2))
