"""Recompute historical HV/GD/IGD from unchanged saved objective vectors."""
from pathlib import Path
import csv
import json
import os
import sys
from collections import defaultdict


def main() -> None:
    """Reuse the exact fair runner's metric functions without changing source results."""
    root = Path(__file__).resolve().parents[1]
    os.chdir(root)
    sys.path.insert(0, str(root))
    out = root / "artifacts/release_front_recheck"
    out.mkdir(parents=True, exist_ok=True)
    os.environ["MPLCONFIGDIR"] = str(out / "_mplcache")
    import numpy as np
    from scripts.tmc_rebuild import run_airhero_allk_fair_same_space_robustness as fair
    source = root / "artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/06_fair_optimizer_robustness_same_space"
    grouped = defaultdict(list)
    for row in fair.read_csv(source / "per_seed_objective_vectors.csv"):
        grouped[(row["method"], row["seed"])].append([float(row[k]) for k in fair.OBJECTIVE_COLUMNS])
    raw_nd = {}
    for (method, seed), rows in grouped.items():
        arr = fair.unique_rows(np.asarray(rows, dtype=float))
        arr = arr[np.isfinite(arr).all(axis=1)]
        raw_nd[method + "|" + seed] = arr[fair.nondominated_mask(arr)]
    union = np.vstack([x for x in raw_nd.values() if x.size])
    ideal, nadir = np.min(union, axis=0), np.max(union, axis=0)
    normalized_union = fair.normalize(union, ideal, nadir)
    reference = normalized_union[fair.nondominated_mask(normalized_union)]
    groups = {key: fair.normalize(arr, ideal, nadir) for key, arr in raw_nd.items()}
    hv = fair.shared_mc_hv(groups, fair.REFERENCE_POINT)
    stored = {r["method"] + "|" + r["seed"]: r for r in fair.read_csv(source / "robustness_per_seed_metrics.csv")}
    checks = []
    for key, arr in groups.items():
        computed = {"HV": hv[key], "GD": fair.rms_nearest(arr, reference), "IGD": fair.rms_nearest(reference, arr)}
        for metric, value in computed.items():
            old = float(stored[key][metric])
            checks.append({"group": key, "metric": metric, "recomputed": value, "stored": old, "absolute_delta": abs(value - old), "match_1e_12": abs(value - old) <= 1e-12})
    fair.write_csv(out / "historical_metric_recheck.csv", checks)
    fair.write_csv(out / "empirical_reference_front_normalized.csv", [{key: float(v) for key, v in zip(fair.OBJECTIVE_COLUMNS, row)} for row in reference])
    result = {"scope": "historical vector reevaluation; no optimization; unresolved internal objective fairness persists", "methods": len({r[0] for r in grouped}), "method_seed_groups": len(grouped), "checks": len(checks), "all_match_1e_12": all(r["match_1e_12"] for r in checks), "max_absolute_delta": max(r["absolute_delta"] for r in checks), "ideal": ideal.tolist(), "nadir": nadir.tolist(), "reference_points_with_original_duplicate_policy": len(reference), "HV_MC_samples": fair.MC_SAMPLES, "HV_reference": fair.REFERENCE_POINT.tolist(), "HV_MC_seed": 20260706}
    (out / "recheck_summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result))
    if not result["all_match_1e_12"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
