"""Run one preserved baseline/ablation/diagnostic unit into a fresh output folder."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys


def main() -> None:
    """Change launch/output paths only; retain the original unit's method settings."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("suite", choices=["baseline", "ablation", "search", "sensitivity", "dense"])
    p.add_argument("--method")
    p.add_argument("--seed", type=int, choices=[2026, 2027, 2028], default=2026)
    p.add_argument("--k", type=int, choices=[5, 10, 15], default=10)
    p.add_argument("--route-count", type=int, choices=[20, 40, 50, 80], default=80)
    p.add_argument("--output", required=True)
    a = p.parse_args()
    root = Path(__file__).resolve().parents[1]
    os.chdir(root)
    sys.path.insert(0, str(root))
    out = (root / a.output).resolve()
    out.relative_to(root)
    if out.exists():
        p.error("Choose a new output directory to preserve historical and previous rerun evidence")
    out.mkdir(parents=True)
    os.environ["MPLCONFIGDIR"] = str(out / "_mplcache")
    os.environ["AIRHERO_ALLK_OUTPUT_ROOT"] = str(out)
    from scripts.tmc_rebuild import airhero_allk_stage2_refinement_common as common
    common.configure_modules(a.seed)
    if a.suite == "baseline":
        zmax = common.zmax
        zmax.configure_modules()
        all_p, current, future, meta = common.build_problems()
        for problem in (all_p, current, future):
            problem.config.setdefault("immogwo", {}).update(population_size=50, max_iterations=150)
            problem.config.setdefault("scenario", {}).update(population_size=50, max_iterations=150)
        method = a.method or "random_current_then_future"
        if method == zmax.PROPOSED:
            p.error("Use run_release.py for adopted all-K AirHERO; old K2-only proposed is historical evidence")
        record = zmax.run_one(method, a.seed, zmax.build_method_registry(), all_p, current, future)
        zmax.write_csv(out / "per_seed_results.csv", [record["row"]])
        zmax.write_csv(out / "decoded_deployment.csv", zmax.decode_rows(record["decision"], method, a.seed, 0 if method == "existing_only" else 5))
        for key in ["context", "stage", "components", "coverage", "continuous", "interruption", "runtime", "height", "consistency", "response", "chromosome"]:
            zmax.write_csv(out / (key + ".csv"), [record[key]])
        (out / "resolved_problem_config.json").write_text(json.dumps(all_p.config, indent=2), encoding="utf-8")
        row = record["row"]
    elif a.suite == "search":
        from scripts.tmc_rebuild import run_airhero_allk_fair_same_space_robustness as unit
        unit.ROOT = out
        method = a.method or "airhero_search_same_initialization"
        if method not in unit.METHODS:
            p.error("Unknown search method; inspect the preserved runner METHODS")
        row = unit.run_single(method, a.seed)
    elif a.suite == "ablation":
        from scripts.tmc_rebuild import run_airhero_allk_final_ablation as unit
        unit.ROOT = out
        variant = a.method or "stagewise_concat"
        if variant == "stagewise_concat":
            row = unit.run_stagewise_seed(a.seed)
        elif variant in unit.NEW_VARIANTS:
            row = unit.run_allk_variant_seed(a.seed, variant)
        else:
            p.error("Unknown ablation variant; inspect NEW_VARIANTS in the preserved runner")
    else:
        from scripts.tmc_rebuild import run_airhero_allk_final_paper_ready_package as unit
        k1, k2 = next((x, y) for k, x, y in unit.K_SETTINGS if k == a.k)
        if a.suite == "sensitivity" and a.seed != 2026:
            p.error("Preserved route/budget experiment uses only seed 2026")
        _, nc, nf = next(x for x in unit.ROUTE_SETTINGS if x[1] + x[2] == a.route_count)
        if a.suite == "dense" and (a.k != 10 or a.route_count != 80):
            p.error("Preserved dense experiment uses K10 and 80 routes")
        ns = argparse.Namespace(output_root=str(out), route_path=str(unit.ROUTE_PATH), station_path=str(unit.DENSE_STATION if a.suite == "dense" else unit.LOW_STATION), current_count=nc if a.route_count < 80 else None, future_count=nf if a.route_count < 80 else None, k=a.k, k1=k1, k2=k2, seed=a.seed, scenario_name="release_" + a.suite, route_count=a.route_count, dense=a.suite == "dense")
        unit.run_single(ns)
        row = json.loads((out / "run_result.json").read_text(encoding="utf-8"))
    (out / "release_launch.json").write_text(json.dumps({"arguments": vars(a), "scope": "new run of preserved candidate implementation; unresolved paper conflicts apply", "result": row}, indent=2, default=str), encoding="utf-8")
    print(json.dumps(row, default=str))


if __name__ == "__main__":
    main()
