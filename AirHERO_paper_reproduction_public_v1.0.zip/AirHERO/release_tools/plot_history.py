"""Plot preserved historical data without rerunning any optimization."""
from pathlib import Path
import csv
import json
import os
import sys


def read(path: Path) -> list[dict[str, str]]:
    """Load a preserved UTF-8 CSV."""
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def main() -> None:
    """Create a main ASU bar chart and the stored four-dimensional front projection."""
    root = Path(__file__).resolve().parents[1]
    os.chdir(root)
    output = root / "artifacts/release_plots"
    output.mkdir(parents=True, exist_ok=True)
    os.environ["MPLCONFIGDIR"] = str(output / "_mplcache")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    base = root / "artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50"
    table = base / "01_main_system/paper_ready_main_system_table.csv"
    rows = [r for r in read(table) if r["method"] != "existing_only"]
    fig, ax = plt.subplots(figsize=(11, 4), constrained_layout=True)
    ax.bar([r["paper_name"] for r in rows], [float(r["_ASU_mean"]) for r in rows])
    ax.tick_params(axis="x", labelrotation=30)
    ax.set(ylabel="Historical mean ASU", title="Historical system comparison (pending validation)")
    fig.savefig(output / "historical_main_asu.png", dpi=160)
    plt.close(fig)
    vectors = base / "06_fair_optimizer_robustness_same_space/per_seed_nondominated_vectors.csv"
    nd = [r for r in read(vectors) if int(r["seed"]) == 2026]
    fig = plt.figure(figsize=(9, 6), constrained_layout=True)
    ax = fig.add_subplot(111, projection="3d")
    for method in sorted({r["method"] for r in nd}):
        group = [r for r in nd if r["method"] == method]
        ax.scatter([float(r["handover_count"]) for r in group], [-float(r["minus_Q_E"]) for r in group], [-float(r["minus_Q_P"]) for r in group], label=method, s=15)
    ax.set(xlabel="H", ylabel="Q current", zlabel="Q future", title="Historical 4D nondominated solutions: 3D projection, seed 2026")
    ax.legend(fontsize=5, loc="upper left")
    fig.savefig(output / "historical_pareto_projection.png", dpi=160)
    plt.close(fig)
    (output / "plot_sources.json").write_text(json.dumps({"inputs": [str(table.relative_to(root)), str(vectors.relative_to(root))], "scope": "new plots from unchanged historical CSV; not exact paper figure regeneration; cost omitted in projection; internal objective fairness unresolved"}, indent=2), encoding="utf-8")
    print("Historical plots saved in artifacts/release_plots")


if __name__ == "__main__":
    main()
