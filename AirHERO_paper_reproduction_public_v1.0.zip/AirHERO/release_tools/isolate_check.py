"""Deny original-project reads while running an extracted public launcher."""
from pathlib import Path
import argparse
import os
import runpy
import sys

p = argparse.ArgumentParser()
p.add_argument("--root", required=True)
p.add_argument("--forbid-root", required=True)
p.add_argument("--mode", choices=["smoke", "route60"], default="smoke")
a = p.parse_args()
allowed, forbidden = Path(a.root).resolve(), Path(a.forbid_root).resolve()


def within(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def guard(event: str, args: tuple) -> None:
    if event == "open" and args and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.fsdecode(args[0])).resolve()
        if within(path, forbidden) and not within(path, allowed):
            raise PermissionError("Read outside the extracted public package was denied")


os.chdir(allowed)
sys.path[:] = [str(allowed)] + [x for x in sys.path if x and not within(Path(x).resolve(), forbidden)]
sys.addaudithook(guard)
if a.mode == "smoke":
    sys.argv = [str(allowed / "release_tools/run_release.py"), "--config", "configs/release/smoke.json", "--output", "artifacts/isolated_public_smoke"]
else:
    sys.argv = [str(allowed / "release_tools/run_route60.py"), "--output", "artifacts/isolated_public_route60"]
runpy.run_path(sys.argv[0], run_name="__main__")
print("Original project and private audit file reads denied: PASS")
