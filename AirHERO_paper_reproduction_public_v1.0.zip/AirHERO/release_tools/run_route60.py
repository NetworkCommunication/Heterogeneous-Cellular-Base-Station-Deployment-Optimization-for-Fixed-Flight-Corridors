"""Load/check the preserved route60 supplement or explicitly run one new unit."""
from pathlib import Path
import argparse
import json
import os
import sys


def main() -> None:
    """Redirect outputs only; retain the supplement's original method and RNG flow."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run", action="store_true", help="Explicitly run one formal-scale unit; otherwise input check only")
    p.add_argument("--method", default="true_joint_closed_loop_elite_immigration_response_v3_asu_v2")
    p.add_argument("--k", type=int, choices=[5, 10, 15], default=10)
    p.add_argument("--output", required=True)
    a = p.parse_args()
    root = Path(__file__).resolve().parents[1]
    os.chdir(root)
    sys.path.insert(0, str(root))
    out = (root / a.output).resolve()
    out.relative_to(root / "artifacts")
    if out.exists():
        p.error("Output must be a new directory to preserve archived results")
    out.mkdir(parents=True)
    os.environ["MPLCONFIGDIR"] = str(out / "_mplcache")
    from scripts.tmc_rebuild import run_route60_historical_multioptimizer_extension as supplement
    if a.method not in supplement.METHOD_META:
        p.error("Unknown method; inspect the supplement METHODS")
    supplement.ROOT = out
    supplement.RUNS_ROOT = out / "runs"
    supplement.LOG_ROOT = out / "logs"
    supplement.PLOT_ROOT = out / "plot_data_with_route60"
    if a.run:
        raise SystemExit(supplement.run_unit(a.method, a.k, 2026))
    historical = supplement.historical
    k1, k2 = supplement.K_META[a.k]
    historical.configure(a.k, k1, k2)
    stations = historical.formal.read_csv(historical.formal.STATION_PATH)
    all_routes = historical.formal.read_csv(historical.formal.ROUTE_POINT_PATH)
    subset = historical.select_route_subset(all_routes, 25, 35)
    all_p, current, future, _ = historical.build_problems(stations, subset)
    result = {"check_only": True, "optimization_executed": False, "method": a.method, "K": a.k, "K1": k1, "K2": k2, "route_count": len({x["route_id"] for x in subset}), "points": len(all_p.test_points), "current_points": len(current.test_points), "future_points": len(future.test_points), "station_count": len(stations), "seed": 2026, "population": supplement.POPULATION, "iterations_per_stage": supplement.ITERATIONS}
    assert (result["route_count"], result["points"], result["current_points"], result["future_points"]) == (60, 1800, 750, 1050)
    (out / "check_result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
