"""Portable launcher around the copied, unchanged all-K runner."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys


def main() -> None:
    """Read an explicit entry config, then run the original two-stage chain."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/release/smoke.json")
    parser.add_argument("--output", default="artifacts/release_runs/smoke")
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    os.chdir(root)
    sys.path.insert(0, str(root))
    cfg = json.loads(Path(args.config).read_text(encoding="utf-8"))
    output = (root / args.output).resolve()
    output.relative_to(root)
    output.mkdir(parents=True, exist_ok=True)
    os.environ["MPLCONFIGDIR"] = str(output / "_mplcache")
    # Override only the output location; no inherited AirHERO environment needed.
    os.environ["AIRHERO_ALLK_OUTPUT_ROOT"] = str(output)
    from scripts.tmc_rebuild import airhero_allk_stage2_refinement_common as common
    common.ROOT = output
    common.K, common.K1, common.K2 = cfg["K"], cfg["K1"], cfg["K2"]
    common.POPULATION = cfg["population"]
    common.ITERATIONS = cfg["iterations_per_stage"]
    common.SEEDS = cfg["seeds"]
    common.formal.STATION_PATH = Path(cfg["station_path"])
    common.formal.ROUTE_POINT_PATH = Path(cfg["route_path"])
    (output / "release_entry_config.json").write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    if args.check_only:
        common.configure_modules(cfg["seeds"][0])
        all_p, current_p, future_p, meta = common.build_problems()
        snapshot = {
            "entry": cfg,
            "scope": "builder configuration before adapter-specific defaults; historical snapshots retained separately",
            "all_problem": all_p.config,
            "current_problem": current_p.config,
            "future_problem": future_p.config,
            "input_meta": meta,
        }
        (output / "resolved_builder_configs.json").write_text(json.dumps(snapshot, indent=2, default=lambda v: v.tolist()), encoding="utf-8")
        print(json.dumps(meta, ensure_ascii=True))
        return
    rows = [common.run_seed(int(seed)) for seed in cfg["seeds"]]
    (output / "release_run_results.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print(json.dumps({"validation_only": cfg["validation_only"], "runs": len(rows), "success": all(r["success"] for r in rows), "ASU": [r["ASU"] for r in rows]}))


if __name__ == "__main__":
    main()
