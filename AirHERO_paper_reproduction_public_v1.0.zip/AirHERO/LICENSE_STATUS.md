# License status

No project-wide LICENSE/COPYING file was present in the supplied project, and the publisher instructed that packaging must not invent a new open-source license. Accordingly no MIT/Apache/GPL or other blanket software license is assigned by this release.

This is a publicly distributable reproduction archive prepared at the publisher's request. The publisher confirmed permission to distribute the fixed POI and derived-route data. Existing source notices and upstream data/dependency terms remain applicable; see THIRD_PARTY_NOTICES.md. Public availability of the archive should not be represented as an established project-wide open-source license.

The associated manuscript and raw external GIS dataset are excluded. Obtain any required permission for reuse beyond the rights documented by the respective author, publisher or upstream source.
