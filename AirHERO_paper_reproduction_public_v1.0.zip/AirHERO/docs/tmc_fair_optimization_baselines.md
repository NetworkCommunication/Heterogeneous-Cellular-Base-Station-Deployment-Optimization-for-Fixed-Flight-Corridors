# Chapter 5.5.2 Fair Optimization Baselines

This document records the fair optimization methods used for the Chapter 5.5.2
optimization robustness experiments under route-scale changes. These methods
are compared only when they solve the same TMC deployment decision space and use
the same objective vectors, constraints, route data, candidate region, seed
list, and comparable evaluation budgets.

HV, GD, and IGD are computed from objective vectors only. ASU is exported as an
auxiliary reporting metric and is not used as an optimizer objective or as an
input to HV/GD/IGD.

## Summary Table

| Method key | Paper-facing name | Source paper | Original algorithm type | Native multiobjective in source? | TMC adaptation | System-level baseline comparison | Fair optimization robustness comparison |
|---|---|---|---|---|---|---|---|
| `proposed_method` | Proposed | This thesis / repository proposed TEVC-style method, not an external baseline paper | Two-stage seeded heterogeneous deployment with improved MOPSO | Yes, implemented as a multiobjective optimizer with a nondominated archive | Frozen proposed pipeline: Stage-1 blind-spot deployment, Stage-2 seeded initialization, stagnation-aware MOPSO, heterogeneous 5G/5GA decisions | No; not a system-level baseline | Yes |
| `nsga2_extended` | NSGA-II-Ext | Deb et al., 2002, "A Fast and Elitist Multiobjective Genetic Algorithm: NSGA-II" | Elitist genetic multiobjective optimizer | Yes | Real-coded NSGA-II with mixed-variable repair and Stage-2 seeded initialization | No | Yes |
| `moead_extended` | MOEA/D-Ext | Zhang and Li, 2007, MOEA/D | Decomposition-based evolutionary multiobjective optimizer | Yes | Tchebycheff decomposition over the shared TMC objective vectors, with mixed-variable repair and external archive | No | Yes |
| `clpso_ls_decomposition_extended` | CLPSO-LS-Ext | Cao et al., 2019, CLPSO-LS | Single-objective multimodal comprehensive-learning PSO with local search | No | Decomposition/scalarization adaptation for the TMC multiobjective problem; not an exact native multiobjective reproduction | No | Yes |
| `ppso_extended` | PPSO-Ext | "Leader Prediction for Multiobjective Particle Swarm Optimization" | Leader-prediction multiobjective PSO using SOM structure learning | Yes | PPSO leader prediction over the shared mixed TMC decision vector, with lightweight local SOM and mixed-variable repair | No | Yes |

## Shared Fairness Contract

All Chapter 5.5.2 fair optimization methods use the same per-station decision
vector:

```text
[x, y, z, station_type_index, sector_direction_index]
```

The discrete mappings are:

```text
station_type_index: 0 = 5G, 1 = 5GA
sector_direction_index: 0..7 -> [0, 45, 90, 135, 180, 225, 270, 315] degrees
```

The objective evaluator is the shared deployment objective path used by the
same-decision-space baselines:

```text
evaluate_population_objectives(...)
build_deployment_minimization_objectives(...)
```

The objective vector convention is minimization:

```text
[handover_count,
 deployment_cost,
 existing_route_continuity_loss,
 future_route_continuity_loss]
```

The compared methods use the same constraints and feasibility handling from the
configured deployment problem, including heterogeneous deployment budget,
minimum coverage constraints, map/candidate-region bounds, non-building repair
where enabled, and 5GA directional sector service rules. Objective, constraint,
and penalty values remain config-driven.

## Output Schema

Each method run exports per-run final solution files:

```text
final_objective_vectors.csv
final_nondominated_solutions.csv
final_decoded_deployments.csv
all_final_objective_vectors.csv
run_config.json
run_log.json
```

The Chapter 5.5.2 optimization robustness runner also exports:

```text
per_seed_optimization_metrics.csv
mean_std_optimization_metrics.csv
reference_front_log.csv
reference_front_metadata.json
fair_method_metadata.json
optimization_robustness_report.md
decision_space_audit.csv
skipped_or_excluded_methods.csv
HV_vs_route_scale.png
GD_vs_route_scale.png
IGD_vs_route_scale.png
runtime_vs_route_scale.png
nondominated_count_vs_route_scale.png
```

Unified schema exports are written under `unified_schema/`:

```text
per_seed_results.csv
nondominated_solutions.csv
decoded_deployments.csv
asu_summary.csv
asu_components.csv
optimization_metrics.csv
runtime_summary.csv
config_snapshot.json
```

## Method Details

### `proposed_method` / Proposed

- Source paper: this thesis / repository proposed TEVC-style method. It is not
  an external baseline paper.
- Original algorithm type: two-stage heterogeneous deployment with improved
  MOPSO.
- Native multiobjective: yes in this repository implementation; the method
  maintains and exports a nondominated archive.
- TMC adaptation: this is the frozen main method. Stage 1 fills blind spots
  using existing stations and Stage 1 5GA sector-direction selection. Stage 2
  initializes particles from Stage-1 deployment results plus random particles,
  then refines with stagnation-aware MOPSO.
- Decision vector: `[x, y, z, station_type_index, sector_direction_index]`.
- Objective evaluator: shared route deployment objective evaluation; final
  exported objectives use the same minimization convention as the baselines.
- Constraints: uses the configured heterogeneous constraints, sector geometry,
  candidate region, map bounds, and feasibility penalties.
- ASU for optimization: no. ASU is auxiliary reporting only.
- HV/GD/IGD source: objective vectors only.
- Known deviations: not applicable as an external-paper reproduction; it is
  the frozen proposed method and should not be modified for baseline fairness.
- Included in system-level baseline comparison: no, it is not a system-level
  baseline method.
- Included in fair optimization robustness comparison: yes.

### `nsga2_extended` / NSGA-II-Ext

- Source paper: Deb et al., 2002, "A Fast and Elitist Multiobjective Genetic
  Algorithm: NSGA-II".
- Original algorithm type: elitist nondominated-sorting genetic algorithm.
- Native multiobjective: yes.
- TMC adaptation: SBX crossover and polynomial mutation operate on bounded
  real-valued genes; repair handles the mixed continuous-discrete deployment
  vector; the initial population uses Stage-2 seeded particles for fair
  comparison.
- Decision vector: `[x, y, z, station_type_index, sector_direction_index]`.
- Objective evaluator: `evaluate_extended_chromosomes(...)`, which calls the
  shared deployment evaluator and builds the common minimization objectives.
- Constraints: shared heterogeneous constraints and repair; type and sector
  indices are rounded/clipped before evaluation.
- ASU for optimization: no.
- HV/GD/IGD source: objective vectors only.
- Known deviations: the original NSGA-II paper does not model 5G/5GA station
  types, directional sectors, or Stage-2 seeded TMC initialization.
- Included in system-level baseline comparison: no.
- Included in fair optimization robustness comparison: yes.

### `moead_extended` / MOEA/D-Ext

- Source paper: Zhang and Li, 2007, MOEA/D.
- Original algorithm type: decomposition-based evolutionary multiobjective
  optimizer.
- Native multiobjective: yes.
- TMC adaptation: uses Tchebycheff decomposition over the shared TMC objective
  vectors, weight-vector neighborhoods, objective normalization, mixed-variable
  SBX/polynomial mutation, repair, Stage-2 seeded initialization, and an
  external nondominated archive for export.
- Decision vector: `[x, y, z, station_type_index, sector_direction_index]`.
- Objective evaluator: `evaluate_extended_chromosomes(...)` and the shared
  deployment objective interface.
- Constraints: same heterogeneous deployment constraints, candidate region,
  sector-direction rules, and mixed-variable repair as the other fair methods.
- ASU for optimization: no.
- HV/GD/IGD source: objective vectors only.
- Known deviations: the original MOEA/D is adapted to a mixed
  continuous-discrete 5G/5GA deployment encoding and repository-specific
  seeded initialization.
- Included in system-level baseline comparison: no.
- Included in fair optimization robustness comparison: yes.

### `clpso_ls_decomposition_extended` / CLPSO-LS-Ext

- Source paper: Cao et al., 2019, CLPSO-LS.
- Original algorithm type: single-objective multimodal comprehensive-learning
  PSO with local search.
- Native multiobjective: no. The original paper is single-objective multimodal
  optimization.
- TMC adaptation: this implementation wraps CLPSO-LS in a decomposition /
  scalarization layer so each particle is associated with a scalar subproblem,
  while final archives and all fair metrics still use the shared
  multiobjective vectors.
- Decision vector: `[x, y, z, station_type_index, sector_direction_index]`.
- Objective evaluator: `evaluate_extended_chromosomes(...)` and the shared
  deployment objective interface; scalarization is used only for CLPSO-style
  update decisions.
- Constraints: same heterogeneous deployment constraints, sector geometry,
  candidate region, and mixed-variable repair.
- ASU for optimization: no.
- HV/GD/IGD source: objective vectors only.
- Known deviations: this is not an exact native multiobjective reproduction.
  BFGS/Nelder-Mead style local search from continuous settings is approximated
  by mixed-variable pattern search because station type and sector-direction
  genes are rounded discrete variables.
- Included in system-level baseline comparison: no.
- Included in fair optimization robustness comparison: yes.

### `ppso_extended` / PPSO-Ext

- Source paper: "Leader Prediction for Multiobjective Particle Swarm
  Optimization".
- Original algorithm type: leader-prediction MOPSO using SOM to approximate
  the swarm manifold and predict leaders.
- Native multiobjective: yes.
- TMC adaptation: trains a lightweight deterministic SOM on normalized
  flattened deployment vectors each iteration. The best-matching neuron
  predicts `pbest`; a random neighborhood neuron predicts `gbest`; velocity
  update, repair, polynomial mutation, and archive maintenance are applied in
  the full shared decision space.
- Decision vector: `[x, y, z, station_type_index, sector_direction_index]`.
- Objective evaluator: `evaluate_extended_chromosomes(...)` and the shared
  deployment objective interface.
- Constraints: same heterogeneous deployment constraints, map/candidate bounds,
  5GA sector-direction rules, and mixed-variable repair.
- ASU for optimization: no.
- HV/GD/IGD source: objective vectors only.
- Known deviations: a compact local SOM is used instead of an external SOM
  package; the PPSO paper is adapted to the repository's mixed
  continuous-discrete 5G/5GA deployment encoding and Stage-2 seeded
  initialization.
- Included in system-level baseline comparison: no.
- Included in fair optimization robustness comparison: yes.

## System-Level Baseline Exclusion

The following methods are system-level, position-only, fixed-sector, or
heuristic-sector baselines and must not enter Chapter 5.5.2 fair optimization
HV/GD/IGD tables:

```text
existing_only
random_deployment
kmeans_deployment
greedy_blind_spot_filling
5g_only
5ga_fixed_sector
nsga2_position_only_fixed_sector
```

They may be exported for separate system-level analysis, but they are not
fair optimization baselines because they do not solve the same full decision
space as the proposed method.
