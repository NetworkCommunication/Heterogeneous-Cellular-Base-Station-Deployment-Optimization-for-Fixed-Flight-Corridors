# Paper–code–result map

All paths are relative to this package. This map records actual implementation and saved evidence. It does not assert that all historical runs have been repeated or that exact historical source fingerprints exist.

Prefixes: `F=artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50`, `M=artifacts/tmc_rebuild/airhero_allk_main_candidate_zmax50/01_main_system`, `B=artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50`, `S=artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_sensitivity`.

| Experiment | Entry and dependencies | Fixed data / settings | Per-seed evidence → statistics / figures |
|---|---|---|---|
| Main AirHERO | `release_tools/run_release.py` → `scripts/tmc_rebuild/airhero_allk_stage2_refinement_common.py::run_seed` → `scripts/run_true_joint_response_v3_closed_loop_diagnostic_K15.py` → SINR evaluator | 144 existing stations, 80 corridors/2400 points; K/K1/K2=10/5/5; 50 particles, 150 iterations **per stage**; seeds2026/2027/2028, Stage-II seed+1009 | `M/seed_<seed>` decisions/objectives/runtime/response logs → `F/01_main_system` → `F/07_figure_data` |
| System baselines | `release_tools/run_historical.py baseline` → zmax runner → independent registry adapters / strict-current-future wrapper | Same fixed scenario and external seeds; method-specific deployment/search rules | `B/height_constrained_zmax50_all_runs.csv`, decoded/stage/context/consistency files; separate `formal_K10_true_sinr_height_constrained_zmax50_clpso_baseline` → main system table |
| Ablations | `run_historical.py ablation` → `scripts/tmc_rebuild/run_airhero_allk_final_ablation.py` | Full, stagewise concat, no Stage-I guidance, no response, fixed sector, 5G-only; three seeds | `F/02_ablation` per-seed/decoded/summary/delta/figures; full reuses the saved main run |
| Main route/K sensitivity | `run_historical.py sensitivity` → `run_airhero_allk_final_paper_ready_package.py::run_single` | Actual20/40/50/80, K5/10/15; K1/K2=2/3,5/5,7/8; seed2026 | `F/03_route_budget_sensitivity` → `F/07_figure_data/03_route_budget_heatmaps` |
| Verified60 supplement | `release_tools/run_route60.py` → `scripts/tmc_rebuild/run_route60_historical_multioptimizer_extension.py` → `scripts/run_formal_true_sinr_height_constrained_zmax50_sensitivity.py::run_method` → `run_closed_loop_true_joint_variant` | Actual25current/35predicted; 1800 points; K1/K2=3/2,5/5,8/7; seed2026; 50×150/stage | `S/route60_extension`:15 successful units, selected-route manifest, results/config/deployments; `plot_data_with_route60` retains historical20/40/60/80 heatmaps and complete20/40/50/60/80 data |
| Dense infrastructure | `run_historical.py dense` → same main integration runner | Fixed768 proxy stations, 80 corridors, three seeds | `F/04_dense_existing_sensitivity`; baseline source `formal_true_sinr_height_constrained_zmax50_existing_density_sensitivity_3gpp_uma_like` |
| AirHERO-search / optimizer diagnostic | `run_historical.py search` → `scripts/tmc_rebuild/run_airhero_allk_fair_same_space_robustness.py` | Shared all-K initial population per seed; internal search objective conventions retained | `F/06_fair_optimizer_robustness_same_space`:21 method/seed groups, full vectors/ND sets/metrics/runtime; `F/07_figure_data/04*` and`05*` |

## SSSE, CRAI, CER, JR

| Paper term | Actual implementation | Behavior |
|---|---|---|
| SSSE | `src/experiments/asu_route_service_v2_sinr.py` → `evaluation_consistency.py` → `src/propagation/a2g_probabilistic.py` and `sector_geometry.py` | Existing+new stations serve/interfere; strongest received-power server; SINR, route utility, coverage, handover, cost and ASU |
| CRAI / Stage I | all-K common `run_seed`, current-only problem with K1 stations | Current-route seed optimization; selected Stage-I deployment used as a seed, not a frozen final batch |
| K1→K / JR | common `_make_stage2_initializer`, `closed_loop_stage_run(all_problem,seed+1009,...)` | Main population50 splits12/12/12/14 into exact Stage-I+future anchors, perturbed Stage-I+anchors, exact Stage-I+larger anchor perturbation, original initializer; allK positions/types/directions remain mutable |
| CER | closed-loop `closed_loop_response`, response-v2 stagnation factors and response-v3 candidate generation | Trigger severity/cooldown/budget; protect top ASU elites; generate low-service/elite-guided candidates; evaluate, accept population improvements, update pbest/archive/global-best, retain candidate provenance |
| Final selection | closed-loop final selection, `formal.best_decision` | ASU-best over recorded archive/pbest/response/global-best candidate pool; not restricted to archive alone |

Particle encoding is `[x,y,z,type_index,sector_index]` per station. Types0/1 map to5G/5GA; sector0…7 maps to0°,45°,…315°. 5GA has one active directional sector, main beamwidth120°, with no service outside the beam; 5G remains omni under the supplied settings. Cost is1/1.35 per new5G/5GA station.

Actual main internal objectives are `[-ASU,H,Cdep,1-current_coverage,1-future_coverage]`. The saved diagnostic four-vector is `[Cdep,H,-Qcurrent,-Qfuture]`. The publisher accepted retaining this implementation; this package does not claim that dropping the composite objective is mathematically Pareto-equivalent. See IMPLEMENTATION_NOTES for objective/fairness/constraint interpretation.

Stage I uses current-only samples and an SNR-based initial blind-point helper; its metadata/route grouping convention is preserved. The main evaluator uses empty building geometry and the probabilistic low-fidelity model. A2G elevation/distance uses station height over a ground-projected receiver, so route altitude does not enter that calculation. Feasibility fields from a zero-penalty evaluator should not be interpreted as independently checked engineering constraints.

## Metric definitions and historical postprocessing

`Qcurrent/Qfuture=mean(I[SINR>=threshold]*log2(1+linear SINR))` over each point set. `ASU=(.5Qcurrent+.5Qfuture)/(Cdep+.01H+1)`. Handover counts adjacent strongest-serving-station changes within route order, with no dwell/hysteresis rule. Coverage is a point fraction. CCU uses the fraction of adjacent sample pairs both covered within each route, then the unweighted route mean:30 points give29 pairs. Interruption counts coverage-state transitions.

The exact Table-III-related historical metric code is the fair runner's aggregate protocol: keep all7methods×3seeds; round10 for deduplication; finite rows; per-group nondomination; global min/max scaling with span floor1e-12; merged nondominated empirical reference front. There is no known true Pareto front. HV uses shared Monte Carlo120000, seed20260706, reference[1.1]⁴. GD/IGD are RMS nearest Euclidean distances in opposite directions. Three-seed summaries use sample std(ddof1); route/K sensitivity is single-seed. Equal iterations do not establish equal evaluation counts because candidate responses add evaluations.

`release_tools/recheck_history.py` checks saved summary arithmetic; `recheck_fronts.py` reconstructs the empirical front and checks HV/GD/IGD from unchanged vectors. These are historical-data checks. `plot_history.py` creates new plots from those stored CSVs. Original figure inputs retain source/selection descriptions; some Stage-I spatial states were reconstructed by later deterministic replay, not persisted in the original main run. Rerunning the original figure extractor may replay Stage I.

Fixed inputs, their provenance and the missing external GIS scope are described in DATA.md. Existing source/reference comments and baseline READMEs are retained. No algorithm or historical result was changed to reconcile a manuscript value.
