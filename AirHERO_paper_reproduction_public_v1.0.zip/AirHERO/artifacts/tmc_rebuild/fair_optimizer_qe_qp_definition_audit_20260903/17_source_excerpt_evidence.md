# Source Excerpt Evidence

## SINR_linear

- Source: `src/experiments/asu_route_service_v2_sinr.py`
- Function: `_evaluate_one_sinr`
- Lines: `135-146`
- Formula: `S/(noise + rho * non-serving received power); SINR_dB=10log10(SINR_linear)`

```text
135: rx_dbm = np.asarray(rx_dbm[0], dtype=float) 136: rx_mw = np.power(10.0, rx_dbm / 10.0) 137: serving_idx = np.argmax(rx_dbm, axis=0) 138: point_idx = np.arange(rx_dbm.shape[1]) 139: serving_mw = rx_mw[serving_idx, point_idx] 140: total_mw = np.sum(rx_mw, axis=0) 141: non_serving_mw = np.maximum(total_mw - serving_mw, 0.0) 142: noise_mw = 10.0 ** (float(problem.channel_params.get("noisePower", config.get("channel", {}).get("noisePower", -90.0))) / 10.0) 143: rho = float(cfg["rho"]) 144: sinr_linear = serving_mw / np.maximum(noise_mw + rho * non_serving_mw, 1e-30) 145: sinr_db = 10.0 * np.log10(np.maximum(sinr_linear, 1e-30)) 146: covered = sinr_db >= float(cfg["threshold_main_db"])
```

## Q_current / Q_E and Q_future / Q_P

- Source: `src/experiments/asu_route_service_v2_sinr.py`
- Function: `_q_component`
- Lines: `298-303`
- Formula: `mean(I[SINR_dB >= threshold_main_db] * log2(1 + SINR_linear))`

```text
298: def _q_component(signal_linear: np.ndarray, covered: np.ndarray, indices: np.ndarray) -> tuple[float, float]: 299: if indices.size == 0: 300: return 0.0, 0.0 301: vals = np.asarray(signal_linear[indices], dtype=float) 302: logs = np.log2(1.0 + np.maximum(vals, 0.0)) 303: return float(np.mean(covered[indices].astype(float) * logs)), float(np.mean(logs))
```

## current/predicted subset selection

- Source: `src/experiments/asu_route_service_v2_sinr.py`
- Function: `_route_groups`
- Lines: `279-289`
- Formula: `explicit current/future point-index arrays when splitMode=explicit_indices`

```text
279: def _route_groups(test_points: np.ndarray, config: Config) -> Dict[str, np.ndarray]: 280: n = int(test_points.shape[0]) 281: route_cfg = config.get("routeObjectives", {}) 282: if str(route_cfg.get("splitMode", "")).strip().lower() == "explicit_indices": 283: current = _sanitize_indices(np.asarray(route_cfg.get("existingIndices", []), dtype=int), n) 284: future = _sanitize_indices(np.asarray(route_cfg.get("futureIndices", []), dtype=int), n) 285: if current.size or future.size: 286: return {"current": current, "future": future} 287: ratio = float(np.clip(route_cfg.get("existingRatio", 0.5), 0.0, 1.0)) 288: cut = int(np.clip(np.floor(ratio * n), 0, n)) 289: return {"current": np.arange(0, cut, dtype=int), "future": np.arange(cut, n, dtype=int)}
```

## minus_Q_E / minus_Q_P

- Source: `scripts/tmc_rebuild/run_airhero_allk_fair_same_space_robustness.py`
- Function: `desired_objectives_from_metrics`
- Lines: `154-163`
- Formula: `minus_Q_E=-Q_current; minus_Q_P=-Q_future`

```text
154: def desired_objectives_from_metrics(metrics: Sequence[Mapping[str, Any]]) -> np.ndarray: 155: rows = [] 156: for row in metrics: 157: rows.append([ 158: _as_float(row.get("C_dep", row.get("deployment_cost"))), 159: _as_float(row.get("handover_count")), 160: -_as_float(row.get("Q_current")), 161: -_as_float(row.get("Q_future")), 162: ]) 163: return np.asarray(rows, dtype=float)
```

## saved objective and decision rows

- Source: `scripts/tmc_rebuild/run_airhero_allk_fair_same_space_robustness.py`
- Function: `objective_rows`
- Lines: `350-374`
- Formula: `reevaluate each final population/archive decision and serialize 50-value X`

```text
350: def objective_rows(method: str, seed: int, decisions: np.ndarray, problem: Any, cfg: Mapping[str, Any], source: str) -> List[Dict[str, Any]]: 351: arr = np.asarray(decisions, dtype=float).reshape(-1, K, 5) 352: pack = evaluate_desired(arr, problem, cfg, method) 353: rows = [] 354: for idx, (obj, metric, dec) in enumerate(zip(np.asarray(pack.objectives, dtype=float), pack.metrics, arr)): 355: rows.append({ 356: "method": method, 357: "seed": seed, 358: "candidate_index": idx, 359: "candidate_source": source, 360: "scenario_name": "route80_current33_predicted47_K10_zmax50_same_space", 361: "route_count": 80, 362: "current_route_count": 33, 363: "predicted_route_count": 47, 364: "K": K, 365: "C_dep": float(obj[0]), 366: "handover_count": float(obj[1]), 367: "minus_Q_E": float(obj[2]), 368: "minus_Q_P": float(obj[3]), 369: "Q_E": _as_float(metric.get("Q_current")), 370: "Q_P": _as_float(metric.get("Q_future")), 371: "ASU_auxiliary": _as_float(metric.get("ASU")), 372: "ASU_used_for_HV_GD_IGD": False, 373: "decision_vector_json": json.dumps(dec.reshape(-1).tolist()), 374: })
```

## manuscript Q_E / Q_P

- Source: `no repository implementation located`
- Function: `not available`
- Lines: `not available`
- Formula: `required: mean(min(log2(1+SINR_linear)/log2(1+gamma_tar_linear), 1))`

```text
not available
```
