# Route60 selection audit

1. The historical sensitivity uses a deterministic sorted `route_id` prefix within each semantic route-priority class.
2. The route20/40/50/60/80 subsets are nested because every setting uses a longer prefix of the same sorted class-specific ID lists.
3. Route60 uses the first 25 current routes and first 35 predicted routes; no random sampling was introduced.
4. The route60 set is compatible with route20/40/50/80 under the same nested-prefix policy.
5. New random route sampling introduced: no.
6. Every method and K uses the same route IDs and hash `7afd30fa3d1fd3dbde3304d9ebe7ae025eaaf8e10aeadc4811d2258193a6da15`.

Counts: current=25, predicted=35, total=60. Routes are generated/proxy semantic POI routes, not real measured airways.
