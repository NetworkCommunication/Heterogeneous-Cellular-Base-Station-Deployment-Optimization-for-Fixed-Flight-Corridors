# Route60 historical multi-optimizer extension

1. Previous experiment: `artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_sensitivity`.
2. Methods: `AirHERO-v3 historical, CSA, NSGA-II, MOEA/D, Greedy`.
3. Seed policy: single seed `[2026]`.
4. Reused budget: population 50 and 150 iterations per stage for optimizers; Greedy is non-iterative.
5. Route60 selection: deterministic sorted route-ID prefix within each semantic priority class.
6. Route split: exactly 25 current and 35 predicted generated/proxy routes.
7. Route IDs are identical across all methods and K values.
8. Historical initialization policy is method-specific under the common seed; no shared initial-population artifact existed.
9. Completed K settings: `[5, 10, 15]` with splits `3/2, 5/5, 8/7`.
10. Expected runs: 15.
11. Successful runs: 15; failed or missing: 0.
12. Resume/retry status is recorded in `logs/launcher_summary.json`; completed unit files are restart-safe.
13. Old route20/40/50/80 optimizations were not rerun.
14. Existing experiment files were not overwritten; only the extension directory was written.
15. ASU, Coverage@0, and CCU@0 complete: True.
16. HV/GD/IGD are unavailable because the historical sensitivity protocol did not export compatible full objective-vector archives; ASU was never substituted.
17. The 20/40/60/80 heatmap dataset has 60 directly observed rows.
18. Route50 remains present in the complete-data file.
19. Origin matrix/XYZ files are ready when all cell and safety checks pass; no values are interpolated.
20. Paper caveats: these are single-seed generated/proxy-route sensitivity results; the historical methods do not all share an identical all-K search architecture, so do not present them as strict Pareto-fair optimizer robustness.

The equally spaced heatmap subset uses route counts 20, 40, 60, and 80. The existing route-count 50 results are preserved for complete-data reporting but are excluded from the equally spaced heatmap.

The route-scale and deployment-budget sensitivity results are single-seed results. Therefore, standard deviations are not reported as zero and should not be interpreted as robustness estimates.

## Route60 preview

|method_label|K|ASU_mean|Coverage@0_mean|CCU@0_mean|runtime_seconds_mean|
|---|---|---|---|---|---|
|AirHERO-v3 historical|5|0.20117650091671468|0.6883333333333334|0.6775862068965517|871.4255704879761|
|AirHERO-v3 historical|10|0.13486374562466252|0.7433333333333333|0.7212643678160919|895.2169823646545|
|AirHERO-v3 historical|15|0.11034884840007983|0.865|0.8517241379310344|905.3114120960236|
|CSA|5|0.13995235468764353|0.5172222222222222|0.5051724137931034|564.0606064796448|
|CSA|10|0.08502952567665463|0.49333333333333335|0.47758620689655173|567.55477643013|
|CSA|15|0.06533920199171322|0.4955555555555556|0.4741379310344828|577.3037440776825|
|NSGA-II|5|0.10761616539815125|0.4116666666666667|0.4057471264367816|240.9490921497345|
|NSGA-II|10|0.06387510896720747|0.4116666666666667|0.4057471264367816|222.61369395256042|
|NSGA-II|15|0.048931400546814385|0.44222222222222224|0.4344827586206897|259.8099296092987|
|MOEA/D|5|0.12611228568346333|0.44333333333333336|0.43563218390804603|658.4466586112976|
|MOEA/D|10|0.06514113726601686|0.41555555555555557|0.40862068965517234|653.8604292869568|
|MOEA/D|15|0.04170525668485168|0.4116666666666667|0.4057471264367816|659.4534840583801|
|Greedy|5|0.16902288633127963|0.5916666666666667|0.5764367816091954|0.14847564697265625|
|Greedy|10|0.11784229017469933|0.6788888888888889|0.6614942528735632|0.13585519790649414|
|Greedy|15|0.0893446955773918|0.6866666666666666|0.6666666666666666|0.18413209915161133|
