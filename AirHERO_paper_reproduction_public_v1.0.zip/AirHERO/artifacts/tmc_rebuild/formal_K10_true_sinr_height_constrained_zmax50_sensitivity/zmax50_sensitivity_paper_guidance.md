# z_max=50 m sensitivity paper guidance

Safe claims:
- Parameter sensitivity is evaluated under the same z_max=50 m height constraint as the main experiment.
- Route-scale sensitivity uses 20, 40, 50, and 80 generated/proxy semantic POI routes.
- Route subsets preserve route boundaries.
- Increasing K generally improves coverage utility only when the additional stations overcome deployment cost, handover, interference, and route-distribution effects.
- ASU may be non-monotonic because it is a cost-and-handover-aware service efficiency metric.

Unsafe claims:
- The results prove universal scalability.
- The route-count trend is strictly monotonic unless all metrics support it.
- All stations in the entire scenario are below 50 m; only newly deployed stations are constrained.
- Existing stations are real operator deployments.
- UAV routes are real measured routes.
- HV/GD/IGD are the main system-level sensitivity metrics.
