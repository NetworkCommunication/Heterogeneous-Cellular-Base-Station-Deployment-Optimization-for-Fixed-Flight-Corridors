# z_max=50 m versus unconstrained sensitivity guidance

Use this comparison as a height-limit sensitivity check only. The constrained and unconstrained packages are separate variants; differences reflect both the height cap and the strict-context z_max=50 m rerun/evaluation protocol.
