# Formal Claim Boundary

This package freezes the configuration for an ASU-v2 route-priority two-stage optimizer comparison. It does not contain formal experiment results.

## Allowed Claims After Running The Frozen Formal Suite

- The formal run compares ASU-v2 based route-priority two-stage optimizers.
- All frozen completed methods use the same K, K1/K2 split, route set, station file, ASU formula, random seed list, and evaluation budget.
- `proposed_method_search_expansion_response_v2_asu_v2` can be analyzed with response logs if the run exports them.
- CSA, GWO, WOA, SSA, and HHO are fair ASU-v2 baselines under the same route-priority two-stage wrapper.
- Existing stations are simulated/proxy infrastructure from real-map features.
- Routes are generated semantic POI route subsets.

## Pending Claims

- NSGA-II and MOEA/D are pending until ASU-v2 route-priority two-stage adapters are frozen and validated.

## Must Not Claim

- Do not compare these ASU-v2 formal results directly with old `tmc_asu` experiments.
- Do not claim existing stations are real operator base stations.
- Do not claim routes are real measured airways.
- Do not claim Pareto-front superiority unless a separate objective-vector HV/GD/IGD suite supports it.
- Do not claim response mechanisms improve performance unless enabled response logs and controls support that claim.
