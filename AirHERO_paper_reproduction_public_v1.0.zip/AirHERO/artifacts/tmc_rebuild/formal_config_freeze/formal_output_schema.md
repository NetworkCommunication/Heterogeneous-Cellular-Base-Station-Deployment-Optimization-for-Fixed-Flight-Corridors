# Formal Output Schema

This schema is frozen for the K10 balanced ASU-v2 route-priority two-stage formal run. The formal run has not been executed in this step.

## Required Tables

- `formal_all_runs.csv`
- `formal_asu_components.csv`
- `formal_mean_std.csv`
- `formal_station_summary.csv`
- `formal_two_stage_summary.csv`
- `formal_runtime_summary.csv`
- `formal_response_summary.csv`
- `formal_trace_summary.csv`
- `formal_method_status.csv`
- `formal_safety_check.md`

## Required Plots

- `ASU_by_method.png`
- `current_future_Q_by_method.png`
- `current_future_coverage_by_method.png`
- `coverage_outage_by_method.png`
- `cost_handover_by_method.png`
- `runtime_by_method.png`
- `station_type_by_method.png`
- `best_ASU_trace_by_method.png`
- `response_count_for_v2.png`

## Core Columns

`formal_all_runs.csv` must include method, seed, K, K1, K2, ASU, Q_current, Q_future, current/future coverage, coverage_rate, outage_probability, deployment_cost, handover_count, selected station type counts, and runtime.

`formal_asu_components.csv` must export the full ASU-v2 component set: numerator components, denominator components, route weights, station costs, handover penalty, and signal metric.

`formal_response_summary.csv` must include response_count, mild_response_count, moderate_response_count, severe_response_count, restart_count, and pbest_preservation_count. Non-response bio-inspired baselines should use zero or `not_applicable`, but the columns must still exist.

`formal_method_status.csv` must report completed, failed, or pending status for every frozen method key.
