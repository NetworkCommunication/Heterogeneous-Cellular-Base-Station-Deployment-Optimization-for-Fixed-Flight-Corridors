# Formal Run Plan

This plan is frozen but not executed in this step.

## Planned Command

After the formal runner is implemented, run:

```powershell
python scripts\run_formal_rebuild_k10_balanced_asu_v2.py --config artifacts\tmc_rebuild\formal_config_freeze\formal_main_K10_balanced.yaml
```

The runner should load the companion YAML files in this directory and should fail if the output directory already exists.

## Expected Runtime Estimate

Frozen budget:

- methods: 6
- seeds: 3
- stages per run: 2
- population: 50
- iterations per stage: 150

Approximate optimization evaluations:

- per method/seed: 15000
- total: 270000

Runtime should be estimated from the tiny validation before execution. The formal run may take several hours depending on evaluator speed.

## Resume If Interrupted

The formal runner should write one method/seed result atomically, then update `formal_method_status.csv`. To resume:

1. Inspect `formal_method_status.csv`.
2. Skip method/seed pairs marked `completed`.
3. Re-run only failed or missing method/seed pairs.
4. Rebuild summaries and plots after all required method/seed rows are complete.

## Verify Outputs

Check that all required tables and plots in `formal_output_schema.md` exist. Then verify:

- each frozen method has rows for seeds 2026, 2027, and 2028;
- no method is marked failed;
- `formal_safety_check.md` says no station/route/POI regeneration occurred;
- station source labels include Stage-I current-priority and Stage-II future-priority labels;
- ASU-v2 denominator is positive for every run.

## Extend To K Sensitivity Later

Do not run K sensitivity in the K10 formal run. Future extension:

- K=10: K1=5, K2=5
- K=15: K1=8, K2=7
- K=20: K1=10, K2=10

Use the same artifact paths, ASU-v2 definition, and route-priority two-stage semantics unless a new config freeze explicitly changes them.
