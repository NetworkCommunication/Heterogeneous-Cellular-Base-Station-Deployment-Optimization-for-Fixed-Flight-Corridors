# Route Generation Code Locations

| topic | path | note |
| --- | --- | --- |
| POI DFS route generation config | src/utils/config.py | futureAirway graph and routeGeneration defaults. |
| Future airway generator | src/data/future_airway_generator.py | POI records, DFS generation, discretization, unreachable target reporting. |
| Route construction audit | scripts/route_construction_audit.py | Existing post-hoc audit used for final paper route construction. |
| Predicted route source | data\real\shenyang\shenyang_predicted_routes.csv | Existing generated route80-style source CSV. |
| POI source | data\real\shenyang\shenyang_pois.csv | Existing real-map-derived POI CSV. |
