# Candidate Formal Claim Boundary

- This directory is a candidate config package, not a formal result.
- Existing stations are simulated/proxy infrastructure, not real operator base stations.
- Routes are generated/proxy semantic POI route points, not real measured airways.
- SNR -5 dB is retained only for diagnostic/backward comparison.
- SINR 0 dB is the candidate main service threshold; SINR 5/10 dB are auxiliary quality metrics.
- Do not claim optimization performance until formal K sensitivity experiments are run.
