# SINR Density-Calibrated Candidate Readiness Report

- recommended station artifact: `artifacts/tmc_rebuild/station_generation_citywide_route_agnostic/generated_existing_stations_citywide_route_agnostic_low.csv`
- station artifact key: `citywide_low`
- density label: `route_agnostic_citywide_low`
- station count: `144`
- route artifact: `artifacts/tmc_rebuild/route_resampling/shenyang_predicted_routes_resampled_points.csv`
- signal metric: `sinr`
- main threshold: `0 dB`
- auxiliary thresholds: `5 dB`, `10 dB`
- rho: `0.1`
- power mode: `station_file_preferred`
- K candidates: `10, 15, 20`

Ready for formal rerun only after the formal evaluator is explicitly wired to this SINR setting.
