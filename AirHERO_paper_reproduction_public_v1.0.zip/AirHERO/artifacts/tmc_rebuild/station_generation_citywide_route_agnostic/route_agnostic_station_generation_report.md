# Route-Agnostic Citywide Station Generation Report

This package generates route-agnostic citywide proxy base-station candidates. It does not use UAV routes, route points, current/future labels, OD pairs, route semantics, or the experiment POI file.

## Features

Used: study-area boundary, boundary-derived urban-core score, uniform base intensity.

Missing: road density, building footprint density, building height, land use, population density. See `missing_citywide_feature_report.md`.

## Candidates

- low: 144
- medium: 240
- high: 384

Recommended candidate: **medium**.

All generated stations are simulated/proxy infrastructure and are not real operator base-station records.
