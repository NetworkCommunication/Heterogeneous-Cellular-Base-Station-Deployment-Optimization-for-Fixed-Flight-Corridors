# Route-Agnostic 3GPP-Style Sanity Report

- low: map coverage=0.989, urban-core coverage=1.000, map outage=0.011, route coverage diagnostic=1.000
- medium: map coverage=0.999, urban-core coverage=1.000, map outage=0.002, route coverage diagnostic=1.000
- high: map coverage=0.998, urban-core coverage=1.000, map outage=0.002, route coverage diagnostic=1.000

Route metrics are diagnostic_only and were not used for generation or selection.
