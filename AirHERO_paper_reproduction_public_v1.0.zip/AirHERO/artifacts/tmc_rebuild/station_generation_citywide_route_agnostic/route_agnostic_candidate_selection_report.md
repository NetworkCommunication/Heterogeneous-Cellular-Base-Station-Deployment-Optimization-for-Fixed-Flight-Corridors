# Route-Agnostic Candidate Selection Report

Recommended artifact: `generated_existing_stations_citywide_route_agnostic_recommended.csv`

Recommended candidate: **medium**

Selection used only route-agnostic metrics: map-grid coverage, urban-core grid coverage, map-grid outage/SNR, hard-core constraints, macro/micro ratio, station density, and nearest-neighbor distribution. Route-point coverage is reported only as diagnostic and was not used for candidate selection.

Scores:
```json
{
  "low": 1.4115,
  "medium": 1.4515,
  "high": 1.372
}
```
