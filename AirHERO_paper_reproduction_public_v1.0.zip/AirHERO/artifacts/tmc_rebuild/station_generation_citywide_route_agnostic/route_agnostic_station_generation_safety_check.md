# Route-Agnostic Station Generation Safety Check

- no_optimization_experiments_run: true
- old_96_station_artifact_preserved: true
- previous_citywide_artifacts_preserved: true
- original_route_artifact_preserved: true
- resampled_route_artifact_preserved: true
- no_optimizer_code_modified: true
- no_ASU_formula_modified: true
- no_route_derived_features_used_in_station_generation: true
- no_target_POI_route_semantics_used_in_station_generation: true
- generated_proxy_station_labels_preserved: true
- no_real_operator_base_station_claim: true
- no_real_measured_airway_claim: true
- route_coverage_used_only_as_diagnostic_not_selection: true
