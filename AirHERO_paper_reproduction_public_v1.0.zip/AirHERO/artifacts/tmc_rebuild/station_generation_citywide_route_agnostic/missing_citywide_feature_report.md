# Missing Citywide Feature Report

Road/building/height/land-use/population layers are not available as frozen rebuild artifacts. The route-agnostic generator therefore does **not** fall back to UAV routes or target POIs. It uses only study boundary, boundary-derived urban-core weighting, and uniform base intensity. This is a diagnostic route-agnostic fallback candidate.
