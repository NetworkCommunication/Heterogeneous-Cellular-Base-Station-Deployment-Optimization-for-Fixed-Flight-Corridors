# Previous Station Artifact Status

- The 96-station artifact is preserved as a selected-study-area diagnostic/proxy station set: `artifacts\tmc_rebuild\station_generation\generated_existing_stations.csv`.
- Count: 96 total, 34 macro_proxy, 62 micro_proxy.
- The previous citywide low/medium/high artifacts are preserved under `artifacts\tmc_rebuild\station_generation_citywide`.
- Previous citywide route coverage values must not be used as the main station-candidate selection criterion.
- This package generates new route-agnostic citywide artifacts separately.

Safety wording: all station artifacts are simulated/proxy infrastructure, not real operator base-station records.
