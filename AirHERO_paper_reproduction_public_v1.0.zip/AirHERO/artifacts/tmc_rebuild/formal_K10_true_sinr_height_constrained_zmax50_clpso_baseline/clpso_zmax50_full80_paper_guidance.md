# CLPSO paper guidance

Safe:
- CLPSO is included as a classic PSO-family scalar ASU-driven optimizer baseline.
- CLPSO uses the same deployment budget, decision space, z_max=50 m height constraint, and final true-SINR ASU-v2 evaluator.
- CLPSO is not treated as a same-objective Pareto baseline.

Unsafe:
- Do not call CLPSO a top-journal adapted baseline.
- Do not claim CLPSO optimizes the same four-objective vector as ImMOGWO unless separately implemented.
- Do not use ASU to compute HV/GD/IGD.
