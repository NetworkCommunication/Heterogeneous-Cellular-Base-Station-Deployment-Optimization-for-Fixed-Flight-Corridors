# CLPSO z_max=50 m full80 report

- Method key: `clpso_extended_true_sinr_asu_v2`.
- Paper-facing name: `CLPSO-adapted`.
- Role: classic PSO-family scalar ASU-driven optimizer baseline.
- Objective: maximize official true-SINR ASU-v2; HV/GD/IGD are not used inside search.
- Completed runs: `3` / `3`.
- Failed runs: `0`.
- Mean ASU: `0.07160835131004457`.
- Mean Coverage Utility@0: `0.48`.
- Mean Coverage Utility@10: `0.06333333333333334`.
- Height compliance: `True`.
- ASU consistency: `True`.

Existing stations are simulated/proxy infrastructure and routes are generated/proxy semantic POI route points.
