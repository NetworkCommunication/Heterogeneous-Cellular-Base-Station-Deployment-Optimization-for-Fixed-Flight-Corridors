# CLPSO support audit

- Existing CLPSO-LS support was found, but it is a decomposition-adapted multiobjective diagnostic baseline.
- A new isolated scalar ASU-v2 CLPSO adapter was added as `clpso_extended_true_sinr_asu_v2`.
- It uses the full `[x, y, z, station_type_index, sector_direction_index]` decision encoding and the z_max=50 m runner repair.
- It is not a top-journal adapted baseline and not a same-objective Pareto optimizer.
