# Unsafe claims

- Do not claim real operator base stations or real measured UAV routes.
- Do not claim ray tracing, SINR multi-fidelity, QE hard gate, or universal dominance over all metrics.
- Do not claim exact reproduction for adapted top-journal baselines.
- Do not claim Pareto-front universal dominance from unmatched old robustness rows.
