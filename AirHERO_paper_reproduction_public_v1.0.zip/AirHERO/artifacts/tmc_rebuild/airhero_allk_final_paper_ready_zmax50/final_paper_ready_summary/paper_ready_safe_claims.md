# Safe claims

- AirHERO adopts a two-stage heterogeneous deployment optimization framework.
- Stage-I generates a current-route-aware initial deployment.
- Stage-II is initialized from Stage-I and refines all K newly deployed stations.
- Stage-II can adjust positions, station types, and 5G-A sector directions.
- Final deployment is evaluated over all current and predicted generated/proxy route samples.
- Matched-main optimization robustness uses objective vectors only and a unified empirical reference front.
