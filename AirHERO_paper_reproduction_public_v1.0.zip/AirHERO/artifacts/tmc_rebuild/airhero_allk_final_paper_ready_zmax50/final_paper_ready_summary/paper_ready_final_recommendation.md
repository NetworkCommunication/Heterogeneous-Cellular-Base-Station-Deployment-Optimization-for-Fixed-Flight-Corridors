# Final Recommendation

Adopt `airhero_allk_stage2_refinement_v1` as the paper-facing AirHERO method by explicit design choice.

Baseline results were reused read-only. The previous formal AirHERO remains archived and unchanged.

## AirHERO deployment-method ranks
- ASU: rank 1 value 0.11150727716544173
- Coverage@0: rank 1 value 0.7202777777777777
- Coverage@10: rank 1 value 0.11430555555555556
- CCU@0: rank 1 value 0.700287356321839
- CCU@10: rank 1 value 0.09324712643678161

## Previous formal AirHERO comparison
All-K refinement has slightly lower mean ASU than the archived previous formal AirHERO, but stronger method logic and better low-threshold coverage/CCU.
