# AirHERO-AllKRefine exploratory report

This package is exploratory only. It does not overwrite frozen formal AirHERO artifacts.

## Design
- Method key: `airhero_allk_stage2_refinement_v1`
- Paper-facing temporary name: `AirHERO-AllKRefine`
- Stage-I is the frozen AirHERO current-route stage.
- Stage-II jointly refines all K=10 stations initialized by Stage-I plus future low-service anchors.
- The frozen response-v3 loop is reused; only Stage-II initialization is replaced in the exploratory script process.

## Result preview
- Completed seeds: 3/3
- Best seed ASU: 0.11573047426546769 (seed 2027)
- Mean ASU: 0.11150727716544173

## Comparison to formal AirHERO
- Seed 2026: delta ASU=-0.000795501761963982, delta Coverage@0=0.012083333333333335, delta CCU@0=0.012068965517241459
- Seed 2027: delta ASU=-0.004335192402832394, delta Coverage@0=0.014999999999999902, delta CCU@0=0.008189655172413768
- Seed 2028: delta ASU=0.0017498474085644034, delta Coverage@0=0.012916666666666687, delta CCU@0=0.01163793103448274

## Readiness
- all_3_seeds_success: True (3/3 successful)
- height_violations_zero: True (all successful rows have zero height violations)
- asu_recompute_mismatch_zero: True (stored and recomputed ASU match)
- mean_ASU_higher_than_formal: False (variant=0.11150727716544173, formal=0.11263422608418573)
- at_least_2_of_3_seeds_improve_ASU: False (1/3 seeds improve ASU)
- coverage_CCU_do_not_collapse: True (coverage_collapse=False; ccu_collapse=False)
- runtime_increase_reported: True (variant_mean_runtime=844.0551133950552; formal_mean_runtime=480.3928469022115)
- overall_acceptance: False (exploratory variant is paper-candidate only if all required criteria pass)

## Verdict
Not accepted as a replacement; keep diagnostic/exploratory unless explicitly promoted later.

## Safety
- Existing station artifacts remain simulated/proxy and unchanged.
- Route artifacts remain generated/proxy semantic POI route points and unchanged.
- ASU-v2, true-SINR evaluator, cost, handover, and z_max=50 settings are unchanged.
- No ray tracing or SINR multi-fidelity claim is made.
