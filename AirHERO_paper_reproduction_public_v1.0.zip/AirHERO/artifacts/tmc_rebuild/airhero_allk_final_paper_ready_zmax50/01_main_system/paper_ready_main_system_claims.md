# Main-system claims with all-K AirHERO candidate

- Baseline rows are reused from the frozen final paper-ready z_max=50 package; they were not rerun.
- The previous formal AirHERO row is removed from the main deployment-method table and replaced by the all-K candidate row.
- Existing-only remains a no-deployment reference, not a deployment optimizer.

## Proposed ranks excluding existing-only
- ASU: rank 1 with value 0.11150727716544173
- Coverage@0: rank 1 with value 0.7202777777777777
- Coverage@10: rank 1 with value 0.11430555555555556
- CCU@0: rank 1 with value 0.700287356321839
- CCU@10: rank 1 with value 0.09324712643678161

## Safe interpretation
- The all-K candidate remains comparable against frozen deployment baselines under the same z_max=50 true-SINR setting.
- The all-K candidate improves Coverage@0 and CCU@0 relative to the archived previous AirHERO, but its mean ASU is lower.
- Replacement should be conditional on final readiness, not automatic.
