# Paper-ready ablation claims

- Completed variants: `full_airhero, stagewise_concat, without_5ga_sector_optimization, without_closed_loop_elite_immigration_response, without_heterogeneous_5g_5ga, without_stage1_guided_initialization`.
- Not-applicable variants are explicitly recorded: `0`.
- AirHERO improves ASU over Stagewise concat: `True`.
- AirHERO improves Coverage@0 / Coverage@10 over Stagewise concat: `True` / `True`.
- AirHERO improves CCU@0 / CCU@10 over Stagewise concat: `True` / `True`.
- Largest absolute ASU delta versus Full AirHERO: `without_heterogeneous_5g_5ga`.
- Largest absolute Coverage@0 delta versus Full AirHERO: `without_heterogeneous_5g_5ga`.
- Largest absolute Coverage@10 delta versus Full AirHERO: `without_heterogeneous_5g_5ga`.
- Largest absolute CCU@0 / CCU@10 delta versus Full AirHERO: `without_heterogeneous_5g_5ga` / `without_heterogeneous_5g_5ga`.
- Safe wording: Stagewise concat denotes independent current/future optimization followed by concatenation.
- Unsafe wording: do not say AirHERO universally dominates every metric.
