# AirHERO all-K ablation report

This package compares the adopted all-K AirHERO against Stagewise concat.

Stagewise concat runs current-route Stage-I for K1 stations and predicted-route Stage-II independently for K2 stations, then concatenates both deployments and evaluates all current and predicted route samples.

## Completed variants

|variant_name|n|ASU_mean|Coverage@0_mean|Coverage@10_mean|CCU@0_mean|CCU@10_mean|
|---|---|---|---|---|---|---|
|full_airhero|3|0.11150727716544173|0.7202777777777777|0.11430555555555556|0.700287356321839|0.09324712643678161|
|stagewise_concat|3|0.1089674451600496|0.6795833333333333|0.11236111111111109|0.661206896551724|0.092816091954023|
|without_5ga_sector_optimization|3|0.10097285172500498|0.6736111111111112|0.10416666666666667|0.6563218390804598|0.08491379310344827|
|without_closed_loop_elite_immigration_response|3|0.10284962016628806|0.6543055555555556|0.0961111111111111|0.6363505747126437|0.08002873563218392|
|without_heterogeneous_5g_5ga|3|0.09606797450787019|0.5159722222222222|0.08263888888888889|0.49310344827586206|0.06206896551724137|
|without_stage1_guided_initialization|3|0.10414074551484277|0.6520833333333333|0.10125|0.6324712643678161|0.08304597701149426|

## Not applicable variants

|variant_name|status|reason|
|---|---|---|

## Interpretation

- Full AirHERO outperforms Stagewise concat in ASU: `True`.
- Full AirHERO outperforms Stagewise concat in Coverage@0/10: `True` / `True`.
- Full AirHERO outperforms Stagewise concat in CCU@0/10: `True` / `True`.
- Largest ASU impact component: `without_heterogeneous_5g_5ga`.
- Largest Coverage@0 impact component: `without_heterogeneous_5g_5ga`.
- Largest Coverage@10 impact component: `without_heterogeneous_5g_5ga`.
- Largest CCU@0/10 impact components: `without_heterogeneous_5g_5ga` / `without_heterogeneous_5g_5ga`.