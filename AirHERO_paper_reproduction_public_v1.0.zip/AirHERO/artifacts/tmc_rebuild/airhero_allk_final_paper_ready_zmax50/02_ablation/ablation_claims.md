# Ablation claims

- Completed comparison: full all-K refinement versus previous K2-only Stage-II formal AirHERO.
- Delta ASU full-minus-previous: -0.0011269489187440002
- All-K refinement improves Coverage@0/CCU@0 but lowers mean ASU and increases runtime in this three-seed setting.
- Do not claim all-K refinement improves ASU.
- Do not claim unsupported component ablations for not-applicable variants.
