# Fair Optimizer Robustness Under Same All-K Search Space

This package is separate from the previous matched-main diagnostic package. It uses K=10 all-K heterogeneous decisions, shared initial populations, and the unified objective vector `[C_dep, H, -Q_E, -Q_P]`.

AirHERO caveat: `airhero_search_same_initialization` preserves the adopted AirHERO internal search and response logic; this package post-evaluates its final population on the unified four-objective vector for HV/GD/IGD/AN. Therefore, use this as a same-space and same-initialization robustness diagnostic, not as proof that every optimizer has identical search-time scalarization internals.

## Completed methods

airhero_search_same_initialization, clpso_extended_allk_same_space, csa_extended_allk_same_space, immogwo_extended_allk_same_space, moead_extended_allk_same_space, nsga2_extended_allk_same_space, scenario_sampling_robust_deployment_allk_same_space

## Not applicable

|method|status|reason|
|---|---|---|
|existing_only/random/kmeans/greedy/5g_only|not_applicable|system/no-deployment baselines are excluded from fair optimizer HV/GD/IGD.|
|DCR|not_applicable|No existing stable DCR implementation was found for this exact four-objective same-space package.|
|OE|not_applicable|Existing OE code is artifact-specific audit code, not a stable shared implementation for this package.|

## Summary

|method|HV_mean|GD_mean|IGD_mean|AN_mean|nondominated_count_mean|runtime_seconds_mean|
|---|---|---|---|---|---|---|
|airhero_search_same_initialization|0.4587676011111113|0.23836289048883155|0.24385833957292744|0.10920228283420952|43.0|632.2609902222952|
|clpso_extended_allk_same_space|0.10656614527777782|0.22756934901013803|0.4184465420596735|0.12251096580443943|14.666666666666666|883.8806790510813|
|csa_extended_allk_same_space|0.12123968083333338|0.20936734242783195|0.43973989765844634|0.0371662001431387|11.333333333333334|977.566468556722|
|immogwo_extended_allk_same_space|0.11555409250000005|0.06486699659922875|0.38710299362046396|0.03455242257975578|52.333333333333336|852.4434705575308|
|moead_extended_allk_same_space|0.0452569577777778|0.03182394448565529|0.4784944815524335|0.026908512216405677|15.0|1322.1725775400798|
|nsga2_extended_allk_same_space|0.579909675277778|0.057105091929278144|0.20260538097293876|0.055664891006170863|48.333333333333336|1419.572344382604|
|scenario_sampling_robust_deployment_allk_same_space|0.020521801666666676|0.1032130573435795|0.5465751744736983|0.1885042180936893|5.0|763.981184164683|

## Answers

- Best mean HV: `nsga2_extended_allk_same_space`.
- Best mean GD: `moead_extended_allk_same_space`.
- Best mean IGD: `nsga2_extended_allk_same_space`.
- Largest AN: `scenario_sampling_robust_deployment_allk_same_space`.
- DCR and OE: not available as stable existing implementations for this package.
- Safe: describe this as fair optimizer robustness under the same all-K search space.
- Unsafe: do not claim universal dominance unless HV, GD, IGD, AN, and system metrics jointly support it.
