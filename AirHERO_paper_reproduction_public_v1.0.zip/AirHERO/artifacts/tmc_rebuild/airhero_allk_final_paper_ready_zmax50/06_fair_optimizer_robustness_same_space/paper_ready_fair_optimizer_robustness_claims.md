# Fair Optimizer Robustness Claims

- This is the fair optimizer robustness under the same all-K search space.
- All completed methods use K=10 heterogeneous `[x,y,z,station_type_index,sector_direction_index]` encoding and the same per-seed shared initial population.
- HV/GD/IGD/AN use only `[C_dep, H, -Q_E, -Q_P]`; ASU is not used.
- AirHERO caveat: `airhero_search_same_initialization` preserves the adopted AirHERO search/evaluator logic internally; its final population is post-evaluated on `[C_dep, H, -Q_E, -Q_P]` for this robustness diagnostic.
- Best mean HV: `nsga2_extended_allk_same_space`.
- Best mean GD: `moead_extended_allk_same_space`.
- Best mean IGD: `nsga2_extended_allk_same_space`.
- Largest mean AN: `scenario_sampling_robust_deployment_allk_same_space`.
- DCR/OE are not reported because no stable existing implementation was available for this exact package.
- Safe: discuss same-space objective-vector robustness for completed optimizers.
- Unsafe: do not mix with package 05 or claim universal dominance unless all metrics support it.
