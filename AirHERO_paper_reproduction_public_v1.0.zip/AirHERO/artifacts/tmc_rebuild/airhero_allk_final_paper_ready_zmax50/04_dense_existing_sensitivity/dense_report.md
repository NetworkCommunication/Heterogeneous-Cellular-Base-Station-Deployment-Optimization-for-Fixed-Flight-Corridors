# Dense report

Finished tasks: `[{"name": "dense_K10_seed2028", "returncode": 0, "output_root": "artifacts\\tmc_rebuild\\airhero_allk_final_paper_ready_zmax50\\04_dense_existing_sensitivity\\runs\\dense_K10_seed2028"}, {"name": "dense_K10_seed2026", "returncode": 0, "output_root": "artifacts\\tmc_rebuild\\airhero_allk_final_paper_ready_zmax50\\04_dense_existing_sensitivity\\runs\\dense_K10_seed2026"}, {"name": "dense_K10_seed2027", "returncode": 0, "output_root": "artifacts\\tmc_rebuild\\airhero_allk_final_paper_ready_zmax50\\04_dense_existing_sensitivity\\runs\\dense_K10_seed2027"}]`.
