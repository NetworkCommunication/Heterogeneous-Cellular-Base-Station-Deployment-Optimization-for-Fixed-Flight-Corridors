# Existing-density claims

Dense all-K AirHERO was rerun using generated/proxy 3GPP UMa-like infrastructure only. Existing-only is a no-deployment reference.
