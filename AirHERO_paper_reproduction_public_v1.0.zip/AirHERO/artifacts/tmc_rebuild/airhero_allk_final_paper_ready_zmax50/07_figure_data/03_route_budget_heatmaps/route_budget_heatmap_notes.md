# Route-count by deployment-budget heatmap notes

All 12 canonical AirHERO all-K cells are present. The source package contains seed 2026 only for each cell, so `seed_count=1` and standard deviations are intentionally blank rather than zero. These heatmaps show single-seed sensitivity, not multi-seed variability.
