# Pareto projection data notes

## Extraction status

- Primary nondominated-vector source: `artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/06_fair_optimizer_robustness_same_space/per_seed_nondominated_vectors.csv`.
- Fallback nondominated filtering required: `False`.
- Raw objective values available: `True`; no normalization recovery was needed.
- Extracted unique four-dimensional nondominated points: `569`.
- Exact duplicate rows removed: `0`.
- Dataset ready for final plotting: `True`.

## Point counts

|method|seed|points|cost_QE_envelope|H_QP_envelope|
|---|---|---|---|---|
|AirHERO-search|2026|47|6|9|
|AirHERO-search|2027|38|5|10|
|AirHERO-search|2028|44|5|14|
|NSGA-II|2026|49|2|10|
|NSGA-II|2027|48|4|11|
|NSGA-II|2028|48|2|12|
|MOEA/D|2026|17|2|4|
|MOEA/D|2027|13|6|1|
|MOEA/D|2028|15|4|5|
|CSA|2026|19|1|4|
|CSA|2027|9|1|1|
|CSA|2028|6|2|3|
|CLPSO|2026|18|6|6|
|CLPSO|2027|13|5|5|
|CLPSO|2028|13|4|5|
|IMMOGWO|2026|61|3|6|
|IMMOGWO|2027|44|3|7|
|IMMOGWO|2028|52|3|6|
|Scenario sampling|2026|6|5|2|
|Scenario sampling|2027|4|3|2|
|Scenario sampling|2028|5|5|1|

## Objective and sign handling

The verified source mapping is `C_dep -> C_dep`, `handover_count -> H`, `minus_Q_E -> -Q_E`, and `minus_Q_P -> -Q_P`. Positive utilities are restored as `Q_E = -minus_Q_E` and `Q_P = -minus_Q_P`. ASU is not used as a projection coordinate.

All seven methods use K=10, the same all-K heterogeneous decision encoding, route80/current33/predicted47, and a shared initial population for each seed. Seed 2026 is complete for all methods and is suitable for an optional uncluttered comparison because it applies one common initialization seed rather than method-specific best seeds.

## Recommended use

Use both projections together: deployment cost versus current-route utility shows the deployment-efficiency/current-service trade-off, while handover count versus predicted-route utility shows the mobility/predicted-service trade-off. For an uncluttered main or supplementary panel, use `pareto_projection_seed2026.csv`; use all three seeds when showing robustness or pooled point clouds. Filter `pareto_projection_envelopes.csv` by `is_projected_nondominated=True` before connecting an envelope.

## Required questions

1. **Primary source:** `artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/06_fair_optimizer_robustness_same_space/per_seed_nondominated_vectors.csv`.
2. **Fallback required:** No. The primary file was complete, and every extracted tuple was found in the full objective-vector source.
3. **Methods extracted:** AirHERO-search, NSGA-II, MOEA/D, CSA, CLPSO, IMMOGWO, and Scenario sampling.
4. **Point counts:** The complete per-method and per-seed counts are listed in the Point counts table above; the total is `569`.
5. **Raw objectives:** Yes. `C_dep`, `handover_count`, `minus_Q_E`, and `minus_Q_P` were directly available as raw physical objective values.
6. **Utility restoration:** `Q_E = -minus_Q_E` and `Q_P = -minus_Q_P`; both identities were checked for every row.
7. **Same K=10 search space:** Yes. All rows come from the verified same all-K heterogeneous encoding.
8. **Shared initialization:** Yes. All methods use the same seed-specific initial population in the source package.
9. **Final-paper projection:** Use both requested planes. Use the three-seed point cloud for robustness and connect only separately flagged two-dimensional envelope points.
10. **Seed 2026 subset:** Yes. It contains all seven methods under one shared initialization seed and is suitable for a less cluttered comparison.
11. **Caption caveats:** State that these are two-dimensional projections of four-dimensional nondominated solutions, projected points may become dominated, ASU is excluded, and internal search objectives/scalarization may differ despite unified postprocessing.
12. **Ready for plotting:** `True`. All 17 readiness checks pass; no fabricated or fallback points are present.

## Required caveats

This figure projects four-dimensional nondominated solutions onto two two-dimensional planes. A point that is nondominated in the original four-objective space may appear dominated after projection. Therefore, the projection is used for visual interpretation only.

All Pareto projection data are based on the unified fairness-diagnostic objective vector `[C_dep, H, -Q_E, -Q_P]`. ASU is not used as a projection coordinate.

AirHERO-search preserves the AirHERO search and response logic, but its final population is postprocessed into the unified objective vector. The experiment uses the same search space and shared initialization, while the internal search objectives or scalarization mechanisms are not necessarily identical across all optimizers.

A larger nondominated point count does not by itself imply better Pareto quality. Raw projected points must not all be connected; only the separately recomputed two-dimensional envelope may be connected.
