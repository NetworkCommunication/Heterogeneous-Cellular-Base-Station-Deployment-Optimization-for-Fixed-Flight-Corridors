# Representative route profile notes

All 80 generated/proxy semantic POI routes were evaluated for Existing only, Stagewise concat, and AirHERO with seed `2026` where applicable. Current and predicted representative routes were selected independently using the median-positive AirHERO-minus-Stagewise CCU@0 rule. CCU is the mean of adjacent covered-pair indicators within one route. Handover events are counted only between adjacent samples of the same route; the first point is always zero. Outage segment ID `0` denotes a covered sample.
