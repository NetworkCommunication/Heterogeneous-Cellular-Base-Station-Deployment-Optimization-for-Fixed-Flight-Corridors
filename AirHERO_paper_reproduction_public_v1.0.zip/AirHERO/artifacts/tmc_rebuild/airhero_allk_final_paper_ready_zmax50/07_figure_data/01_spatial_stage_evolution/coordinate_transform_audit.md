# AirHERO coordinate-transform provenance audit

## Verdict

There is **no single verified local-x/y to WGS84 transformation for the final AirHERO experiment**. The route/POI artifact and the existing-proxy-station artifact encode two different affine scales in nominally the same local coordinate space. Route samples can be placed on WGS84 reliably, but optimized Stage-I/final stations and the requested crop windows cannot be assigned one exact WGS84 location without choosing one of two conflicting frames.

The verified route/POI frame is a repository-defined `LOCAL_METERS` transform, not UTM, AEQD, Web Mercator, or a `pyproj` CRS:

```text
x = (longitude - 122.350000000000) * 83219.393604030134
y = (latitude  - 41.180000000000) * 111067.723611839945
```

The existing-station CSV instead encodes this empirically recovered affine frame:

```text
x = (longitude - 122.349999999020) * 82857.503878662261
y = (latitude  - 41.180000000239) * 111000.000106723164
```

## Provenance

- Source CRS: `EPSG:4326` / WGS84 longitude-latitude.
- Destination: repository-defined `LOCAL_METERS`; it has no EPSG code.
- Configured bbox: `[122.35, 41.18, 123.92, 42.25]`.
- Both frames have an origin numerically equal to the southwest bbox corner within CSV-fit precision.
- Route scale latitude: bbox midpoint `41.715000000000` degrees.
- Route scales: longitude `83219.393604030134 m/degree`; latitude `111067.723611839945 m/degree`.
- Existing-station encoded scales: longitude `82857.503878662261 m/degree`; latitude `111000.000106723164 m/degree`.
- False easting/northing: effectively `0 m, 0 m` at the bbox southwest corner.
- Axis orientation: x increases eastward; y increases northward.
- Rotation/shear: none. Normalization: none.
- The optimizer later clips new-station decisions to its experiment candidate bounds; that is a decision constraint, not a geographic reprojection.

The route-producing code path is `src/data/shenyang_real_map_preparation.py::extract_shenyang_pois()`, whose local `to_xy()` uses `_meters_per_degree(center_lat)` from `src/data/real_map_loader.py`. Generated routes retain those POI coordinates and the resampled artifact interpolates endpoint lon/lat and endpoint x/y. The generic station module `src/data_generation/existing_bs_nonuniform_hardcore.py::_xy_to_lonlat()` uses `CityMap.geo_m_per_deg`, but the final route-agnostic station package does not preserve the exact source function/configuration that supplied its differing scale. Its frame can be recovered from 144 control points, but its code provenance is incomplete.

## Control-point validation

- Route samples under the route frame: `2400` checked; maximum residual `0.001307 m`; verified: `True`.
- Existing stations under their empirically recovered frame: `144` checked; maximum residual `0.001006 m`; internally consistent: `True`.
- Existing stations forced through the route frame: maximum residual `571.763969 m`.
- Routes forced through the station frame: maximum residual `513.363304 m`.
- A single common transform is verified: `False`.
- Millimetre-scale native residuals reflect CSV rounding; the hundreds-of-metres cross-frame residual is not rounding.

## Why the earlier bbox-stretch conversion is wrong

Mapping `map_extent.csv` min/max directly onto the WGS84 bbox is incorrect because the extent is a padded experiment candidate window, not the geographic bbox extent. More importantly, even the correct route-frame inverse cannot reproduce the existing-station lon/lat metadata. The earlier conversion therefore had both an extent-stretch error and an unrecognized mixed-frame error.

## Crop bounds: not exactly recoverable

No exact verified WGS84 bounds can be reported. The requested CSV/GeoJSON files contain both candidates and mark them `unverified`:

- Main, route-frame candidate: lon `[123.7162680666, 123.7691403576]`, lat `[41.2857913102, 41.3317092406]`.
- Main, station-frame candidate: lon `[123.7222353993, 123.7753386162]`, lat `[41.2858558560, 41.3318018019]`.
- Secondary, route-frame candidate: lon `[123.4266721087, 123.5973054117]`, lat `[41.6504336985, 41.9813129027]`.
- Secondary, station-frame candidate: lon `[123.4313745976, 123.6027531613]`, lat `[41.6507207205, 41.9818018013]`.

## Geographic interpretation limits

- Main crop inventory: `16` real-map-derived POIs, `960` generated route samples, `0` simulated/proxy existing stations.
- Secondary crop inventory: `45` real-map-derived POIs, `330` generated route samples, `3` simulated/proxy existing stations.
- The main deployment cluster cannot be scientifically classified as a sparsely developed area from the frozen inputs. Road density, building footprints/heights, land use, and population density were explicitly unavailable to the route-agnostic station generator.
- Route endpoints are aligned to their source POIs: `80/80` routes match both POI endpoints within 0.01 m; maximum endpoint residual is `0.001000 m`.
- Original route geometry is two-point straight-line OD geometry for `67/80` routes. Therefore routes are POI-aligned at endpoints but are not road-network-constrained and must not be described as following visible roads.

## Publication safety

The mixed x/y data are **not safe for a single real-map basemap overlay of routes, existing stations, and optimized deployments**. A route-only overlay is reliable under the route frame. A combined publication figure requires rebuilding or explicitly reconciling the station artifact into the route/POI frame, then re-evaluating the experiment because station relocation changes SINR results. Until then, the local-coordinate spatial figure is safe only as a proxy-coordinate schematic.

## Safety

- Optimizations rerun: false.
- Algorithms modified: false.
- `git diff -- src/algorithms` empty: `True`.
- Route/station/POI source artifacts modified: false.
