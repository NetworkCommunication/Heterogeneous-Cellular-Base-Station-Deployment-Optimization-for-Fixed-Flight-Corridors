# Robustness plot caveats

All methods use K=10, the same all-K decision encoding, and the same initial population for each seed. HV, GD, IGD, and AN use `[C_dep, H, -Q_E, -Q_P]`; ASU is not used. AirHERO final-population vectors are postprocessed into this unified objective vector. This is a same-space and same-initialization robustness diagnostic. Internal search scalarization and objective mechanisms are not necessarily identical. DCR and OE are unavailable and are not included.
