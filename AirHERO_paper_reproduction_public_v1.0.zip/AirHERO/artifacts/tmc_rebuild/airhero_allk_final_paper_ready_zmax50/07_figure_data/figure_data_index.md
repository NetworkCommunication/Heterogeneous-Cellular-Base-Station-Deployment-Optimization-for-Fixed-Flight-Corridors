# Final figure data index

All four datasets are extracted without generating publication figures. `4/4` figure datasets are structurally ready for plotting.

| Figure | Demonstrates | Primary plotting file | Ready | Key caveat |
|---|---|---|---:|---|
| Figure 1 | Stage-I to Stage-II spatial deployment evolution | `artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/07_figure_data/01_spatial_stage_evolution/route_samples.csv` | True | Stage-I and Stage-II seed were recovered by deterministic extraction-only Stage-I replay; source package actually uses 150 iterations per stage. |
| Figure 2 | Representative current and predicted route SINR/service profiles | `artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/07_figure_data/02_representative_route_profiles/representative_route_profiles.csv` | True | Routes are deterministic median-positive CCU@0 examples, not maximum-improvement examples. |
| Figure 3 | Route-count by deployment-budget sensitivity | `artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/07_figure_data/03_route_budget_heatmaps/route_budget_heatmap_long.csv` | True | Each canonical cell has one seed (2026); standard deviation is blank and the heatmap is single-seed sensitivity. |
| Figure 4 | Fair optimizer robustness under matched search space and initialization | `artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/07_figure_data/04_fair_optimizer_robustness/robustness_plot_long.csv` | True | Same-space/same-initialization diagnostic; internal search scalarization is not necessarily identical. |

Representative AirHERO seed: `2026`, selected because ASU `0.111293683275` is closest to the three-seed mean `0.111507277165`.

- Selected current route: `sy_predicted_route_0037`.
- Selected predicted route: `sy_predicted_route_0068`.
- Stage-I intermediate data: recovered by a deterministic Stage-I-only replay; no Stage-II optimization rerun.
- Missing data: none among required outputs after the scoped recovery.
- Route-budget cells: `12/12`; each uses seed 2026 only.
- Robustness rows: `84/84` (7 methods x 3 seeds x 4 metrics).
- Configuration caveat: the completed adopted source package records `150` iterations per stage, whereas the task text states 500. Plot data preserve the completed source rather than silently changing it.
