# Optimization robustness claims

- HV/GD/IGD use only objective vectors `[C_dep, H, -Q_E, -Q_P]`; ASU is not used.
- Completed methods: `airhero_allk_stage2_refinement_v1, clpso_extended_true_sinr_asu_v2, csa_extended, immogwo_adapted_same_objective_true_sinr_asu_v2, moead_current_then_future_asu_v2, nsga2_current_then_future_asu_v2, scenario_sampling_robust_deployment_true_sinr_asu_v2`.
- Best mean HV method: `csa_extended`.
- Best mean GD method: `csa_extended`.
- Best mean IGD method: `immogwo_adapted_same_objective_true_sinr_asu_v2`.
- AirHERO mean HV/GD/IGD: `0.025479406944444453` / `0.05195406815359677` / `1.458467343897001`.
- AirHERO source note: the matched main AirHERO source package did not include unified `[C_dep, H, -Q_E, -Q_P]` archive decision exports, so this package recomputes the unified objective vector from each final decoded AirHERO deployment only.
- Safe: describe robustness as matched-main, objective-vector-based, and diagnostic.
- Safe: state that exported-candidate baselines show stronger final-population/archive Pareto coverage in this diagnostic.
- Unsafe: do not claim universal dominance unless every reported metric supports it.
- Unsafe: do not claim AirHERO Pareto-front superiority from this table because AirHERO has only final selected deployment vectors here.
