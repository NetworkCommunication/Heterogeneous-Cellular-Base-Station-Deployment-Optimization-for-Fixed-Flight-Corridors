# Matched-main optimization robustness report

This package reruns optimizer baselines under the matched route80/current33_future47/K10 setting and imports the already completed AirHERO all-K selected deployments.

AirHERO source note: the matched main AirHERO artifact does not contain unified `[C_dep, H, -Q_E, -Q_P]` archive decision exports. To avoid fabricating archive members or reinterpreting internal objectives, this package recomputes the unified objective vector only from each final decoded AirHERO deployment. Therefore, AirHERO HV/GD/IGD rows are diagnostic and cardinality-limited.

## Completed methods

airhero_allk_stage2_refinement_v1, clpso_extended_true_sinr_asu_v2, csa_extended, immogwo_adapted_same_objective_true_sinr_asu_v2, moead_current_then_future_asu_v2, nsga2_current_then_future_asu_v2, scenario_sampling_robust_deployment_true_sinr_asu_v2

## Not applicable

|method|status|reason|
|---|---|---|
|hho_extended|not_applicable|HHO is registered but not included in the final AirHERO main-system table for this package.|
|existing_only/random/kmeans/greedy/5g_only|not_applicable|system/no-deployment baselines are excluded from fair HV/GD/IGD because they do not provide comparable optimizer candidate sets.|

## Summary

|method|HV_mean|GD_mean|IGD_mean|nondominated_count_mean|runtime_seconds_mean|
|---|---|---|---|---|---|
|airhero_allk_stage2_refinement_v1|0.025479406944444453|0.05195406815359677|1.458467343897001|1.0|844.0551133950552|
|clpso_extended_true_sinr_asu_v2|0.1101613241666667|0.030743456992205976|0.41729772664070514|8.666666666666666|771.4032046000162|
|csa_extended|0.11867750583333338|0.0262423659852391|0.5060575220000639|2.6666666666666665|807.6439499855042|
|immogwo_adapted_same_objective_true_sinr_asu_v2|0.1020071005555556|0.045805670139524995|0.377970273644838|7.666666666666667|124.63763499259949|
|moead_current_then_future_asu_v2|0.05174780111111114|0.05213812517076342|0.5234122572267731|5.0|447.0172914663951|
|nsga2_current_then_future_asu_v2|0.07891499000000003|0.07058975524424906|0.4597293234081567|7.333333333333333|149.38992730776468|
|scenario_sampling_robust_deployment_true_sinr_asu_v2|0.05345998472222224|0.12906767284968904|0.4711894075816207|3.6666666666666665|162.00839153925577|

## Interpretation

- Best mean HV: `csa_extended`.
- Best mean GD: `csa_extended`.
- Best mean IGD: `immogwo_adapted_same_objective_true_sinr_asu_v2`.
- AirHERO is not the best method in HV/GD/IGD in this matched diagnostic.
- This table should not be used to claim AirHERO Pareto-front superiority.
- Do not compare this table against old unmatched robustness rows.
