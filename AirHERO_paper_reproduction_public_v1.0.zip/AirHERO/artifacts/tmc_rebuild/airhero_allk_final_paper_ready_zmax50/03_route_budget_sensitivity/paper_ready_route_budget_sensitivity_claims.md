# Route-Budget Sensitivity Claims

- Only adopted all-K AirHERO was rerun; no baselines were rerun.
- K is deployment budget; ASU may be non-monotonic because C_dep and handover burden enter the denominator.
- Use these tables to discuss trends for the adopted AirHERO only, not cross-method superiority.
