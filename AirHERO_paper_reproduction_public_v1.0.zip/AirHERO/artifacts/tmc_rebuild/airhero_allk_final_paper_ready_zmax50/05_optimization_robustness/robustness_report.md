# Robustness report

Finished tasks: `[{"name": "allk_airhero_route80_K10_seed2026", "returncode": 0, "output_root": "artifacts\\tmc_rebuild\\airhero_allk_final_paper_ready_zmax50\\05_optimization_robustness\\allk_airhero_route80_K10_seed2026"}]`.

## Scope note

The all-K AirHERO row was computed for `route80 / current33_future47 / K=10 / seed=2026` using objective vectors `[C_dep, handover_count, -Q_current, -Q_future]`. ASU was not used for HV/GD/IGD.

Existing split-aligned robustness baselines were inspected for reuse, but the available baseline rows cover `current8_future12` and `current21_future29`; no matching `current33_future47` baseline rows were available. Therefore the robustness table is an all-K row diagnostic for the route80 setting, not a complete cross-method route80 HV/GD/IGD comparison.

Safe wording: use this file to document the adopted AirHERO all-K objective-vector export and diagnostic final-population metrics. Do not claim Pareto-front superiority over baselines for route80 from this table alone.
