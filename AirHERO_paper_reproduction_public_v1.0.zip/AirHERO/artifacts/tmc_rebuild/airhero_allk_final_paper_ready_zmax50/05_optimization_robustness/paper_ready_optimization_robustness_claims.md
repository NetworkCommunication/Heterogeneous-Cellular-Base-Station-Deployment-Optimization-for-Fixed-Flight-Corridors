# Optimization robustness claims

HV/GD/IGD are diagnostic final-population metrics from objective vectors only. Do not claim universal Pareto superiority.
