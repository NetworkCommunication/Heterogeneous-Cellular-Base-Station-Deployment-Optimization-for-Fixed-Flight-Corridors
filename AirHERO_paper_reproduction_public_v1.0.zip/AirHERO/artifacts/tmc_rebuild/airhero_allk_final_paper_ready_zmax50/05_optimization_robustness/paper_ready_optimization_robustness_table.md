|method|final_population_HV|final_population_GD|final_population_IGD|AN|DCR|nondominated_count|
|---|---|---|---|---|---|---|
|airhero_allk_stage2_refinement_v1|0.39808879000000014|0.0|0.0||1.0|62|
