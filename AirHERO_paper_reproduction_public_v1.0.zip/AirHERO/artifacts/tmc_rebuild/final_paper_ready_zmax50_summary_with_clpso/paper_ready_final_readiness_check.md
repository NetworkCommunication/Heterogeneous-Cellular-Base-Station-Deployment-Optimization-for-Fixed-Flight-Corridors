| check | status | evidence |
| --- | --- | --- |
| Main system-level comparison uses z_max=50 m | PASS | artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50/final_system_level_integration_with_clpso |
| Main system-level comparison includes CLPSO | PASS | method list |
| Existing-only is no-deployment reference | PASS | method role |
| Extended ablation contains 7 completed variants x 3 seeds | PASS | variants=7 |
| Split-aligned sensitivity final table contains 60 rows | PASS | rows=60 |
| Sensitivity route splits are canonical | PASS | [('20', '8', '12'), ('40', '17', '23'), ('50', '21', '29'), ('80', '33', '47')] |
| Final-population robustness uses final population only | PASS | source package final_population |
| HV/GD/IGD use four-objective vectors | PASS | ASU_used_for_HV_GD_IGD false |
| ASU is not used for HV/GD/IGD | PASS | robustness audit |
| Dense comparison includes CLPSO | PASS | dense with CLPSO |
| Dense stations labeled simulated/proxy | PASS | station safety check |
| No dense real-operator claim | PASS | station safety check |
| Newly deployed stations satisfy z <= 50 m | PASS | source height audits checked in source packages |
| Original route artifact unchanged | PASS | read-only packaging |
| Original low-density station artifact unchanged | PASS | read-only packaging |
| Frozen proposed method unchanged | PASS | git diff -- src/algorithms |
