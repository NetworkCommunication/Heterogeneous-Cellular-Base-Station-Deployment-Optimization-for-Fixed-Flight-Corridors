# Sensitivity Claims

- Final table contains 20, 40, 50, and 80 route settings with splits 8/12, 17/23, 21/29, and 33/47.
- Increasing route_count under fixed K makes the task harder.
- Increasing K often improves coverage but may reduce ASU because ASU-v2 includes deployment cost and handover overhead.
- Do not claim monotonic improvement unless every metric supports it.
- Do not use 10/10 as the main 20-route split.
