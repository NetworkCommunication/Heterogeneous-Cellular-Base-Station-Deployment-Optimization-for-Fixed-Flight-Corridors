# Optimization Robustness Claims

- HV/GD/IGD are final-population optimization diagnostics computed from [C_dep, handover_count, -Q_current, -Q_future].
- ASU is not used for HV/GD/IGD.
- AirHERO has strong HV/IGD and AN/OE in several settings, but GD and DCR are mixed.
- Do not claim stable universal Pareto superiority.
- CLPSO is not available for HV/GD/IGD because final population objective vectors were not exported.
