# Unsafe Claims

- Existing stations are real operator base stations.
- UAV routes are real measured UAV routes.
- AirHERO universally dominates every baseline on every metric.
- Existing-only is a deployment optimization baseline.
- HV/GD/IGD are computed from ASU.
- All baselines are same-objective Pareto optimizers.
- ImMOGWO and scenario-sampling are exact reproductions of the original papers.
- Stage-I is simple blind filling.
- Stagewise concat is the full proposed method.
- 500 m dense infrastructure is a real operator network or universal urban standard.
- The dense scenario proves real-world deployment feasibility.
