# Experiment Section Outline

## V.A Experimental Setup
- Use package index, split audit, dense station audit.
- Caveat: generated/proxy existing stations and generated/proxy semantic POI route points.

## V.B Overall Deployment Performance Comparison
- Table: `paper_ready_main_system_table`.
- Figures: main ASU, Coverage@0, Coverage@10.
- Key claim: AirHERO ranks first by ASU among deployment methods.
- Avoid ranking existing-only as an optimizer.

## V.C Ablation Study
- Table: `paper_ready_ablation_table`.
- Figures: delta ASU and delta Coverage@0.
- Use "blind-spot-aware optimized initialization stage" for Stage-I.

## V.D Parameter Sensitivity Analysis
- Tables: route-count and budget sensitivity.
- Claims must be non-monotonic when ASU and coverage diverge.

## V.E Optimization Robustness Diagnostics
- Table: final-population robustness diagnostics.
- HV/GD/IGD are diagnostic and objective-vector based.

## V.F Discussion
- Dense existing-infrastructure sensitivity and limitations.
- No real operator or real measured airway claims.
