# Final Recommendation

1. Main system comparison: use `formal_K10_true_sinr_height_constrained_zmax50/final_system_level_integration_with_clpso`.
2. Ablation: use `formal_K10_true_sinr_height_constrained_zmax50_ablation` extended files.
3. Sensitivity: use the merged split-aligned paper-ready sensitivity table in this package.
4. Robustness: use split-aligned final-population robustness diagnostics, with canonical 80-route setting.
5. Dense infrastructure: use `full80_all_baselines_with_clpso`.
6. Unconstrained results should not be used as main results.
7. Old non-split-aligned sensitivity results are used only for verified canonical 40/80 settings as instructed.
8. Old 10/10 balanced route-count robustness should not be used as main route-scale evidence.
9. CLPSO should be included in the final system table.
10. CLPSO should not be included in HV/GD/IGD unless final population objective vectors become available.

Main conclusions:
- AirHERO has the highest ASU among deployment methods under z_max=50 m.
- AirHERO improves coverage utilities compared with most optimizer baselines.
- The full method outperforms key ablated variants, especially stagewise concatenation.
- Dense existing-infrastructure sensitivity is useful as a generated/proxy sensitivity analysis.

Key limitations:
- Existing stations are simulated/proxy, not real operator base stations.
- Routes are generated/proxy semantic POI route subsets, not real measured UAV routes.
- HV/GD/IGD are optimization diagnostics and should not be treated as sole system-level evidence.
- CLPSO is scalar ASU-driven and not a same-objective Pareto baseline.

Missing or unavailable data:
- CLPSO final-population HV/GD/IGD unavailable because final population objective vectors were not exported.
