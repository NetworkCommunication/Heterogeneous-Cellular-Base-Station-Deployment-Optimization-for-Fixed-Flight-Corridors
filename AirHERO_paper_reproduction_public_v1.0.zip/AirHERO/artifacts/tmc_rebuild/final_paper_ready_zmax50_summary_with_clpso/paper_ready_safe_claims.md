# Safe Claims

- AirHERO achieves the highest ASU among deployment methods under z_max=50 m.
- AirHERO improves point-wise and continuous coverage utilities compared with most optimizer baselines.
- Stage-I is a blind-spot-aware optimized initialization stage.
- True joint refinement outperforms stagewise current/future concatenation.
- Route-count sensitivity uses deterministic proportional stratified route subsets.
- The 20/40/50/80-route settings use 8/12, 17/23, 21/29, and 33/47 splits.
- Dense existing-infrastructure sensitivity uses generated/proxy 3GPP UMa-like infrastructure.
- HV/GD/IGD are final-population optimization diagnostics.
- HV/GD/IGD are computed from [C_dep, handover_count, -Q_current, -Q_future].
- CLPSO is a classic PSO-family scalar ASU-driven optimizer baseline.
