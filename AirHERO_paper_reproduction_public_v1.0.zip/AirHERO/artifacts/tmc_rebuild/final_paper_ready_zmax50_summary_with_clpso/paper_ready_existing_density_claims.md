# Existing-Density Claims

- Dense station count: `768`.
- Target hard-core / ISD reference: `500.0` m.
- Existing BS height: `25 m`.
- Nearest-neighbor mean / median / min: `2317.6095942581633` / `2061.5528128088304` / `500.0` m.
- AirHERO ASU rank among deployment methods under dense infrastructure: `1`.
- The full 500 m citywide grid would be computationally infeasible and was not used as a real operator deployment claim.
- Existing-only remains a no-deployment reference, not an optimizer baseline.
