| experiment_name | source_path | role_in_paper | used_in_main_paper | auxiliary_only | caveats |
| --- | --- | --- | --- | --- | --- |
| Main z_max=50 system with CLPSO | artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50/final_system_level_integration_with_clpso | main system comparison | True | False |  |
| Extended z_max=50 ablation | artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_ablation | ablation | True | False |  |
| Split-aligned sensitivity | artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_sensitivity_split_aligned | 20/50 route repaired sensitivity source | True | False | Merged with canonical 40/80. |
| Canonical sensitivity | artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_sensitivity | 40/80 route canonical sensitivity source | True | False | Only 40 and 80 used in final table. |
| Route split consistency audit | artifacts/tmc_rebuild/zmax50_route_split_consistency_audit | split policy and audit | True | False |  |
| Split-aligned final-population robustness | artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_optimization_robustness_final_population_split_aligned | 20/50 robustness diagnostics | True | False |  |
| Canonical final-population robustness | artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_optimization_robustness_final_population | 80-route robustness diagnostics | True | False |  |
| Dense existing-infrastructure with CLPSO | artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_existing_density_sensitivity_3gpp_uma_like/full80_all_baselines_with_clpso | existing-density sensitivity | True | False |  |
| Dense station generation audit | artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_existing_density_sensitivity_3gpp_uma_like/station_generation_3gpp_uma_like | dense proxy station audit | True | False |  |
| CLPSO low-density baseline | artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_clpso_baseline | CLPSO baseline source | True | False |  |
| CLPSO dense baseline | artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_existing_density_sensitivity_3gpp_uma_like/clpso_full80 | CLPSO dense baseline source | True | False |  |
