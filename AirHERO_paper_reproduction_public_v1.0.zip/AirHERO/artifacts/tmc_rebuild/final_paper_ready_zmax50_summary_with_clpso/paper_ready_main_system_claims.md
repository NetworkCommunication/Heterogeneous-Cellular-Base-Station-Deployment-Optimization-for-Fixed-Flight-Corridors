# Main System Claims

- AirHERO ASU rank among deployment methods: 1.
- AirHERO ASU improvement over CLPSO-adapted: 0.041026 (57.29%).
- AirHERO ASU improvement over NSGA-II: 0.045584 (67.99%).
- AirHERO ASU improvement over MOEA/D: 0.048808 (76.47%).
- AirHERO ASU improvement over ImMOGWO-adapted: 0.053260 (89.70%).
- AirHERO ASU improvement over Scenario-sampling-inspired: 0.051502 (84.25%).
- Existing-only is excluded from deployment-method rankings because it is a no-deployment reference.
