# Ablation Claims

- Largest ASU drop relative to full AirHERO: `w/o heterogeneous deployment`.
- Stage-I terminology: blind-spot-aware optimized initialization stage.
- Stagewise concat is the old current/future independent optimization and concatenation variant, not the full proposed method.
- True joint refinement outperforms stagewise concat if full AirHERO exceeds `Stagewise concat` in the delta table.
- Component effectiveness should be claimed only for metrics where the full variant improves over the ablated variant.
