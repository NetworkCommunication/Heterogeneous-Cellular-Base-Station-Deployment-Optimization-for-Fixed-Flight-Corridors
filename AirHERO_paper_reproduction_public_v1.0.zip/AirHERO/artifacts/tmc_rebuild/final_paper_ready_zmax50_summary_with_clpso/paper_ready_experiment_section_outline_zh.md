# 实验章节结构建议

## V.A 实验设置
- 使用 package index、路线划分审计和密集既有站审计。
- 明确既有站为生成/代理基础设施，航线为生成/代理语义 POI 航线点。

## V.B 总体部署性能比较
- 使用 `paper_ready_main_system_table`。
- 图：ASU、Coverage@0、Coverage@10。
- 安全结论：AirHERO 在部署方法中 ASU 排名第一。
- 不要把 existing-only 排为部署优化器。

## V.C 消融实验
- 使用 `paper_ready_ablation_table`。
- Stage-I 表述为“盲区感知优化初始化阶段”。
- stagewise concat 不是完整方法。

## V.D 参数敏感性分析
- 使用 route-count 和 budget sensitivity 表。
- ASU 含成本和切换负担，不要强行声称单调提升。

## V.E 优化鲁棒性诊断
- 使用 final-population robustness 表。
- HV/GD/IGD 是目标向量诊断指标，不替代系统效用。

## V.F 讨论
- 讨论密集既有基础设施敏感性和局限。
- 避免真实运营商基站/真实实测航线表述。
