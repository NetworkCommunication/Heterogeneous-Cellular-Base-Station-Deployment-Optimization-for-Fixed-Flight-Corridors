# 3GPP UMa-like Dense Proxy Station Generation Report

- Reused method principle: route-agnostic citywide non-uniform hard-core proxy generation using boundary-derived urban-core score and uniform base intensity.
- Modified hard constraints: target/hard-core ISD `500` m, existing BS antenna height `25` m.
- Actual generated station count: `768`.
- Theoretical whole-study-area 500 m square-spacing count: `64315`.
- Computational cap used for formal optimizer sensitivity: `768`.
- Real operator claim: false.
- Route blind-spot optimization used: false.

| station_artifact | station_count | approximate_study_area_km2 | theoretical_uncapped_station_count_at_500m | computational_target_count_cap | target_ISD_m | actual_mean_nearest_neighbor_m | actual_median_nearest_neighbor_m | actual_min_nearest_neighbor_m | actual_max_nearest_neighbor_m | height_mean_m | height_median_m | height_min_m | height_max_m | type_distribution | tier_distribution | source_label_distribution | route_agnostic_flag | generated_from_route_blind_spots |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_existing_density_sensitivity_3gpp_uma_like/station_generation_3gpp_uma_like/generated_existing_stations_citywide_route_agnostic_3gpp_uma_like_500m.csv | 768 | 16078.738296870002 | 64315 | 768 | 500.0 | 2317.6095942581633 | 2061.5528128088304 | 500.0 | 7778.174593052023 | 25.0 | 25.0 | 25.0 | 25.0 | {"5G": 768} | {"macro_proxy": 768} | {"simulated_proxy_route_agnostic_citywide_existing_infrastructure_3gpp_uma_like_dense": 768} | True | False |

