No optional route-scale optimization was run.
