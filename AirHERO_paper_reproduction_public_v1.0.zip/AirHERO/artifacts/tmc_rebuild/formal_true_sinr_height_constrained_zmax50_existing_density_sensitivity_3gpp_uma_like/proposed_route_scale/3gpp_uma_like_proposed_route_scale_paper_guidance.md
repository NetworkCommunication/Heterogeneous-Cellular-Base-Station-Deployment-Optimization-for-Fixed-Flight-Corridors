Do not claim dense route-scale sensitivity because the optional route-scale run was skipped.
