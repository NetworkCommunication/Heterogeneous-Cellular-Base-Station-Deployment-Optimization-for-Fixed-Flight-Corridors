# Dense existing-infrastructure guidance with CLPSO

- Proposed ASU rank excluding existing-only: `1`.
- CLPSO ASU rank excluding existing-only: `5`.
- CLPSO remains a scalar ASU-driven PSO-family baseline.
- Dense stations are simulated/proxy existing infrastructure, not real operator stations.
