# K10 true-SINR height-constrained deployment report

- New-station decision bound: `z <= 50 m`; original existing stations were read unchanged.
- Completed method-seed units: `30` / `30`; failed: `0`.
- Height compliant after the shared clipping rule: `True`.
- Final true-SINR ASU consistency: `True`.
- Highest deployment-method mean ASU: `true_joint_closed_loop_elite_immigration_response_v3_asu_v2`.
- Proposed mean ASU: `0.1871612529327774`.

The original existing stations remain route-agnostic simulated/proxy infrastructure. Routes remain generated/proxy semantic POI route points. Existing-only is a no-deployment reference; the height constraint does not apply to it. Continuous coverage and route interruptions are computed only between adjacent ordered points belonging to the same route ID.
