# 3GPP UMa-like Dense Existing-Infrastructure Paper Guidance

Safe claims:
- The dense existing-infrastructure sensitivity reuses the same route-agnostic proxy station generation policy.
- The hard constraints are adjusted to a 3GPP UMa-like setting, with 500 m hard-core spacing and 25 m existing-BS antenna height in the generated dense proxy artifact.
- The generated stations are simulated/proxy existing infrastructure.
- All newly deployed stations are constrained to z <= 50 m.
- This experiment evaluates sensitivity to existing-infrastructure density.

Unsafe claims:
- The dense stations are real operator base stations.
- The generated station layout is a real urban deployment.
- The 500 m spacing is a universal urban standard.
- The UAV routes are real measured routes.
- The dense scenario proves real-world deployment feasibility.
- Existing-only is a deployment optimization method.
