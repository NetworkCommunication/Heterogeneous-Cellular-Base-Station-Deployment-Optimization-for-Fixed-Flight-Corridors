# z_max=50 m versus unconstrained guidance

The two packages are distinct variants. Use this comparison to quantify the consequence of limiting only newly deployed-station antenna heights. Treat the earlier unconstrained package as an elevated-height auxiliary variant if the height-constrained package remains complete, compliant, and scientifically adequate.
