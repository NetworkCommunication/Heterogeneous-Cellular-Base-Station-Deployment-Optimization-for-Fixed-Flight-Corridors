# Paper guidance

Use this package as the height-constrained K10 true-SINR formal variant. State that all newly deployed stations are capped at 50 m, while original existing proxy stations are read unchanged. Existing-only should be discussed as a no-deployment cost-efficiency reference, not as a deployment optimizer.

Safe wording:
- Under the z_max=50 m decision constraint, the proposed deployment method achieves the highest mean ASU among deployment methods in this K10 true-SINR package.
- Coverage Utility and Continuous Coverage Utility quantify service adequacy beyond ASU-v2 cost efficiency.
- The constrained and unconstrained packages are separate variants; compare them as a height-limit sensitivity result.

Unsafe wording:
- Do not claim real operator base-station data.
- Do not claim real measured UAV routes.
- Do not claim all physical stations in the scenario are below 50 m; only newly deployed stations are constrained.
- Do not use existing-only as a fair deployment optimizer baseline.
