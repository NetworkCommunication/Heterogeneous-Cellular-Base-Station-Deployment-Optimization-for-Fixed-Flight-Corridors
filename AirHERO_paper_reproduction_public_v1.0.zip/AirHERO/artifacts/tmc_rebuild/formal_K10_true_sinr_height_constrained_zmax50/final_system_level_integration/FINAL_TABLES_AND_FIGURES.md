# Tables and figures

## Tables

- `FINAL_CLAIM_MATRIX.csv`
- `final_asu_consistency.csv`
- `final_deployment_method_ranking_excluding_existing.csv`
- `final_height_constrained_paper_table.csv`
- `final_height_constrained_system_level_comparison_mean_std.csv`
- `final_height_constraint_audit.csv`
- `final_top_journal_baseline_comparison.csv`
- `final_top_journal_relative_improvement.csv`
- `final_zmax50_vs_unconstrained_mean_std_comparison.csv`
- `final_zmax50_vs_unconstrained_relative_change.csv`

## Figures

- `final_zmax50_ASU_by_method.png`
- `final_zmax50_ContinuousCoverageUtility0_by_method.png`
- `final_zmax50_CoverageUtility0_by_method.png`
- `final_zmax50_CoverageUtility10_by_method.png`
- `final_zmax50_runtime_by_method.png`
