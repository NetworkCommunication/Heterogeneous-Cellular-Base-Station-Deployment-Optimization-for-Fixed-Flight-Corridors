# Deployment ranking excluding existing-only

| method_label | rank_ASU | rank_CoverageUtility0 | rank_CoverageUtility10 | rank_ContinuousCoverageUtility0 | rank_ContinuousCoverageUtility10 | rank_route_interruption0 | rank_runtime |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Random | 9 | 9 | 9 | 9 | 9 | 1 | 1 |
| K-means | 5 | 3 | 4 | 3 | 4 | 7 | 3 |
| Greedy | 3 | 2 | 2 | 2 | 2 | 6 | 2 |
| CSA | 2 | 4 | 3 | 4 | 3 | 8 | 7 |
| NSGA-II | 4 | 6 | 5 | 6 | 7 | 4 | 4 |
| MOEA/D | 6 | 8 | 6 | 8 | 5 | 5 | 6 |
| ImMOGWO-adapted | 8 | 7 | 8 | 7 | 8 | 3 | 9 |
| Scenario-sampling | 7 | 5 | 7 | 5 | 6 | 2 | 8 |
| Proposed | 1 | 1 | 1 | 1 | 1 | 9 | 5 |
