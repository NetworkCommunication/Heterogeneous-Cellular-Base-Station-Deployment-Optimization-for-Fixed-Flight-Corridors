# z_max=50 m final integration report

- Package root: `artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50`.
- Completed method-seed units: `30` / `30`; failed units: `0`.
- Shared new-station height cap: `z <= 50 m`.
- Height compliance: `True`.
- Recomputed true-SINR ASU consistency: `True`.
- Highest deployment-method ASU: `Proposed`.
- Proposed mean ASU: `0.112634`.
- Proposed Coverage Utility@10 mean: `0.117222`.

Existing-only is a no-deployment cost-efficiency reference and is not ranked as a deployment optimizer. Existing base stations are simulated/proxy infrastructure; routes are generated/proxy semantic POI route points.
