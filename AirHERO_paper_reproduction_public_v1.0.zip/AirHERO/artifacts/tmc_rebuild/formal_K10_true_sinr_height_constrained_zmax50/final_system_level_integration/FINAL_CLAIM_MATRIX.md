# Claim matrix

| claim | status | evidence |
| --- | --- | --- |
| The z_max=50 m package is complete for all 10 methods and 3 seeds. | strongly supported | completed=30, failed=0 |
| All newly deployed stations satisfy z <= 50 m. | strongly supported | height audit |
| The proposed method is the best deployment method by mean ASU under z_max=50 m. | strongly supported | rank 1 ASU method=Proposed |
| The proposed method is the best deployment method by Coverage Utility@10. | strongly supported | rank 1 CU@10 method=Proposed |
| Existing-only is a deployment optimizer baseline. | must not claim | C_dep=0 no-deployment reference |
| The station data are real operator base stations. | must not claim | proxy/simulated station labels |
| The route data are real measured UAV airways. | must not claim | generated/proxy route labels |
