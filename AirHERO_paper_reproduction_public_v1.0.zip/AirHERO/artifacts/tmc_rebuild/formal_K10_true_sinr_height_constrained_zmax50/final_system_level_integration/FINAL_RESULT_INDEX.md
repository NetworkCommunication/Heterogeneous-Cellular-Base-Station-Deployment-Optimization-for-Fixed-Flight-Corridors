# Final result index

- `final_height_constrained_system_level_comparison_mean_std.csv`: all method mean/std summary.
- `final_height_constrained_paper_table.csv`: compact paper-facing table.
- `final_deployment_method_ranking_excluding_existing.csv`: deployment-method ranks excluding existing-only.
- `final_top_journal_baseline_comparison.csv`: proposed versus adapted/inspired top-journal baselines.
- `final_zmax50_vs_unconstrained_mean_std_comparison.csv`: constrained versus unconstrained comparison.
- `FINAL_CLAIM_MATRIX.md`: supported and unsafe claims.
- `FINAL_PAPER_GUIDANCE.md`: paper-safe wording.
- `FINAL_SAFETY_CHECK.md`: artifact and assumption safety check.
