# Paper guidance: z_max=50 m variant

Safe claims:
- All newly deployed stations are constrained to an antenna installation height no larger than 50 m.
- The same height decision bound and final repair are used for every deployment method.
- Existing stations are route-agnostic simulated/proxy infrastructure and remain unchanged.
- The deployment represents ground infrastructure with constrained antenna installation height.
- All methods use the same final true-SINR ASU-v2 evaluator.

Current result-dependent statement: proposed ranks first among deployment methods by mean ASU: `True`.

Unsafe claims:
- Existing stations are real operator base stations.
- Routes are real measured UAV routes.
- All stations in the full scenario are below 50 m; only new stations are constrained.
- The constrained and unconstrained experiments are the same experiment.
- The result proves universal real-world feasibility.
