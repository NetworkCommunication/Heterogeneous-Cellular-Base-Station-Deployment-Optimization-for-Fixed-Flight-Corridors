# Claim safety with CLPSO

- Proposed ASU rank excluding existing-only: `1`.
- CLPSO ASU rank excluding existing-only: `4`.
- Proposed relative ASU improvement over CLPSO: `57.29202533446182` percent.
- CLPSO is scalar ASU-driven, not same-objective Pareto.
- Existing-only remains a no-deployment reference.
