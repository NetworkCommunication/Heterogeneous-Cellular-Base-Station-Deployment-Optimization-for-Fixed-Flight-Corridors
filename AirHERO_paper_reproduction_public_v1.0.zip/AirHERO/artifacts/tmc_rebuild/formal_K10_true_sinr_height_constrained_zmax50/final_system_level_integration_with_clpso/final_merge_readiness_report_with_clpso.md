# Merge readiness with CLPSO

The CLPSO rows were added from the dedicated CLPSO z_max=50 package. The original final_system_level_integration folder was not overwritten. Use this `with_clpso` folder for paper tables that include CLPSO-adapted.
