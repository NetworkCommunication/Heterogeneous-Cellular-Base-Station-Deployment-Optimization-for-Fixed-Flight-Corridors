# Route Resampling Safety Check

- original_route_artifact_preserved: true
- output_route_artifact_is_new_file: true
- no_poi_regeneration: true
- route_type_labels_preserved: true
- route_order_preserved_by_point_index: true
- no_real_measured_airway_claim: true
