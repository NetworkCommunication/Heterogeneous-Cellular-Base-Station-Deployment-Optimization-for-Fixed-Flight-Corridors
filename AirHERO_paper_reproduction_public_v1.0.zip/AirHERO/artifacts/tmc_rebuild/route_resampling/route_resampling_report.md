# Route Resampling Report

The original route artifact was not overwritten. A new route-point artifact was created.

- Input route artifact: `data\real\shenyang\shenyang_predicted_routes.csv`
- Output route point artifact: `artifacts\tmc_rebuild\route_resampling\shenyang_predicted_routes_resampled_points.csv`
- Total routes: **80**
- Points per route: **30**
- Total route points: **2400**
- Current-priority routes: **33**
- Current-priority points: **990**
- Future-priority routes: **47**
- Future-priority points: **1410**
- Altitude: 100 m default low-altitude UAV altitude.

Route order is preserved using `route_id` and `point_index`. These are generated/proxy semantic POI route points, not real measured airways.
