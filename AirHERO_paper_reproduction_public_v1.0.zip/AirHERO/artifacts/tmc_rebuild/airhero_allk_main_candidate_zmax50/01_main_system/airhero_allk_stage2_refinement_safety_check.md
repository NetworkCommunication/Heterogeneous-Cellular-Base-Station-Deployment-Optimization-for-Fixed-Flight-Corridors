# Safety check

- no frozen formal artifacts overwritten: true
- legacy/proposed optimizer source files modified by this script: false
- `git diff -- src/algorithms` empty: True
- ASU-v2 formula unchanged: true
- station/route/POI artifacts regenerated: false
- generated/proxy labels preserved: true
- exploratory variant clearly separated from formal AirHERO: true
