Not rerun in this partial package because main all-K candidate readiness did not pass replacement criteria.
