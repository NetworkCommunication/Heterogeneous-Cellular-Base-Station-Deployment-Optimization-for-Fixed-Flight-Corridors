# Unsafe claims

- Do not claim all-K refinement improves ASU; mean ASU is lower than the archived previous formal AirHERO.
- Do not claim all requested ablations/sensitivities are complete.
- Do not claim ray tracing, SINR multi-fidelity, QE hard gate, real operator base stations, or real measured UAV routes.
