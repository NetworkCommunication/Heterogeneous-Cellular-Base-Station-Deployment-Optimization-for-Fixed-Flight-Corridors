# Final recommendation

The all-K Stage-II refinement candidate should not replace the previous formal AirHERO in the paper at this point.

Reason: the independent three-seed K10 z_max=50 rerun completed and was internally consistent, but mean ASU decreased from the archived formal AirHERO, only 1/3 seeds improved ASU, and runtime increased substantially. The candidate is useful as a coverage/continuity-oriented diagnostic.
