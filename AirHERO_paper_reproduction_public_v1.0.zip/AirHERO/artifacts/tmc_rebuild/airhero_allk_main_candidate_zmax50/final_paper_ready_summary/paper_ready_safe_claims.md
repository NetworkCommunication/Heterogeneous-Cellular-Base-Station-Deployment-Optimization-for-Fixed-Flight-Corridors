# Safe claims

- AirHERO can be described as a two-stage framework where Stage-II may jointly refine all newly deployed stations only for this candidate package.
- The all-K candidate improves low-threshold route coverage/continuity relative to the previous formal AirHERO in the completed K10 z_max=50 rerun.
- Existing stations are simulated/proxy; routes are generated/proxy semantic POI route samples.
