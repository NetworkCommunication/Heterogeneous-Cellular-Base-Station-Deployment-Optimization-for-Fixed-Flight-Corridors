|section|path|exists|
|---|---|---|
|main_system|artifacts/tmc_rebuild/airhero_allk_main_candidate_zmax50/01_main_system/paper_ready_main_system_table_allk_candidate.csv|True|
|main_ranking|artifacts/tmc_rebuild/airhero_allk_main_candidate_zmax50/01_main_system/paper_ready_main_system_ranking_allk_candidate.csv|True|
|ablation|artifacts/tmc_rebuild/airhero_allk_main_candidate_zmax50/02_ablation/ablation_summary.csv|True|
|ablation_delta|artifacts/tmc_rebuild/airhero_allk_main_candidate_zmax50/02_ablation/ablation_delta_table.csv|True|
