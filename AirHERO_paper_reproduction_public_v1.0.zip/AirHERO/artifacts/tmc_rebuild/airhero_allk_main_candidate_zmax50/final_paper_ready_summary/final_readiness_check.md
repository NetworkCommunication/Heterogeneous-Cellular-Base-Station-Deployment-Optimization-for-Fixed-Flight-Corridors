|criterion|pass|detail|
|---|---|---|
|main_proposed_method_uses_allK_stage2_refinement|True||
|stage2_particle_dimension_is_K_not_K2|True||
|stage2_can_mutate_stage1_stations|True||
|final_deployment_is_ASU_best_allK_stage2_solution|True||
|final_evaluation_uses_all_current_and_predicted_route_points|True||
|baselines_not_rerun|True||
|existing_baseline_tables_only_merged_not_modified|True||
|all_new_proposed_runs_height_violation_zero|True||
|all_new_proposed_runs_asu_recompute_mismatch_zero|True||
|route_count_sensitivity_uses_canonical_splits|False|not rerun in this partial package|
|dense_sensitivity_uses_generated_proxy_3gpp_uma_like|False|not rerun in this partial package|
|no_real_operator_bs_claim|True||
|no_real_measured_uav_route_claim|True||
|no_ray_tracing_claim|True||
|no_sinr_multi_fidelity_claim|True||
|no_qe_hard_gate_claim|True||
|overall_ready_to_replace_previous_formal_airhero|False||
