# Route-budget sensitivity claims

The all-K candidate route-budget sensitivity was not rerun in this package because the main candidate did not pass replacement readiness. Do not claim route-count or K sensitivity for the all-K candidate from this package.
