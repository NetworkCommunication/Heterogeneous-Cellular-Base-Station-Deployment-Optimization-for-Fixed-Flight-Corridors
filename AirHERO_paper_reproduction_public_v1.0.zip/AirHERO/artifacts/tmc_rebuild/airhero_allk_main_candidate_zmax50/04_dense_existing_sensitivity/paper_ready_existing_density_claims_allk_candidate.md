# Existing-density claims

The dense-infrastructure rerun for the all-K candidate was not executed in this package. Do not make dense-infrastructure claims for the all-K candidate from these placeholder files.
