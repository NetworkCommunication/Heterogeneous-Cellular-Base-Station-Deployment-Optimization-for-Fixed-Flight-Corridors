# Dense existing-infrastructure sensitivity

Not rerun because the independent K10 z_max=50 main-candidate rerun did not pass replacement readiness: mean ASU was lower than archived formal AirHERO and only 1/3 seeds improved ASU. No baseline or route/station artifact was modified.
