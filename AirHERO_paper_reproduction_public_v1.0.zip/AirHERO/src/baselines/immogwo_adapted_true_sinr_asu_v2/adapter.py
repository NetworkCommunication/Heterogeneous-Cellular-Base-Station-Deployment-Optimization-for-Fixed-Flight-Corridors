"""ImMOGWO-inspired, not paper-identical, true-SINR deployment baseline."""
from __future__ import annotations
from typing import Any, Dict
import numpy as np
from src.baselines.bio_inspired_common import ASUV2BioInspiredAdapter, clip_to_bounds, extended_asu_v2_config, initialize_population, evaluate_for_asu
from src.baselines.base import BaselineResult
from src.baselines.nsga2_extended.encoding import build_extended_deployment_encoding, unflatten_extended_chromosomes
from src.baselines.nsga2_extended.repair import repair_extended_chromosomes
from src.experiments.multiobjective_metrics import nondominated_mask

class ImMOGWOAdaptedTrueSINRASUV2Adapter(ASUV2BioInspiredAdapter):
    method_key="immogwo_adapted_true_sinr_asu_v2"
    display_name="ImMOGWO-adapted baseline"
    algorithm_name="ImMOGWO-inspired multi-objective grey-wolf search"
    implemented=True
    def run(self, problem, seed, config):
        """Archive-based MOGWO adaptation using the shared four deployment objectives."""
        import time
        rng=np.random.default_rng(int(seed)); cfg=extended_asu_v2_config(config); enc=build_extended_deployment_encoding(cfg); alg=self._algorithm_config(cfg); n=int(alg["population_size"]); iters=int(alg["max_iterations"]);t0=time.time()
        pop=initialize_population(n,enc,problem,cfg,rng); ev=evaluate_for_asu(pop,enc,problem,cfg); obj=self._deployment_objectives(ev); archive_p,archive_o,archive_e=pop.copy(),obj.copy(),ev; levy=sine=0
        for it in range(1,iters+1):
            nd=nondominated_mask(archive_o); leaders=archive_p[nd] if np.any(nd) else pop
            chosen=leaders[rng.integers(0,len(leaders),size=3)] if len(leaders) else pop[:3]
            a=2-2*it/max(iters,1); out=np.zeros_like(pop)
            for lead in chosen:
                r1,r2=rng.random(pop.shape),rng.random(pop.shape);out+=lead[None,:]-(2*a*r1-a)*np.abs(2*r2*lead[None,:]-pop)
            out/=3
            m=rng.random(n)<float(alg["levy_probability"]);out[m]+=rng.standard_cauchy(out[m].shape)*.01*(enc.upper_bounds-enc.lower_bounds);levy+=int(m.sum())
            m=rng.random(n)<float(alg["sine_cosine_probability"]);out[m]+=.1*np.sin(rng.uniform(-np.pi,np.pi,out[m].shape))*(chosen[0][None,:]-out[m]);sine+=int(m.sum())
            pop=repair_extended_chromosomes(clip_to_bounds(out,enc),enc,problem.city_map,cfg,rng);ev=evaluate_for_asu(pop,enc,problem,cfg);obj=self._deployment_objectives(ev)
            archive_p=np.vstack([archive_p,pop]);archive_o=np.vstack([archive_o,obj]); nd=nondominated_mask(archive_o);archive_p,archive_o=archive_p[nd],archive_o[nd]
            if len(archive_p)>80:
                score=np.asarray([self._asu_for_objective(o,archive_o) for o in archive_o]);keep=np.argsort(-score)[:80];archive_p,archive_o=archive_p[keep],archive_o[keep]
        final=evaluate_for_asu(archive_p,enc,problem,cfg);scores=final.asu_scores;best=int(np.argmax(scores));dec=unflatten_extended_chromosomes(archive_p,enc);nd=nondominated_mask(archive_o)
        return BaselineResult(method_name=self.method_key,group=self.group,seed=int(seed),objective_vectors=archive_o,decision_variables=dec,nondominated_objectives=archive_o[nd],nondominated_decisions=dec[nd],runtime_seconds=time.time()-t0,feasible_mask=final.feasible_mask,nondominated_feasible_mask=final.feasible_mask[nd],logs={"method_key":self.method_key,"objective_definition":"[C_dep, handover_count, -Q_current, -Q_future]","objective_selection":"multi-objective archive; representative selected by ASU-v2","best_chromosome":archive_p[best].tolist(),"best_ASU":float(scores[best]),"archive_size":int(len(archive_p)),"levy_perturbation_count":levy,"sine_cosine_update_count":sine,"adaptation_status":"adapted; not exact TCOM 2024 reproduction","asu_preset":"asu_route_service_v2_sinr","uses_tmc_asu":False})
    @staticmethod
    def _deployment_objectives(ev):
        return np.asarray([[float(r.get("C_dep",r.get("deployment_cost",0))),float(r.get("handover_count",0)),-float(r.get("Q_current",0)),-float(r.get("Q_future",0))] for r in ev.asu_records],dtype=float)
    @staticmethod
    def _asu_for_objective(o, all_o):
        # Only archive truncation tie-breaking; ASU never enters the four objectives.
        return -float(np.sum((o-np.min(all_o,axis=0))/np.maximum(np.ptp(all_o,axis=0),1e-12)))
    def _extra_algorithm_config(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        return {"levy_probability":float(raw.get("levy_probability",0.15)),"sine_cosine_probability":float(raw.get("sine_cosine_probability",0.30))}
    def _next_population(self, *, population, scores, iteration, max_iterations, encoding, problem, config, rng, state, alg_cfg):
        order=np.argsort(-scores); leaders=population[order[:min(3,len(order))]]
        while leaders.shape[0]<3: leaders=np.vstack([leaders,leaders[-1:]])
        a=2.0-2.0*iteration/max(max_iterations,1); out=np.zeros_like(population)
        for lead in leaders:
            r1,r2=rng.random(population.shape),rng.random(population.shape); A=2*a*r1-a; C=2*r2
            out += lead[None,:]-A*np.abs(C*lead[None,:]-population)
        out/=3.0
        levy_mask=rng.random(population.shape[0])<float(alg_cfg["levy_probability"])
        if np.any(levy_mask): out[levy_mask]+=rng.standard_cauchy(size=out[levy_mask].shape)*0.01*(encoding.upper_bounds-encoding.lower_bounds)
        sc_mask=rng.random(population.shape[0])<float(alg_cfg["sine_cosine_probability"])
        if np.any(sc_mask):
            phase=rng.uniform(-np.pi,np.pi,size=out[sc_mask].shape)
            out[sc_mask]+=0.10*np.sin(phase)*(leaders[0][None,:]-out[sc_mask])
        state["immogwo_levy_count"]=int(state.get("immogwo_levy_count",0)+np.sum(levy_mask)); state["immogwo_sine_cosine_count"]=int(state.get("immogwo_sine_cosine_count",0)+np.sum(sc_mask))
        return clip_to_bounds(out,encoding)
    def _logs(self, **kwargs):
        out=super()._logs(**kwargs); out.update({"adaptation_status":"adapted; not exact TCOM 2024 reproduction","route_aware_initialization_count":"unavailable: shared seeded initialization is retained for fairness","archive_available":False}); return out
