from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

import numpy as np

from src.data.types import AirRoute, CityMap, Config


class BaselineNotImplementedError(NotImplementedError):
    """Raised by reserved baseline slots that do not yet contain paper logic."""


@dataclass
class DeploymentProblem:
    """Shared deployment problem instance passed to proposed/baseline adapters."""

    config: Config
    city_map: CityMap
    air_route: AirRoute
    channel_params: Config
    route_source_metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def test_points(self) -> np.ndarray:
        return self.air_route.test_points


@dataclass
class BaselineResult:
    """Common return object for all compared methods."""

    method_name: str
    group: str
    seed: int
    objective_vectors: np.ndarray
    decision_variables: np.ndarray
    nondominated_objectives: np.ndarray
    nondominated_decisions: np.ndarray
    runtime_seconds: float
    feasible_mask: Optional[np.ndarray] = None
    nondominated_feasible_mask: Optional[np.ndarray] = None
    logs: Dict[str, Any] = field(default_factory=dict)
    status: str = "ok"
    warning: str = ""


class BaselineAdapter:
    """Common baseline interface.

    Future paper implementations should override `initialize` if they need
    setup, and must override `run` to return objective vectors, decision
    variables, nondominated set, runtime, and logs.
    """

    method_key = "abstract_baseline"
    display_name = "Abstract Baseline"
    group = "baseline"
    implemented = False

    def initialize(self, config: Config, problem: DeploymentProblem) -> None:
        """Optional setup hook before each run."""
        return None

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        """Run one method on one shared problem instance."""
        raise BaselineNotImplementedError(
            f"{self.method_key} is a reserved baseline slot and has not been implemented yet."
        )


def ensure_2d_objectives(objectives: np.ndarray, expected_dim: Optional[int] = None) -> np.ndarray:
    """Validate and coerce objective matrix shape."""
    arr = np.asarray(objectives, dtype=float)
    if arr.size == 0:
        dim = int(expected_dim or 0)
        return np.zeros((0, dim), dtype=float)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    if arr.ndim != 2:
        raise ValueError("objective vectors must be a 2D array")
    if expected_dim is not None and arr.shape[1] != int(expected_dim):
        raise ValueError(f"objective dimension {arr.shape[1]} does not match expected {expected_dim}")
    finite = np.isfinite(arr).all(axis=1)
    return arr[finite]
