from __future__ import annotations

import json
from typing import Any, Dict, List

from src.algorithms.fitness_interface import build_station_type_plan
from src.baselines.base import BaselineResult, DeploymentProblem
from src.baselines.paper_01.adapter import Paper01BaselineAdapter
from src.data.types import Config
from src.experiments.evaluation_consistency import existing_station_particle


class NSGA2PositionOnlyFixedSectorAdapter(Paper01BaselineAdapter):
    """Preserved NSGA-II baseline that optimizes only station coordinates.

    This adapter intentionally wraps the current `paper_01` implementation
    without changing its search behavior. It is a system-level simplified
    baseline, not a same-decision-space optimization-algorithm baseline.
    """

    method_key = "nsga2_position_only_fixed_sector"
    display_name = "NSGA-II-position-only-fixed-sector"
    group = "system_level_position_only_baseline"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        """Run the preserved position-only NSGA-II baseline."""
        result = super().run(problem=problem, seed=seed, config=config)
        result.decision_variables = _prepend_existing(result.decision_variables, config)
        result.nondominated_decisions = _prepend_existing(result.nondominated_decisions, config)
        result.logs.update(_position_only_metadata(config, int(result.decision_variables.shape[1])))
        result.logs["service_evaluation_stations"] = "existing_plus_new"
        result.logs["deployment_cost_scope"] = "new_stations_only"
        return result


def _prepend_existing(decisions, config: Config):
    import numpy as np

    arr = np.asarray(decisions, dtype=float)
    if arr.size == 0 or arr.ndim != 3:
        return arr
    existing = existing_station_particle(config, target_dims=max(arr.shape[2], 5))
    if existing.shape[0] == 0:
        return arr
    if arr.shape[2] < existing.shape[1]:
        padded = np.zeros((arr.shape[0], arr.shape[1], existing.shape[1]), dtype=float)
        padded[:, :, : arr.shape[2]] = arr
        arr = padded
    tiled = np.repeat(existing[None, :, :], arr.shape[0], axis=0)
    if arr.shape[1] >= existing.shape[0] and np.allclose(arr[:, : existing.shape[0], :3], tiled[:, :, :3]):
        return arr
    return np.concatenate([tiled, arr], axis=1)


def _position_only_metadata(config: Config, num_base_stations: int) -> Dict[str, Any]:
    station_plan = build_station_type_plan(config, num_base_stations)
    station_rows: List[Dict[str, Any]] = []
    for idx, station_type in enumerate(station_plan.station_type_names):
        is_5ga = str(station_type).strip().lower() == "5ga"
        station_rows.append(
            {
                "station_id": int(idx + 1),
                "station_type": str(station_type),
                "station_type_source": "fixed/config-derived",
                "sector_direction_source": "fixed/config-derived" if is_5ga else "not_applicable",
                "sector_azimuth_deg": float(station_plan.sector_azimuths_deg[idx]) if is_5ga else None,
            }
        )

    return {
        "baseline_label": "NSGA-II-position-only-fixed-sector",
        "decision_space_label": "position-only fixed-sector",
        "optimized_decision_variables": ["station_x", "station_y", "station_z"],
        "not_optimized_decision_variables": ["station_type", "5ga_sector_direction"],
        "station_type_decision": "fixed/config-derived; not optimized by NSGA-II",
        "sector_direction_decision": "fixed/config-derived for 5GA slots; not optimized by NSGA-II",
        "sector_assignment_mechanism": (
            "Uses build_station_type_plan(config, num_base_stations), which reads fixed station type ratios "
            "and heterogeneousDeployment sectorAzimuthsDeg/defaultSectorAzimuthDeg when present."
        ),
        "fair_optimization_table_eligible": False,
        "excluded_from_main_fair_optimization_table": True,
        "allowed_usage": json.dumps(
            [
                "system-level comparison",
                "ablation",
                "pipeline validation",
                "simplified heuristic comparison",
            ]
        ),
        "station_type_sector_assumptions": station_rows,
    }
