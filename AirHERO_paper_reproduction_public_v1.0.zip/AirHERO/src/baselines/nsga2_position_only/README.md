# NSGA-II-position-only-fixed-sector

This module preserves the current `baseline_paper_01` NSGA-II implementation
under an explicit system-level baseline name.

Decision-space scope:

- Optimizes only station coordinates: `[x, y, z]`.
- Does not optimize `station_type`.
- Does not optimize `5GA sector_direction`.
- Uses the repository's fixed/config-derived station type and 5GA sector
  assumptions through `build_station_type_plan(config, num_base_stations)`.

Allowed use:

- system-level comparison
- ablation
- pipeline validation
- simplified heuristic comparison

This method is intentionally excluded from the main fair optimization-algorithm
HV/GD/IGD comparison table because it does not solve the same decision space as
`proposed_method`.
