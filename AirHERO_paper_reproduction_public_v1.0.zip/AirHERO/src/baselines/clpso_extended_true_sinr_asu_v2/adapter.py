from __future__ import annotations

from typing import Any, Dict

import numpy as np

from src.baselines.bio_inspired_common import ASUV2BioInspiredAdapter, clip_to_bounds


class CLPSOExtendedTrueSINRASUV2Adapter(ASUV2BioInspiredAdapter):
    """Classic CLPSO baseline driven by the official true-SINR ASU-v2 scalar."""

    method_key = "clpso_extended_true_sinr_asu_v2"
    display_name = "CLPSO-adapted"
    algorithm_name = "Comprehensive Learning PSO"
    implemented = True
    default_population_size = 50
    default_max_iterations = 150

    def _extra_algorithm_config(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "inertia_weight": float(raw.get("inertia_weight", raw.get("inertiaWeight", 0.7298))),
            "learning_factor": float(raw.get("learning_factor", raw.get("learningFactor", 1.49618))),
            "velocity_fraction": float(raw.get("velocity_fraction", raw.get("velocityFraction", 0.20))),
            "refresh_gap": int(raw.get("refresh_gap", raw.get("refreshGap", 7))),
            "learning_probability_min": float(raw.get("learning_probability_min", raw.get("learningProbabilityMin", 0.05))),
            "learning_probability_max": float(raw.get("learning_probability_max", raw.get("learningProbabilityMax", 0.50))),
        }

    def _next_population(
        self,
        *,
        population,
        scores,
        iteration,
        max_iterations,
        encoding,
        problem,
        config,
        rng,
        state,
        alg_cfg,
    ):
        pop_size, dim = population.shape
        if "clpso_velocity" not in state:
            span = encoding.upper_bounds - encoding.lower_bounds
            state["clpso_velocity"] = rng.uniform(-0.05, 0.05, size=population.shape) * span
            state["clpso_pbest"] = population.copy()
            state["clpso_pbest_scores"] = np.asarray(scores, dtype=float).copy()
            state["clpso_refresh_counter"] = np.zeros(pop_size, dtype=int)
            state["clpso_exemplars"] = _build_exemplars(state["clpso_pbest_scores"], rng, pop_size, dim, alg_cfg)

        pbest_scores = np.asarray(state["clpso_pbest_scores"], dtype=float)
        improved = np.asarray(scores, dtype=float) > pbest_scores
        if np.any(improved):
            state["clpso_pbest"][improved] = population[improved]
            pbest_scores[improved] = np.asarray(scores, dtype=float)[improved]
            state["clpso_refresh_counter"][improved] = 0
        state["clpso_refresh_counter"][~improved] += 1
        state["clpso_pbest_scores"] = pbest_scores

        refresh_gap = max(1, int(alg_cfg["refresh_gap"]))
        stale = state["clpso_refresh_counter"] >= refresh_gap
        if np.any(stale):
            exemplars = state["clpso_exemplars"]
            stale_indices = np.flatnonzero(stale)
            exemplars[stale_indices] = _build_exemplars(pbest_scores, rng, pop_size, dim, alg_cfg)[stale_indices]
            state["clpso_exemplars"] = exemplars
            state["clpso_refresh_counter"][stale_indices] = 0

        exemplars = np.asarray(state["clpso_exemplars"], dtype=int)
        pbest = np.asarray(state["clpso_pbest"], dtype=float)
        learned = pbest[exemplars, np.arange(dim)[None, :]]

        span = encoding.upper_bounds - encoding.lower_bounds
        vmax = np.maximum(float(alg_cfg["velocity_fraction"]) * span, 1e-12)
        velocity = (
            float(alg_cfg["inertia_weight"]) * np.asarray(state["clpso_velocity"], dtype=float)
            + float(alg_cfg["learning_factor"]) * rng.random(size=population.shape) * (learned - population)
        )
        velocity = np.clip(velocity, -vmax, vmax)
        state["clpso_velocity"] = velocity
        state["clpso_pbest_update_count"] = int(np.sum(improved))
        state["clpso_stale_refresh_count"] = int(np.sum(stale))
        return clip_to_bounds(population + velocity, encoding)

    def _logs(self, **kwargs):
        logs = super()._logs(**kwargs)
        logs.update(
            {
                "paper_facing_name": "CLPSO-adapted",
                "baseline_role": "classic PSO-family scalar ASU-driven optimizer baseline",
                "objective": "maximize official true-SINR ASU-v2 (equivalently minimize -ASU)",
                "selection_metric": "official true-SINR ASU-v2",
                "same_objective_pareto_baseline": False,
                "top_journal_adapted_baseline": False,
                "uses_hv_gd_igd_inside_search": False,
            }
        )
        return logs


def _build_exemplars(
    pbest_scores: np.ndarray,
    rng: np.random.Generator,
    pop_size: int,
    dim: int,
    alg_cfg: Dict[str, Any],
) -> np.ndarray:
    """Choose CLPSO dimension-wise pbest exemplars by tournament on ASU."""
    if pop_size <= 1:
        return np.zeros((pop_size, dim), dtype=int)
    ranks = np.argsort(np.argsort(-np.asarray(pbest_scores, dtype=float)))
    if pop_size == 1:
        probabilities = np.ones(1, dtype=float)
    else:
        lo = float(alg_cfg["learning_probability_min"])
        hi = float(alg_cfg["learning_probability_max"])
        probabilities = lo + (hi - lo) * ranks / max(pop_size - 1, 1)
    exemplars = np.empty((pop_size, dim), dtype=int)
    for i in range(pop_size):
        own = np.full(dim, i, dtype=int)
        candidates_a = rng.integers(0, pop_size, size=dim)
        candidates_b = rng.integers(0, pop_size, size=dim)
        better = np.where(pbest_scores[candidates_a] >= pbest_scores[candidates_b], candidates_a, candidates_b)
        mask = rng.random(dim) < probabilities[i]
        exemplars[i] = np.where(mask, better, own)
        if np.all(exemplars[i] == i):
            j = int(rng.integers(0, dim))
            exemplars[i, j] = int(better[j])
    return exemplars
