"""Classic CLPSO scalar ASU-v2 baseline."""

