# Ablation: Fixed 5GA Sector

Method key: `ablation_fixed_5ga_sector`

This is an ablation-only adapter. It is not the frozen `proposed_method` and is
not eligible for the main fair optimization-algorithm table.

Fixed-sector rule:

- The optimizer does not optimize `5ga_sector_direction_index`.
- `particleEncoding.optimizeSectorDirection` is set to `false` inside this
  adapter's local run config.
- Every 5GA station uses the deterministic configured fixed azimuth
  `heterogeneousDeployment.defaultSectorAzimuthDeg`, snapped by the shared
  sector geometry code to one of the eight compass directions.
- If no fixed azimuth is configured, the adapter uses `0.0` degrees.

All other scenario inputs are inherited from the shared problem instance: map,
routes, existing base stations, station cost parameters, propagation settings,
constraints, and ASU definition.
