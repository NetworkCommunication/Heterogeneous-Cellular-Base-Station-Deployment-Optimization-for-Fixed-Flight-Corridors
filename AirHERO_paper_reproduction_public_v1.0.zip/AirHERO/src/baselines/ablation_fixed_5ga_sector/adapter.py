from __future__ import annotations

import json
import time
from typing import Any, Dict, List

import numpy as np

from src.algorithms.fitness_interface import build_station_type_plan, evaluate_population_objectives
from src.algorithms.improved_mopso import (
    ParetoArchive,
    StagnationIndicators,
    _apply_stagnation_response,
    _build_multi_objectives,
    _build_stagnation_log_entry,
    _classify_stagnation_severity,
    _compute_global_best_change_rate,
    _compute_nondominated_front_change_rate,
    _compute_objective_space_spread,
    _compute_population_radius,
    _compute_quasi_entropy_from_pbest,
    _compute_velocity_norm,
    _enforce_deployment_constraints,
    _initialize_particles,
    _init_adaptive_weight_state,
    _is_quasi_entropy_triggered,
    _non_qe_stagnation_factor_keys,
    _prepare_stage1_restart_sites,
    _search_space_diagonal,
    _should_update_personal_best,
)
from src.algorithms.particle_encoding import (
    SECTOR_INDEX_COL,
    encoding_min_max,
    extend_particles_with_decisions,
    is_extended_particle_array,
    particle_encoding_spec,
    repair_particle_encoding,
)
from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.data.types import Config


class AblationFixed5GASectorAdapter(BaselineAdapter):
    """Ablation-only MOPSO adapter with fixed 5GA sector directions."""

    method_key = "ablation_fixed_5ga_sector"
    display_name = "Ablation: fixed 5GA sector"
    group = "ablation"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        """Run a proposed-like MOPSO ablation without sector-direction optimization."""
        method_cfg = _fixed_sector_config(config)
        config.clear()
        config.update(json.loads(json.dumps(method_cfg)))
        rng = np.random.default_rng(int(seed))
        t0 = time.time()
        result = _run_fixed_sector_mopso(problem=problem, config=method_cfg, rng=rng)
        runtime = float(time.time() - t0)
        result.seed = int(seed)
        result.runtime_seconds = runtime
        return result


def _fixed_sector_config(config: Config) -> Config:
    cfg = json.loads(json.dumps(config))
    cfg.setdefault("experiment", {})
    cfg["experiment"]["method"] = "ablation_fixed_5ga_sector"
    cfg["experiment"]["group"] = "ablation"
    cfg.setdefault("heterogeneousDeployment", {})
    cfg["heterogeneousDeployment"]["enabled"] = True
    cfg["heterogeneousDeployment"]["defaultSectorAzimuthDeg"] = float(
        cfg["heterogeneousDeployment"].get(
            "defaultSectorAzimuthDeg",
            cfg["heterogeneousDeployment"].get("default_sector_azimuth_deg", 0.0),
        )
    )
    cfg.setdefault("particleEncoding", {})
    cfg["particleEncoding"]["optimizeSectorDirection"] = False
    cfg.setdefault("channel", {})
    cfg["channel"]["sector_directions_deg"] = [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]
    return cfg


def _run_fixed_sector_mopso(
    problem: DeploymentProblem,
    config: Config,
    rng: np.random.Generator,
) -> BaselineResult:
    pso_cfg = config["pso"]
    mopso_cfg = config.get("mopso", {})
    num_particles = int(pso_cfg["numParticles"])
    max_iterations = int(pso_cfg["maxIterations"])
    num_base = int(pso_cfg["numBaseStations"])

    w = float(pso_cfg.get("w", 0.729))
    c1 = float(pso_cfg.get("c1", 1.49445))
    c2 = float(pso_cfg.get("c2", 1.49445))
    wdamp = float(pso_cfg.get("wdamp", 0.99))

    spatial_min_pos = np.asarray(pso_cfg["minPosition"], dtype=float)
    spatial_max_pos = np.asarray(pso_cfg["maxPosition"], dtype=float)
    encoding_spec = particle_encoding_spec(config, num_base)
    min_pos, max_pos = encoding_min_max(spatial_min_pos, spatial_max_pos, encoding_spec)
    fixed_sector_index = int(encoding_spec.default_sector_index)

    archive = ParetoArchive(max_size=int(mopso_cfg.get("archiveSize", 80)))
    station_plan = build_station_type_plan(config=config, num_base_stations=num_base)
    evaluation_station_plan = None if encoding_spec.enabled else station_plan
    stagnation_cfg = mopso_cfg.get("stagnation", {})

    positions, init_stats = _initialize_particles(
        config=config,
        test_points=problem.test_points,
        city_map=problem.city_map,
        channel_params=problem.channel_params,
        rng=rng,
        num_particles=num_particles,
        num_base=num_base,
        min_pos=spatial_min_pos,
        max_pos=spatial_max_pos,
    )
    positions = extend_particles_with_decisions(positions, config=config, rng=rng)
    positions = _fix_sector_columns(positions, fixed_sector_index, config)
    positions = _enforce_deployment_constraints(
        positions=positions,
        city_map=problem.city_map,
        min_pos=spatial_min_pos,
        max_pos=spatial_max_pos,
        config=config,
        rng=rng,
    )
    positions = _fix_sector_columns(positions, fixed_sector_index, config)
    stage1_restart_sites = _prepare_stage1_restart_sites(
        config=config,
        test_points=problem.test_points,
        city_map=problem.city_map,
        channel_params=problem.channel_params,
        min_pos=spatial_min_pos,
        rng=rng,
    )

    vel_scale = (max_pos - min_pos) * 0.1
    velocities = (rng.random(positions.shape) - 0.5) * vel_scale[None, None, :]
    velocities = _zero_sector_velocity(velocities)

    pbest_pos = positions.copy()
    pbest_obj = np.full((num_particles, 4), np.inf, dtype=float)
    pbest_comp = np.full((num_particles,), -np.inf, dtype=float)
    pbest_metrics: List[Dict[str, float]] = [_empty_metric_row() for _ in range(num_particles)]

    search_diag = _search_space_diagonal(min_pos=min_pos, max_pos=max_pos, num_base=num_base)
    prev_best_composite = None
    prev_archive_objectives = np.zeros((0, 0), dtype=float)
    qe_initial = None
    adaptive_weight_state = _init_adaptive_weight_state(stagnation_cfg)
    stagnation_logs: List[Dict[str, float | str]] = []
    stagnation_events: List[Dict[str, float | str]] = []
    trigger_stats = {"mild": 0.0, "moderate": 0.0, "severe": 0.0, "low_latency": 0.0, "high_stagnation": 0.0}
    objective_history: List[Dict[str, float]] = []
    non_qe_factor_keys = _non_qe_stagnation_factor_keys(stagnation_cfg)

    for it in range(max_iterations):
        w *= wdamp
        positions = _fix_sector_columns(positions, fixed_sector_index, config)
        batch = evaluate_population_objectives(
            positions=positions,
            test_points=problem.test_points,
            city_map=problem.city_map,
            channel_params=problem.channel_params,
            config=config,
            station_plan=evaluation_station_plan,
        )
        curr_comp = np.asarray(batch.composite, dtype=float)
        curr_obj = _build_multi_objectives(
            handover_count=batch.handover_count,
            deployment_cost=batch.deployment_cost,
            existing_route_continuous_coverage_rate=batch.existing_route_continuous_coverage_rate,
            future_route_continuous_coverage_rate=batch.future_route_continuous_coverage_rate,
        )
        curr_metrics = [batch.at(i) for i in range(num_particles)]

        pbest_update_count = 0
        for i in range(num_particles):
            if _should_update_personal_best(curr_obj[i], float(curr_comp[i]), pbest_obj[i], float(pbest_comp[i])):
                pbest_obj[i] = curr_obj[i]
                pbest_comp[i] = float(curr_comp[i])
                pbest_pos[i] = positions[i]
                pbest_metrics[i] = curr_metrics[i]
                pbest_update_count += 1

        finite_mask = np.isfinite(pbest_obj).all(axis=1)
        archive.update(
            candidate_positions=_fix_sector_columns(pbest_pos[finite_mask], fixed_sector_index, config),
            candidate_objectives=pbest_obj[finite_mask],
            candidate_composite=pbest_comp[finite_mask],
            candidate_metrics=[pbest_metrics[i] for i in np.where(finite_mask)[0]],
        )

        if len(archive) > 0:
            best_idx = int(np.argmax(archive.composite_scores))
            best_comp = float(archive.composite_scores[best_idx])
            best_metrics = archive.metrics[best_idx]
        else:
            best_idx = int(np.argmax(curr_comp))
            best_comp = float(curr_comp[best_idx])
            best_metrics = curr_metrics[best_idx]

        quasi_entropy, qe_meta = _compute_quasi_entropy_from_pbest(pbest_comp=pbest_comp, stagnation_cfg=stagnation_cfg)
        if qe_initial is None:
            qe_initial = float(quasi_entropy)
        qe_theta = float(qe_meta["theta"])
        quasi_entropy_trigger = _is_quasi_entropy_triggered(float(quasi_entropy), float(qe_initial), qe_theta)
        indicators = StagnationIndicators(
            quasi_entropy=float(quasi_entropy),
            quasi_entropy_q0=float(qe_initial),
            quasi_entropy_theta=qe_theta,
            quasi_entropy_trigger=bool(quasi_entropy_trigger),
            quasi_entropy_non_positive_replaced=int(qe_meta["replaced_non_positive_count"]),
            quasi_entropy_selected_count=int(qe_meta["selected_count"]),
            quasi_entropy_ratio=float(quasi_entropy) / max(float(qe_initial), 1e-12),
            global_best_change_rate=_compute_global_best_change_rate(prev_best_composite, best_comp),
            non_dominated_front_change_rate=_compute_nondominated_front_change_rate(
                prev_archive_objectives,
                archive.objectives if len(archive) > 0 else np.zeros((0, 0), dtype=float),
            ),
            population_radius=_compute_population_radius(positions, search_diag),
            pbest_improvement_rate=float(pbest_update_count) / float(max(num_particles, 1)),
            velocity_norm=_compute_velocity_norm(velocities, search_diag),
            leader_archive_diversity=_compute_objective_space_spread(
                archive.objectives if len(archive) > 0 else np.zeros((0, curr_obj.shape[1]), dtype=float)
            ),
            objective_space_spread=_compute_objective_space_spread(curr_obj),
        )
        severity, active_names, stagnation_score, stagnation_diag = _classify_stagnation_severity(
            indicators,
            stagnation_cfg,
            it,
            adaptive_weight_state,
        )
        strategies: Dict[str, Any] = {
            "updated_w": float(w),
            "updated_c1": float(c1),
            "updated_c2": float(c2),
            "low_latency_response": False,
            "high_stagnation_response": False,
            "applied": [],
        }
        if severity != "none":
            trigger_stats[severity] += 1.0
            positions, velocities, strategies = _apply_stagnation_response(
                severity=severity,
                positions=positions,
                velocities=velocities,
                pbest_pos=pbest_pos,
                pbest_obj=pbest_obj,
                pbest_comp=pbest_comp,
                min_pos=min_pos,
                max_pos=max_pos,
                archive=archive,
                city_map=problem.city_map,
                rng=rng,
                config=config,
                current_w=w,
                current_c1=c1,
                current_c2=c2,
                stage1_restart_sites=stage1_restart_sites,
                particle_scores=curr_comp,
            )
            positions = _fix_sector_columns(positions, fixed_sector_index, config)
            velocities = _zero_sector_velocity(velocities)
            if strategies.get("low_latency_response", False):
                trigger_stats["low_latency"] += 1.0
            if strategies.get("high_stagnation_response", False):
                trigger_stats["high_stagnation"] += 1.0
            w = float(strategies.get("updated_w", w))
            c1 = float(strategies.get("updated_c1", c1))
            c2 = float(strategies.get("updated_c2", c2))

        log_entry = _build_stagnation_log_entry(it + 1, severity, stagnation_score, indicators, stagnation_diag, active_names, strategies)
        stagnation_logs.append(log_entry)
        if severity != "none":
            stagnation_events.append(log_entry)

        objective_history.append(
            {
                "best_composite": best_comp,
                "best_handover_count": float(best_metrics.get("handover_count", 0.0)),
                "best_coverage_rate": float(best_metrics.get("coverage_rate", 0.0)),
                "best_deployment_cost": float(best_metrics.get("deployment_cost", 0.0)),
                "population_radius": float(indicators.population_radius),
                "velocity_norm": float(indicators.velocity_norm),
                "stagnation_score": float(stagnation_score),
                **{f"stagnation_factor_{k}": float(stagnation_diag.get("factors", {}).get(k, 0.0)) for k in non_qe_factor_keys if isinstance(stagnation_diag.get("factors", {}), dict)},
            }
        )

        prev_best_composite = float(best_comp)
        prev_archive_objectives = np.asarray(archive.objectives, dtype=float).copy()

        leaders = archive.select_leaders(rng=rng, num_leaders=num_particles) if len(archive) > 0 else pbest_pos
        leaders = _fix_sector_columns(leaders, fixed_sector_index, config)
        r1 = rng.random(positions.shape)
        r2 = rng.random(positions.shape)
        velocities = w * velocities + c1 * r1 * (pbest_pos - positions) + c2 * r2 * (leaders - positions)
        vel_lim = (max_pos - min_pos) * float(mopso_cfg.get("velocityLimitRatio", 0.2))
        velocities = np.clip(velocities, -vel_lim[None, None, :], vel_lim[None, None, :])
        velocities = _zero_sector_velocity(velocities)
        positions = np.clip(positions + velocities, min_pos[None, None, :], max_pos[None, None, :])
        positions = _fix_sector_columns(repair_particle_encoding(positions, config=config), fixed_sector_index, config)
        positions = _enforce_deployment_constraints(
            positions=positions,
            city_map=problem.city_map,
            min_pos=spatial_min_pos,
            max_pos=spatial_max_pos,
            config=config,
            rng=rng,
        )
        positions = _fix_sector_columns(positions, fixed_sector_index, config)

    if len(archive) == 0:
        fallback_idx = int(np.argmax(pbest_comp))
        nd_positions = _fix_sector_columns(pbest_pos[fallback_idx : fallback_idx + 1], fixed_sector_index, config)
        nd_objectives = pbest_obj[fallback_idx : fallback_idx + 1]
        nd_metrics = [pbest_metrics[fallback_idx]]
        objective_vectors = nd_objectives
        decision_variables = nd_positions
    else:
        nd_positions = _fix_sector_columns(archive.positions, fixed_sector_index, config)
        nd_objectives = np.asarray(archive.objectives, dtype=float)
        nd_metrics = list(archive.metrics)
        objective_vectors = nd_objectives
        decision_variables = nd_positions

    feasible = _feasible_mask_from_metrics(nd_metrics, config)
    logs = _ablation_logs(
        config=config,
        fixed_sector_index=fixed_sector_index,
        init_stats=init_stats,
        stagnation_logs=stagnation_logs,
        stagnation_events=stagnation_events,
        trigger_stats=trigger_stats,
        objective_history=objective_history,
    )
    return BaselineResult(
        method_name=AblationFixed5GASectorAdapter.method_key,
        group=AblationFixed5GASectorAdapter.group,
        seed=0,
        objective_vectors=np.asarray(objective_vectors, dtype=float),
        decision_variables=np.asarray(decision_variables, dtype=float),
        nondominated_objectives=np.asarray(nd_objectives, dtype=float),
        nondominated_decisions=np.asarray(nd_positions, dtype=float),
        runtime_seconds=0.0,
        feasible_mask=feasible,
        nondominated_feasible_mask=feasible,
        logs=logs,
    )


def _fix_sector_columns(particles: np.ndarray, fixed_sector_index: int, config: Config) -> np.ndarray:
    arr = np.asarray(particles, dtype=float).copy()
    if is_extended_particle_array(arr):
        arr[..., SECTOR_INDEX_COL] = float(fixed_sector_index)
        arr = repair_particle_encoding(arr, config=config)
        arr[..., SECTOR_INDEX_COL] = float(fixed_sector_index)
    return arr


def _zero_sector_velocity(velocities: np.ndarray) -> np.ndarray:
    arr = np.asarray(velocities, dtype=float).copy()
    if arr.ndim >= 3 and arr.shape[-1] > SECTOR_INDEX_COL:
        arr[..., SECTOR_INDEX_COL] = 0.0
    return arr


def _empty_metric_row() -> Dict[str, float]:
    return {
        "objective_composite": -np.inf,
        "handover_count": float("inf"),
        "coverage_count": 0.0,
        "coverage_rate": 0.0,
        "existing_route_continuous_coverage_rate": 0.0,
        "future_route_continuous_coverage_rate": 0.0,
        "mean_snr_db": 0.0,
        "deployment_cost": float("inf"),
        "cost_effectiveness": 0.0,
        "capacity_effective": 0.0,
        "constraint_penalty": 0.0,
    }


def _feasible_mask_from_metrics(metrics: List[Dict[str, float]], config: Config) -> np.ndarray:
    tol = float(config.get("nsga2", {}).get("feasiblePenaltyTol", 1e-9))
    return np.asarray([float(row.get("constraint_penalty", 0.0)) <= tol for row in metrics], dtype=bool)


def _ablation_logs(
    config: Config,
    fixed_sector_index: int,
    init_stats: Dict[str, float],
    stagnation_logs: List[Dict[str, float | str]],
    stagnation_events: List[Dict[str, float | str]],
    trigger_stats: Dict[str, float],
    objective_history: List[Dict[str, float]],
) -> Dict[str, Any]:
    sector_directions = [float(v) for v in config.get("channel", {}).get("sector_directions_deg", [])]
    fixed_azimuth = sector_directions[fixed_sector_index] if 0 <= fixed_sector_index < len(sector_directions) else 0.0
    optimize_type = bool(config.get("particleEncoding", {}).get("optimizeStationType", False))
    return {
        "baseline_label": "Ablation: fixed 5GA sector",
        "decision_space_label": "fixed-sector ablation",
        "optimized_decision_variables": _optimized_variables(optimize_type),
        "not_optimized_decision_variables": ["5ga_sector_direction_index"],
        "station_type_decision": "same as shared config; optimized only if particleEncoding.optimizeStationType=True",
        "sector_direction_decision": (
            "fixed deterministic ablation: all 5GA sectors use "
            "heterogeneousDeployment.defaultSectorAzimuthDeg snapped to the eight compass directions"
        ),
        "fixed_sector_rule": "all_5ga_use_default_sector_azimuth",
        "fixed_sector_azimuth_deg": float(fixed_azimuth),
        "config_optimizeSectorDirection": False,
        "config_optimizeStationType": optimize_type,
        "uses_same_problem_instance": True,
        "fair_optimization_table_eligible": False,
        "excluded_from_main_fair_optimization_table": True,
        "exclusion_reason": "fixed-sector ablation does not optimize the same 5GA sector-direction decision variable",
        "allowed_usage": json.dumps(["component ablation", "diagnostic sensitivity"], ensure_ascii=False),
        "initialization_stats": init_stats,
        "trigger_stats": trigger_stats,
        "stagnation_logs": stagnation_logs,
        "stagnation_events": stagnation_events,
        "objective_history": objective_history,
    }


def _optimized_variables(optimize_type: bool) -> List[str]:
    values = ["station_x", "station_y", "station_z"]
    if optimize_type:
        values.append("station_type_index")
    return values
