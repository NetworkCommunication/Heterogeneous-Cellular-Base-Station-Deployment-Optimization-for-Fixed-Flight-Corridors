from __future__ import annotations

from typing import Dict, List

from src.baselines._reserved import ReservedPaperBaselineAdapter
from src.baselines.ablation_fixed_5ga_sector.adapter import AblationFixed5GASectorAdapter
from src.baselines.base import BaselineAdapter
from src.baselines.clpso_ls_decomposition_extended.adapter import CLPSOLSDecompositionExtendedAdapter
from src.baselines.clpso_extended_true_sinr_asu_v2.adapter import CLPSOExtendedTrueSINRASUV2Adapter
from src.baselines.csa_extended.adapter import CSAExtendedAdapter
from src.baselines.dummy_baseline.adapter import DummyBaselineAdapter
from src.baselines.gwo_extended.adapter import GWOExtendedAdapter
from src.baselines.hho_extended.adapter import HHOExtendedAdapter
from src.baselines.moead_extended.adapter import MOEADExtendedAdapter
from src.baselines.nsga2_moead_current_future_asu_v2.adapter import (
    MOEADCurrentThenFutureASUV2Adapter,
    NSGA2CurrentThenFutureASUV2Adapter,
)
from src.baselines.nsga2_extended.adapter import NSGA2ExtendedAdapter
from src.baselines.nsga2_position_only.adapter import NSGA2PositionOnlyFixedSectorAdapter
from src.baselines.ppso_extended.adapter import PPSOExtendedAdapter
from src.baselines.proposed_asu_aligned.adapter import ProposedASUAlignedAdapter
from src.baselines.proposed_asu_aligned_v2.adapter import ProposedASUAlignedV2Adapter
from src.baselines.proposed_asu_aligned_v3.adapter import ProposedASUAlignedV3Adapter
from src.baselines.proposed_adapter import ProposedMethodAdapter
from src.baselines.proposed_constrained_station_type.adapter import (
    Proposed5GAOnlyConstrainedAdapter,
    Proposed5GOnlyConstrainedAdapter,
)
from src.baselines.proposed_multifactor_stagnation.adapter import (
    ProposedMultifactorStagnationAdapter,
    ProposedMultifactorStagnationResponseDisabledAdapter,
)
from src.baselines.proposed_qe_corrected.adapter import (
    ProposedQECorrectedAdapter,
    ProposedQECorrectedResponseDisabledAdapter,
)
from src.baselines.proposed_search_expansion_response_v2.adapter import (
    ProposedSearchExpansionResponseV2Adapter,
    ProposedSearchExpansionResponseV2ASUGuardAdapter,
    ProposedSearchExpansionResponseV2DisabledAdapter,
    ProposedSearchExpansionResponseV2MildOnlyAdapter,
    ProposedSearchExpansionResponseV2Restart10Adapter,
    ProposedSearchExpansionResponseV2Restart20Adapter,
    ProposedSearchExpansionResponseV21Adapter,
    ProposedSearchExpansionResponseV21DisabledAdapter,
)
from src.baselines.proposed_search_expansion_response_v2_asu_v2.adapter import (
    ProposedSearchExpansionResponseV2ASUV2Adapter,
    ProposedSearchExpansionResponseV2ASUV2FrozenStage1SequentialAdapter,
    ProposedSearchExpansionResponseV2ASUV2WithoutResponseAdapter,
)
from src.baselines.ssa_extended.adapter import SSAExtendedAdapter
from src.baselines.immogwo_adapted_true_sinr_asu_v2.adapter import ImMOGWOAdaptedTrueSINRASUV2Adapter
from src.baselines.scenario_sampling_robust_deployment_true_sinr_asu_v2.adapter import ScenarioSamplingRobustDeploymentTrueSINRASUV2Adapter
from src.baselines.system_level.adapter import system_level_adapters
from src.baselines.v2_heterogeneous_ablation_asu_v2.adapter import (
    V25GAOnlyCurrentThenFutureAdapter,
    V25GOnlyCurrentThenFutureAdapter,
)
from src.baselines.woa_extended.adapter import WOAExtendedAdapter


def build_method_registry() -> Dict[str, BaselineAdapter]:
    """Return all selectable proposed/baseline method adapters."""
    adapters: List[BaselineAdapter] = [
        ProposedMethodAdapter(),
        ProposedASUAlignedAdapter(),
        ProposedASUAlignedV2Adapter(),
        ProposedASUAlignedV3Adapter(),
        ProposedMultifactorStagnationAdapter(),
        ProposedMultifactorStagnationResponseDisabledAdapter(),
        ProposedQECorrectedAdapter(),
        ProposedQECorrectedResponseDisabledAdapter(),
        ProposedSearchExpansionResponseV2Adapter(),
        ProposedSearchExpansionResponseV2ASUGuardAdapter(),
        ProposedSearchExpansionResponseV2DisabledAdapter(),
        ProposedSearchExpansionResponseV2MildOnlyAdapter(),
        ProposedSearchExpansionResponseV2Restart10Adapter(),
        ProposedSearchExpansionResponseV2Restart20Adapter(),
        ProposedSearchExpansionResponseV2ASUV2Adapter(),
        ProposedSearchExpansionResponseV2ASUV2WithoutResponseAdapter(),
        ProposedSearchExpansionResponseV2ASUV2FrozenStage1SequentialAdapter(),
        ProposedSearchExpansionResponseV21Adapter(),
        ProposedSearchExpansionResponseV21DisabledAdapter(),
        V25GOnlyCurrentThenFutureAdapter(),
        V25GAOnlyCurrentThenFutureAdapter(),
        Proposed5GOnlyConstrainedAdapter(),
        Proposed5GAOnlyConstrainedAdapter(),
        AblationFixed5GASectorAdapter(),
        DummyBaselineAdapter(),
        *system_level_adapters(),
        NSGA2PositionOnlyFixedSectorAdapter(),
        NSGA2ExtendedAdapter(),
        MOEADExtendedAdapter(),
        NSGA2CurrentThenFutureASUV2Adapter(),
        MOEADCurrentThenFutureASUV2Adapter(),
        CLPSOLSDecompositionExtendedAdapter(),
        CLPSOExtendedTrueSINRASUV2Adapter(),
        PPSOExtendedAdapter(),
        CSAExtendedAdapter(),
        GWOExtendedAdapter(),
        WOAExtendedAdapter(),
        SSAExtendedAdapter(),
        HHOExtendedAdapter(),
        ImMOGWOAdaptedTrueSINRASUV2Adapter(),
        ScenarioSamplingRobustDeploymentTrueSINRASUV2Adapter(),
        ReservedPaperBaselineAdapter("baseline_paper_02", "Baseline Paper 02"),
        ReservedPaperBaselineAdapter("baseline_paper_03", "Baseline Paper 03"),
        ReservedPaperBaselineAdapter("baseline_paper_04", "Baseline Paper 04"),
        ReservedPaperBaselineAdapter("baseline_paper_05", "Baseline Paper 05"),
    ]
    return {adapter.method_key: adapter for adapter in adapters}


def get_method_adapter(method_key: str) -> BaselineAdapter:
    """Fetch one adapter by registry key."""
    registry = build_method_registry()
    key = str(method_key).strip()
    if key not in registry:
        valid = ", ".join(sorted(registry.keys()))
        raise KeyError(f"Unknown method key: {method_key}. Valid methods: {valid}")
    return registry[key]


def list_registered_methods() -> List[str]:
    """List registered proposed/baseline method keys."""
    return sorted(build_method_registry().keys())
