from __future__ import annotations

import numpy as np

from src.baselines.bio_inspired_common import ASUV2BioInspiredAdapter, clip_to_bounds, random_population_like


class HHOExtendedAdapter(ASUV2BioInspiredAdapter):
    """Harris Hawks Optimization baseline for ASU-v2 deployment."""

    method_key = "hho_extended"
    display_name = "Harris Hawks Optimization Extended"
    algorithm_name = "Harris Hawks Optimization"
    implemented = True

    def _next_population(self, *, population, scores, iteration, max_iterations, encoding, problem, config, rng, state, alg_cfg):
        rabbit = state["best"]
        mean_pop = np.mean(population, axis=0)
        out = population.copy()
        for i in range(population.shape[0]):
            e0 = 2.0 * float(rng.random()) - 1.0
            escaping_energy = 2.0 * e0 * (1.0 - float(iteration) / max(float(max_iterations), 1.0))
            q = float(rng.random())
            r = float(rng.random())
            if abs(escaping_energy) >= 1.0:
                rand = population[int(rng.integers(0, population.shape[0]))]
                if q < 0.5:
                    out[i] = rand - rng.random(size=population.shape[1]) * np.abs(rand - 2.0 * rng.random(size=population.shape[1]) * population[i])
                else:
                    out[i] = (rabbit - mean_pop) - rng.random(size=population.shape[1]) * (
                        encoding.lower_bounds + rng.random(size=population.shape[1]) * (encoding.upper_bounds - encoding.lower_bounds)
                    )
            else:
                jump_strength = 2.0 * (1.0 - float(rng.random()))
                if r >= 0.5 and abs(escaping_energy) >= 0.5:
                    out[i] = rabbit - escaping_energy * np.abs(jump_strength * rabbit - population[i])
                elif r >= 0.5 and abs(escaping_energy) < 0.5:
                    out[i] = rabbit - escaping_energy * np.abs(rabbit - population[i])
                else:
                    y = rabbit - escaping_energy * np.abs(jump_strength * rabbit - population[i])
                    z = y + rng.normal(0.0, 0.05, size=population.shape[1]) * (encoding.upper_bounds - encoding.lower_bounds)
                    out[i] = z if float(rng.random()) < 0.5 else y
        if not np.isfinite(out).all():
            out = random_population_like(population, encoding, rng)
        return clip_to_bounds(out, encoding)
