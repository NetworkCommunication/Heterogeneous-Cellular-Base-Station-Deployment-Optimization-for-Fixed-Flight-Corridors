from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Tuple

import numpy as np

from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.baselines.moead_extended.adapter import _update_archive
from src.baselines.nsga2_extended.adapter import _validate_station_type_mapping
from src.baselines.nsga2_extended.encoding import (
    NSGA2_SECTOR_AZIMUTHS_DEG,
    build_extended_deployment_encoding,
    unflatten_extended_chromosomes,
)
from src.baselines.nsga2_extended.evaluation import evaluate_extended_chromosomes
from src.baselines.nsga2_extended.initialization import initialize_extended_with_stage2_seeded_particles
from src.baselines.nsga2_extended.repair import repair_extended_chromosomes
from src.baselines.paper_01.nsga2 import environmental_selection, nondominated_indices, rank_population
from src.baselines.paper_01.operators import polynomial_mutation
from src.baselines.ppso_extended.som import (
    LightweightSOM,
    denormalize_decisions,
    neighborhood_indices,
    normalize_decisions,
)
from src.data.types import Config


class PPSOExtendedAdapter(BaselineAdapter):
    """Leader-prediction MOPSO baseline over the full extended deployment vector."""

    method_key = "ppso_extended"
    display_name = "PPSO-Ext"
    group = "fair_optimization_baseline"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        """Run PPSO-Ext on one shared deployment problem."""
        rng = np.random.default_rng(int(seed))
        method_cfg = _extended_config(config)
        _validate_station_type_mapping(method_cfg)
        cfg = _ppso_config(method_cfg)
        encoding = build_extended_deployment_encoding(method_cfg)
        pop_size = int(cfg["swarm_size"])
        max_iter = int(cfg["max_iterations"])
        max_evals = cfg.get("max_evaluations", None)
        max_evals_int = None if max_evals is None else int(max_evals)
        mutation_prob = cfg.get("mutation_probability", None)
        if mutation_prob is None:
            mutation_prob = 1.0 / max(encoding.num_variables, 1)

        t0 = time.time()
        particles, init_stats = initialize_extended_with_stage2_seeded_particles(
            config=method_cfg,
            problem=problem,
            encoding=encoding,
            population_size=pop_size,
            rng=rng,
        )
        velocity = _initial_velocity(pop_size, encoding.num_variables, encoding.lower_bounds, encoding.upper_bounds, rng)
        evaluation = evaluate_extended_chromosomes(particles, encoding, problem, method_cfg)
        objectives = evaluation.objectives
        feasible_mask = evaluation.feasible_mask
        evaluations = int(particles.shape[0])
        archive_x, archive_obj, archive_feasible = _update_archive(
            np.zeros((0, encoding.num_variables), dtype=float),
            np.zeros((0, objectives.shape[1]), dtype=float),
            np.zeros((0,), dtype=bool),
            particles,
            objectives,
            feasible_mask,
            int(cfg["archive_size"]),
        )

        history: List[Dict[str, float]] = []
        som_training_calls = 0
        predicted_pbest_count = 0
        predicted_gbest_count = 0

        for iteration in range(max_iter):
            if max_evals_int is not None and evaluations + pop_size > max_evals_int:
                break

            normalized = normalize_decisions(particles, encoding.lower_bounds, encoding.upper_bounds)
            som = LightweightSOM(
                neuron_count=int(cfg["som_neuron_count"]),
                input_dim=encoding.num_variables,
                rng=rng,
            )
            som_result = som.fit(normalized, int(cfg["som_training_iterations"]))
            som_training_calls += 1
            neuron_decisions = denormalize_decisions(
                som_result.weights,
                encoding.lower_bounds,
                encoding.upper_bounds,
            )
            neuron_decisions = repair_extended_chromosomes(neuron_decisions, encoding, problem.city_map, method_cfg, rng)
            predicted_pbest, predicted_gbest = _predict_leaders(
                particles=particles,
                neuron_decisions=neuron_decisions,
                bmu_indices=som_result.bmu_indices,
                neighbor_count=int(cfg["som_neighbor_count"]),
                rng=rng,
            )
            predicted_pbest = repair_extended_chromosomes(predicted_pbest, encoding, problem.city_map, method_cfg, rng)
            predicted_gbest = repair_extended_chromosomes(predicted_gbest, encoding, problem.city_map, method_cfg, rng)
            predicted_pbest_count += int(predicted_pbest.shape[0])
            predicted_gbest_count += int(predicted_gbest.shape[0])

            inertia = _linear_inertia(iteration, max_iter, float(cfg["inertia_start"]), float(cfg["inertia_end"]))
            alpha1 = rng.uniform(float(cfg["alpha1_range"][0]), float(cfg["alpha1_range"][1]), size=particles.shape)
            alpha2 = rng.uniform(float(cfg["alpha2_range"][0]), float(cfg["alpha2_range"][1]), size=particles.shape)
            velocity = inertia * velocity + alpha1 * (predicted_pbest - particles) + alpha2 * (predicted_gbest - particles)
            velocity = _clip_velocity(velocity, encoding.lower_bounds, encoding.upper_bounds, float(cfg["velocity_clip_ratio"]))
            offspring = particles + velocity
            offspring = repair_extended_chromosomes(offspring, encoding, problem.city_map, method_cfg, rng)
            offspring = polynomial_mutation(
                chromosomes=offspring,
                lower_bounds=encoding.lower_bounds,
                upper_bounds=encoding.upper_bounds,
                mutation_probability=float(mutation_prob),
                distribution_index=float(cfg["mutation_eta"]),
                rng=rng,
            )
            offspring = repair_extended_chromosomes(offspring, encoding, problem.city_map, method_cfg, rng)
            offspring_eval = evaluate_extended_chromosomes(offspring, encoding, problem, method_cfg)
            evaluations += int(offspring.shape[0])

            combined_x = np.vstack([particles, offspring])
            combined_obj = np.vstack([objectives, offspring_eval.objectives])
            combined_feasible = np.concatenate([feasible_mask, offspring_eval.feasible_mask])
            particles, objectives, feasible_mask = _environment_select(
                chromosomes=combined_x,
                objectives=combined_obj,
                feasible_mask=combined_feasible,
                population_size=pop_size,
                mode=str(cfg["environment_selection"]),
            )
            particles = repair_extended_chromosomes(particles, encoding, problem.city_map, method_cfg, rng)

            archive_x, archive_obj, archive_feasible = _update_archive(
                archive_x,
                archive_obj,
                archive_feasible,
                offspring,
                offspring_eval.objectives,
                offspring_eval.feasible_mask,
                int(cfg["archive_size"]),
            )
            history.append(
                {
                    "iteration": float(iteration + 1),
                    "evaluations": float(evaluations),
                    "som_training_calls": float(som_training_calls),
                    "archive_size": float(archive_obj.shape[0]),
                    "num_nondominated_current": float(nondominated_indices(objectives).size),
                    "feasibility_rate": float(np.mean(feasible_mask.astype(float))) if feasible_mask.size else 0.0,
                    "inertia": float(inertia),
                }
            )
            if max_evals_int is not None and evaluations >= max_evals_int:
                break

        if archive_obj.size == 0:
            nd_idx = nondominated_indices(objectives)
            archive_x = particles[nd_idx]
            archive_obj = objectives[nd_idx]
            archive_feasible = feasible_mask[nd_idx]

        runtime = float(time.time() - t0)
        decision_variables = unflatten_extended_chromosomes(particles, encoding)
        nd_decisions = unflatten_extended_chromosomes(archive_x, encoding)
        logs: Dict[str, Any] = {
            "paper": "Leader Prediction for Multiobjective Particle Swarm Optimization",
            "algorithm": "PPSO-Ext leader prediction MOPSO with lightweight SOM",
            "baseline_label": "PPSO-Ext",
            "method_category": "fair_optimization_baseline",
            "decision_space_label": "same-decision-space extended deployment",
            "chromosome_definition": "[x,y,z,station_type_index,sector_direction_index] per deployed station",
            "chromosome_length": int(encoding.num_variables),
            "optimized_decision_variables": [
                "station_x",
                "station_y",
                "station_z",
                "station_type_index",
                "5ga_sector_direction_index",
            ],
            "station_type_decision": "optimized as station_type_index gene",
            "sector_direction_decision": "optimized as 5ga_sector_direction_index gene",
            "station_type_mapping": {"0": "5G", "1": "5GA"},
            "sector_direction_mapping": {str(i): float(v) for i, v in enumerate(NSGA2_SECTOR_AZIMUTHS_DEG.tolist())},
            "som_operates_on": "normalized flattened decision vectors",
            "pbest_prediction_rule": "Map each particle to its SOM best-matching neuron and use that neuron's repaired decision vector.",
            "gbest_prediction_rule": "Randomly select one repaired neuron from the BMU neighborhood for each particle.",
            "mixed_discrete_adaptation": (
                "PPSO updates run in flattened real-coded space; repair clips coordinates and rounds/clips "
                "station_type_index to {0,1} and sector_direction_index to {0,...,7} before leader use, "
                "after velocity movement, and after polynomial mutation."
            ),
            "deviation_from_paper": (
                "The original PPSO leader prediction procedure is adapted to this repository's mixed "
                "continuous-discrete 5G/5GA deployment vector, stage-2 seeded initialization, and shared objective "
                "evaluator. A one-dimensional online SOM is used as a lightweight deterministic substitute when no "
                "external SOM library is available."
            ),
            "uses_fixed_station_type_plan": False,
            "fair_optimization_table_eligible": True,
            "swarm_size": pop_size,
            "generations_completed": len(history),
            "iterations_completed": len(history),
            "evaluations": evaluations,
            "max_evaluations": "" if max_evals_int is None else int(max_evals_int),
            "som_neuron_count": int(cfg["som_neuron_count"]),
            "som_training_iterations": int(cfg["som_training_iterations"]),
            "som_neighbor_count": int(cfg["som_neighbor_count"]),
            "som_training_called": bool(som_training_calls > 0),
            "som_training_calls": int(som_training_calls),
            "predicted_pbest_generated": bool(predicted_pbest_count > 0),
            "predicted_gbest_generated": bool(predicted_gbest_count > 0),
            "predicted_pbest_count": int(predicted_pbest_count),
            "predicted_gbest_count": int(predicted_gbest_count),
            "inertia_start": float(cfg["inertia_start"]),
            "inertia_end": float(cfg["inertia_end"]),
            "alpha1_range": [float(v) for v in cfg["alpha1_range"]],
            "alpha2_range": [float(v) for v in cfg["alpha2_range"]],
            "mutation_probability": float(mutation_prob),
            "mutation_eta": float(cfg["mutation_eta"]),
            "environment_selection": str(cfg["environment_selection"]),
            "archive_size": int(archive_obj.shape[0]),
            "feasibility_rate": float(np.mean(feasible_mask.astype(float))) if feasible_mask.size else 0.0,
            "nondominated_feasibility_rate": (
                float(np.mean(archive_feasible.astype(float))) if archive_feasible.size else 0.0
            ),
            "initialization_stats": init_stats,
            "history": history,
        }
        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=objectives,
            decision_variables=decision_variables,
            nondominated_objectives=archive_obj,
            nondominated_decisions=nd_decisions,
            runtime_seconds=runtime,
            feasible_mask=feasible_mask,
            nondominated_feasible_mask=archive_feasible,
            logs=logs,
        )


def _ppso_config(config: Config) -> Dict[str, Any]:
    raw = dict(config.get("ppso", config.get("ppso_extended", config.get("ppsoExtended", {}))))
    pso = config.get("pso", {})
    swarm_size = int(raw.get("swarm_size", raw.get("swarmSize", pso.get("numParticles", 50))))
    max_iterations = int(raw.get("max_iterations", raw.get("maxIterations", pso.get("maxIterations", 100))))
    neuron_count = int(raw.get("som_neuron_count", raw.get("somNeuronCount", max(swarm_size, 4))))
    environment_selection = str(raw.get("environment_selection", raw.get("environmentSelection", "crowding_distance")))
    if environment_selection not in {"nondominated_sorting", "crowding_distance"}:
        raise ValueError("ppso.environment_selection must be nondominated_sorting or crowding_distance")
    return {
        "swarm_size": max(2, swarm_size),
        "max_iterations": max(0, max_iterations),
        "max_evaluations": raw.get("max_evaluations", raw.get("maxEvaluations", None)),
        "som_neuron_count": max(1, neuron_count),
        "som_training_iterations": int(raw.get("som_training_iterations", raw.get("somTrainingIterations", 20))),
        "som_neighbor_count": int(raw.get("som_neighbor_count", raw.get("somNeighborCount", 1))),
        "inertia_start": float(raw.get("inertia_start", raw.get("inertiaStart", 0.9))),
        "inertia_end": float(raw.get("inertia_end", raw.get("inertiaEnd", 0.4))),
        "alpha1_range": _range(raw.get("alpha1_range", raw.get("alpha1Range", [0.0, 1.0])), 0.0, 1.0),
        "alpha2_range": _range(raw.get("alpha2_range", raw.get("alpha2Range", [-1.0, 1.0])), -1.0, 1.0),
        "mutation_probability": raw.get("mutation_probability", raw.get("mutationProbability", None)),
        "mutation_eta": float(raw.get("mutation_eta", raw.get("mutationEta", 20.0))),
        "archive_size": int(raw.get("archive_size", raw.get("archiveSize", max(swarm_size, 20)))),
        "environment_selection": environment_selection,
        "velocity_clip_ratio": float(raw.get("velocity_clip_ratio", raw.get("velocityClipRatio", 0.25))),
    }


def _extended_config(config: Config) -> Config:
    cfg = json.loads(json.dumps(config))
    cfg.setdefault("heterogeneousDeployment", {})
    cfg["heterogeneousDeployment"]["enabled"] = True
    cfg.setdefault("particleEncoding", {})
    cfg["particleEncoding"]["optimizeStationType"] = True
    cfg["particleEncoding"]["optimizeSectorDirection"] = True
    cfg.setdefault("channel", {})
    cfg["channel"]["sector_directions_deg"] = [float(v) for v in NSGA2_SECTOR_AZIMUTHS_DEG.tolist()]
    repair_cfg = cfg.get("ppso", {}).get("repair", None)
    if repair_cfg is not None:
        cfg.setdefault("nsga2", {})["repair"] = dict(repair_cfg)
    return cfg


def _predict_leaders(
    *,
    particles: np.ndarray,
    neuron_decisions: np.ndarray,
    bmu_indices: np.ndarray,
    neighbor_count: int,
    rng: np.random.Generator,
) -> Tuple[np.ndarray, np.ndarray]:
    pbest = np.asarray(neuron_decisions, dtype=float)[np.asarray(bmu_indices, dtype=int)]
    gbest = np.zeros_like(np.asarray(particles, dtype=float))
    neuron_count = int(neuron_decisions.shape[0])
    for i, bmu in enumerate(np.asarray(bmu_indices, dtype=int)):
        neighbors = neighborhood_indices(int(bmu), neuron_count, int(neighbor_count))
        chosen = int(rng.choice(neighbors)) if neighbors.size else int(bmu)
        gbest[i] = neuron_decisions[chosen]
    return pbest, gbest


def _environment_select(
    *,
    chromosomes: np.ndarray,
    objectives: np.ndarray,
    feasible_mask: np.ndarray,
    population_size: int,
    mode: str,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    if str(mode) == "crowding_distance":
        selected_x, selected_obj, selected_feasible, _ = environmental_selection(
            chromosomes=chromosomes,
            objectives=objectives,
            feasible_mask=feasible_mask,
            population_size=population_size,
        )
        return selected_x, selected_obj, selected_feasible

    ranking = rank_population(objectives)
    selected: List[int] = []
    for front in ranking.fronts:
        if len(selected) + int(front.size) <= int(population_size):
            selected.extend([int(i) for i in front.tolist()])
            continue
        remaining = int(population_size) - len(selected)
        if remaining > 0:
            selected.extend([int(i) for i in front[:remaining].tolist()])
        break
    idx = np.asarray(selected, dtype=int)
    return chromosomes[idx], objectives[idx], feasible_mask[idx]


def _initial_velocity(
    population_size: int,
    num_variables: int,
    lower_bounds: np.ndarray,
    upper_bounds: np.ndarray,
    rng: np.random.Generator,
) -> np.ndarray:
    span = np.maximum(np.asarray(upper_bounds, dtype=float) - np.asarray(lower_bounds, dtype=float), 1e-12)
    return rng.uniform(-0.05, 0.05, size=(int(population_size), int(num_variables))) * span[None, :]


def _clip_velocity(velocity: np.ndarray, lower_bounds: np.ndarray, upper_bounds: np.ndarray, ratio: float) -> np.ndarray:
    span = np.maximum(np.asarray(upper_bounds, dtype=float) - np.asarray(lower_bounds, dtype=float), 1e-12)
    vmax = max(float(ratio), 1e-6) * span
    return np.clip(np.asarray(velocity, dtype=float), -vmax[None, :], vmax[None, :])


def _linear_inertia(iteration: int, max_iterations: int, start: float, end: float) -> float:
    if int(max_iterations) <= 1:
        return float(end)
    ratio = float(np.clip(iteration / max(int(max_iterations) - 1, 1), 0.0, 1.0))
    return float(start + ratio * (end - start))


def _range(raw: Any, lo: float, hi: float) -> Tuple[float, float]:
    values = list(raw) if isinstance(raw, (list, tuple)) else [lo, hi]
    if len(values) != 2:
        raise ValueError("PPSO coefficient range must contain two values")
    a = float(np.clip(float(values[0]), lo, hi))
    b = float(np.clip(float(values[1]), lo, hi))
    return (min(a, b), max(a, b))
