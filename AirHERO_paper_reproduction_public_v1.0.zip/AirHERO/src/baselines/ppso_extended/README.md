# PPSO-Ext

`ppso_extended` implements `PPSO-Ext`, a paper-based fair optimization baseline
for Chapter 5.5.2, based on **Leader Prediction for Multiobjective Particle
Swarm Optimization**.

## SOM Leader Prediction

At every iteration, the current swarm is flattened in the full deployment
decision space and normalized by the configured gene bounds. A lightweight
one-dimensional SOM is trained with deterministic random initialization under
the method seed. SOM weights therefore approximate the current swarm manifold
without allowing large coordinate scales to dominate station type or sector
genes.

## pbest Prediction Rule

Each particle is mapped to its best-matching SOM neuron. That neuron's repaired
decision vector is used as the predicted `pbest` in the PPSO velocity update.

## gbest Prediction Rule

For each particle, PPSO-Ext builds a capped neighborhood around the particle's
best-matching neuron and randomly selects one neighbor neuron as predicted
`gbest`. The selected neuron is repaired before use.

## Mixed-Variable Adaptation

The optimizer uses exactly the same extended vector as `proposed_method` and
`nsga2_extended`:

```text
[x, y, z, station_type_index, sector_direction_index]
```

Velocity updates and polynomial mutation operate in real-valued flattened
space. Repair is applied before leader use, after PSO movement, and after
mutation. Coordinates are clipped to configured bounds and map constraints;
`station_type_index` is rounded/clipped to `0` or `1`; `sector_direction_index`
is rounded/clipped to `0..7`, corresponding exactly to:

```text
[0, 45, 90, 135, 180, 225, 270, 315]
```

## Deviations From Original Paper

The original PPSO paper is adapted to this repository's mixed
continuous-discrete 5G/5GA deployment problem. This implementation uses the
shared stage-2 seeded initialization, shared evaluator, shared constraints, and
external nondominated archive. A compact online SOM is implemented locally
instead of relying on an external SOM package.
