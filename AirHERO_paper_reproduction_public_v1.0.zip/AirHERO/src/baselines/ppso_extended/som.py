from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class SOMTrainingResult:
    """Lightweight SOM outputs used by PPSO-Ext leader prediction."""

    weights: np.ndarray
    bmu_indices: np.ndarray


class LightweightSOM:
    """One-dimensional SOM trained on normalized decision vectors."""

    def __init__(self, neuron_count: int, input_dim: int, rng: np.random.Generator) -> None:
        """Create a deterministic SOM under the caller-provided RNG."""
        self.neuron_count = int(max(neuron_count, 1))
        self.input_dim = int(input_dim)
        self.rng = rng
        self.weights = self.rng.random((self.neuron_count, self.input_dim))

    def fit(self, data: np.ndarray, iterations: int) -> SOMTrainingResult:
        """Train the SOM online and return final best-matching neurons."""
        x = np.asarray(data, dtype=float)
        if x.ndim != 2 or x.shape[1] != self.input_dim:
            raise ValueError("SOM data must have shape [samples, input_dim]")
        if x.shape[0] == 0:
            return SOMTrainingResult(
                weights=self.weights.copy(),
                bmu_indices=np.zeros((0,), dtype=int),
            )

        init_idx = self.rng.choice(x.shape[0], size=self.neuron_count, replace=x.shape[0] < self.neuron_count)
        jitter = 1e-6 * self.rng.normal(size=(self.neuron_count, self.input_dim))
        self.weights = np.clip(x[init_idx] + jitter, 0.0, 1.0)

        total = int(max(iterations, 0))
        if total > 0:
            initial_radius = max(self.neuron_count / 2.0, 1.0)
            for step in range(total):
                sample = x[int(self.rng.integers(0, x.shape[0]))]
                bmu = self.best_matching_unit(sample)
                progress = step / max(total - 1, 1)
                lr = 0.5 * (1.0 - progress) + 0.05 * progress
                radius = max(initial_radius * (1.0 - progress), 1.0)
                grid = np.arange(self.neuron_count, dtype=float)
                influence = np.exp(-np.square(grid - float(bmu)) / (2.0 * radius * radius))
                self.weights += lr * influence[:, None] * (sample[None, :] - self.weights)
                self.weights = np.clip(self.weights, 0.0, 1.0)

        bmu_indices = self.map_samples(x)
        return SOMTrainingResult(weights=self.weights.copy(), bmu_indices=bmu_indices)

    def best_matching_unit(self, sample: np.ndarray) -> int:
        """Return the closest neuron index for one normalized decision vector."""
        distances = np.linalg.norm(self.weights - np.asarray(sample, dtype=float)[None, :], axis=1)
        return int(np.argmin(distances))

    def map_samples(self, data: np.ndarray) -> np.ndarray:
        """Map every sample to its best-matching neuron."""
        x = np.asarray(data, dtype=float)
        distances = np.linalg.norm(x[:, None, :] - self.weights[None, :, :], axis=2)
        return np.argmin(distances, axis=1).astype(int)


def normalize_decisions(chromosomes: np.ndarray, lower_bounds: np.ndarray, upper_bounds: np.ndarray) -> np.ndarray:
    """Normalize mixed decision vectors by configured gene bounds."""
    x = np.asarray(chromosomes, dtype=float)
    lb = np.asarray(lower_bounds, dtype=float)
    ub = np.asarray(upper_bounds, dtype=float)
    span = np.maximum(ub - lb, 1e-12)
    return np.clip((x - lb[None, :]) / span[None, :], 0.0, 1.0)


def denormalize_decisions(normalized: np.ndarray, lower_bounds: np.ndarray, upper_bounds: np.ndarray) -> np.ndarray:
    """Convert normalized SOM neuron weights back to decision-space values."""
    z = np.asarray(normalized, dtype=float)
    lb = np.asarray(lower_bounds, dtype=float)
    ub = np.asarray(upper_bounds, dtype=float)
    return lb[None, :] + np.clip(z, 0.0, 1.0) * (ub - lb)[None, :]


def neighborhood_indices(center: int, neuron_count: int, neighbor_count: int) -> np.ndarray:
    """Return capped one-dimensional SOM neighbor indices around a center neuron."""
    n = int(max(neuron_count, 1))
    radius = int(max(neighbor_count, 0))
    lo = max(int(center) - radius, 0)
    hi = min(int(center) + radius + 1, n)
    return np.arange(lo, hi, dtype=int)
