﻿# TODO for baseline_paper_01

- [ ] Add paper citation and assumptions.
- [ ] Define decision variables.
- [ ] Define initialization procedure.
- [ ] Implement optimization loop or external adapter.
- [ ] Convert outputs to shared minimization objective vectors.
- [ ] Add deterministic seed handling.
- [ ] Add unit tests and toy validation.
