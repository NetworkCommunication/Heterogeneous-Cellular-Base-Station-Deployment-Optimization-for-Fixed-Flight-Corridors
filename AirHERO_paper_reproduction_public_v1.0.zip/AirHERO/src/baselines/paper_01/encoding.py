from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np

from src.data.types import Config


@dataclass(frozen=True)
class DeploymentEncoding:
    """Real-coded chromosome encoding for NSGA-II deployment baseline."""

    num_base_stations: int
    min_position: np.ndarray
    max_position: np.ndarray

    @property
    def num_variables(self) -> int:
        return int(self.num_base_stations * 3)

    @property
    def lower_bounds(self) -> np.ndarray:
        return np.tile(self.min_position, self.num_base_stations)

    @property
    def upper_bounds(self) -> np.ndarray:
        return np.tile(self.max_position, self.num_base_stations)


def build_deployment_encoding(config: Config) -> DeploymentEncoding:
    pso_cfg = config["pso"]
    return DeploymentEncoding(
        num_base_stations=int(pso_cfg["numBaseStations"]),
        min_position=np.asarray(pso_cfg["minPosition"], dtype=float),
        max_position=np.asarray(pso_cfg["maxPosition"], dtype=float),
    )


def flatten_positions(positions: np.ndarray) -> np.ndarray:
    """Convert [population, base, xyz] positions to NSGA-II chromosomes."""
    arr = np.asarray(positions, dtype=float)
    if arr.ndim != 3 or arr.shape[2] < 3:
        raise ValueError("positions must have shape [population, num_base_stations, >=3]")
    return arr[..., :3].reshape(arr.shape[0], -1)


def unflatten_chromosomes(chromosomes: np.ndarray, encoding: DeploymentEncoding) -> np.ndarray:
    """Convert NSGA-II chromosomes to [population, base, xyz] positions."""
    arr = np.asarray(chromosomes, dtype=float)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    if arr.ndim != 2 or arr.shape[1] != encoding.num_variables:
        raise ValueError("chromosomes must have shape [population, num_base_stations * 3]")
    return arr.reshape(arr.shape[0], encoding.num_base_stations, 3)


def clip_chromosomes(chromosomes: np.ndarray, encoding: DeploymentEncoding) -> np.ndarray:
    """Clip chromosomes to configured deployment bounds."""
    return np.clip(
        np.asarray(chromosomes, dtype=float),
        encoding.lower_bounds[None, :],
        encoding.upper_bounds[None, :],
    )


def chromosome_bounds(config: Config) -> Tuple[np.ndarray, np.ndarray]:
    enc = build_deployment_encoding(config)
    return enc.lower_bounds, enc.upper_bounds
