from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

import numpy as np

from src.baselines.base import DeploymentProblem
from src.baselines.paper_01.encoding import DeploymentEncoding, unflatten_chromosomes
from src.data.types import Config
from src.experiments.evaluation_consistency import evaluate_with_existing_context, objective_vector_from_metrics


@dataclass
class NSGA2Evaluation:
    objectives: np.ndarray
    feasible_mask: np.ndarray
    metrics: Dict[str, np.ndarray]


def evaluate_chromosomes(
    chromosomes: np.ndarray,
    encoding: DeploymentEncoding,
    problem: DeploymentProblem,
    config: Config,
) -> NSGA2Evaluation:
    """Evaluate deployment chromosomes using the shared repository objective definitions."""
    positions = unflatten_chromosomes(chromosomes, encoding)
    eval_result = evaluate_with_existing_context(
        decisions=positions,
        problem=problem,
        config=config,
        method_name="nsga2_position_only_fixed_sector",
    )
    metrics_rows = eval_result.metrics
    objectives = np.asarray([objective_vector_from_metrics(row) for row in metrics_rows], dtype=float)
    penalties = np.asarray([float(row.get("constraint_penalty", 0.0)) for row in metrics_rows], dtype=float)
    feasible_mask = np.asarray(penalties <= float(config.get("nsga2", {}).get("feasiblePenaltyTol", 1e-9)))
    metrics = {
        "constraint_penalty": penalties,
        "coverage_rate": np.asarray([float(row.get("coverage_rate", 0.0)) for row in metrics_rows], dtype=float),
        "mean_snr_db": np.asarray([float(row.get("mean_snr_db", 0.0)) for row in metrics_rows], dtype=float),
        "handover_count": np.asarray([float(row.get("handover_count", 0.0)) for row in metrics_rows], dtype=float),
        "deployment_cost": np.asarray([float(row.get("deployment_cost", 0.0)) for row in metrics_rows], dtype=float),
        "existing_route_continuous_coverage_rate": np.asarray(
            [float(row.get("existing_route_continuous_coverage_rate", 0.0)) for row in metrics_rows], dtype=float
        ),
        "future_route_continuous_coverage_rate": np.asarray(
            [float(row.get("future_route_continuous_coverage_rate", 0.0)) for row in metrics_rows], dtype=float
        ),
    }
    return NSGA2Evaluation(objectives=objectives, feasible_mask=feasible_mask, metrics=metrics)


def build_deployment_minimization_objectives(
    handover_count: np.ndarray,
    deployment_cost: np.ndarray,
    existing_route_continuous_coverage_rate: np.ndarray,
    future_route_continuous_coverage_rate: np.ndarray,
) -> np.ndarray:
    """Shared four-objective convention used by the repository metrics."""
    return np.column_stack(
        [
            np.asarray(handover_count, dtype=float),
            np.asarray(deployment_cost, dtype=float),
            1.0 - np.asarray(existing_route_continuous_coverage_rate, dtype=float),
            1.0 - np.asarray(future_route_continuous_coverage_rate, dtype=float),
        ]
    )
