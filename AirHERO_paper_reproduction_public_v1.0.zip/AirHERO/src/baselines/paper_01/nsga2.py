from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np


@dataclass
class RankingResult:
    """Nondominated sorting outputs used by NSGA-II."""

    ranks: np.ndarray
    fronts: List[np.ndarray]
    crowding_distance: np.ndarray


def fast_nondominated_sort(objectives: np.ndarray) -> Tuple[np.ndarray, List[np.ndarray]]:
    """Fast nondominated sorting from NSGA-II for minimization objectives."""
    obj = np.asarray(objectives, dtype=float)
    n = int(obj.shape[0])
    domination_sets: List[List[int]] = [[] for _ in range(n)]
    domination_counts = np.zeros((n,), dtype=int)
    fronts: List[List[int]] = [[]]

    for p in range(n):
        for q in range(n):
            if p == q:
                continue
            if dominates(obj[p], obj[q]):
                domination_sets[p].append(q)
            elif dominates(obj[q], obj[p]):
                domination_counts[p] += 1
        if domination_counts[p] == 0:
            fronts[0].append(p)

    ranks = np.full((n,), np.iinfo(np.int32).max, dtype=int)
    current = 0
    while current < len(fronts) and fronts[current]:
        next_front: List[int] = []
        for p in fronts[current]:
            ranks[p] = current
            for q in domination_sets[p]:
                domination_counts[q] -= 1
                if domination_counts[q] == 0:
                    next_front.append(q)
        current += 1
        if next_front:
            fronts.append(next_front)

    return ranks, [np.asarray(front, dtype=int) for front in fronts if front]


def assign_crowding_distance(objectives: np.ndarray, fronts: List[np.ndarray]) -> np.ndarray:
    """Compute NSGA-II crowding distance in objective space."""
    obj = np.asarray(objectives, dtype=float)
    distances = np.zeros((obj.shape[0],), dtype=float)
    if obj.size == 0:
        return distances

    num_objectives = int(obj.shape[1])
    for front in fronts:
        if front.size == 0:
            continue
        if front.size <= 2:
            distances[front] = np.inf
            continue
        front_obj = obj[front]
        front_dist = np.zeros((front.size,), dtype=float)
        for m in range(num_objectives):
            order = np.argsort(front_obj[:, m], kind="stable")
            front_dist[order[0]] = np.inf
            front_dist[order[-1]] = np.inf
            lo = float(front_obj[order[0], m])
            hi = float(front_obj[order[-1], m])
            span = max(hi - lo, 1e-12)
            for k in range(1, front.size - 1):
                if np.isinf(front_dist[order[k]]):
                    continue
                front_dist[order[k]] += (front_obj[order[k + 1], m] - front_obj[order[k - 1], m]) / span
        distances[front] = front_dist
    return distances


def rank_population(objectives: np.ndarray) -> RankingResult:
    ranks, fronts = fast_nondominated_sort(objectives)
    crowd = assign_crowding_distance(objectives, fronts)
    return RankingResult(ranks=ranks, fronts=fronts, crowding_distance=crowd)


def crowded_tournament_select(
    ranks: np.ndarray,
    crowding_distance: np.ndarray,
    rng: np.random.Generator,
    num_select: int,
) -> np.ndarray:
    """Binary tournament using NSGA-II crowded-comparison operator."""
    n = int(ranks.shape[0])
    chosen = np.zeros((num_select,), dtype=int)
    for i in range(num_select):
        a = int(rng.integers(0, n))
        b = int(rng.integers(0, n))
        chosen[i] = crowded_better(a, b, ranks, crowding_distance)
    return chosen


def crowded_better(a: int, b: int, ranks: np.ndarray, crowding_distance: np.ndarray) -> int:
    if int(ranks[a]) < int(ranks[b]):
        return int(a)
    if int(ranks[b]) < int(ranks[a]):
        return int(b)
    if float(crowding_distance[a]) > float(crowding_distance[b]):
        return int(a)
    if float(crowding_distance[b]) > float(crowding_distance[a]):
        return int(b)
    return int(a)


def environmental_selection(
    chromosomes: np.ndarray,
    objectives: np.ndarray,
    feasible_mask: np.ndarray,
    population_size: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, RankingResult]:
    """Elitist parent+offspring survival selection."""
    ranking = rank_population(objectives)
    selected: List[int] = []
    for front in ranking.fronts:
        if len(selected) + int(front.size) <= population_size:
            selected.extend([int(i) for i in front.tolist()])
            continue
        remaining = population_size - len(selected)
        if remaining <= 0:
            break
        order = sorted(
            [int(i) for i in front.tolist()],
            key=lambda idx: (float(ranking.crowding_distance[idx]), -idx),
            reverse=True,
        )
        selected.extend(order[:remaining])
        break

    idx = np.asarray(selected, dtype=int)
    return chromosomes[idx], objectives[idx], feasible_mask[idx], ranking


def nondominated_indices(objectives: np.ndarray) -> np.ndarray:
    if np.asarray(objectives).size == 0:
        return np.zeros((0,), dtype=int)
    ranks, fronts = fast_nondominated_sort(objectives)
    if not fronts:
        return np.zeros((0,), dtype=int)
    return fronts[0]


def dominates(a: np.ndarray, b: np.ndarray) -> bool:
    return bool(np.all(a <= b) and np.any(a < b))
