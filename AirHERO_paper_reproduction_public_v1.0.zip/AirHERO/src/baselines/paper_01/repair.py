from __future__ import annotations

from typing import Optional, Tuple

import numpy as np

from src.algorithms.init_strategies import enforce_non_building_constraint
from src.baselines.paper_01.encoding import DeploymentEncoding, flatten_positions, unflatten_chromosomes
from src.data.types import CityMap, Config


def repair_chromosomes(
    chromosomes: np.ndarray,
    encoding: DeploymentEncoding,
    city_map: CityMap,
    config: Config,
    rng: np.random.Generator,
) -> np.ndarray:
    """Apply deployment repair local to the NSGA-II baseline."""
    repair_cfg = config.get("nsga2", {}).get("repair", {})
    if not bool(repair_cfg.get("enabled", True)):
        return np.clip(chromosomes, encoding.lower_bounds[None, :], encoding.upper_bounds[None, :])

    positions = unflatten_chromosomes(
        np.clip(chromosomes, encoding.lower_bounds[None, :], encoding.upper_bounds[None, :]),
        encoding,
    )
    if bool(repair_cfg.get("enforceNonBuilding", True)):
        positions = enforce_non_building_constraint(
            positions=positions,
            city_map=city_map,
            min_pos=encoding.min_position,
            max_pos=encoding.max_position,
            rng=rng,
        )
    if bool(repair_cfg.get("enforceRoadCenterAvoidance", True)):
        positions = _repair_road_centerline(
            positions=positions,
            city_map=city_map,
            min_pos=encoding.min_position,
            max_pos=encoding.max_position,
            config=config,
            rng=rng,
        )
        if bool(repair_cfg.get("enforceNonBuilding", True)):
            positions = enforce_non_building_constraint(
                positions=positions,
                city_map=city_map,
                min_pos=encoding.min_position,
                max_pos=encoding.max_position,
                rng=rng,
            )
    return flatten_positions(positions)


def _repair_road_centerline(
    positions: np.ndarray,
    city_map: CityMap,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    config: Config,
    rng: np.random.Generator,
) -> np.ndarray:
    if city_map.road_segments is None:
        return positions
    stage1_cfg = config.get("stage1", {})
    if not bool(stage1_cfg.get("avoidRoadCenter", True)):
        return positions
    out = positions.copy()
    for i in range(out.shape[0]):
        for b in range(out.shape[1]):
            x, y, z = out[i, b]
            out[i, b] = _snap_point_off_road_centerline(
                float(x),
                float(y),
                float(z),
                city_map=city_map,
                min_pos=min_pos,
                max_pos=max_pos,
                stage1_cfg=stage1_cfg,
                rng=rng,
            )
    return out


def _snap_point_off_road_centerline(
    x: float,
    y: float,
    z: float,
    city_map: CityMap,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    stage1_cfg: Config,
    rng: np.random.Generator,
) -> Tuple[float, float, float]:
    clearance = float(stage1_cfg.get("roadCenterClearanceM", 12.0))
    if clearance <= 0.0:
        return x, y, z
    d = _distance_to_nearest_road_centerline(x, y, city_map.road_segments)
    if not np.isfinite(d) or d > clearance:
        return x, y, z

    max_radius = float(stage1_cfg.get("roadSnapMaxRadiusM", max(80.0, clearance * 8.0)))
    step = float(stage1_cfg.get("roadSnapStepM", max(3.0, clearance * 0.5)))
    num_angles = int(max(8, stage1_cfg.get("roadSnapAngles", 24)))
    radii = np.arange(step, max_radius + 1e-9, step, dtype=float)
    for r in radii:
        for k in range(num_angles):
            theta = 2.0 * np.pi * float(k) / float(num_angles)
            cx = float(np.clip(x + r * np.cos(theta), min_pos[0], max_pos[0]))
            cy = float(np.clip(y + r * np.sin(theta), min_pos[1], max_pos[1]))
            cd = _distance_to_nearest_road_centerline(cx, cy, city_map.road_segments)
            if np.isfinite(cd) and cd > clearance:
                return cx, cy, float(np.clip(z, min_pos[2], max_pos[2]))

    for _ in range(80):
        rr = float(rng.uniform(step, max_radius))
        theta = float(rng.uniform(0.0, 2.0 * np.pi))
        cx = float(np.clip(x + rr * np.cos(theta), min_pos[0], max_pos[0]))
        cy = float(np.clip(y + rr * np.sin(theta), min_pos[1], max_pos[1]))
        cd = _distance_to_nearest_road_centerline(cx, cy, city_map.road_segments)
        if np.isfinite(cd) and cd > clearance:
            return cx, cy, float(np.clip(z, min_pos[2], max_pos[2]))
    return x, y, z


def _distance_to_nearest_road_centerline(x: float, y: float, road_segments: Optional[np.ndarray]) -> float:
    if road_segments is None:
        return float("inf")
    segs = np.asarray(road_segments, dtype=float)
    if segs.size == 0 or segs.ndim != 3 or segs.shape[1:] != (2, 2):
        return float("inf")
    p = np.asarray([x, y], dtype=float)
    p0 = segs[:, 0, :]
    p1 = segs[:, 1, :]
    v = p1 - p0
    vv = np.sum(v * v, axis=1)
    valid = vv > 1e-12
    if not np.any(valid):
        return float("inf")
    w = p[None, :] - p0
    t = np.zeros_like(vv)
    t[valid] = np.clip(np.sum(w[valid] * v[valid], axis=1) / vv[valid], 0.0, 1.0)
    proj = p0 + t[:, None] * v
    return float(np.min(np.linalg.norm(proj - p[None, :], axis=1)))
