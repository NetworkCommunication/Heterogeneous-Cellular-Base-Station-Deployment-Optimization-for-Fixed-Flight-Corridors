from __future__ import annotations

import time
from typing import Any, Dict, List

import numpy as np

from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.baselines.paper_01.encoding import build_deployment_encoding, unflatten_chromosomes
from src.baselines.paper_01.evaluation import evaluate_chromosomes
from src.baselines.paper_01.initialization import initialize_with_stage2_seeded_particles
from src.baselines.paper_01.nsga2 import (
    crowded_tournament_select,
    environmental_selection,
    nondominated_indices,
    rank_population,
)
from src.baselines.paper_01.operators import polynomial_mutation, simulated_binary_crossover
from src.baselines.paper_01.repair import repair_chromosomes
from src.data.types import Config


class Paper01BaselineAdapter(BaselineAdapter):
    """NSGA-II baseline from Deb et al., IEEE TEVC 2002."""

    method_key = "baseline_paper_01"
    display_name = "NSGA-II Baseline"
    group = "paper_baseline"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        rng = np.random.default_rng(int(seed))
        cfg = _nsga2_config(config)
        encoding = build_deployment_encoding(config)
        pop_size = int(cfg["populationSize"])
        max_gen = int(cfg["maxGenerations"])
        max_evals = cfg.get("maxEvaluations", None)
        max_evals_int = None if max_evals is None else int(max_evals)
        mutation_prob = cfg.get("mutationProbability", None)
        if mutation_prob is None:
            mutation_prob = 1.0 / max(encoding.num_variables, 1)

        t0 = time.time()
        chromosomes, init_stats = initialize_with_stage2_seeded_particles(
            config=config,
            problem=problem,
            encoding=encoding,
            population_size=pop_size,
            rng=rng,
        )
        evaluation = evaluate_chromosomes(chromosomes, encoding, problem, config)
        objectives = evaluation.objectives
        feasible_mask = evaluation.feasible_mask
        evaluations = int(chromosomes.shape[0])
        history: List[Dict[str, float]] = []

        for gen in range(max_gen):
            ranking = rank_population(objectives)
            selected_idx = crowded_tournament_select(
                ranks=ranking.ranks,
                crowding_distance=ranking.crowding_distance,
                rng=rng,
                num_select=pop_size,
            )
            parents = chromosomes[selected_idx]
            if parents.shape[0] % 2 == 1:
                parents = np.vstack([parents, parents[int(rng.integers(0, parents.shape[0]))]])

            pa = parents[0::2]
            pb = parents[1::2]
            c1, c2 = simulated_binary_crossover(
                parents_a=pa,
                parents_b=pb,
                lower_bounds=encoding.lower_bounds,
                upper_bounds=encoding.upper_bounds,
                crossover_probability=float(cfg["crossoverProbability"]),
                distribution_index=float(cfg["sbxDistributionIndex"]),
                rng=rng,
            )
            offspring = np.vstack([c1, c2])[:pop_size]
            offspring = polynomial_mutation(
                chromosomes=offspring,
                lower_bounds=encoding.lower_bounds,
                upper_bounds=encoding.upper_bounds,
                mutation_probability=float(mutation_prob),
                distribution_index=float(cfg["polynomialMutationDistributionIndex"]),
                rng=rng,
            )
            offspring = repair_chromosomes(offspring, encoding, problem.city_map, config, rng)
            offspring_eval = evaluate_chromosomes(offspring, encoding, problem, config)
            evaluations += int(offspring.shape[0])

            combined_x = np.vstack([chromosomes, offspring])
            combined_obj = np.vstack([objectives, offspring_eval.objectives])
            combined_feasible = np.concatenate([feasible_mask, offspring_eval.feasible_mask])
            chromosomes, objectives, feasible_mask, survival_ranking = environmental_selection(
                chromosomes=combined_x,
                objectives=combined_obj,
                feasible_mask=combined_feasible,
                population_size=pop_size,
            )
            nd_idx = nondominated_indices(objectives)
            history.append(
                {
                    "generation": float(gen + 1),
                    "evaluations": float(evaluations),
                    "num_nondominated": float(nd_idx.size),
                    "feasibility_rate": float(np.mean(feasible_mask.astype(float))) if feasible_mask.size else 0.0,
                    "front_count": float(len(survival_ranking.fronts)),
                }
            )
            if max_evals_int is not None and evaluations >= max_evals_int:
                break

        nd_idx = nondominated_indices(objectives)
        nd_chromosomes = chromosomes[nd_idx]
        nd_objectives = objectives[nd_idx]
        nd_feasible = feasible_mask[nd_idx]
        decision_variables = unflatten_chromosomes(chromosomes, encoding)
        nd_decisions = unflatten_chromosomes(nd_chromosomes, encoding)
        runtime = float(time.time() - t0)
        logs: Dict[str, Any] = {
            "paper": "Deb et al. 2002 NSGA-II",
            "algorithm": "real-coded NSGA-II",
            "deviation_from_paper": "Initial population uses repository stage-2 seeded initialization as requested.",
            "population_size": pop_size,
            "generations_completed": len(history),
            "evaluations": evaluations,
            "crossover_probability": float(cfg["crossoverProbability"]),
            "mutation_probability": float(mutation_prob),
            "sbx_distribution_index": float(cfg["sbxDistributionIndex"]),
            "polynomial_mutation_distribution_index": float(cfg["polynomialMutationDistributionIndex"]),
            "feasibility_rate": float(np.mean(feasible_mask.astype(float))) if feasible_mask.size else 0.0,
            "nondominated_feasibility_rate": float(np.mean(nd_feasible.astype(float))) if nd_feasible.size else 0.0,
            "initialization_stats": init_stats,
            "history": history,
        }
        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=objectives,
            decision_variables=decision_variables,
            nondominated_objectives=nd_objectives,
            nondominated_decisions=nd_decisions,
            runtime_seconds=runtime,
            feasible_mask=feasible_mask,
            nondominated_feasible_mask=nd_feasible,
            logs=logs,
        )


def _nsga2_config(config: Config) -> Dict[str, Any]:
    raw = dict(config.get("nsga2", {}))
    return {
        "populationSize": int(raw.get("populationSize", config.get("pso", {}).get("numParticles", 50))),
        "maxGenerations": int(raw.get("maxGenerations", config.get("pso", {}).get("maxIterations", 100))),
        "maxEvaluations": raw.get("maxEvaluations", None),
        "crossoverProbability": float(raw.get("crossoverProbability", 0.9)),
        "mutationProbability": raw.get("mutationProbability", None),
        "sbxDistributionIndex": float(raw.get("sbxDistributionIndex", 20.0)),
        "polynomialMutationDistributionIndex": float(raw.get("polynomialMutationDistributionIndex", 20.0)),
    }
