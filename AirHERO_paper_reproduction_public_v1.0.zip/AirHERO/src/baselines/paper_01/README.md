﻿# Baseline Paper 01: NSGA-II

Paper:
- K. Deb, A. Pratap, S. Agarwal, and T. Meyarivan, "A Fast and Elitist Multiobjective Genetic Algorithm: NSGA-II," IEEE Transactions on Evolutionary Computation, 2002.

Implemented algorithm:
- Real-coded NSGA-II.
- Fast nondominated sorting.
- Crowding-distance diversity preservation.
- Crowded binary tournament selection.
- Simulated binary crossover (SBX).
- Polynomial mutation.
- Parent+offspring elitist environmental selection.

Repository adaptation:
- Decision vector is flattened 3-D deployment coordinates: `[x1, y1, z1, ..., xn, yn, zn]`.
- Objective vectors use the repository's four minimization objectives:
  1. UAV handover count.
  2. Deployment cost.
  3. Existing-route continuous coverage loss.
  4. Future-route continuous coverage loss.
- Evaluation calls the shared deployment fitness interface.
- Final output is returned as `BaselineResult`.

Deviation from the paper:
- The paper initializes the first population randomly.
- This implementation initializes the first population using the repository's stage-2 seeded deployment initialization, because the experiment owner explicitly requested this.
- The paper's constrained-domination rule is not enabled in this first implementation. The baseline uses repository repair plus the shared objective/penalty evaluation path so it remains comparable with the proposed method.

What remains unchanged:
- Proposed MOPSO implementation.
- Data and route generation pipeline.
- Propagation evaluators.
- Objective definitions.
- HV/GD/IGD metric implementation.
