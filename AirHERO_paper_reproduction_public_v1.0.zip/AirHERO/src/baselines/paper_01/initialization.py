from __future__ import annotations

from typing import Dict, Tuple

import numpy as np

from src.algorithms.stage1_deployment import deploy_stage1_blind_spots
from src.algorithms.stage2_seeded_initialization import build_stage2_seeded_particles
from src.baselines.paper_01.encoding import DeploymentEncoding, flatten_positions
from src.baselines.paper_01.repair import repair_chromosomes
from src.baselines.base import DeploymentProblem
from src.data.types import Config


def initialize_with_stage2_seeded_particles(
    config: Config,
    problem: DeploymentProblem,
    encoding: DeploymentEncoding,
    population_size: int,
    rng: np.random.Generator,
) -> Tuple[np.ndarray, Dict[str, float]]:
    """Use the proposed method's stage-2 initialization result as requested."""
    existing = _load_existing_stations(config=config, default_z=float(encoding.min_position[2]))
    stage1 = deploy_stage1_blind_spots(
        test_points=problem.test_points,
        existing_stations=existing,
        config=config,
        city_map=problem.city_map,
        channel_params=problem.channel_params,
        rng=rng,
    )
    stage2 = build_stage2_seeded_particles(
        stage1_sites=stage1.added_sites,
        existing_stations=existing,
        num_particles=population_size,
        num_base_stations=encoding.num_base_stations,
        min_position=encoding.min_position,
        max_position=encoding.max_position,
        config=config,
        rng=rng,
        city_map=problem.city_map,
    )
    chromosomes = flatten_positions(stage2.particles)
    chromosomes = repair_chromosomes(chromosomes, encoding, problem.city_map, config, rng)
    stats: Dict[str, float] = {}
    stats.update(stage1.stats)
    stats.update(stage2.stats)
    stats["nsga2_initialization_uses_stage2_seeded_particles"] = 1.0
    return chromosomes, stats


def _load_existing_stations(config: Config, default_z: float) -> np.ndarray:
    raw = config.get("heterogeneousDeployment", {}).get("existingStations", [])
    arr = np.asarray(raw, dtype=float)
    if arr.size == 0:
        return np.zeros((0, 3), dtype=float)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    if arr.shape[1] == 2:
        z = np.full((arr.shape[0], 1), default_z, dtype=float)
        arr = np.hstack([arr, z])
    if arr.shape[1] < 3:
        raise ValueError("heterogeneousDeployment.existingStations must contain [x,y,z] or [x,y]")
    return arr[:, :3]
