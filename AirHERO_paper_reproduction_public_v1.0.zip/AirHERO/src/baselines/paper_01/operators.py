from __future__ import annotations

from typing import Tuple

import numpy as np


def simulated_binary_crossover(
    parents_a: np.ndarray,
    parents_b: np.ndarray,
    lower_bounds: np.ndarray,
    upper_bounds: np.ndarray,
    crossover_probability: float,
    distribution_index: float,
    rng: np.random.Generator,
) -> Tuple[np.ndarray, np.ndarray]:
    """Real-coded SBX crossover used by NSGA-II."""
    a = np.asarray(parents_a, dtype=float)
    b = np.asarray(parents_b, dtype=float)
    lb = np.asarray(lower_bounds, dtype=float)
    ub = np.asarray(upper_bounds, dtype=float)
    c1 = a.copy()
    c2 = b.copy()
    pc = float(np.clip(crossover_probability, 0.0, 1.0))
    eta = float(max(distribution_index, 1e-9))

    for i in range(a.shape[0]):
        if rng.random() > pc:
            continue
        for j in range(a.shape[1]):
            if rng.random() > 0.5 or abs(a[i, j] - b[i, j]) <= 1e-14:
                continue
            y1 = min(a[i, j], b[i, j])
            y2 = max(a[i, j], b[i, j])
            yl = lb[j]
            yu = ub[j]
            if yl >= yu:
                continue

            rand = rng.random()
            beta = 1.0 + (2.0 * (y1 - yl) / (y2 - y1))
            alpha = 2.0 - beta ** (-(eta + 1.0))
            if rand <= 1.0 / alpha:
                betaq = (rand * alpha) ** (1.0 / (eta + 1.0))
            else:
                betaq = (1.0 / (2.0 - rand * alpha)) ** (1.0 / (eta + 1.0))
            child1 = 0.5 * ((y1 + y2) - betaq * (y2 - y1))

            beta = 1.0 + (2.0 * (yu - y2) / (y2 - y1))
            alpha = 2.0 - beta ** (-(eta + 1.0))
            if rand <= 1.0 / alpha:
                betaq = (rand * alpha) ** (1.0 / (eta + 1.0))
            else:
                betaq = (1.0 / (2.0 - rand * alpha)) ** (1.0 / (eta + 1.0))
            child2 = 0.5 * ((y1 + y2) + betaq * (y2 - y1))

            child1 = float(np.clip(child1, yl, yu))
            child2 = float(np.clip(child2, yl, yu))
            if rng.random() <= 0.5:
                c1[i, j] = child2
                c2[i, j] = child1
            else:
                c1[i, j] = child1
                c2[i, j] = child2
    return c1, c2


def polynomial_mutation(
    chromosomes: np.ndarray,
    lower_bounds: np.ndarray,
    upper_bounds: np.ndarray,
    mutation_probability: float,
    distribution_index: float,
    rng: np.random.Generator,
) -> np.ndarray:
    """Polynomial mutation for bounded real-coded NSGA-II variables."""
    x = np.asarray(chromosomes, dtype=float).copy()
    lb = np.asarray(lower_bounds, dtype=float)
    ub = np.asarray(upper_bounds, dtype=float)
    pm = float(np.clip(mutation_probability, 0.0, 1.0))
    eta = float(max(distribution_index, 1e-9))

    for i in range(x.shape[0]):
        for j in range(x.shape[1]):
            if rng.random() > pm or ub[j] <= lb[j]:
                continue
            y = x[i, j]
            delta1 = (y - lb[j]) / (ub[j] - lb[j])
            delta2 = (ub[j] - y) / (ub[j] - lb[j])
            rand = rng.random()
            mut_pow = 1.0 / (eta + 1.0)
            if rand <= 0.5:
                xy = 1.0 - delta1
                val = 2.0 * rand + (1.0 - 2.0 * rand) * (xy ** (eta + 1.0))
                deltaq = val**mut_pow - 1.0
            else:
                xy = 1.0 - delta2
                val = 2.0 * (1.0 - rand) + 2.0 * (rand - 0.5) * (xy ** (eta + 1.0))
                deltaq = 1.0 - val**mut_pow
            y = y + deltaq * (ub[j] - lb[j])
            x[i, j] = float(np.clip(y, lb[j], ub[j]))
    return x
