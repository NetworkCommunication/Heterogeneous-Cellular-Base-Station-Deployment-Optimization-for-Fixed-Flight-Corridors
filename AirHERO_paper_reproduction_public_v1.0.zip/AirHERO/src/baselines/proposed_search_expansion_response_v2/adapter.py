from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.baselines.proposed_asu_aligned.adapter import (
    _best_sector_index,
    _initialize_population,
    _repair_particles,
    _station_type_count,
)
from src.baselines.proposed_multifactor_stagnation.adapter import (
    _better_for_personal_best,
    _composite_min_scores,
    _crowding_distance,
    _evaluate_particles,
    _objective_entropy,
    _protected_archive_summary,
    _quasi_entropy,
    _sector_values_valid,
    _select_leaders,
    _sparse_archive_indices,
    _truncate_archive,
)
from src.data.types import Config
from src.experiments.airway_service_utility import materialize_asu_config
from src.experiments.multiobjective_metrics import nondominated_mask
from src.propagation.sector_geometry import DEFAULT_SECTOR_DIRECTIONS_DEG


@dataclass
class _PendingResponse:
    iteration: int
    evaluate_at: int
    severity: str
    before: Dict[str, float]


@dataclass
class _SearchState:
    score_window: List[float] = field(default_factory=list)
    coverage_history: List[float] = field(default_factory=list)
    novelty_history: List[float] = field(default_factory=list)
    entropy_history: List[float] = field(default_factory=list)
    nd_history: List[int] = field(default_factory=list)
    movement_history: List[float] = field(default_factory=list)
    initial_qe: Optional[float] = None
    last_response_iter: int = -10_000
    response_count: int = 0
    cooldown_extension: int = 0
    response_fraction_scale: float = 1.0
    pre_response_asu_baseline: Optional[float] = None
    v21_future_downshift_steps: int = 0
    v21_cumulative_guard_level: int = 0
    mild_boost_until: int = -1
    severity_cap: str = "severe"
    pending: Optional[_PendingResponse] = None


class ProposedSearchExpansionResponseV2Adapter(BaselineAdapter):
    """Conservative search-expansion response diagnostic with pbest-preserving restarts."""

    method_key = "proposed_method_search_expansion_response_v2"
    display_name = "Proposed Search Expansion Response V2"
    group = "proposed_search_expansion_response_v2"
    implemented = True
    response_enabled_default = True
    mild_only_default = False
    severe_restart_fraction_default = 0.20

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        cfg = _method_config(
            config,
            self.method_key,
            response_enabled=self.response_enabled_default,
            mild_only=self.mild_only_default,
            severe_restart_fraction=self.severe_restart_fraction_default,
        )
        config.clear()
        config.update(json.loads(json.dumps(cfg)))
        v2 = cfg["searchExpansionResponseV2"]
        rng = np.random.default_rng(int(seed))
        t0 = time.time()
        pso = cfg.get("pso", {})
        pop_size = int(pso.get("numParticles", 40))
        max_iter = int(pso.get("maxIterations", 320))
        k = int(pso.get("numBaseStations", cfg.get("stage1", {}).get("numNewStations", 1)))
        archive_size = int(cfg.get("mopso", {}).get("archiveSize", 40))
        min_pos = np.asarray(pso.get("minPosition", [0.0, 0.0, 20.0]), dtype=float)
        max_pos = np.asarray(pso.get("maxPosition", [problem.city_map.size_x, problem.city_map.size_y, 160.0]), dtype=float)
        logs: Dict[str, Any] = {
            "method_key": self.method_key,
            "implementation_revision": "search_expansion_response_v2",
            "legacy_proposed_preserved": True,
            "response_enabled": bool(v2["response_enabled"]),
            "asu_guard_enabled": bool(v2.get("asuGuardEnabled", False)),
            "asu_guard_drop_ratio": float(v2.get("asuGuardDropRatio", 0.05)),
            "qe_auxiliary_only": True,
            "qe_hard_gate": False,
            "pbest_preserved_during_restart": True,
            "response_severity_log": [],
            "response_action_log": [],
            "response_acceptance_log": [],
            "response_before_after_metrics": [],
            "stagnation_score_trace": [],
            "stage1_seed_summary": [],
        }

        particles, stage1_summary = _initialize_population(problem, cfg, rng, pop_size, k, min_pos, max_pos)
        logs["stage1_seed_summary"].extend(stage1_summary)
        velocities = (rng.random((pop_size, k, 3)) - 0.5) * (max_pos[:3] - min_pos[:3])[None, None, :] * 0.08
        pbest = particles.copy()
        pbest_eval = _evaluate_particles(pbest, problem, cfg, self.method_key)
        archive_p, archive_o, archive_asu, archive_metrics = _truncate_archive(
            pbest, pbest_eval.objectives, pbest_eval.asu_values, pbest_eval.metrics, archive_size
        )
        state = _SearchState()
        counters = {
            "trigger_count": 0,
            "response_action_count": 0,
            "mild_response_count": 0,
            "moderate_response_count": 0,
            "severe_response_count": 0,
            "restart_count": 0,
            "sparse_injection_count": 0,
            "accepted_response_count": 0,
            "rejected_response_count": 0,
            "harmful_response_count": 0,
            "pbest_preserved_count": 0,
            "cumulative_asu_guard_count": 0,
            "coverage_outage_guard_count": 0,
        }
        cumulative_movement = 0.0

        for iteration in range(1, max_iter + 1):
            before_particles = particles.copy()
            before_archive_p = archive_p.copy()
            before_archive_o = archive_o.copy()
            leaders, leader_log = _select_leaders(archive_p, archive_o, pop_size, rng)
            if iteration <= state.mild_boost_until and archive_p.shape[0] > 1:
                explore = rng.random(pop_size) < 0.30
                leaders[explore] = archive_p[rng.integers(0, archive_p.shape[0], size=int(np.sum(explore)))]

            boosted = iteration <= state.mild_boost_until
            inertia_scale = 1.06 if boosted else 1.0
            mutation_scale = 1.8 if boosted else 1.0
            r1 = rng.random((pop_size, k, 3))
            r2 = rng.random((pop_size, k, 3))
            w = min(float(pso.get("w", 0.729)) * (0.996 ** (iteration - 1)) * inertia_scale, 0.95)
            c1 = float(pso.get("c1", 1.49445)) * (0.96 if boosted else 1.0)
            c2 = float(pso.get("c2", 1.49445)) * (1.04 if boosted else 1.0)
            velocities = w * velocities + c1 * r1 * (pbest[:, :, :3] - particles[:, :, :3]) + c2 * r2 * (leaders[:, :, :3] - particles[:, :, :3])
            vel_lim = (max_pos[:3] - min_pos[:3]) * float(cfg.get("mopso", {}).get("velocityLimitRatio", 0.2))
            velocities = np.clip(velocities, -vel_lim[None, None, :], vel_lim[None, None, :])
            particles[:, :, :3] = np.clip(particles[:, :, :3] + velocities, min_pos[:3][None, None, :], max_pos[:3][None, None, :])
            type_copy = rng.random((pop_size, k)) < 0.22
            sector_copy = rng.random((pop_size, k)) < 0.28
            particles[:, :, 3] = np.where(type_copy, leaders[:, :, 3], particles[:, :, 3])
            particles[:, :, 4] = np.where(sector_copy, leaders[:, :, 4], particles[:, :, 4])
            type_mut = rng.random((pop_size, k)) < (0.035 * mutation_scale)
            sector_mut = rng.random((pop_size, k)) < (0.07 * mutation_scale)
            particles[:, :, 3] = np.where(type_mut, rng.integers(0, _station_type_count(cfg), size=(pop_size, k)), particles[:, :, 3])
            particles[:, :, 4] = np.where(sector_mut, rng.integers(0, len(DEFAULT_SECTOR_DIRECTIONS_DEG), size=(pop_size, k)), particles[:, :, 4])
            particles = _repair_particles(particles, problem, cfg, rng, min_pos, max_pos)

            curr_eval = _evaluate_particles(particles, problem, cfg, self.method_key)
            improve = _better_for_personal_best(curr_eval.objectives, pbest_eval.objectives)
            pbest_update_rate = float(np.mean(improve.astype(float))) if improve.size else 0.0
            if np.any(improve):
                pbest[improve] = particles[improve]
                pbest_eval.objectives[improve] = curr_eval.objectives[improve]
                pbest_eval.asu_values[improve] = curr_eval.asu_values[improve]
                for idx in np.where(improve)[0].tolist():
                    pbest_eval.metrics[idx] = curr_eval.metrics[idx]
                    pbest_eval.feasible[idx] = curr_eval.feasible[idx]

            merged_p = np.concatenate([archive_p, particles, pbest], axis=0)
            merged_o = np.vstack([archive_o, curr_eval.objectives, pbest_eval.objectives])
            merged_asu = np.concatenate([archive_asu, curr_eval.asu_values, pbest_eval.asu_values])
            merged_metrics = list(archive_metrics) + list(curr_eval.metrics) + list(pbest_eval.metrics)
            archive_p, archive_o, archive_asu, archive_metrics = _truncate_archive(merged_p, merged_o, merged_asu, merged_metrics, archive_size)
            movement = _mean_population_movement(before_particles, particles, min_pos, max_pos)
            cumulative_movement += movement
            dynamics = _search_dynamics(
                particles=particles,
                archive_p=archive_p,
                archive_o=archive_o,
                previous_archive_p=before_archive_p,
                previous_archive_o=before_archive_o,
                movement=movement,
                cumulative_movement=cumulative_movement,
                min_pos=min_pos,
                max_pos=max_pos,
            )
            score = _stagnation_score(
                pbest_objectives=pbest_eval.objectives,
                pbest_update_rate=pbest_update_rate,
                leader_diversity=float(leader_log.get("leader_diversity", 0.0)),
                dynamics=dynamics,
                cfg=cfg,
                state=state,
            )
            _finalize_pending_response(iteration, dynamics, archive_asu, state, logs, counters, cfg, archive_metrics=archive_metrics)
            severity = _trigger_level(iteration, score, cfg, state)
            archive_snapshot = _best_archive_system_snapshot(archive_asu, archive_metrics)
            severity = _apply_v21_cumulative_asu_guard(severity, archive_snapshot, state, logs, counters, cfg)
            action_log: Dict[str, Any] = {"iteration": iteration, "severity": severity, "response_action": "none"}
            if severity != "none":
                counters["trigger_count"] += 1
                state.response_count += 1
                state.last_response_iter = iteration
                logs["response_severity_log"].append({"iteration": iteration, "severity": severity, "S_total": score["S_total"]})
                if bool(v2["response_enabled"]):
                    if state.pre_response_asu_baseline is None:
                        state.pre_response_asu_baseline = float(archive_snapshot["ASU_auxiliary"])
                    particles, velocities, action_log = _apply_response(
                        severity=severity,
                        iteration=iteration,
                        particles=particles,
                        velocities=velocities,
                        curr_objectives=curr_eval.objectives,
                        archive_particles=archive_p,
                        archive_objectives=archive_o,
                        problem=problem,
                        cfg=cfg,
                        rng=rng,
                        min_pos=min_pos,
                        max_pos=max_pos,
                        state=state,
                    )
                    counters["response_action_count"] += 1
                    counters[f"{severity}_response_count"] += 1
                    counters["restart_count"] += int(action_log.get("particles_restarted", 0))
                    counters["sparse_injection_count"] += int(action_log.get("sparse_injection_count", 0))
                    counters["pbest_preserved_count"] += int(action_log.get("pbest_preserved_count", 0))
                    state.pending = _PendingResponse(
                        iteration=iteration,
                        evaluate_at=iteration + int(v2["postResponseEvaluationWindow"]),
                        severity=severity,
                        before=dict(dynamics, **archive_snapshot),
                    )
                else:
                    action_log["response_action"] = "disabled_control"
                logs["response_action_log"].append(action_log)

            logs["stagnation_score_trace"].append(
                {
                    "iteration": iteration,
                    **score,
                    **dynamics,
                    "trigger_level": severity,
                    "trigger_flag": bool(severity != "none"),
                    "response_action": action_log.get("response_action", "none"),
                    "pbest_update_rate": pbest_update_rate,
                    "leader_diversity": float(leader_log.get("leader_diversity", 0.0)),
                    "response_cooldown_extension": state.cooldown_extension,
                    "pre_response_ASU_baseline": state.pre_response_asu_baseline,
                    "v21_future_downshift_steps": state.v21_future_downshift_steps,
                }
            )

        final_eval = _evaluate_particles(archive_p, problem, cfg, self.method_key)
        final_o = final_eval.objectives
        nd = nondominated_mask(final_o) if final_o.size else np.zeros((0,), dtype=bool)
        if not np.any(nd) and final_o.shape[0]:
            nd[0] = True
        logs.update(counters)
        logs["response_cooldown_intervals"] = [int(row.get("cooldown_after", v2["responseCooldown"])) for row in logs["response_acceptance_log"]]
        logs["particles_restarted_per_response"] = [int(row.get("particles_restarted", 0)) for row in logs["response_action_log"]]
        logs["final_archive_size"] = int(archive_p[nd].shape[0])
        logs["best_archive_asu"] = float(np.max(final_eval.asu_values[nd])) if np.any(nd) else float("nan")
        logs["sector_direction_set_valid"] = bool(_sector_values_valid(archive_p[nd]))
        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=np.asarray(final_o, dtype=float),
            decision_variables=np.asarray(archive_p, dtype=float),
            nondominated_objectives=np.asarray(final_o[nd], dtype=float),
            nondominated_decisions=np.asarray(archive_p[nd], dtype=float),
            runtime_seconds=float(time.time() - t0),
            feasible_mask=np.asarray(final_eval.feasible, dtype=bool),
            nondominated_feasible_mask=np.asarray(final_eval.feasible[nd], dtype=bool) if np.any(nd) else np.zeros((0,), dtype=bool),
            logs=logs,
        )


class ProposedSearchExpansionResponseV2DisabledAdapter(ProposedSearchExpansionResponseV2Adapter):
    method_key = "proposed_method_search_expansion_response_v2_disabled"
    display_name = "Proposed Search Expansion Response V2 Disabled"
    group = "proposed_search_expansion_response_v2_ablation"
    response_enabled_default = False


class ProposedSearchExpansionResponseV2MildOnlyAdapter(ProposedSearchExpansionResponseV2Adapter):
    method_key = "proposed_method_search_expansion_response_v2_mild_only"
    display_name = "Proposed Search Expansion Response V2 Mild Only"
    group = "proposed_search_expansion_response_v2_diagnostic"
    mild_only_default = True


class ProposedSearchExpansionResponseV2Restart10Adapter(ProposedSearchExpansionResponseV2Adapter):
    method_key = "proposed_method_search_expansion_response_v2_restart10"
    display_name = "Proposed Search Expansion Response V2 Restart 10"
    group = "proposed_search_expansion_response_v2_diagnostic"
    severe_restart_fraction_default = 0.10


class ProposedSearchExpansionResponseV2Restart20Adapter(ProposedSearchExpansionResponseV2Adapter):
    method_key = "proposed_method_search_expansion_response_v2_restart20"
    display_name = "Proposed Search Expansion Response V2 Restart 20"
    group = "proposed_search_expansion_response_v2_diagnostic"
    severe_restart_fraction_default = 0.20


class ProposedSearchExpansionResponseV2ASUGuardAdapter(ProposedSearchExpansionResponseV2Adapter):
    method_key = "proposed_method_search_expansion_response_v2_asu_guard"
    display_name = "Proposed Search Expansion Response V2 ASU Guard"
    group = "proposed_search_expansion_response_v2_diagnostic"
    asu_guard_default = True


class ProposedSearchExpansionResponseV21Adapter(ProposedSearchExpansionResponseV2Adapter):
    method_key = "proposed_method_search_expansion_response_v2_1"
    display_name = "Proposed Search Expansion Response V2.1"
    group = "proposed_search_expansion_response_v2_1"


class ProposedSearchExpansionResponseV21DisabledAdapter(ProposedSearchExpansionResponseV21Adapter):
    method_key = "proposed_method_search_expansion_response_v2_1_disabled"
    display_name = "Proposed Search Expansion Response V2.1 Disabled"
    group = "proposed_search_expansion_response_v2_1_ablation"
    response_enabled_default = False


def _method_config(config: Config, method_key: str, *, response_enabled: bool, mild_only: bool, severe_restart_fraction: float) -> Config:
    cfg = json.loads(json.dumps(config))
    materialize_asu_config(cfg)
    cfg.setdefault("experiment", {})["method"] = method_key
    cfg["experiment"]["legacy_proposed_method_preserved_as"] = "proposed_method"
    cfg.setdefault("particleEncoding", {})["optimizeStationType"] = True
    cfg["particleEncoding"]["optimizeSectorDirection"] = True
    cfg.setdefault("channel", {})["sector_directions_deg"] = [float(v) for v in DEFAULT_SECTOR_DIRECTIONS_DEG]
    cfg.setdefault("asuAligned", {}).setdefault("stage1_ratio", 0.5)
    cfg["asuAligned"].setdefault("stage1_cap", 6)
    cfg["asuAligned"].setdefault("sector_repair_radius_m", 900.0)
    cfg["asuAligned"].setdefault("sector_repair_max_nearby_points", 80)
    v2 = cfg.setdefault("searchExpansionResponseV2", {})
    defaults = {
        "response_enabled": bool(response_enabled),
        "mild_only": bool(mild_only),
        "scoreWeights": {"coverage": 0.22, "novelty": 0.22, "entropy": 0.15, "nd": 0.15, "movement": 0.14, "pbest": 0.08, "leader": 0.02, "qe": 0.02},
        "plateauWindow": 20,
        "escalationWindow": 40,
        "minIterationsBeforeResponse": 80,
        "responseCooldown": 40,
        "postResponseEvaluationWindow": 20,
        "maxResponsesPerRun": 5,
        "thresholdMild": 0.45,
        "thresholdModerate": 0.60,
        "thresholdSevere": 0.75,
        "moderateResponseFraction": 0.10,
        "severeRestartFraction": min(max(float(severe_restart_fraction), 0.0), 0.20),
        "mildBoostIterations": 20,
        "harmfulCooldownExtension": 20,
        "severeAsuDropRatio": 0.10,
        "asuGuardEnabled": False,
        "asuGuardDropRatio": 0.05,
        "asuGuardResponseFractionMultiplier": 0.50,
        "asuGuardResponseFractionScaleMin": 0.125,
        "v21GuardEnabled": False,
        "v21CumulativeAsuDownshiftRatio": 0.03,
        "v21CumulativeAsuSkipSevereRatio": 0.05,
        "v21SystemMetricHarmfulRatio": 0.02,
        "v21ResponseFractionMultiplier": 0.50,
        "v21ResponseFractionScaleMin": 0.125,
        "restartNoiseRatio": 0.08,
    }
    for key, value in defaults.items():
        v2.setdefault(key, value)
    v2["response_enabled"] = bool(response_enabled)
    v2["mild_only"] = bool(mild_only)
    v2["severeRestartFraction"] = min(max(float(severe_restart_fraction), 0.0), 0.20)
    if method_key == ProposedSearchExpansionResponseV2ASUGuardAdapter.method_key:
        v2["asuGuardEnabled"] = True
    if method_key in {ProposedSearchExpansionResponseV21Adapter.method_key, ProposedSearchExpansionResponseV21DisabledAdapter.method_key}:
        k = int(cfg.get("pso", {}).get("numBaseStations", cfg.get("stage1", {}).get("numNewStations", 1)))
        v2["v21GuardEnabled"] = True
        v2["moderateResponseFraction"] = 0.05 if k >= 8 else 0.10
        v2["severeRestartFraction"] = 0.10 if k >= 8 else 0.20
    return cfg


def _stagnation_score(
    *,
    pbest_objectives: np.ndarray,
    pbest_update_rate: float,
    leader_diversity: float,
    dynamics: Dict[str, float],
    cfg: Config,
    state: _SearchState,
) -> Dict[str, float]:
    v2 = cfg["searchExpansionResponseV2"]
    qe = _quasi_entropy(_composite_min_scores(pbest_objectives))
    if state.initial_qe is None:
        state.initial_qe = max(qe, 1e-12)
    qe_ratio = float(qe / max(state.initial_qe, 1e-12))
    state.coverage_history.append(float(dynamics["decision_space_coverage_ratio"]))
    state.novelty_history.append(float(dynamics["mean_decision_archive_novelty"]))
    state.entropy_history.append(float(dynamics["objective_space_entropy"]))
    state.nd_history.append(int(dynamics["nondominated_count"]))
    state.movement_history.append(float(dynamics["mean_population_movement_distance"]))
    w = int(v2["plateauWindow"])
    scores = {
        "coverage": _plateau_score(state.coverage_history, w, 0.002),
        "novelty": _plateau_score(state.novelty_history, w, 0.002),
        "entropy": _plateau_score(state.entropy_history, w, 0.002),
        "nd": _plateau_score(state.nd_history, w, 1.0),
        "movement": _movement_decay_score(state.movement_history, w),
        "pbest": 1.0 - float(np.clip(pbest_update_rate / 0.08, 0.0, 1.0)),
        "leader": 1.0 - float(np.clip(leader_diversity / 0.55, 0.0, 1.0)),
        "qe": float(np.clip((1.05 - qe_ratio) / 0.20, 0.0, 1.0)),
    }
    weights = dict(v2["scoreWeights"])
    total = max(sum(float(weights.get(k, 0.0)) for k in scores), 1e-12)
    score_total = sum(float(weights.get(k, 0.0)) * val for k, val in scores.items()) / total
    state.score_window.append(float(score_total))
    return {
        "S_total": float(score_total),
        "S_decision_coverage_plateau": scores["coverage"],
        "S_archive_novelty_plateau": scores["novelty"],
        "S_objective_entropy_plateau": scores["entropy"],
        "S_nondominated_growth_stagnation": scores["nd"],
        "S_population_movement_decay": scores["movement"],
        "S_pbest_update_stagnation": scores["pbest"],
        "S_leader_diversity_loss": scores["leader"],
        "S_qe_auxiliary": scores["qe"],
        "QE_ratio": qe_ratio,
    }


def _trigger_level(iteration: int, score: Dict[str, float], cfg: Config, state: _SearchState) -> str:
    v2 = cfg["searchExpansionResponseV2"]
    if iteration < int(v2["minIterationsBeforeResponse"]) or state.response_count >= int(v2["maxResponsesPerRun"]):
        return "none"
    cooldown = int(v2["responseCooldown"]) + int(state.cooldown_extension)
    if iteration - state.last_response_iter < cooldown:
        return "none"
    level = "none"
    total = float(score["S_total"])
    if total >= float(v2["thresholdSevere"]):
        level = "severe"
    elif total >= float(v2["thresholdModerate"]):
        level = "moderate"
    elif total >= float(v2["thresholdMild"]):
        level = "mild"
    ew = int(v2["escalationWindow"])
    if _not_growing(state.coverage_history, ew, 0.002):
        level = _max_severity(level, "moderate")
    if _not_growing(state.novelty_history, ew, 0.002) and _movement_decay_score(state.movement_history, ew) > 0.5:
        level = _max_severity(level, "severe")
    if _decreased(state.entropy_history, ew, 0.002):
        level = _max_severity(level, "severe")
    if bool(v2["mild_only"]) and level != "none":
        return "mild"
    if state.severity_cap == "mild" and level != "none":
        return "mild"
    if state.severity_cap == "moderate" and level == "severe":
        return "moderate"
    return level


def _apply_v21_cumulative_asu_guard(
    severity: str,
    archive_snapshot: Dict[str, float],
    state: _SearchState,
    logs: Dict[str, Any],
    counters: Dict[str, int],
    cfg: Config,
) -> str:
    v2 = cfg["searchExpansionResponseV2"]
    if severity == "none" or not bool(v2.get("v21GuardEnabled", False)):
        return severity
    current_asu = float(archive_snapshot.get("ASU_auxiliary", float("nan")))
    if state.pre_response_asu_baseline is None or not np.isfinite(current_asu):
        return severity
    baseline = float(state.pre_response_asu_baseline)
    drop_ratio = (baseline - current_asu) / max(abs(baseline), 1e-9)
    downshift_ratio = float(v2.get("v21CumulativeAsuDownshiftRatio", 0.03))
    skip_severe_ratio = float(v2.get("v21CumulativeAsuSkipSevereRatio", 0.05))
    guard_level = 2 if drop_ratio > skip_severe_ratio else 1 if drop_ratio > downshift_ratio else 0
    if guard_level > state.v21_cumulative_guard_level:
        counters["cumulative_asu_guard_count"] += 1
        if guard_level >= 2:
            state.cooldown_extension += int(v2["harmfulCooldownExtension"])
        state.v21_cumulative_guard_level = guard_level
    if guard_level >= 1:
        state.v21_future_downshift_steps = max(state.v21_future_downshift_steps, 1)
    severity = _downshift_severity(severity, state.v21_future_downshift_steps)
    logs.setdefault("v21_cumulative_asu_guard_log", []).append(
        {
            "ASU_baseline": baseline,
            "ASU_current": current_asu,
            "ASU_drop_ratio": drop_ratio,
            "guard_level": guard_level,
            "severity_after_guard": severity,
        }
    )
    return severity


def _apply_response(
    *,
    severity: str,
    iteration: int,
    particles: np.ndarray,
    velocities: np.ndarray,
    curr_objectives: np.ndarray,
    archive_particles: np.ndarray,
    archive_objectives: np.ndarray,
    problem: DeploymentProblem,
    cfg: Config,
    rng: np.random.Generator,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    state: _SearchState,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    v2 = cfg["searchExpansionResponseV2"]
    if severity == "mild":
        state.mild_boost_until = max(state.mild_boost_until, iteration + int(v2["mildBoostIterations"]))
        return particles, velocities, {"iteration": iteration, "severity": severity, "response_action": "parameter_and_leader_diversification", "particles_restarted": 0, "sparse_injection_count": 0, "pbest_preserved_count": 0}
    base_frac = float(v2["moderateResponseFraction"] if severity == "moderate" else v2["severeRestartFraction"])
    frac = base_frac * float(state.response_fraction_scale)
    out = np.asarray(particles, dtype=float).copy()
    vel = np.asarray(velocities, dtype=float).copy()
    dominated = np.where(~nondominated_mask(curr_objectives))[0]
    if dominated.size == 0:
        dominated = np.argsort(-_composite_min_scores(curr_objectives), kind="stable")
    count = max(1, min(int(np.ceil(out.shape[0] * frac)), dominated.size, int(np.ceil(out.shape[0] * 0.20))))
    targets = rng.choice(dominated, size=count, replace=False)
    sparse = _sparse_archive_indices(archive_objectives, count)
    route_pts = np.asarray(problem.test_points, dtype=float)
    span = max_pos[:3] - min_pos[:3]
    for j, idx in enumerate(targets.tolist()):
        base = archive_particles[sparse[j % len(sparse)]].copy() if archive_particles.size and sparse else out[idx].copy()
        if route_pts.size and (severity == "severe" or float(rng.random()) < 0.35):
            anchor = route_pts[int(rng.integers(0, route_pts.shape[0]))]
            station_idx = int(rng.integers(0, out.shape[1]))
            base[station_idx, :2] = anchor[:2] + rng.normal(0.0, 350.0, size=2)
            base[station_idx, 2] = anchor[2]
            base[station_idx, 4] = float(_best_sector_index(base[station_idx, :3], route_pts, cfg))
        base[:, :3] += rng.normal(0.0, float(v2["restartNoiseRatio"]), size=base[:, :3].shape) * span[None, :]
        sector_mut = rng.random(base.shape[0]) < (0.15 if severity == "moderate" else 0.25)
        base[:, 4] = np.where(sector_mut, rng.integers(0, len(DEFAULT_SECTOR_DIRECTIONS_DEG), size=base.shape[0]), base[:, 4])
        out[idx] = base
        vel[idx] = 0.0 if severity == "severe" else vel[idx] * 0.35
    out = _repair_particles(out, problem, cfg, rng, min_pos, max_pos)
    action = "archive_guided_sparse_restart" if severity == "severe" else "dominated_sparse_perturbation"
    return out, vel, {
        "iteration": iteration,
        "severity": severity,
        "response_action": action,
        "target_particles": ",".join(str(int(i)) for i in targets.tolist()),
        "particles_restarted": int(count if severity == "severe" else 0),
        "sparse_injection_count": int(count),
        "pbest_preserved_count": int(count if severity == "severe" else 0),
        "archive_elites_protected": True,
        "pbest_overwritten": False,
        "protected_archive": json.dumps(_protected_archive_summary(archive_objectives)),
        "base_response_fraction": base_frac,
        "response_fraction_scale": float(state.response_fraction_scale),
        "effective_response_fraction": frac,
    }


def _finalize_pending_response(
    iteration: int,
    dynamics: Dict[str, float],
    archive_asu: np.ndarray,
    state: _SearchState,
    logs: Dict[str, Any],
    counters: Dict[str, int],
    cfg: Config,
    archive_metrics: Sequence[Dict[str, float]] = (),
) -> None:
    if state.pending is None or iteration < state.pending.evaluate_at:
        return
    before = state.pending.before
    after = dict(dynamics, **_best_archive_system_snapshot(archive_asu, archive_metrics))
    keys = ["decision_space_coverage_ratio", "mean_decision_archive_novelty", "objective_space_entropy", "nondominated_count", "mean_population_movement_distance"]
    improved = [key for key in keys if float(after.get(key, 0.0)) > float(before.get(key, 0.0)) + 1e-12]
    asu_before = float(before.get("ASU_auxiliary", float("nan")))
    asu_after = float(after.get("ASU_auxiliary", float("nan")))
    drop_ratio = (asu_before - asu_after) / max(abs(asu_before), 1e-9) if np.isfinite(asu_before) and np.isfinite(asu_after) else 0.0
    v2 = cfg["searchExpansionResponseV2"]
    asu_guard_enabled = bool(v2.get("asuGuardEnabled", False))
    guard_drop_ratio = float(v2.get("asuGuardDropRatio", 0.05))
    asu_guard_triggered = bool(asu_guard_enabled and drop_ratio > guard_drop_ratio)
    v21_enabled = bool(v2.get("v21GuardEnabled", False))
    system_threshold = float(v2.get("v21SystemMetricHarmfulRatio", 0.02))
    coverage_drop_ratio = _relative_decrease(before.get("coverage_rate"), after.get("coverage_rate"))
    outage_increase_ratio = _relative_increase(before.get("outage_probability"), after.get("outage_probability"))
    hole_increase_ratio = _relative_increase(before.get("coverage_hole_rate"), after.get("coverage_hole_rate"))
    coverage_outage_guard_triggered = bool(
        v21_enabled
        and (
            coverage_drop_ratio > system_threshold
            or outage_increase_ratio > system_threshold
            or hole_increase_ratio > system_threshold
        )
    )
    harmful = bool(drop_ratio > float(v2["severeAsuDropRatio"]) or asu_guard_triggered or coverage_outage_guard_triggered or not improved)
    accepted = bool(improved and not harmful)
    counters["accepted_response_count" if accepted else "rejected_response_count"] += 1
    if harmful:
        counters["harmful_response_count"] += 1
        state.cooldown_extension += int(v2["harmfulCooldownExtension"])
        state.severity_cap = "moderate" if state.severity_cap == "severe" else "mild"
    if coverage_outage_guard_triggered:
        counters["coverage_outage_guard_count"] += 1
        state.v21_future_downshift_steps = min(state.v21_future_downshift_steps + 1, 2)
    if asu_guard_triggered or (v21_enabled and harmful):
        state.response_fraction_scale = max(
            float(v2.get("v21ResponseFractionScaleMin" if v21_enabled else "asuGuardResponseFractionScaleMin", 0.125)),
            state.response_fraction_scale * float(v2.get("v21ResponseFractionMultiplier" if v21_enabled else "asuGuardResponseFractionMultiplier", 0.50)),
        )
    row = {
        "response_iteration": state.pending.iteration,
        "evaluation_iteration": iteration,
        "severity": state.pending.severity,
        "accepted": accepted,
        "harmful": harmful,
        "improved_metrics": ",".join(improved),
        "ASU_drop_ratio": drop_ratio,
        "asu_guard_enabled": asu_guard_enabled,
        "asu_guard_triggered": asu_guard_triggered,
        "coverage_drop_ratio": coverage_drop_ratio,
        "outage_increase_ratio": outage_increase_ratio,
        "coverage_hole_increase_ratio": hole_increase_ratio,
        "coverage_outage_guard_triggered": coverage_outage_guard_triggered,
        "response_fraction_scale_after": state.response_fraction_scale,
        "cooldown_after": int(v2["responseCooldown"]) + state.cooldown_extension,
    }
    for key in keys + ["ASU_auxiliary", "coverage_rate", "outage_probability", "coverage_hole_rate"]:
        row[f"before_{key}"] = before.get(key, "")
        row[f"after_{key}"] = after.get(key, "")
    logs["response_acceptance_log"].append(row)
    logs["response_before_after_metrics"].append(row)
    state.pending = None


def _best_archive_system_snapshot(archive_asu: np.ndarray, archive_metrics: Sequence[Dict[str, float]]) -> Dict[str, float]:
    if not archive_asu.size:
        return {"ASU_auxiliary": float("nan"), "coverage_rate": float("nan"), "outage_probability": float("nan"), "coverage_hole_rate": float("nan")}
    idx = int(np.argmax(archive_asu))
    metrics = dict(archive_metrics[idx]) if idx < len(archive_metrics) else {}
    coverage = float(metrics.get("coverage_rate", float("nan")))
    outage = float(metrics.get("outage_probability", 1.0 - coverage if np.isfinite(coverage) else float("nan")))
    hole = float(metrics.get("coverage_hole_rate", float("nan")))
    return {
        "ASU_auxiliary": float(archive_asu[idx]),
        "coverage_rate": coverage,
        "outage_probability": outage,
        "coverage_hole_rate": hole,
    }


def _relative_decrease(before: Any, after: Any) -> float:
    try:
        left, right = float(before), float(after)
    except (TypeError, ValueError):
        return 0.0
    return (left - right) / max(abs(left), 1e-9) if np.isfinite(left) and np.isfinite(right) else 0.0


def _relative_increase(before: Any, after: Any) -> float:
    try:
        left, right = float(before), float(after)
    except (TypeError, ValueError):
        return 0.0
    return (right - left) / max(abs(left), 1e-9) if np.isfinite(left) and np.isfinite(right) else 0.0


def _downshift_severity(severity: str, steps: int) -> str:
    order = ["none", "mild", "moderate", "severe"]
    return order[max(0, order.index(severity) - max(int(steps), 0))]


def _search_dynamics(
    *,
    particles: np.ndarray,
    archive_p: np.ndarray,
    archive_o: np.ndarray,
    previous_archive_p: np.ndarray,
    previous_archive_o: np.ndarray,
    movement: float,
    cumulative_movement: float,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
) -> Dict[str, float]:
    decision = _decision_space_metrics(particles, min_pos, max_pos)
    return {
        **decision,
        "mean_population_movement_distance": float(movement),
        "cumulative_population_movement_distance": float(cumulative_movement),
        "mean_decision_archive_novelty": _archive_novelty(archive_p, previous_archive_p, min_pos, max_pos),
        "mean_objective_archive_novelty": _objective_archive_novelty(archive_o, previous_archive_o),
        "archive_growth_rate": float(archive_o.shape[0] - previous_archive_o.shape[0]),
        "objective_space_entropy": float(_objective_entropy(archive_o)),
        "archive_grid_occupancy": float(_objective_grid_occupancy(archive_o)),
        "nondominated_count": int(archive_o.shape[0]),
        "HV_proxy": float(_cheap_hv_proxy(archive_o)),
    }


def _normalize_decisions(decisions: np.ndarray, min_pos: np.ndarray, max_pos: np.ndarray) -> np.ndarray:
    arr = np.asarray(decisions, dtype=float)
    if arr.size == 0:
        return np.zeros((0, 0), dtype=float)
    out = arr.copy()
    out[:, :, :3] = (out[:, :, :3] - min_pos[:3][None, None, :]) / np.maximum(max_pos[:3] - min_pos[:3], 1e-9)[None, None, :]
    out[:, :, 3] = out[:, :, 3] / max(float(np.max(out[:, :, 3])), 1.0)
    out[:, :, 4] = out[:, :, 4] / max(float(len(DEFAULT_SECTOR_DIRECTIONS_DEG) - 1), 1.0)
    return np.clip(out, 0.0, 1.0)


def _decision_space_metrics(decisions: np.ndarray, min_pos: np.ndarray, max_pos: np.ndarray, bins: int = 4) -> Dict[str, float]:
    norm = _normalize_decisions(decisions, min_pos, max_pos)
    if norm.size == 0:
        return {"decision_space_coverage_ratio": 0.0, "occupied_decision_cells": 0, "mean_pairwise_decision_distance": 0.0, "decision_space_entropy": 0.0}
    station_rows = norm.reshape(-1, 5)
    cells = np.floor(np.clip(station_rows, 0.0, 0.999999) * bins).astype(int)
    _, counts = np.unique(cells, axis=0, return_counts=True)
    prob = counts.astype(float) / float(np.sum(counts))
    flat = norm.reshape(norm.shape[0], -1)
    pair = np.linalg.norm(flat[:, None, :] - flat[None, :, :], axis=2)
    upper = pair[np.triu_indices(pair.shape[0], k=1)]
    return {
        "decision_space_coverage_ratio": float(counts.size / (bins ** 5)),
        "occupied_decision_cells": int(counts.size),
        "mean_pairwise_decision_distance": float(np.mean(upper)) if upper.size else 0.0,
        "decision_space_entropy": float(-np.sum(prob * np.log(prob + 1e-12))),
    }


def _mean_population_movement(before: np.ndarray, after: np.ndarray, min_pos: np.ndarray, max_pos: np.ndarray) -> float:
    a = _normalize_decisions(before, min_pos, max_pos).reshape(before.shape[0], -1)
    b = _normalize_decisions(after, min_pos, max_pos).reshape(after.shape[0], -1)
    return float(np.mean(np.linalg.norm(b - a, axis=1))) if a.size and b.size else 0.0


def _archive_novelty(current: np.ndarray, previous: np.ndarray, min_pos: np.ndarray, max_pos: np.ndarray) -> float:
    cur = _normalize_decisions(current, min_pos, max_pos).reshape(current.shape[0], -1) if current.size else np.zeros((0, 0))
    prev = _normalize_decisions(previous, min_pos, max_pos).reshape(previous.shape[0], -1) if previous.size else np.zeros((0, 0))
    if not cur.size or not prev.size:
        return 0.0
    dist = np.linalg.norm(cur[:, None, :] - prev[None, :, :], axis=2)
    dist[dist <= 1e-12] = np.inf
    nearest = np.min(dist, axis=1)
    nearest[~np.isfinite(nearest)] = 0.0
    return float(np.mean(nearest))


def _objective_archive_novelty(current: np.ndarray, previous: np.ndarray) -> float:
    cur = np.asarray(current, dtype=float)
    prev = np.asarray(previous, dtype=float)
    if not cur.size or not prev.size:
        return 0.0
    merged = np.vstack([cur, prev])
    lo = np.min(merged, axis=0)
    span = np.maximum(np.max(merged, axis=0) - lo, 1e-9)
    dist = np.linalg.norm(((cur - lo) / span)[:, None, :] - ((prev - lo) / span)[None, :, :], axis=2)
    dist[dist <= 1e-12] = np.inf
    nearest = np.min(dist, axis=1)
    nearest[~np.isfinite(nearest)] = 0.0
    return float(np.mean(nearest))


def _objective_grid_occupancy(objectives: np.ndarray, bins: int = 4) -> int:
    arr = np.asarray(objectives, dtype=float)
    if not arr.size:
        return 0
    lo = np.min(arr, axis=0)
    norm = (arr - lo) / np.maximum(np.max(arr, axis=0) - lo, 1e-9)
    return int(np.unique(np.floor(np.clip(norm, 0.0, 0.999999) * bins).astype(int), axis=0).shape[0])


def _cheap_hv_proxy(objectives: np.ndarray) -> float:
    arr = np.asarray(objectives, dtype=float)
    if not arr.size:
        return 0.0
    lo = np.min(arr, axis=0)
    norm = (arr - lo) / np.maximum(np.max(arr, axis=0) - lo, 1e-9)
    return float(np.mean(np.prod(np.clip(1.05 - norm, 0.0, 1.05), axis=1)))


def _plateau_score(values: Sequence[float], window: int, epsilon: float) -> float:
    if len(values) <= window:
        return 0.0
    gain = float(values[-1]) - float(values[-window])
    return 1.0 - float(np.clip(max(gain, 0.0) / max(epsilon, 1e-12), 0.0, 1.0))


def _movement_decay_score(values: Sequence[float], window: int) -> float:
    if len(values) <= window:
        return 0.0
    base = max(float(np.mean(values[: min(window, len(values))])), 1e-12)
    recent = float(np.mean(values[-window:]))
    return 1.0 - float(np.clip(recent / base, 0.0, 1.0))


def _not_growing(values: Sequence[float], window: int, epsilon: float) -> bool:
    return len(values) > window and float(values[-1]) - float(values[-window]) <= epsilon


def _decreased(values: Sequence[float], window: int, epsilon: float) -> bool:
    return len(values) > window and float(values[-window]) - float(values[-1]) > epsilon


def _max_severity(left: str, right: str) -> str:
    order = {"none": 0, "mild": 1, "moderate": 2, "severe": 3}
    return left if order[left] >= order[right] else right
