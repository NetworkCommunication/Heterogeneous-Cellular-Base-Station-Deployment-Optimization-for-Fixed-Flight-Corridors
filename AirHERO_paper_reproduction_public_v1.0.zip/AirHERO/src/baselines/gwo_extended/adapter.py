from __future__ import annotations

from typing import Any, Dict

import numpy as np

from src.baselines.bio_inspired_common import ASUV2BioInspiredAdapter, clip_to_bounds


class GWOExtendedAdapter(ASUV2BioInspiredAdapter):
    """Grey Wolf Optimizer baseline for ASU-v2 deployment."""

    method_key = "gwo_extended"
    display_name = "Grey Wolf Optimizer Extended"
    algorithm_name = "Grey Wolf Optimizer"
    implemented = True

    def _next_population(self, *, population, scores, iteration, max_iterations, encoding, problem, config, rng, state, alg_cfg):
        order = np.argsort(-scores)
        alpha = population[order[0]]
        beta = population[order[min(1, len(order) - 1)]]
        delta = population[order[min(2, len(order) - 1)]]
        a = 2.0 - 2.0 * float(iteration) / max(float(max_iterations), 1.0)
        out = np.zeros_like(population)
        for leader in (alpha, beta, delta):
            r1 = rng.random(size=population.shape)
            r2 = rng.random(size=population.shape)
            A = 2.0 * a * r1 - a
            C = 2.0 * r2
            D = np.abs(C * leader[None, :] - population)
            out += leader[None, :] - A * D
        out /= 3.0
        return clip_to_bounds(out, encoding)
