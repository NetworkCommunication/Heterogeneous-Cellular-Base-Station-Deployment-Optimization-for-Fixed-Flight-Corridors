from __future__ import annotations

import json
import time
from typing import Any, Dict, Literal

import numpy as np

from src.algorithms.improved_mopso import run_mopso_optimize
from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.data.types import Config


StationTypeConstraint = Literal["5G", "5GA"]


class Proposed5GOnlyConstrainedAdapter(BaselineAdapter):
    """Diagnostic wrapper: frozen proposed optimizer with all-new 5G stations."""

    method_key = "proposed_5g_only_constrained"
    display_name = "Proposed constrained to 5G-only"
    group = "component_ablation"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        return _run_constrained_proposed(problem, seed, config, forced_type="5G", method_key=self.method_key)


class Proposed5GAOnlyConstrainedAdapter(BaselineAdapter):
    """Diagnostic wrapper: frozen proposed optimizer with all-new 5GA stations."""

    method_key = "proposed_5ga_only_constrained"
    display_name = "Proposed constrained to 5GA-only"
    group = "component_ablation"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        return _run_constrained_proposed(problem, seed, config, forced_type="5GA", method_key=self.method_key)


def _run_constrained_proposed(
    problem: DeploymentProblem,
    seed: int,
    config: Config,
    *,
    forced_type: StationTypeConstraint,
    method_key: str,
) -> BaselineResult:
    cfg = _constrained_type_config(config, forced_type=forced_type, method_key=method_key)
    config.clear()
    config.update(json.loads(json.dumps(cfg)))
    rng = np.random.default_rng(int(seed))
    t0 = time.time()
    result = run_mopso_optimize(
        config=cfg,
        test_points=problem.test_points,
        city_map=problem.city_map,
        channel_params=problem.channel_params,
        rng=rng,
        verbose=bool(cfg.get("verbose", False)),
    )
    elapsed = float(time.time() - t0)
    logs: Dict[str, Any] = {
        "best_fitness": float(result.best_fitness),
        "pareto_size": int(result.pareto_objectives.shape[0]),
        "trigger_stats": dict(result.trigger_stats),
        "init_stats": dict(result.init_stats),
        "station_type_constraint": forced_type,
        "station_type_decision": "fixed_by_ablation_adapter",
        "note": "Config/adapter-level diagnostic; proposed_method algorithm files are unchanged.",
    }
    return BaselineResult(
        method_name=method_key,
        group="component_ablation",
        seed=int(seed),
        objective_vectors=np.asarray(result.pareto_objectives, dtype=float),
        decision_variables=np.asarray(result.pareto_positions, dtype=float),
        nondominated_objectives=np.asarray(result.pareto_objectives, dtype=float),
        nondominated_decisions=np.asarray(result.pareto_positions, dtype=float),
        runtime_seconds=elapsed,
        logs=logs,
    )


def _constrained_type_config(config: Config, *, forced_type: StationTypeConstraint, method_key: str) -> Config:
    cfg = json.loads(json.dumps(config))
    cfg.setdefault("experiment", {})
    cfg["experiment"]["method"] = method_key
    cfg["experiment"]["group"] = "component_ablation"
    cfg.setdefault("particleEncoding", {})
    cfg["particleEncoding"]["optimizeStationType"] = False
    cfg["particleEncoding"]["optimizeSectorDirection"] = True
    cfg.setdefault("heterogeneousDeployment", {})
    station_types = cfg["heterogeneousDeployment"].setdefault("stationTypes", [])
    for item in station_types:
        name = str(item.get("name", "")).strip().upper()
        item["ratio"] = 1.0 if name == forced_type.upper() else 0.0
    cfg.setdefault("constrainedVariant", {})
    cfg["constrainedVariant"].update(
        {
            "enabled": True,
            "forced_new_station_type": forced_type,
            "implementation_layer": "baseline_adapter_config_wrapper",
            "proposed_algorithm_files_modified": False,
        }
    )
    return cfg
