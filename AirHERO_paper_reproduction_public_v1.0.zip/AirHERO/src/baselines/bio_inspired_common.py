from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

import numpy as np

from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.baselines.nsga2_extended.adapter import _validate_station_type_mapping
from src.baselines.nsga2_extended.encoding import (
    NSGA2_SECTOR_AZIMUTHS_DEG,
    ExtendedDeploymentEncoding,
    build_extended_deployment_encoding,
    unflatten_extended_chromosomes,
)
from src.baselines.nsga2_extended.evaluation import evaluate_extended_chromosomes
from src.baselines.nsga2_extended.repair import repair_extended_chromosomes
from src.data.types import Config
from src.experiments.asu_route_service_v2 import ASU_ROUTE_SERVICE_V2, asu_route_service_v2_from_metrics
from src.experiments.asu_route_service_v2_sinr import (
    ASU_ROUTE_SERVICE_V2_SINR,
    evaluate_with_existing_context_sinr_asu_v2,
)
from src.experiments.multiobjective_metrics import nondominated_mask
from src.experiments.exploration_trace import capture_candidate_sets


@dataclass(frozen=True)
class BioInspiredEvaluation:
    """ASU-v2 and objective-vector evaluation for one bio-inspired population."""

    objectives: np.ndarray
    feasible_mask: np.ndarray
    asu_scores: np.ndarray
    asu_records: List[Dict[str, Any]]


class ASUV2BioInspiredAdapter(BaselineAdapter):
    """Shared ASU-v2 baseline scaffold for simple bio-inspired optimizers."""

    method_key = "abstract_bio_inspired"
    display_name = "Abstract Bio-Inspired ASU-v2 Baseline"
    group = "fair_optimization_baseline"
    implemented = False
    algorithm_name = "abstract"
    default_population_size = 30
    default_max_iterations = 80

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        """Run one ASU-v2 bio-inspired optimizer over the full decision encoding."""
        rng = np.random.default_rng(int(seed))
        method_cfg = extended_asu_v2_config(config)
        _validate_station_type_mapping(method_cfg)
        encoding = build_extended_deployment_encoding(method_cfg)
        alg_cfg = self._algorithm_config(method_cfg)
        pop_size = int(alg_cfg["population_size"])
        max_iter = int(alg_cfg["max_iterations"])

        t0 = time.time()
        population = initialize_population(pop_size, encoding, problem, method_cfg, rng)
        evaluation = evaluate_for_asu(population, encoding, problem, method_cfg)
        best_idx = int(np.argmax(evaluation.asu_scores))
        best = population[best_idx].copy()
        best_score = float(evaluation.asu_scores[best_idx])
        best_record = dict(evaluation.asu_records[best_idx])
        history: List[Dict[str, float]] = [
            {"iteration": 0.0, "best_ASU": best_score, "mean_ASU": float(np.mean(evaluation.asu_scores))}
        ]
        state: Dict[str, Any] = {
            "best": best.copy(),
            "best_score": best_score,
            "best_record": best_record,
            "population": population.copy(),
            "scores": evaluation.asu_scores.copy(),
        }
        trace_logs: Dict[str, Any] = {}
        capture_candidate_sets(
            trace_logs, method_cfg, iteration=0, max_iterations=max_iter,
            candidate_sets=[{"candidate_source": "population", "decisions": unflatten_extended_chromosomes(population, encoding),
                             "objectives": evaluation.objectives, "feasible": evaluation.feasible_mask,
                             "metrics": evaluation.asu_records}],
        )

        for iteration in range(1, max_iter + 1):
            population = self._next_population(
                population=population,
                scores=evaluation.asu_scores,
                iteration=iteration,
                max_iterations=max_iter,
                encoding=encoding,
                problem=problem,
                config=method_cfg,
                rng=rng,
                state=state,
                alg_cfg=alg_cfg,
            )
            population = repair_extended_chromosomes(population, encoding, problem.city_map, method_cfg, rng)
            evaluation = evaluate_for_asu(population, encoding, problem, method_cfg)
            iter_best_idx = int(np.argmax(evaluation.asu_scores))
            iter_best_score = float(evaluation.asu_scores[iter_best_idx])
            if iter_best_score > best_score:
                best_score = iter_best_score
                best = population[iter_best_idx].copy()
                best_record = dict(evaluation.asu_records[iter_best_idx])
            state.update(
                {
                    "best": best.copy(),
                    "best_score": best_score,
                    "best_record": best_record,
                    "population": population.copy(),
                    "scores": evaluation.asu_scores.copy(),
                }
            )
            history.append(
                {
                    "iteration": float(iteration),
                    "best_ASU": float(best_score),
                    "mean_ASU": float(np.mean(evaluation.asu_scores)),
                    "iteration_best_ASU": iter_best_score,
                }
            )
            capture_candidate_sets(
                trace_logs, method_cfg, iteration=iteration, max_iterations=max_iter,
                candidate_sets=[{"candidate_source": "population", "decisions": unflatten_extended_chromosomes(population, encoding),
                                 "objectives": evaluation.objectives, "feasible": evaluation.feasible_mask,
                                 "metrics": evaluation.asu_records}],
            )

        final_eval = evaluate_for_asu(population, encoding, problem, method_cfg)
        objectives = final_eval.objectives
        feasible = final_eval.feasible_mask
        nd_mask = nondominated_mask(objectives)
        decisions = unflatten_extended_chromosomes(population, encoding)
        runtime = float(time.time() - t0)
        logs = self._logs(
            encoding=encoding,
            alg_cfg=alg_cfg,
            history=history,
            best=best,
            best_score=best_score,
            best_record=best_record,
            evaluations=int(pop_size * (max_iter + 1)),
        )
        # Optional baseline-specific diagnostic counters; never affect search.
        for key, value in state.items():
            if key.startswith("immogwo_") or key in {"sampled_scenario_count"}:
                logs[key] = value
        logs.update(trace_logs)
        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=objectives,
            decision_variables=decisions,
            nondominated_objectives=objectives[nd_mask],
            nondominated_decisions=decisions[nd_mask],
            runtime_seconds=runtime,
            feasible_mask=feasible,
            nondominated_feasible_mask=feasible[nd_mask],
            logs=logs,
        )

    def _next_population(
        self,
        *,
        population: np.ndarray,
        scores: np.ndarray,
        iteration: int,
        max_iterations: int,
        encoding: ExtendedDeploymentEncoding,
        problem: DeploymentProblem,
        config: Config,
        rng: np.random.Generator,
        state: Dict[str, Any],
        alg_cfg: Dict[str, Any],
    ) -> np.ndarray:
        raise NotImplementedError

    def _algorithm_config(self, config: Config) -> Dict[str, Any]:
        raw = config.get(self._config_section, {}).get(self.method_key, config.get(self._config_section, {}))
        if not isinstance(raw, dict):
            raw = {}
        return {
            "population_size": int(raw.get("population_size", raw.get("populationSize", self.default_population_size))),
            "max_iterations": int(raw.get("max_iterations", raw.get("maxIterations", self.default_max_iterations))),
            **self._extra_algorithm_config(raw),
        }

    @property
    def _config_section(self) -> str:
        return self.method_key.split("_", 1)[0]

    def _extra_algorithm_config(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        return {}

    def _logs(
        self,
        *,
        encoding: ExtendedDeploymentEncoding,
        alg_cfg: Dict[str, Any],
        history: List[Dict[str, float]],
        best: np.ndarray,
        best_score: float,
        best_record: Dict[str, Any],
        evaluations: int,
    ) -> Dict[str, Any]:
        return {
            "algorithm": self.algorithm_name,
            "method_key": self.method_key,
            "baseline_label": self.display_name,
            "decision_space_label": "same-decision-space extended deployment",
            "chromosome_definition": "[x,y,z,station_type_index,sector_direction_index] per deployed station",
            "station_type_mapping": {"0": "5G", "1": "5GA"},
            "sector_direction_mapping": {str(i): float(v) for i, v in enumerate(NSGA2_SECTOR_AZIMUTHS_DEG.tolist())},
            "optimized_decision_variables": [
                "station_x",
                "station_y",
                "station_z",
                "station_type_index",
                "5ga_sector_direction_index",
            ],
            "asu_preset": str(best_record.get("asu_preset", ASU_ROUTE_SERVICE_V2)),
            "uses_tmc_asu": False,
            "population_size": int(alg_cfg["population_size"]),
            "max_iterations": int(alg_cfg["max_iterations"]),
            "evaluations": int(evaluations),
            "best_ASU": float(best_score),
            "best_chromosome": best.tolist(),
            "best_asu_record": best_record,
            "history": history,
            "algorithm_parameters": {k: v for k, v in alg_cfg.items() if k not in {"population_size", "max_iterations"}},
            "fair_optimization_table_eligible": True,
        }


def extended_asu_v2_config(config: Config) -> Config:
    """Return a copied config forcing full decision encoding and ASU-v2 metadata."""
    cfg = json.loads(json.dumps(config))
    preset = ASU_ROUTE_SERVICE_V2_SINR if _optimization_signal_metric(cfg) == "sinr" else ASU_ROUTE_SERVICE_V2
    cfg["asu_preset"] = preset
    cfg.setdefault("airwayServiceUtility", {})["asu_preset"] = preset
    if preset == ASU_ROUTE_SERVICE_V2_SINR:
        cfg.setdefault("airwayServiceUtilityV2", {})["signal_metric"] = "sinr"
        cfg["airwayServiceUtilityV2"]["optimization_signal_metric"] = "sinr"
        cfg.setdefault("evaluation", {})["optimization_signal_metric"] = "sinr"
    cfg.setdefault("heterogeneousDeployment", {})["enabled"] = True
    cfg.setdefault("particleEncoding", {})
    cfg["particleEncoding"]["optimizeStationType"] = True
    cfg["particleEncoding"]["optimizeSectorDirection"] = True
    cfg.setdefault("channel", {})
    cfg["channel"]["sector_directions_deg"] = [float(v) for v in NSGA2_SECTOR_AZIMUTHS_DEG.tolist()]
    cfg.setdefault("nsga2", {}).setdefault("repair", {"enabled": True, "enforceNonBuilding": True})
    return cfg


def initialize_population(
    pop_size: int,
    encoding: ExtendedDeploymentEncoding,
    problem: DeploymentProblem,
    config: Config,
    rng: np.random.Generator,
) -> np.ndarray:
    """Initialize and repair a full-decision population."""
    chromosomes = rng.uniform(encoding.lower_bounds, encoding.upper_bounds, size=(pop_size, encoding.num_variables))
    return repair_extended_chromosomes(chromosomes, encoding, problem.city_map, config, rng)


def evaluate_for_asu(
    chromosomes: np.ndarray,
    encoding: ExtendedDeploymentEncoding,
    problem: DeploymentProblem,
    config: Config,
) -> BioInspiredEvaluation:
    """Evaluate chromosomes with shared objectives and physical-cost ASU-v2 scores."""
    if _optimization_signal_metric(config) == "sinr":
        particles = unflatten_extended_chromosomes(chromosomes, encoding)
        evaluation = evaluate_with_existing_context_sinr_asu_v2(
            decisions=particles,
            problem=problem,
            config=config,
            method_name=str(config.get("experiment", {}).get("method", "bio_inspired_sinr")),
        )
        return BioInspiredEvaluation(
            objectives=np.asarray(evaluation.objectives, dtype=float),
            feasible_mask=np.asarray(evaluation.feasible, dtype=bool),
            asu_scores=np.asarray(evaluation.asu_values, dtype=float),
            asu_records=[dict(row) for row in evaluation.metrics],
        )
    evaluation = evaluate_extended_chromosomes(chromosomes, encoding, problem, config)
    scores: List[float] = []
    records: List[Dict[str, Any]] = []
    particles = unflatten_extended_chromosomes(chromosomes, encoding)
    for i in range(evaluation.objectives.shape[0]):
        n_5g, n_5ga = count_station_types_from_particle(particles[i])
        row = {
            "coverage_rate": evaluation.metrics["coverage_rate"][i],
            "mean_snr_db": evaluation.metrics["mean_snr_db"][i],
            "handover_count": evaluation.metrics["handover_count"][i],
            "deployment_cost": evaluation.metrics["deployment_cost"][i],
            "existing_route_continuous_coverage_rate": evaluation.metrics["existing_route_continuous_coverage_rate"][i],
            "future_route_continuous_coverage_rate": evaluation.metrics["future_route_continuous_coverage_rate"][i],
            "N_5G": n_5g,
            "N_5GA": n_5ga,
        }
        rec = asu_route_service_v2_from_metrics(row, config).as_dict()
        scores.append(float(rec["ASU"]))
        records.append(rec)
    return BioInspiredEvaluation(
        objectives=evaluation.objectives,
        feasible_mask=evaluation.feasible_mask,
        asu_scores=np.asarray(scores, dtype=float),
        asu_records=records,
    )


def _optimization_signal_metric(config: Config) -> str:
    raw = (
        config.get("optimization_signal_metric")
        or config.get("evaluation", {}).get("optimization_signal_metric")
        or config.get("airwayServiceUtilityV2", {}).get("optimization_signal_metric")
        or "snr"
    )
    return str(raw).strip().lower()


def count_station_types_from_particle(particle: np.ndarray) -> Tuple[int, int]:
    """Return 5G/5GA counts from repaired full-decision particle."""
    type_idx = np.rint(np.asarray(particle, dtype=float)[:, 3]).astype(int)
    n_5ga = int(np.sum(type_idx == 1))
    n_5g = int(type_idx.size - n_5ga)
    return n_5g, n_5ga


def random_population_like(population: np.ndarray, encoding: ExtendedDeploymentEncoding, rng: np.random.Generator) -> np.ndarray:
    """Draw random chromosomes with same population size and bounds."""
    return rng.uniform(encoding.lower_bounds, encoding.upper_bounds, size=population.shape)


def clip_to_bounds(population: np.ndarray, encoding: ExtendedDeploymentEncoding) -> np.ndarray:
    """Clip continuous chromosome values to configured bounds before repair."""
    return np.clip(np.asarray(population, dtype=float), encoding.lower_bounds[None, :], encoding.upper_bounds[None, :])
