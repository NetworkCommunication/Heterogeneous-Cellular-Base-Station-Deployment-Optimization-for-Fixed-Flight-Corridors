from __future__ import annotations

import json
from typing import Any, Dict, Literal

import numpy as np

import src.baselines.proposed_search_expansion_response_v2.adapter as v2_module
import src.baselines.proposed_search_expansion_response_v2_asu_v2.adapter as asu_v2_module
from src.baselines.base import BaselineResult, DeploymentProblem
from src.data.types import Config
from src.experiments.multiobjective_metrics import nondominated_mask


ForcedType = Literal["5G", "5GA"]


class _V2ForcedTypeCurrentFutureAdapter(asu_v2_module.ProposedSearchExpansionResponseV2ASUV2Adapter):
    """Config/adapter-level heterogeneous-deployment ablation for v2 ASU-v2.

    The optimizer core remains unchanged. This adapter constrains station type
    through temporary wrapper hooks around config materialization, particle
    repair, and evaluation, then restores the original hooks after the run.
    """

    group = "v2_heterogeneous_ablation_asu_v2"
    forced_station_type: ForcedType

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        original_method_config = v2_module._method_config
        original_evaluate_particles = v2_module._evaluate_particles
        original_repair_particles = v2_module._repair_particles
        forced_type = self.forced_station_type
        forced_idx = 0 if forced_type == "5G" else 1

        def constrained_config(
            raw_config: Config,
            method_key: str,
            *,
            response_enabled: bool,
            mild_only: bool,
            severe_restart_fraction: float,
        ) -> Config:
            cfg = asu_v2_module._method_config_asu_v2(
                raw_config,
                method_key,
                response_enabled=response_enabled,
                mild_only=mild_only,
                severe_restart_fraction=severe_restart_fraction,
            )
            cfg.setdefault("constrainedVariant", {})
            cfg["constrainedVariant"].update(
                {
                    "enabled": True,
                    "variant_family": "v2_heterogeneous_deployment_ablation",
                    "forced_new_station_type": forced_type,
                    "current_then_future_is_two_stage": True,
                    "single_stage_ablation_key": "v2_single_stage_all_routes",
                    "implementation_layer": "additive_baseline_adapter_hooks",
                    "optimizer_core_logic_modified": False,
                }
            )
            cfg.setdefault("particleEncoding", {})["optimizeStationType"] = False
            return cfg

        def constrained_repair(particles: np.ndarray, *args: Any, **kwargs: Any) -> np.ndarray:
            repaired = original_repair_particles(particles, *args, **kwargs)
            return _force_station_type(repaired, forced_idx)

        def constrained_eval(particles: np.ndarray, eval_problem: DeploymentProblem, eval_config: Config, method_key: str) -> Any:
            return asu_v2_module._evaluate_particles_asu_v2(
                _force_station_type(particles, forced_idx),
                eval_problem,
                eval_config,
                method_key,
            )

        try:
            v2_module._method_config = constrained_config  # type: ignore[assignment]
            v2_module._evaluate_particles = constrained_eval  # type: ignore[assignment]
            v2_module._repair_particles = constrained_repair  # type: ignore[assignment]
            result = v2_module.ProposedSearchExpansionResponseV2Adapter.run(self, problem, seed=seed, config=config)
        finally:
            v2_module._method_config = original_method_config  # type: ignore[assignment]
            v2_module._evaluate_particles = original_evaluate_particles  # type: ignore[assignment]
            v2_module._repair_particles = original_repair_particles  # type: ignore[assignment]

        _finalize_forced_type_result(result, problem, config, self.method_key, self.group, forced_type, forced_idx)
        return result


class V25GOnlyCurrentThenFutureAdapter(_V2ForcedTypeCurrentFutureAdapter):
    """V2 current->future ablation with all new stations constrained to 5G."""

    method_key = "v2_5g_only_current_then_future"
    display_name = "V2 5G-only current-then-future"
    forced_station_type = "5G"


class V25GAOnlyCurrentThenFutureAdapter(_V2ForcedTypeCurrentFutureAdapter):
    """V2 current->future ablation with all new stations constrained to 5GA."""

    method_key = "v2_5ga_only_current_then_future"
    display_name = "V2 5GA-only current-then-future"
    forced_station_type = "5GA"


def _finalize_forced_type_result(
    result: BaselineResult,
    problem: DeploymentProblem,
    config: Config,
    method_key: str,
    group: str,
    forced_type: ForcedType,
    forced_idx: int,
) -> None:
    cfg = json.loads(json.dumps(config))
    cfg["asu_preset"] = "asu_route_service_v2"
    cfg.setdefault("airwayServiceUtility", {})["asu_preset"] = "asu_route_service_v2"
    result.method_name = method_key
    result.group = group
    result.decision_variables = _force_station_type(result.decision_variables, forced_idx)
    if result.nondominated_decisions.size:
        result.nondominated_decisions = _force_station_type(result.nondominated_decisions, forced_idx)
    evaluation = asu_v2_module._evaluate_particles_asu_v2(result.decision_variables, problem, cfg, method_key)
    nd = nondominated_mask(evaluation.objectives) if evaluation.objectives.size else np.zeros((0,), dtype=bool)
    if not np.any(nd) and evaluation.objectives.shape[0]:
        nd[0] = True
    result.objective_vectors = evaluation.objectives
    result.feasible_mask = evaluation.feasible
    result.nondominated_objectives = evaluation.objectives[nd]
    result.nondominated_decisions = result.decision_variables[nd]
    result.nondominated_feasible_mask = evaluation.feasible[nd]
    idx = int(np.argmax(evaluation.asu_values)) if evaluation.asu_values.size else 0
    best = result.decision_variables[idx] if result.decision_variables.size else np.zeros((0, 5), dtype=float)
    best_record = dict(evaluation.metrics[idx]) if evaluation.metrics else {}
    result.logs.update(
        {
            "method_key": method_key,
            "asu_preset": "asu_route_service_v2",
            "uses_tmc_asu": False,
            "old_v2_asu_v2_behavior_preserved": True,
            "adapter_mode": "additive_v2_heterogeneous_deployment_ablation",
            "variant_family": "v2_only_ablation",
            "forced_new_station_type": forced_type,
            "station_type_decision": "fixed_by_additive_ablation_adapter",
            "current_future_is_two_stage": True,
            "single_stage_ablation_key": "v2_single_stage_all_routes",
            "existing_stations_excluded_from_C_dep": True,
            "best_ASU": float(evaluation.asu_values[idx]) if evaluation.asu_values.size else float("nan"),
            "best_asu_record": {
                key: value
                for key, value in best_record.items()
                if key in {"ASU", "Q_current", "Q_future", "denominator", "C_dep", "handover_count", "N_5G", "N_5GA"}
            },
            "best_chromosome": np.asarray(best, dtype=float).reshape(-1).tolist(),
        }
    )
    result.logs["response_count"] = int(result.logs.get("trigger_count", result.logs.get("response_count", 0)))
    for key in [
        "mild_response_count",
        "moderate_response_count",
        "severe_response_count",
        "restart_count",
        "pbest_preservation_count",
    ]:
        result.logs.setdefault(key, 0)


def _force_station_type(particles: np.ndarray, forced_idx: int) -> np.ndarray:
    arr = np.asarray(particles, dtype=float).copy()
    if arr.size == 0:
        return arr
    if arr.ndim == 2:
        arr[:, 3] = float(forced_idx)
    elif arr.ndim == 3:
        arr[:, :, 3] = float(forced_idx)
    else:
        raise ValueError("forced-type particles must be 2D or 3D")
    if int(forced_idx) == 0:
        arr[..., 4] = 0.0
    else:
        arr[..., 4] = np.clip(np.rint(arr[..., 4]), 0.0, 7.0)
    return arr
