"""CLPSO-LS decomposition-adapted fair optimization baseline."""

