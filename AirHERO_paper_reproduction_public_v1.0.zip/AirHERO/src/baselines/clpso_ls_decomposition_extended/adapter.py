from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Tuple

import numpy as np

from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.baselines.moead_extended.decomposition import (
    generate_weight_vectors,
    normalization_range,
    tchebycheff_scalar,
    update_ideal_point,
)
from src.baselines.moead_extended.adapter import _update_archive
from src.baselines.nsga2_extended.adapter import _validate_station_type_mapping
from src.baselines.nsga2_extended.encoding import (
    NSGA2_SECTOR_AZIMUTHS_DEG,
    build_extended_deployment_encoding,
    unflatten_extended_chromosomes,
)
from src.baselines.nsga2_extended.evaluation import evaluate_extended_chromosomes
from src.baselines.nsga2_extended.initialization import initialize_extended_with_stage2_seeded_particles
from src.baselines.nsga2_extended.repair import repair_extended_chromosomes
from src.data.types import Config


class CLPSOLSDecompositionExtendedAdapter(BaselineAdapter):
    """CLPSO-LS adapted with decomposition for the TMC multiobjective deployment problem."""

    method_key = "clpso_ls_decomposition_extended"
    display_name = "CLPSO-LS-Ext"
    group = "fair_optimization_baseline"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        """Run one CLPSO-LS decomposition-adapted optimization."""
        rng = np.random.default_rng(int(seed))
        method_cfg = _extended_config(config)
        _validate_station_type_mapping(method_cfg)
        cfg = _clpso_config(method_cfg)
        encoding = build_extended_deployment_encoding(method_cfg)

        pop_size = int(cfg["population_size"])
        max_gen = int(cfg["max_generations"])
        max_evals = cfg.get("max_evaluations", None)
        max_evals_int = None if max_evals is None else int(max_evals)
        t0 = time.time()

        weights = generate_weight_vectors(pop_size, 4)
        particles, init_stats = initialize_extended_with_stage2_seeded_particles(
            config=method_cfg,
            problem=problem,
            encoding=encoding,
            population_size=pop_size,
            rng=rng,
        )
        velocity = _initial_velocity(pop_size, encoding.num_variables, encoding.lower_bounds, encoding.upper_bounds, rng)
        evaluation = evaluate_extended_chromosomes(particles, encoding, problem, method_cfg)
        objectives = evaluation.objectives
        feasible_mask = evaluation.feasible_mask
        evaluations = int(particles.shape[0])
        ideal = update_ideal_point(np.zeros((0,), dtype=float), objectives)
        norm_min, norm_max = normalization_range(objectives, ideal)
        scalar_values = _scalar_values(objectives, weights, ideal, norm_min, norm_max, cfg)

        pbest = particles.copy()
        pbest_obj = objectives.copy()
        pbest_feasible = feasible_mask.copy()
        pbest_scalar = scalar_values.copy()
        exemplars = _refresh_exemplars(pbest_scalar, pop_size, encoding.num_variables, rng)
        exemplar_refresh_count = 1
        archive_x, archive_obj, archive_feasible = _update_archive(
            np.zeros((0, encoding.num_variables), dtype=float),
            np.zeros((0, objectives.shape[1]), dtype=float),
            np.zeros((0,), dtype=bool),
            particles,
            objectives,
            feasible_mask,
            int(cfg["archive_size"]),
        )

        q_history: List[float] = []
        history: List[Dict[str, float]] = []
        local_search_triggered = False
        local_search_reason = "not_triggered"
        local_search_evaluations = 0

        for gen in range(max_gen):
            if max_evals_int is not None and evaluations + pop_size > max_evals_int:
                break
            if gen > 0 and gen % int(cfg["exemplar_refresh_interval"]) == 0:
                exemplars = _refresh_exemplars(pbest_scalar, pop_size, encoding.num_variables, rng)
                exemplar_refresh_count += 1

            inertia = _linear_inertia(gen, max_gen, float(cfg["inertia_weight_start"]), float(cfg["inertia_weight_end"]))
            learned = pbest[exemplars, np.arange(encoding.num_variables)[None, :]]
            velocity = inertia * velocity + float(cfg["learning_factor"]) * rng.random(velocity.shape) * (learned - particles)
            velocity = _clip_velocity(velocity, encoding.lower_bounds, encoding.upper_bounds, float(cfg["velocity_clip_ratio"]))
            particles = particles + velocity
            particles = repair_extended_chromosomes(particles, encoding, problem.city_map, method_cfg, rng)

            evaluation = evaluate_extended_chromosomes(particles, encoding, problem, method_cfg)
            objectives = evaluation.objectives
            feasible_mask = evaluation.feasible_mask
            evaluations += int(particles.shape[0])
            ideal = update_ideal_point(ideal, objectives)
            norm_min, norm_max = normalization_range(np.vstack([pbest_obj, objectives]), ideal)
            scalar_values = _scalar_values(objectives, weights, ideal, norm_min, norm_max, cfg)

            improved = scalar_values <= pbest_scalar
            pbest[improved] = particles[improved]
            pbest_obj[improved] = objectives[improved]
            pbest_feasible[improved] = feasible_mask[improved]
            pbest_scalar[improved] = scalar_values[improved]
            archive_x, archive_obj, archive_feasible = _update_archive(
                archive_x,
                archive_obj,
                archive_feasible,
                particles,
                objectives,
                feasible_mask,
                int(cfg["archive_size"]),
            )

            q_value = _quasi_entropy_like_index(pbest, encoding.lower_bounds, encoding.upper_bounds)
            q_history.append(float(q_value))
            if _should_start_local_search(q_history, cfg, local_search_triggered):
                ls = _run_mixed_variable_pattern_search(
                    pbest=pbest,
                    pbest_obj=pbest_obj,
                    pbest_feasible=pbest_feasible,
                    pbest_scalar=pbest_scalar,
                    weights=weights,
                    ideal=ideal,
                    norm_min=norm_min,
                    norm_max=norm_max,
                    encoding=encoding,
                    problem=problem,
                    config=method_cfg,
                    cfg=cfg,
                    rng=rng,
                    remaining_budget=_remaining_budget(max_evals_int, evaluations, int(cfg["local_search_budget"])),
                )
                local_search_triggered = True
                local_search_reason = str(ls["trigger_reason"])
                local_search_evaluations += int(ls["evaluations"])
                evaluations += int(ls["evaluations"])
                pbest = ls["pbest"]
                pbest_obj = ls["pbest_obj"]
                pbest_feasible = ls["pbest_feasible"]
                pbest_scalar = ls["pbest_scalar"]
                ideal = update_ideal_point(ideal, pbest_obj)
                norm_min, norm_max = normalization_range(np.vstack([pbest_obj, objectives]), ideal)
                archive_x, archive_obj, archive_feasible = _update_archive(
                    archive_x,
                    archive_obj,
                    archive_feasible,
                    ls["evaluated_x"],
                    ls["evaluated_obj"],
                    ls["evaluated_feasible"],
                    int(cfg["archive_size"]),
                )

            history.append(
                {
                    "generation": float(gen + 1),
                    "evaluations": float(evaluations),
                    "archive_size": float(archive_obj.shape[0]),
                    "pbest_improvement_count": float(np.sum(improved.astype(int))),
                    "quasi_entropy_like_index": float(q_value),
                    "local_search_triggered": float(1 if local_search_triggered else 0),
                    "feasibility_rate": float(np.mean(feasible_mask.astype(float))) if feasible_mask.size else 0.0,
                }
            )
            if max_evals_int is not None and evaluations >= max_evals_int:
                break

        if archive_obj.size == 0:
            archive_x, archive_obj, archive_feasible = _update_archive(
                archive_x,
                archive_obj,
                archive_feasible,
                pbest,
                pbest_obj,
                pbest_feasible,
                int(cfg["archive_size"]),
            )
        if not local_search_triggered:
            local_search_reason = _local_search_not_triggered_reason(q_history, cfg)

        decision_variables = unflatten_extended_chromosomes(particles, encoding)
        nd_decisions = unflatten_extended_chromosomes(archive_x, encoding)
        runtime = float(time.time() - t0)
        logs: Dict[str, Any] = {
            "paper": "Cao et al. 2019 CLPSO-LS",
            "algorithm": "CLPSO-LS adapted with decomposition for the TMC multiobjective deployment problem",
            "baseline_label": "CLPSO-LS-Ext",
            "decision_space_label": "same-decision-space extended deployment",
            "chromosome_definition": "[x,y,z,station_type_index,sector_direction_index] per deployed station",
            "chromosome_length": int(encoding.num_variables),
            "optimized_decision_variables": [
                "station_x",
                "station_y",
                "station_z",
                "station_type_index",
                "5ga_sector_direction_index",
            ],
            "station_type_decision": "optimized as station_type_index gene",
            "sector_direction_decision": "optimized as 5ga_sector_direction_index gene",
            "station_type_mapping": {"0": "5G", "1": "5GA"},
            "sector_direction_mapping": {str(i): float(v) for i, v in enumerate(NSGA2_SECTOR_AZIMUTHS_DEG.tolist())},
            "decomposition": str(cfg["decomposition"]),
            "objective_normalization": bool(cfg["objective_normalization"]),
            "comprehensive_learning": (
                "Each particle has one scalar subproblem; each decision dimension learns from a deterministic, "
                "seeded exemplar selected from two candidate particles' pbest scalar values."
            ),
            "local_search_trigger_rule": (
                "Approximate quasi-entropy is the mean normalized standard deviation of pbest positions. "
                "Local search starts when the configured window is available and the latest value is below "
                "quasi_entropy_threshold."
            ),
            "local_search_method": str(cfg["local_search_method"]),
            "local_search_triggered": bool(local_search_triggered),
            "local_search_reason": local_search_reason,
            "local_search_evaluations": int(local_search_evaluations),
            "deviation_from_paper": (
                "The source paper is single-objective multimodal CLPSO-LS. This baseline wraps CLPSO-LS in "
                "decomposition/scalarization for the shared TMC multiobjective decision space; it is not an exact "
                "native multiobjective reproduction."
            ),
            "mixed_discrete_adaptation": (
                "Velocity updates operate in the real-coded flattened space; repair clips x/y/z and rounds/clips "
                "station_type_index and sector_direction_index before every evaluation."
            ),
            "uses_fixed_station_type_plan": False,
            "fair_optimization_table_eligible": True,
            "population_size": pop_size,
            "generations_completed": len(history),
            "evaluations": evaluations,
            "max_evaluations": "" if max_evals_int is None else int(max_evals_int),
            "inertia_weight_start": float(cfg["inertia_weight_start"]),
            "inertia_weight_end": float(cfg["inertia_weight_end"]),
            "learning_factor": float(cfg["learning_factor"]),
            "exemplar_refresh_interval": int(cfg["exemplar_refresh_interval"]),
            "exemplar_refresh_count": int(exemplar_refresh_count),
            "quasi_entropy_window": int(cfg["quasi_entropy_window"]),
            "quasi_entropy_threshold": float(cfg["quasi_entropy_threshold"]),
            "archive_size": int(archive_obj.shape[0]),
            "feasibility_rate": float(np.mean(feasible_mask.astype(float))) if feasible_mask.size else 0.0,
            "nondominated_feasibility_rate": (
                float(np.mean(archive_feasible.astype(float))) if archive_feasible.size else 0.0
            ),
            "initialization_stats": init_stats,
            "history": history,
        }
        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=objectives,
            decision_variables=decision_variables,
            nondominated_objectives=archive_obj,
            nondominated_decisions=nd_decisions,
            runtime_seconds=runtime,
            feasible_mask=feasible_mask,
            nondominated_feasible_mask=archive_feasible,
            logs=logs,
        )


def _clpso_config(config: Config) -> Dict[str, Any]:
    raw = dict(config.get("clpso_ls_decomposition", config.get("clpsoLsDecomposition", {})))
    pso = config.get("pso", {})
    population_size = int(raw.get("population_size", raw.get("populationSize", pso.get("numParticles", 50))))
    max_generations = int(raw.get("max_generations", raw.get("maxGenerations", pso.get("maxIterations", 100))))
    decomposition = str(raw.get("decomposition", "tchebycheff")).strip().lower()
    if decomposition not in {"tchebycheff", "weighted_sum"}:
        raise ValueError("clpso_ls_decomposition_extended supports decomposition='tchebycheff' or 'weighted_sum'")
    return {
        "population_size": max(2, population_size),
        "max_generations": max(0, max_generations),
        "max_evaluations": raw.get("max_evaluations", raw.get("maxEvaluations", None)),
        "decomposition": decomposition,
        "objective_normalization": bool(raw.get("objective_normalization", raw.get("objectiveNormalization", True))),
        "inertia_weight_start": float(raw.get("inertia_weight_start", raw.get("inertiaWeightStart", 0.9))),
        "inertia_weight_end": float(raw.get("inertia_weight_end", raw.get("inertiaWeightEnd", 0.4))),
        "learning_factor": float(raw.get("learning_factor", raw.get("learningFactor", 1.5))),
        "exemplar_refresh_interval": int(
            raw.get("exemplar_refresh_interval", raw.get("refresh_gap", raw.get("refreshGap", 7)))
        ),
        "quasi_entropy_window": int(raw.get("quasi_entropy_window", raw.get("quasiEntropyWindow", 3))),
        "quasi_entropy_threshold": float(raw.get("quasi_entropy_threshold", raw.get("quasiEntropyThreshold", 0.08))),
        "local_search_enabled": bool(raw.get("local_search_enabled", raw.get("localSearchEnabled", True))),
        "local_search_budget": int(raw.get("local_search_budget", raw.get("localSearchBudget", 4))),
        "local_search_method": str(
            raw.get("local_search_method", raw.get("localSearchMethod", "mixed_variable_pattern_search"))
        ),
        "local_search_initial_step_ratio": float(
            raw.get("local_search_initial_step_ratio", raw.get("localSearchInitialStepRatio", 0.05))
        ),
        "local_search_step_decay": float(raw.get("local_search_step_decay", raw.get("localSearchStepDecay", 0.5))),
        "velocity_clip_ratio": float(raw.get("velocity_clip_ratio", raw.get("velocityClipRatio", 0.25))),
        "archive_size": int(raw.get("archive_size", raw.get("archiveSize", max(population_size, 20)))),
    }


def _extended_config(config: Config) -> Config:
    cfg = json.loads(json.dumps(config))
    cfg.setdefault("heterogeneousDeployment", {})
    cfg["heterogeneousDeployment"]["enabled"] = True
    cfg.setdefault("particleEncoding", {})
    cfg["particleEncoding"]["optimizeStationType"] = True
    cfg["particleEncoding"]["optimizeSectorDirection"] = True
    cfg.setdefault("channel", {})
    cfg["channel"]["sector_directions_deg"] = [float(v) for v in NSGA2_SECTOR_AZIMUTHS_DEG.tolist()]
    repair_cfg = cfg.get("clpso_ls_decomposition", {}).get("repair", None)
    if repair_cfg is not None:
        cfg.setdefault("nsga2", {})["repair"] = dict(repair_cfg)
    return cfg


def _scalar_values(
    objectives: np.ndarray,
    weights: np.ndarray,
    ideal: np.ndarray,
    norm_min: np.ndarray,
    norm_max: np.ndarray,
    cfg: Dict[str, Any],
) -> np.ndarray:
    obj = np.asarray(objectives, dtype=float)
    if str(cfg["decomposition"]) == "weighted_sum":
        if bool(cfg["objective_normalization"]):
            span = np.maximum(np.asarray(norm_max, dtype=float) - np.asarray(norm_min, dtype=float), 1e-12)
            obj = (obj - norm_min[None, :]) / span[None, :]
        return np.sum(np.asarray(weights, dtype=float) * obj, axis=1)
    return tchebycheff_scalar(
        obj,
        weights,
        ideal,
        norm_min,
        norm_max,
        normalize=bool(cfg["objective_normalization"]),
    )


def _initial_velocity(
    population_size: int,
    num_variables: int,
    lower_bounds: np.ndarray,
    upper_bounds: np.ndarray,
    rng: np.random.Generator,
) -> np.ndarray:
    span = np.maximum(np.asarray(upper_bounds, dtype=float) - np.asarray(lower_bounds, dtype=float), 1e-12)
    return rng.uniform(-0.05, 0.05, size=(int(population_size), int(num_variables))) * span[None, :]


def _clip_velocity(velocity: np.ndarray, lower_bounds: np.ndarray, upper_bounds: np.ndarray, ratio: float) -> np.ndarray:
    span = np.maximum(np.asarray(upper_bounds, dtype=float) - np.asarray(lower_bounds, dtype=float), 1e-12)
    vmax = max(float(ratio), 1e-6) * span
    return np.clip(np.asarray(velocity, dtype=float), -vmax[None, :], vmax[None, :])


def _refresh_exemplars(
    pbest_scalar: np.ndarray,
    population_size: int,
    num_variables: int,
    rng: np.random.Generator,
) -> np.ndarray:
    exemplars = np.zeros((int(population_size), int(num_variables)), dtype=int)
    scalar = np.asarray(pbest_scalar, dtype=float)
    for i in range(int(population_size)):
        for j in range(int(num_variables)):
            a = int(rng.integers(0, int(population_size)))
            b = int(rng.integers(0, int(population_size)))
            exemplars[i, j] = a if scalar[a] <= scalar[b] else b
    return exemplars


def _linear_inertia(generation: int, max_generations: int, start: float, end: float) -> float:
    if int(max_generations) <= 1:
        return float(end)
    ratio = float(np.clip(generation / max(int(max_generations) - 1, 1), 0.0, 1.0))
    return float(start + ratio * (end - start))


def _quasi_entropy_like_index(chromosomes: np.ndarray, lower_bounds: np.ndarray, upper_bounds: np.ndarray) -> float:
    arr = np.asarray(chromosomes, dtype=float)
    if arr.ndim != 2 or arr.shape[0] <= 1:
        return 0.0
    span = np.maximum(np.asarray(upper_bounds, dtype=float) - np.asarray(lower_bounds, dtype=float), 1e-12)
    normalized = (arr - lower_bounds[None, :]) / span[None, :]
    return float(np.mean(np.std(normalized, axis=0)))


def _should_start_local_search(q_history: List[float], cfg: Dict[str, Any], already_triggered: bool) -> bool:
    if already_triggered or not bool(cfg["local_search_enabled"]):
        return False
    window = int(max(cfg["quasi_entropy_window"], 1))
    if len(q_history) < window:
        return False
    return float(q_history[-1]) <= float(cfg["quasi_entropy_threshold"])


def _local_search_not_triggered_reason(q_history: List[float], cfg: Dict[str, Any]) -> str:
    if not bool(cfg["local_search_enabled"]):
        return "local_search_disabled"
    if len(q_history) < int(max(cfg["quasi_entropy_window"], 1)):
        return "quasi_entropy_window_not_reached"
    return "quasi_entropy_above_threshold"


def _remaining_budget(max_evals: int | None, evaluations: int, configured_budget: int) -> int:
    budget = int(max(configured_budget, 0))
    if max_evals is None:
        return budget
    return int(max(min(budget, int(max_evals) - int(evaluations)), 0))


def _run_mixed_variable_pattern_search(
    *,
    pbest: np.ndarray,
    pbest_obj: np.ndarray,
    pbest_feasible: np.ndarray,
    pbest_scalar: np.ndarray,
    weights: np.ndarray,
    ideal: np.ndarray,
    norm_min: np.ndarray,
    norm_max: np.ndarray,
    encoding: Any,
    problem: DeploymentProblem,
    config: Config,
    cfg: Dict[str, Any],
    rng: np.random.Generator,
    remaining_budget: int,
) -> Dict[str, Any]:
    """Derivative-free local search that respects mixed-variable repair."""
    if int(remaining_budget) <= 0:
        return {
            "trigger_reason": "quasi_entropy_threshold_met_but_no_remaining_budget",
            "evaluations": 0,
            "pbest": pbest,
            "pbest_obj": pbest_obj,
            "pbest_feasible": pbest_feasible,
            "pbest_scalar": pbest_scalar,
            "evaluated_x": np.zeros((0, encoding.num_variables), dtype=float),
            "evaluated_obj": np.zeros((0, pbest_obj.shape[1]), dtype=float),
            "evaluated_feasible": np.zeros((0,), dtype=bool),
        }

    best_idx = int(np.argmin(np.asarray(pbest_scalar, dtype=float)))
    current = np.asarray(pbest[best_idx : best_idx + 1], dtype=float).copy()
    current_obj = np.asarray(pbest_obj[best_idx : best_idx + 1], dtype=float).copy()
    current_feasible = np.asarray(pbest_feasible[best_idx : best_idx + 1], dtype=bool).copy()
    current_scalar = float(pbest_scalar[best_idx])
    step = (
        np.maximum(np.asarray(encoding.upper_bounds, dtype=float) - np.asarray(encoding.lower_bounds, dtype=float), 1e-12)
        * float(cfg["local_search_initial_step_ratio"])
    )
    evaluated_x: List[np.ndarray] = []
    evaluated_obj: List[np.ndarray] = []
    evaluated_feasible: List[bool] = []
    evals = 0
    method = str(cfg["local_search_method"]).strip().lower()
    trigger_reason = "quasi_entropy_threshold_met"
    if method in {"bfgs", "nelder_mead"}:
        trigger_reason += f"_{method}_approximated_by_mixed_variable_pattern_search"

    while evals < int(remaining_budget):
        dim = int(rng.integers(0, encoding.num_variables))
        direction = -1.0 if rng.random() < 0.5 else 1.0
        candidate = current.copy()
        candidate[0, dim] += direction * step[dim]
        candidate = repair_extended_chromosomes(candidate, encoding, problem.city_map, config, rng)
        ev = evaluate_extended_chromosomes(candidate, encoding, problem, config)
        obj = ev.objectives
        feasible = ev.feasible_mask
        candidate_ideal = update_ideal_point(ideal, obj)
        cand_scalar = float(_scalar_values(obj, weights[best_idx : best_idx + 1], candidate_ideal, norm_min, norm_max, cfg)[0])
        evaluated_x.append(candidate[0].copy())
        evaluated_obj.append(obj[0].copy())
        evaluated_feasible.append(bool(feasible[0]))
        evals += 1
        if cand_scalar <= current_scalar:
            current = candidate
            current_obj = obj
            current_feasible = feasible
            current_scalar = cand_scalar
            step = step * max(float(cfg["local_search_step_decay"]), 1e-6)

    pbest = pbest.copy()
    pbest_obj = pbest_obj.copy()
    pbest_feasible = pbest_feasible.copy()
    pbest_scalar = pbest_scalar.copy()
    if current_scalar <= float(pbest_scalar[best_idx]):
        pbest[best_idx] = current[0]
        pbest_obj[best_idx] = current_obj[0]
        pbest_feasible[best_idx] = bool(current_feasible[0])
        pbest_scalar[best_idx] = current_scalar

    return {
        "trigger_reason": trigger_reason,
        "evaluations": evals,
        "pbest": pbest,
        "pbest_obj": pbest_obj,
        "pbest_feasible": pbest_feasible,
        "pbest_scalar": pbest_scalar,
        "evaluated_x": np.asarray(evaluated_x, dtype=float).reshape(-1, encoding.num_variables),
        "evaluated_obj": np.asarray(evaluated_obj, dtype=float).reshape(-1, pbest_obj.shape[1]),
        "evaluated_feasible": np.asarray(evaluated_feasible, dtype=bool),
    }
