# CLPSO-LS-Ext

`clpso_ls_decomposition_extended` is documented as:

```text
CLPSO-LS adapted with decomposition for the TMC multiobjective deployment problem.
```

The reference CLPSO-LS paper is a single-objective multimodal optimizer. This
baseline therefore does not claim exact native multiobjective reproduction.
It wraps CLPSO-LS in a decomposition/scalarization layer so each particle is
associated with one scalar subproblem while the final archive and all fair
metrics still use the shared multiobjective vectors.

Faithful components:

- comprehensive learning from different particles' pbest values per dimension;
- linearly decreasing inertia weight;
- adaptive local-search start based on a diversity/quasi-entropy-like index;
- local search after convergence/basin-entry evidence.

Adapted components:

- objective vectors are converted to scalar values by Tchebycheff or weighted
  sum decomposition;
- local search is a derivative-free mixed-variable pattern search by default,
  because BFGS/Nelder-Mead are not directly suitable for rounded station type
  and sector-direction genes;
- Stage-1/Stage-2 seeded initialization is used for fair comparison with the
  other TMC same-decision-space baselines.

Mixed-variable repair:

- x/y/z are clipped to the configured deployment bounds and non-building repair
  is reused from `nsga2_extended`;
- `station_type_index` is rounded/clipped to 0 or 1;
- `sector_direction_index` is rounded/clipped to 0..7 and decoded to one of
  `[0,45,90,135,180,225,270,315]` for every 5GA station.
