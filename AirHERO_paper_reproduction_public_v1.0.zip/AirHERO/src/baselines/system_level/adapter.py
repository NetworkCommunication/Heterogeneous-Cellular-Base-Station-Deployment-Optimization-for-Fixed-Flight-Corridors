from __future__ import annotations

import time
from typing import Any, Dict, List, Sequence

import numpy as np

from src.algorithms.init_strategies import ensure_non_building, kmeans_init
from src.algorithms.stage1_deployment import (
    choose_stage1_5ga_sector_direction,
    deploy_stage1_blind_spots,
)
from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.data.types import Config
from src.experiments.evaluation_consistency import evaluate_with_existing_context, objective_vector_from_metrics
from src.experiments.multiobjective_metrics import nondominated_mask
from src.propagation.low_fidelity import compute_point_snr
from src.propagation.sector_geometry import DEFAULT_SECTOR_DIRECTIONS_DEG, nearest_supported_sector_direction_deg

try:
    from sklearn.cluster import KMeans
except Exception:  # pragma: no cover - optional dependency fallback.
    KMeans = None


SYSTEM_BASELINE_GROUP = "system_level_baseline"


class ExistingOnlyAdapter(BaselineAdapter):
    """Evaluate current configured base stations without adding new stations."""

    method_key = "existing_only"
    display_name = "Existing stations only"
    group = SYSTEM_BASELINE_GROUP
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        t0 = time.time()
        particle = _existing_station_particle(config)
        return _build_result(
            method_key=self.method_key,
            group=self.group,
            seed=seed,
            particle_set=particle[None, :, :],
            problem=problem,
            config=config,
            started_at=t0,
            logs={
                "baseline_label": "existing_only",
                "deployment_rule": "Evaluate heterogeneousDeployment.existingStations only; no added stations.",
                "added_station_count": 0,
            },
        )


class RandomDeploymentAdapter(BaselineAdapter):
    """Random deployment system baseline with random valid 5GA sector directions."""

    method_key = "random_deployment"
    display_name = "Random deployment"
    group = SYSTEM_BASELINE_GROUP
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        t0 = time.time()
        rng = np.random.default_rng(int(seed))
        num_candidates = _num_candidates(config, self.method_key)
        particles = np.stack(
            [_random_particle(config, problem, rng, random_sector=True) for _ in range(num_candidates)],
            axis=0,
        )
        return _build_result(
            method_key=self.method_key,
            group=self.group,
            seed=seed,
            particle_set=particles,
            problem=problem,
            config=config,
            started_at=t0,
            logs={
                "baseline_label": "random_deployment",
                "deployment_rule": "Uniform random station locations; station types follow configured ratios.",
                "sector_assignment_rule": "5GA sector_direction_index sampled uniformly from the eight valid directions.",
                "num_candidates": num_candidates,
            },
        )


class RandomRouteCorridorDeploymentAdapter(BaselineAdapter):
    """Random deployment sampled near the route corridor as a stronger random baseline."""

    method_key = "random_route_corridor_deployment"
    display_name = "Random route-corridor deployment"
    group = SYSTEM_BASELINE_GROUP
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        t0 = time.time()
        rng = np.random.default_rng(int(seed))
        num_candidates = _num_candidates(config, self.method_key)
        particles = np.stack(
            [_random_route_corridor_particle(config, problem, rng, random_sector=True) for _ in range(num_candidates)],
            axis=0,
        )
        return _build_result(
            method_key=self.method_key,
            group=self.group,
            seed=seed,
            particle_set=particles,
            problem=problem,
            config=config,
            started_at=t0,
            logs={
                "baseline_label": "random_route_corridor_deployment",
                "deployment_rule": "Random station locations sampled within a configured buffer around route/blind route points.",
                "sector_assignment_rule": "5GA sector_direction_index sampled uniformly from the eight valid directions.",
                "num_candidates": num_candidates,
                "route_corridor_buffer_m": _route_corridor_buffer_m(config, self.method_key),
            },
        )


class KMeansDeploymentAdapter(BaselineAdapter):
    """KMeans deployment baseline with enumerated-best 5GA sector assignment."""

    method_key = "kmeans_deployment"
    display_name = "KMeans deployment"
    group = SYSTEM_BASELINE_GROUP
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        t0 = time.time()
        rng = np.random.default_rng(int(seed))
        spatial, target_points = _route_aware_spatial(
            problem=problem,
            config=config,
            rng=rng,
        )
        particle = _typed_particle(
            spatial=spatial,
            config=config,
            sector_rule="enumerate_best",
            sector_points=target_points,
            rng=rng,
        )
        return _build_result(
            method_key=self.method_key,
            group=self.group,
            seed=seed,
            particle_set=particle[None, :, :],
            problem=problem,
            config=config,
            started_at=t0,
            logs={
                "baseline_label": "kmeans_deployment",
                "deployment_rule": "Route-aware KMeans station locations from existing-only blind route points when available; otherwise all route points.",
                "sector_assignment_rule": "5GA sectors use enumerate_best over eight compass directions.",
                "route_target_point_count": int(target_points.shape[0]),
            },
        )


class GreedyBlindSpotFillingAdapter(BaselineAdapter):
    """Greedy Stage-1-style blind-spot filling as a system-level baseline."""

    method_key = "greedy_blind_spot_filling"
    display_name = "Greedy blind-spot filling"
    group = SYSTEM_BASELINE_GROUP
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        t0 = time.time()
        rng = np.random.default_rng(int(seed))
        existing = _existing_station_particle(config)
        existing_spatial = existing[:, :3] if existing.size else np.zeros((0, 3), dtype=float)
        stage1 = deploy_stage1_blind_spots(
            test_points=problem.test_points,
            existing_stations=existing_spatial,
            config=_greedy_stage1_config(config),
            city_map=problem.city_map,
            channel_params=problem.channel_params,
            rng=rng,
        )
        added = _records_to_particle(stage1.added_station_records or [], config)
        particle = np.vstack([existing, added]) if existing.size or added.size else np.zeros((0, 5), dtype=float)
        return _build_result(
            method_key=self.method_key,
            group=self.group,
            seed=seed,
            particle_set=particle[None, :, :],
            problem=problem,
            config=config,
            started_at=t0,
            logs={
                "baseline_label": "greedy_blind_spot_filling",
                "deployment_rule": "Evaluate existing stations plus Stage-1 greedy blind-spot additions.",
                "sector_assignment_rule": "5GA additions use enumerate_best over eight compass directions.",
                "stage1_stats": dict(stage1.stats),
                "added_station_count": int(added.shape[0]),
            },
        )


class FiveGOnlyAdapter(BaselineAdapter):
    """KMeans placement using only omnidirectional 5G stations."""

    method_key = "5g_only"
    display_name = "5G only"
    group = SYSTEM_BASELINE_GROUP
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        t0 = time.time()
        rng = np.random.default_rng(int(seed))
        spatial, target_points = _route_aware_spatial(problem=problem, config=config, rng=rng)
        particle = _forced_type_particle(spatial, config, station_type="5G", sector_idx=0)
        return _build_result(
            method_key=self.method_key,
            group=self.group,
            seed=seed,
            particle_set=particle[None, :, :],
            problem=problem,
            config=config,
            started_at=t0,
            logs={
                "baseline_label": "5g_only",
                "deployment_rule": "Route-aware KMeans station locations with all deployed stations forced to 5G.",
                "sector_assignment_rule": "No 5GA station is deployed; sector direction is not applicable.",
                "route_target_point_count": int(target_points.shape[0]),
            },
        )


class FiveGAFixedSectorAdapter(BaselineAdapter):
    """KMeans placement using 5GA stations with documented fixed sectors."""

    method_key = "5ga_fixed_sector"
    display_name = "5GA fixed sector"
    group = SYSTEM_BASELINE_GROUP
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        t0 = time.time()
        rng = np.random.default_rng(int(seed))
        spatial, target_points = _route_aware_spatial(problem=problem, config=config, rng=rng)
        fixed_azimuth = float(
            config.get("systemBaselines", {})
            .get(self.method_key, {})
            .get("fixedSectorAzimuthDeg", config.get("heterogeneousDeployment", {}).get("defaultSectorAzimuthDeg", 0.0))
        )
        sector_rule = str(
            config.get("systemBaselines", {}).get(self.method_key, {}).get("sectorRule", "nearest_route_cluster_centroid")
        ).strip().lower()
        if sector_rule == "nearest_route_cluster_centroid":
            particle = _forced_5ga_route_facing_particle(spatial, config, target_points)
            sector_note = "Each 5GA sector points deterministically toward the nearest route-cluster centroid."
            fixed_sector_for_log = "route_facing"
        else:
            sector_idx = _sector_index(fixed_azimuth)
            particle = _forced_type_particle(spatial, config, station_type="5GA", sector_idx=sector_idx)
            sector_note = (
                "Fixed/rule-based sector assignment; every 5GA station uses the configured "
                "systemBaselines.5ga_fixed_sector.fixedSectorAzimuthDeg snapped to a valid compass direction."
            )
            fixed_sector_for_log = float(DEFAULT_SECTOR_DIRECTIONS_DEG[sector_idx])
        return _build_result(
            method_key=self.method_key,
            group=self.group,
            seed=seed,
            particle_set=particle[None, :, :],
            problem=problem,
            config=config,
            started_at=t0,
            logs={
                "baseline_label": "5ga_fixed_sector",
                "deployment_rule": "Route-aware KMeans station locations with all deployed stations forced to 5GA.",
                "sector_assignment_rule": sector_note,
                "fixed_sector_azimuth_deg": fixed_sector_for_log,
                "route_target_point_count": int(target_points.shape[0]),
            },
        )


def system_level_adapters() -> List[BaselineAdapter]:
    """Return all implemented TMC system-level baseline adapters."""
    return [
        ExistingOnlyAdapter(),
        RandomDeploymentAdapter(),
        RandomRouteCorridorDeploymentAdapter(),
        KMeansDeploymentAdapter(),
        GreedyBlindSpotFillingAdapter(),
        FiveGOnlyAdapter(),
        FiveGAFixedSectorAdapter(),
    ]


def _build_result(
    *,
    method_key: str,
    group: str,
    seed: int,
    particle_set: np.ndarray,
    problem: DeploymentProblem,
    config: Config,
    started_at: float,
    logs: Dict[str, Any],
) -> BaselineResult:
    particles = np.asarray(particle_set, dtype=float)
    if particles.ndim != 3:
        raise ValueError("system baseline particle_set must have shape [num_candidates, num_stations, 5]")

    if particles.shape[1] == 0:
        objectives = np.asarray([[0.0, 0.0, 1.0, 1.0]], dtype=float)
        metrics = [_empty_service_metrics()]
        feasible = np.asarray([True], dtype=bool)
        eval_particles = particles
        eval_info = None
    else:
        eval_info = evaluate_with_existing_context(
            decisions=particles,
            problem=problem,
            config=config,
            method_name=method_key,
        )
        eval_particles = eval_info.particles
        metrics = eval_info.metrics
        objectives = np.asarray([objective_vector_from_metrics(m) for m in metrics], dtype=float)
        feasible = np.asarray([float(m.get("constraint_penalty", 0.0)) <= 1e-12 for m in metrics], dtype=bool)

    nd = nondominated_mask(objectives)
    base_logs = _system_level_logs(method_key)
    base_logs.update(logs)
    base_logs["service_metrics"] = metrics
    base_logs["objective_vectors_source"] = "shared_evaluator_existing_plus_new_service_metrics"
    base_logs["num_candidates"] = int(eval_particles.shape[0])
    base_logs["num_nondominated"] = int(np.sum(nd.astype(int)))
    if eval_info is not None:
        base_logs["service_evaluation_stations"] = (
            "existing_only" if method_key == "existing_only" else "existing_plus_new"
        )
        base_logs["deployment_cost_scope"] = "new_stations_only"
        base_logs["existing_station_count"] = int(eval_info.existing_station_count)
        base_logs["newly_deployed_station_count"] = int(eval_info.newly_deployed_station_count)
        base_logs["evaluation_station_count"] = int(eval_info.total_station_count)
        base_logs["input_already_included_existing"] = bool(eval_info.already_included_existing)
    return BaselineResult(
        method_name=method_key,
        group=group,
        seed=int(seed),
        objective_vectors=objectives,
        decision_variables=eval_particles,
        nondominated_objectives=objectives[nd],
        nondominated_decisions=eval_particles[nd],
        runtime_seconds=float(time.time() - started_at),
        feasible_mask=feasible,
        nondominated_feasible_mask=feasible[nd],
        logs=base_logs,
    )


def _system_level_logs(method_key: str) -> Dict[str, Any]:
    return {
        "decision_space_label": "system-level heuristic baseline",
        "optimized_decision_variables": [],
        "station_type_decision": "heuristic/configured; not optimized as a fair optimization baseline",
        "sector_direction_decision": "heuristic/configured; not optimized as a fair optimization baseline",
        "fair_optimization_table_eligible": False,
        "excluded_from_main_fair_optimization_table": True,
        "comparison_category": "system_baseline",
        "allowed_usage": [
            "system-level ASU comparison",
            "decomposed service metric comparison",
            "pipeline validation",
        ],
        "method_key": method_key,
    }


def _objective_vector(metrics: Dict[str, float]) -> List[float]:
    existing = float(metrics.get("existing_route_continuous_coverage_rate", metrics.get("coverage_rate", 0.0)))
    future = float(metrics.get("future_route_continuous_coverage_rate", metrics.get("coverage_rate", 0.0)))
    return [
        float(metrics.get("handover_count", 0.0)),
        float(metrics.get("deployment_cost", 0.0)),
        1.0 - existing,
        1.0 - future,
    ]


def _empty_service_metrics() -> Dict[str, float]:
    return {
        "handover_count": 0.0,
        "deployment_cost": 0.0,
        "coverage_rate": 0.0,
        "existing_route_continuous_coverage_rate": 0.0,
        "future_route_continuous_coverage_rate": 0.0,
        "mean_snr_db": 0.0,
        "cost_effectiveness": 0.0,
        "capacity_effective": 0.0,
        "constraint_penalty": 0.0,
    }


def _existing_station_particle(config: Config) -> np.ndarray:
    raw = config.get("heterogeneousDeployment", {}).get("existingStations", [])
    if not raw:
        return np.zeros((0, 5), dtype=float)
    spatial = np.asarray(raw, dtype=float)
    if spatial.ndim == 1:
        spatial = spatial.reshape(1, -1)
    spatial = spatial[:, :3]
    h_cfg = config.get("heterogeneousDeployment", {})
    type_names = list(h_cfg.get("existingStationTypes", []))
    if len(type_names) != spatial.shape[0]:
        type_names = ["5G"] * spatial.shape[0]
    raw_azimuths = list(h_cfg.get("existingStationSectorAzimuthsDeg", []))
    out = np.zeros((spatial.shape[0], 5), dtype=float)
    out[:, :3] = spatial
    for i, name in enumerate(type_names):
        out[i, 3] = float(_type_index(config, str(name)))
        if str(name).strip().lower() == "5ga":
            raw_az = raw_azimuths[i] if i < len(raw_azimuths) else h_cfg.get("defaultSectorAzimuthDeg", 0.0)
            out[i, 4] = float(_sector_index(float(raw_az)))
    return out


def _random_particle(config: Config, problem: DeploymentProblem, rng: np.random.Generator, random_sector: bool) -> np.ndarray:
    pso = config.get("pso", {})
    num_base = int(pso.get("numBaseStations", 1))
    min_pos = np.asarray(pso.get("minPosition", [0.0, 0.0, 10.0]), dtype=float)
    max_pos = np.asarray(pso.get("maxPosition", [problem.city_map.size_x, problem.city_map.size_y, 60.0]), dtype=float)
    spatial = np.zeros((num_base, 3), dtype=float)
    for i in range(num_base):
        x = float(rng.uniform(min_pos[0], max_pos[0]))
        y = float(rng.uniform(min_pos[1], max_pos[1]))
        z = float(rng.uniform(min_pos[2], max_pos[2]))
        spatial[i] = ensure_non_building(x, y, z, problem.city_map, min_pos, max_pos, rng)
    particle = _typed_particle(
        spatial=spatial,
        config=config,
        sector_rule="random" if random_sector else "fixed",
        rng=rng,
    )
    return particle


def _random_route_corridor_particle(
    config: Config,
    problem: DeploymentProblem,
    rng: np.random.Generator,
    random_sector: bool,
) -> np.ndarray:
    pso = config.get("pso", {})
    num_base = int(pso.get("numBaseStations", 1))
    min_pos = np.asarray(pso.get("minPosition", [0.0, 0.0, 10.0]), dtype=float)
    max_pos = np.asarray(pso.get("maxPosition", [problem.city_map.size_x, problem.city_map.size_y, 60.0]), dtype=float)
    target_points = _route_target_points(problem, config)
    if target_points.size == 0:
        return _random_particle(config, problem, rng, random_sector=random_sector)
    buffer_m = _route_corridor_buffer_m(config, "random_route_corridor_deployment")
    spatial = np.zeros((num_base, 3), dtype=float)
    for i in range(num_base):
        anchor = target_points[int(rng.integers(0, target_points.shape[0]))]
        radius = buffer_m * np.sqrt(float(rng.random()))
        theta = 2.0 * np.pi * float(rng.random())
        x = float(anchor[0] + radius * np.cos(theta))
        y = float(anchor[1] + radius * np.sin(theta))
        z = float(anchor[2]) if target_points.shape[1] > 2 else float(max_pos[2])
        z = float(np.clip(z, min_pos[2], max_pos[2]))
        x = float(np.clip(x, min_pos[0], max_pos[0]))
        y = float(np.clip(y, min_pos[1], max_pos[1]))
        spatial[i] = ensure_non_building(x, y, z, problem.city_map, min_pos, max_pos, rng)
    return _typed_particle(
        spatial=spatial,
        config=config,
        sector_rule="random" if random_sector else "fixed",
        rng=rng,
        sector_points=target_points,
    )


def _route_aware_spatial(
    *,
    problem: DeploymentProblem,
    config: Config,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    pso = config.get("pso", {})
    num_base = int(pso.get("numBaseStations", 1))
    min_pos = np.asarray(pso.get("minPosition", [0.0, 0.0, 10.0]), dtype=float)
    max_pos = np.asarray(pso.get("maxPosition", [problem.city_map.size_x, problem.city_map.size_y, 60.0]), dtype=float)
    target_points = _route_target_points(problem, config)
    if target_points.size == 0:
        return kmeans_init(problem.test_points, 1, config, problem.city_map, rng)[0], target_points

    n_clusters = int(min(max(num_base, 1), target_points.shape[0]))
    if KMeans is not None and target_points.shape[0] >= n_clusters:
        km = KMeans(n_clusters=n_clusters, max_iter=int(config.get("kmeans", {}).get("maxIterations", 100)), n_init=10, random_state=42)
        centers = km.fit(target_points[:, :3]).cluster_centers_
    else:
        idx = np.linspace(0, target_points.shape[0] - 1, n_clusters).round().astype(int)
        centers = target_points[idx, :3]

    spatial = np.zeros((num_base, 3), dtype=float)
    for i in range(num_base):
        center = centers[i % centers.shape[0]].copy()
        center[2] = float(np.clip(center[2], min_pos[2], max_pos[2]))
        x = float(np.clip(center[0], min_pos[0], max_pos[0]))
        y = float(np.clip(center[1], min_pos[1], max_pos[1]))
        z = float(center[2])
        spatial[i] = ensure_non_building(x, y, z, problem.city_map, min_pos, max_pos, rng)
    return spatial, target_points


def _route_target_points(problem: DeploymentProblem, config: Config) -> np.ndarray:
    pts = np.asarray(problem.test_points, dtype=float)
    if pts.size == 0:
        return np.zeros((0, 3), dtype=float)
    existing = _existing_station_particle(config)
    if existing.size == 0:
        return pts
    try:
        snr = compute_point_snr(existing, pts, problem.city_map, problem.channel_params)
        threshold = float(problem.channel_params.get("snrThreshold", config.get("channel", {}).get("snrThreshold", 0.0)))
        blind = pts[np.asarray(snr, dtype=float) < threshold]
        min_blind = int(config.get("systemBaselines", {}).get("routeAware", {}).get("minBlindPointCount", 4))
        if blind.shape[0] >= max(1, min_blind):
            return blind
    except Exception:
        pass
    return pts


def _typed_particle(
    *,
    spatial: np.ndarray,
    config: Config,
    sector_rule: str,
    rng: np.random.Generator,
    sector_points: np.ndarray | None = None,
) -> np.ndarray:
    points = np.asarray(sector_points if sector_points is not None else np.zeros((0, 3)), dtype=float)
    type_indices = _ratio_type_indices(config, int(np.asarray(spatial).shape[0]))
    out = np.zeros((len(type_indices), 5), dtype=float)
    out[:, :3] = np.asarray(spatial, dtype=float)[:, :3]
    out[:, 3] = type_indices.astype(float)
    for i, type_idx in enumerate(type_indices.tolist()):
        if _type_name(config, int(type_idx)).lower() != "5ga":
            out[i, 4] = 0.0
        elif sector_rule == "random":
            out[i, 4] = float(rng.integers(0, len(DEFAULT_SECTOR_DIRECTIONS_DEG)))
        elif sector_rule == "enumerate_best":
            choice = choose_stage1_5ga_sector_direction(
                site=out[i, :3],
                blind_spot_points=points,
                sector_beamwidth_deg=float(config.get("channel", {}).get("sector_beamwidth_deg", 90.0)),
                config=_enumerate_sector_config(config),
                rng=rng,
            )
            out[i, 4] = float(choice["sector_direction_index"])
        else:
            out[i, 4] = 0.0
    return out


def _forced_type_particle(spatial: np.ndarray, config: Config, station_type: str, sector_idx: int) -> np.ndarray:
    arr = np.asarray(spatial, dtype=float)
    out = np.zeros((arr.shape[0], 5), dtype=float)
    out[:, :3] = arr[:, :3]
    out[:, 3] = float(_type_index(config, station_type))
    if station_type.strip().lower() == "5ga":
        out[:, 4] = float(sector_idx)
    return out


def _forced_5ga_route_facing_particle(spatial: np.ndarray, config: Config, route_points: np.ndarray) -> np.ndarray:
    arr = np.asarray(spatial, dtype=float)
    out = np.zeros((arr.shape[0], 5), dtype=float)
    out[:, :3] = arr[:, :3]
    out[:, 3] = float(_type_index(config, "5GA"))
    pts = np.asarray(route_points[:, :2], dtype=float) if np.asarray(route_points).size else np.zeros((0, 2), dtype=float)
    for i, site in enumerate(arr[:, :2]):
        if pts.size == 0:
            out[i, 4] = 0.0
            continue
        d = np.sqrt(np.sum((pts - site[None, :]) ** 2, axis=1))
        nearest = pts[int(np.argmin(d))]
        azimuth = (np.degrees(np.arctan2(nearest[0] - site[0], nearest[1] - site[1])) + 360.0) % 360.0
        out[i, 4] = float(_sector_index(float(azimuth)))
    return out


def _records_to_particle(records: Sequence[Dict[str, Any]], config: Config) -> np.ndarray:
    if not records:
        return np.zeros((0, 5), dtype=float)
    out = np.zeros((len(records), 5), dtype=float)
    for i, rec in enumerate(records):
        out[i, :3] = [float(rec["x"]), float(rec["y"]), float(rec.get("z", rec.get("height", 0.0)))]
        out[i, 3] = float(_type_index(config, str(rec.get("station_type", "5G"))))
        if str(rec.get("station_type", "")).strip().lower() == "5ga":
            out[i, 4] = float(rec.get("sector_direction_index", 0))
    return out


def _ratio_type_indices(config: Config, num_base: int) -> np.ndarray:
    specs = config.get("heterogeneousDeployment", {}).get("stationTypes", [])
    if not specs:
        return np.zeros((num_base,), dtype=int)
    ratios = np.asarray([max(float(item.get("ratio", 0.0)), 0.0) for item in specs], dtype=float)
    if float(np.sum(ratios)) <= 0.0:
        ratios = np.ones_like(ratios)
    ratios = ratios / float(np.sum(ratios))
    counts = np.floor(ratios * num_base).astype(int)
    while int(np.sum(counts)) < num_base:
        counts[int(np.argmax(ratios - counts / max(num_base, 1)))] += 1
    indices: List[int] = []
    for idx, count in enumerate(counts.tolist()):
        indices.extend([idx] * int(count))
    return np.asarray(indices[:num_base], dtype=int)


def _type_index(config: Config, station_type: str) -> int:
    target = station_type.strip().lower()
    for idx, item in enumerate(config.get("heterogeneousDeployment", {}).get("stationTypes", [])):
        if str(item.get("name", "")).strip().lower() == target:
            return int(idx)
    return 0


def _type_name(config: Config, type_idx: int) -> str:
    raw = config.get("heterogeneousDeployment", {}).get("stationTypes", [])
    if 0 <= int(type_idx) < len(raw):
        return str(raw[int(type_idx)].get("name", "5G"))
    return "5G"


def _sector_index(azimuth_deg: float) -> int:
    snapped = float(nearest_supported_sector_direction_deg(float(azimuth_deg), DEFAULT_SECTOR_DIRECTIONS_DEG))
    matches = np.where(np.isclose(DEFAULT_SECTOR_DIRECTIONS_DEG, snapped, atol=1e-9, rtol=0.0))[0]
    return int(matches[0]) if matches.size else 0


def _num_candidates(config: Config, method_key: str) -> int:
    raw = config.get("systemBaselines", {}).get(method_key, {}).get("numCandidates")
    if raw is None:
        raw = min(int(config.get("pso", {}).get("numParticles", 4)), 8)
    return int(max(1, raw))


def _route_corridor_buffer_m(config: Config, method_key: str) -> float:
    raw = (
        config.get("systemBaselines", {})
        .get(method_key, {})
        .get("routeCorridorBufferM", config.get("systemBaselines", {}).get("routeAware", {}).get("routeCorridorBufferM", 1500.0))
    )
    return float(max(float(raw), 0.0))


def _enumerate_sector_config(config: Config) -> Config:
    cfg = dict(config)
    stage1 = dict(config.get("stage1", {}))
    stage1["stage1_5ga_direction_strategy"] = "enumerate_best"
    cfg["stage1"] = stage1
    return cfg


def _greedy_stage1_config(config: Config) -> Config:
    cfg = dict(config)
    stage1 = dict(config.get("stage1", {}))
    stage1["stage1_5ga_direction_strategy"] = "enumerate_best"
    cfg["stage1"] = stage1
    return cfg
