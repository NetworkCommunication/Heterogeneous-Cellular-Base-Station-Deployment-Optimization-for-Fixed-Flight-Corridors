"""Scenario-sampling-inspired robust baseline; not a TVT 2020 reproduction."""
from __future__ import annotations
from typing import Any, Dict
import numpy as np
from src.baselines.bio_inspired_common import ASUV2BioInspiredAdapter, clip_to_bounds

class ScenarioSamplingRobustDeploymentTrueSINRASUV2Adapter(ASUV2BioInspiredAdapter):
    method_key="scenario_sampling_robust_deployment_true_sinr_asu_v2"; display_name="Scenario-sampling-inspired robust deployment baseline"; algorithm_name="route-scenario sampling robust search"; implemented=True
    def _extra_algorithm_config(self, raw: Dict[str, Any]) -> Dict[str, Any]: return {"scenario_fraction":float(raw.get("scenario_fraction",0.40))}
    def _next_population(self, *, population, scores, iteration, max_iterations, encoding, problem, config, rng, state, alg_cfg):
        best=population[int(np.argmax(scores))]; pts=np.asarray(problem.test_points,dtype=float)
        out=population.copy(); frac=float(alg_cfg["scenario_fraction"])
        sample=pts[rng.choice(pts.shape[0],size=max(1,int(pts.shape[0]*frac)),replace=False)] if pts.size else np.zeros((1,3))
        target=sample[rng.integers(0,sample.shape[0],size=population.shape[0])]
        for i in range(population.shape[0]):
            out[i]+=0.25*rng.random(population.shape[1])*(best-population[i]); out[i].reshape(-1,5)[:,:3]+=0.15*rng.random()*(target[i%len(target),:3]-out[i].reshape(-1,5)[:,:3])
        state["sampled_scenario_count"]=int(sample.shape[0]); return clip_to_bounds(out,encoding)
    def _logs(self, **kwargs):
        out=super()._logs(**kwargs); out.update({"adaptation_status":"inspired; not exact TVT 2020 reproduction","candidate_site_count":"population-derived route scenario positions","selected_candidate_site_count":"best chromosome stations"}); return out
