from __future__ import annotations

import time
from typing import Dict

import numpy as np

from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.data.types import Config
from src.experiments.multiobjective_metrics import nondominated_mask


class DummyBaselineAdapter(BaselineAdapter):
    """Synthetic baseline used only to validate the comparison pipeline."""

    method_key = "dummy_baseline"
    display_name = "Dummy Synthetic Baseline"
    group = "baseline_dummy"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        t0 = time.time()
        rng = np.random.default_rng(int(seed) + 777)
        cfg = config.get("dummyBaseline", {})
        num_points = int(max(3, cfg.get("numPoints", 5)))
        objective_dim = int(max(2, cfg.get("objectiveDim", 4)))

        # Synthetic minimization front with a mild tradeoff; not a real deployment algorithm.
        t = np.linspace(0.0, 1.0, num_points)
        objectives = np.zeros((num_points, objective_dim), dtype=float)
        objectives[:, 0] = 2.0 + 4.0 * t
        objectives[:, 1] = 2.5 + 3.5 * (1.0 - t)
        if objective_dim >= 3:
            objectives[:, 2] = 0.08 + 0.35 * np.square(t)
        if objective_dim >= 4:
            objectives[:, 3] = 0.10 + 0.30 * np.square(1.0 - t)
        if objective_dim > 4:
            objectives[:, 4:] = rng.uniform(0.05, 0.4, size=(num_points, objective_dim - 4))

        jitter = float(cfg.get("jitter", 0.0))
        if jitter > 0.0:
            objectives += rng.normal(0.0, jitter, size=objectives.shape)
            objectives = np.maximum(objectives, 0.0)

        nd_mask = nondominated_mask(objectives)
        decisions = rng.uniform(0.0, 1.0, size=(num_points, 1, 3))
        logs: Dict[str, object] = {
            "note": "Synthetic validation baseline; not a paper algorithm.",
            "num_points": num_points,
            "objective_dim": objective_dim,
        }
        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=objectives,
            decision_variables=decisions,
            nondominated_objectives=objectives[nd_mask],
            nondominated_decisions=decisions[nd_mask],
            runtime_seconds=float(time.time() - t0),
            logs=logs,
        )
