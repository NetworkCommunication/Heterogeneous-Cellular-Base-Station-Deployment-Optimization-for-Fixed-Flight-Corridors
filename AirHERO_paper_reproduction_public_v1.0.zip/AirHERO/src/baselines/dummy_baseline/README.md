# Dummy Baseline

This slot is a synthetic validation adapter for the baseline comparison
pipeline. It is not a scientific baseline and must not be reported as a paper
algorithm.

Purpose:
- Return a small nondominated objective set.
- Exercise HV, GD, IGD, Pareto plotting, and CSV export.
- Verify that unimplemented paper baseline slots can be skipped safely.
