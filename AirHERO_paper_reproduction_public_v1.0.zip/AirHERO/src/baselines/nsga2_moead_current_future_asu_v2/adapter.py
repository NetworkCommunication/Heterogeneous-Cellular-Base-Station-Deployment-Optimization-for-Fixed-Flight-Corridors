from __future__ import annotations

from dataclasses import replace
from typing import Any, Dict, Tuple, Type

import numpy as np

from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.baselines.bio_inspired_common import evaluate_for_asu, extended_asu_v2_config
from src.baselines.moead_extended.adapter import MOEADExtendedAdapter
from src.baselines.nsga2_extended.adapter import NSGA2ExtendedAdapter
from src.baselines.nsga2_extended.encoding import (
    NSGA2_SECTOR_AZIMUTHS_DEG,
    build_extended_deployment_encoding,
    flatten_extended_particles,
)
from src.data.types import Config


class _CurrentFutureASUV2Wrapper(BaselineAdapter):
    """Add ASU-v2 best-candidate selection to an existing extended optimizer.

    The current/future deployment itself is executed by the route-priority
    two-stage wrapper or formal runner. This adapter intentionally leaves the
    underlying optimizer search logic untouched and only appends ASU-v2 metadata
    plus a `best_chromosome` for downstream two-stage solution selection.
    """

    implemented = True
    group = "optimizer_system_baseline_asu_v2"
    base_adapter_cls: Type[BaselineAdapter]
    base_method_key = ""

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        cfg = extended_asu_v2_config(config)
        cfg.setdefault("evaluation", {})
        cfg["evaluation"].setdefault("signal_metric", "sinr")
        cfg["evaluation"].setdefault("threshold_main_db", 0.0)
        cfg["evaluation"].setdefault("auxiliary_thresholds_db", [5.0, 10.0])
        cfg["evaluation"].setdefault("rho", 0.10)
        cfg["evaluation"].setdefault("power_mode", "station_file_preferred")
        base = self.base_adapter_cls()
        result = base.run(problem, seed=seed, config=cfg)
        best, best_score, best_record, candidate_count = _select_asu_v2_best(result, problem, cfg)
        logs: Dict[str, Any] = dict(result.logs)
        logs.update(
            {
                "method_key": self.method_key,
                "base_method_key": self.base_method_key,
                "wrapper_label": "current_then_future_two_stage_asu_v2",
                "current_future_is_two_stage": True,
                "single_stage_ablation_key": "v2_single_stage_all_routes",
                "stage1_target": "current-priority route protection",
                "stage2_target": "future-priority route expansion",
                "final_selection": "ASU-v2 best candidate",
                "asu_preset": "asu_route_service_v2",
                "uses_tmc_asu": False,
                "signal_metric": str(cfg.get("evaluation", {}).get("signal_metric", "sinr")),
                "threshold_main_db": float(cfg.get("evaluation", {}).get("threshold_main_db", 0.0)),
                "auxiliary_thresholds_db": cfg.get("evaluation", {}).get("auxiliary_thresholds_db", [5.0, 10.0]),
                "rho": float(cfg.get("evaluation", {}).get("rho", 0.10)),
                "power_mode": str(cfg.get("evaluation", {}).get("power_mode", "station_file_preferred")),
                "best_ASU": float(best_score),
                "best_chromosome": np.asarray(best, dtype=float).reshape(-1).tolist(),
                "best_asu_record": best_record,
                "asu_v2_candidate_count": int(candidate_count),
                "sector_direction_mapping": {str(i): float(v) for i, v in enumerate(NSGA2_SECTOR_AZIMUTHS_DEG.tolist())},
                "fair_optimization_table_eligible": False,
                "system_baseline_table_eligible": True,
            }
        )
        return replace(
            result,
            method_name=self.method_key,
            group=self.group,
            logs=logs,
        )


class NSGA2CurrentThenFutureASUV2Adapter(_CurrentFutureASUV2Wrapper):
    """NSGA-II current->future two-stage system baseline under ASU-v2."""

    method_key = "nsga2_current_then_future_asu_v2"
    display_name = "NSGA-II current-then-future ASU-v2"
    base_adapter_cls = NSGA2ExtendedAdapter
    base_method_key = "nsga2_extended"


class MOEADCurrentThenFutureASUV2Adapter(_CurrentFutureASUV2Wrapper):
    """MOEA/D current->future two-stage system baseline under ASU-v2."""

    method_key = "moead_current_then_future_asu_v2"
    display_name = "MOEA/D current-then-future ASU-v2"
    base_adapter_cls = MOEADExtendedAdapter
    base_method_key = "moead_extended"


def _select_asu_v2_best(
    result: BaselineResult,
    problem: DeploymentProblem,
    config: Config,
) -> Tuple[np.ndarray, float, Dict[str, Any], int]:
    particles = _candidate_particles(result)
    encoding = build_extended_deployment_encoding(config)
    chromosomes = flatten_extended_particles(particles)
    evaluation = evaluate_for_asu(chromosomes, encoding, problem, config)
    finite_scores = np.where(np.isfinite(evaluation.asu_scores), evaluation.asu_scores, -np.inf)
    best_idx = int(np.argmax(finite_scores)) if finite_scores.size else 0
    best = particles[best_idx]
    best_score = float(finite_scores[best_idx]) if finite_scores.size else float("nan")
    best_record = dict(evaluation.asu_records[best_idx]) if evaluation.asu_records else {}
    return best, best_score, best_record, int(particles.shape[0])


def _candidate_particles(result: BaselineResult) -> np.ndarray:
    arrays = []
    if result.decision_variables.size:
        arrays.append(np.asarray(result.decision_variables, dtype=float).reshape(-1, result.decision_variables.shape[-2], 5))
    if result.nondominated_decisions.size:
        arrays.append(np.asarray(result.nondominated_decisions, dtype=float).reshape(-1, result.nondominated_decisions.shape[-2], 5))
    if not arrays:
        raise ValueError("ASU-v2 wrapper received no decision candidates from base optimizer")
    particles = np.concatenate(arrays, axis=0)
    unique = []
    seen = set()
    for particle in particles:
        key = tuple(np.round(particle.reshape(-1), 8).tolist())
        if key in seen:
            continue
        seen.add(key)
        unique.append(particle)
    return np.asarray(unique, dtype=float)
