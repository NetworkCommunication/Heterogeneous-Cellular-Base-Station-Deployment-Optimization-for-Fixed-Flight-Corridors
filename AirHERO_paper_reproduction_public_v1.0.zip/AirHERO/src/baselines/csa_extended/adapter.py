from __future__ import annotations

import json
import time
import gc
from typing import Any, Dict, List, Tuple

import numpy as np

from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.baselines.nsga2_extended.adapter import _validate_station_type_mapping
from src.baselines.nsga2_extended.encoding import (
    NSGA2_SECTOR_AZIMUTHS_DEG,
    build_extended_deployment_encoding,
    unflatten_extended_chromosomes,
)
from src.baselines.nsga2_extended.evaluation import evaluate_extended_chromosomes
from src.baselines.nsga2_extended.repair import repair_extended_chromosomes
from src.data.types import Config
from src.experiments.asu_route_service_v2 import ASU_ROUTE_SERVICE_V2, asu_route_service_v2_from_metrics
from src.experiments.asu_route_service_v2_sinr import (
    ASU_ROUTE_SERVICE_V2_SINR,
    evaluate_with_existing_context_sinr_asu_v2,
)
from src.experiments.multiobjective_metrics import nondominated_mask
from src.experiments.exploration_trace import capture_candidate_sets


class CSAExtendedAdapter(BaselineAdapter):
    """Crow Search Algorithm baseline over full heterogeneous deployment decisions."""

    method_key = "csa_extended"
    display_name = "Crow Search Algorithm Extended"
    group = "fair_optimization_baseline"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        """Run CSA using `[x,y,z,station_type_index,sector_direction_index]` decisions."""
        rng = np.random.default_rng(int(seed))
        method_cfg = _extended_config(config)
        _validate_station_type_mapping(method_cfg)
        encoding = build_extended_deployment_encoding(method_cfg)
        csa_cfg = _csa_config(method_cfg)
        pop_size = int(csa_cfg["population_size"])
        max_iter = int(csa_cfg["max_iterations"])
        awareness_probability = float(csa_cfg["awareness_probability"])
        flight_length = float(csa_cfg["flight_length"])

        t0 = time.time()
        positions = _initialize_population(pop_size, encoding, problem, method_cfg, rng)
        memory = positions.copy()
        eval_pack = _evaluate_for_asu(positions, encoding, problem, method_cfg)
        memory_scores = eval_pack["asu_scores"].copy()
        best_idx = int(np.argmax(memory_scores))
        global_best = memory[best_idx].copy()
        global_best_score = float(memory_scores[best_idx])
        history: List[Dict[str, float]] = [
            {"iteration": 0.0, "best_ASU": global_best_score, "mean_ASU": float(np.mean(memory_scores))}
        ]
        trace_logs: Dict[str, Any] = {}
        capture_candidate_sets(
            trace_logs, method_cfg, iteration=0, max_iterations=max_iter,
            candidate_sets=[{"candidate_source": "population", "decisions": unflatten_extended_chromosomes(positions, encoding),
                             "objectives": eval_pack["objectives"], "feasible": eval_pack["feasible_mask"],
                             "metrics": eval_pack["asu_records"]}],
        )

        for iteration in range(1, max_iter + 1):
            new_positions = positions.copy()
            perm = rng.permutation(pop_size)
            for i in range(pop_size):
                if float(rng.random()) >= awareness_probability:
                    target = memory[int(perm[i])]
                    step = flight_length * float(rng.random()) * (target - positions[i])
                    new_positions[i] = positions[i] + step
                else:
                    new_positions[i] = rng.uniform(encoding.lower_bounds, encoding.upper_bounds)
            new_positions = repair_extended_chromosomes(new_positions, encoding, problem.city_map, method_cfg, rng)
            new_eval = _evaluate_for_asu(new_positions, encoding, problem, method_cfg)
            new_scores = new_eval["asu_scores"]
            improved = new_scores > memory_scores
            memory[improved] = new_positions[improved]
            memory_scores[improved] = new_scores[improved]
            positions = new_positions
            idx = int(np.argmax(memory_scores))
            if float(memory_scores[idx]) > global_best_score:
                global_best = memory[idx].copy()
                global_best_score = float(memory_scores[idx])
            history.append(
                {
                    "iteration": float(iteration),
                    "best_ASU": float(global_best_score),
                    "mean_ASU": float(np.mean(memory_scores)),
                    "improved_memory_count": float(np.sum(improved)),
                }
            )
            capture_candidate_sets(
                trace_logs, method_cfg, iteration=iteration, max_iterations=max_iter,
                candidate_sets=[{"candidate_source": "population", "decisions": unflatten_extended_chromosomes(positions, encoding),
                                 "objectives": new_eval["objectives"], "feasible": new_eval["feasible_mask"],
                                 "metrics": new_eval["asu_records"]}],
            )
            memory_safe_gc_interval = int(csa_cfg["memory_safe_gc_interval"])
            if memory_safe_gc_interval > 0 and iteration % memory_safe_gc_interval == 0:
                # Observation/evaluation buffers are independent of the CSA state.
                # Collection changes neither the sampled decisions nor their scores.
                gc.collect()

        final_eval = _evaluate_for_asu(memory, encoding, problem, method_cfg)
        objectives = final_eval["objectives"]
        feasible = final_eval["feasible_mask"]
        nd_mask = nondominated_mask(objectives)
        decisions = unflatten_extended_chromosomes(memory, encoding)
        runtime = float(time.time() - t0)
        logs: Dict[str, Any] = {
            "algorithm": "Crow Search Algorithm",
            "method_key": self.method_key,
            "baseline_label": "CSA-extended",
            "decision_space_label": "same-decision-space extended deployment",
            "chromosome_definition": "[x,y,z,station_type_index,sector_direction_index] per deployed station",
            "station_type_mapping": {"0": "5G", "1": "5GA"},
            "sector_direction_mapping": {str(i): float(v) for i, v in enumerate(NSGA2_SECTOR_AZIMUTHS_DEG.tolist())},
            "optimized_decision_variables": [
                "station_x",
                "station_y",
                "station_z",
                "station_type_index",
                "5ga_sector_direction_index",
            ],
            "asu_preset": str(final_eval["asu_records"][0].get("asu_preset", ASU_ROUTE_SERVICE_V2)) if final_eval["asu_records"] else ASU_ROUTE_SERVICE_V2,
            "uses_tmc_asu": False,
            "population_size": pop_size,
            "max_iterations": max_iter,
            "awareness_probability": awareness_probability,
            "flight_length": flight_length,
            "evaluation_batch_size": int(csa_cfg["evaluation_batch_size"]),
            "memory_safe_gc_interval": int(csa_cfg["memory_safe_gc_interval"]),
            "memory_safe_evaluation_enabled": bool(int(csa_cfg["evaluation_batch_size"]) > 0 or int(csa_cfg["memory_safe_gc_interval"]) > 0),
            "evaluations": int(pop_size * (max_iter + 1)),
            "best_ASU": float(global_best_score),
            "best_chromosome": global_best.tolist(),
            "history": history,
            "asu_component_records": final_eval["asu_records"],
            "fair_optimization_table_eligible": True,
        }
        logs.update(trace_logs)
        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=objectives,
            decision_variables=decisions,
            nondominated_objectives=objectives[nd_mask],
            nondominated_decisions=decisions[nd_mask],
            runtime_seconds=runtime,
            feasible_mask=feasible,
            nondominated_feasible_mask=feasible[nd_mask],
            logs=logs,
        )


def _evaluate_for_asu(
    chromosomes: np.ndarray,
    encoding: Any,
    problem: DeploymentProblem,
    config: Config,
) -> Dict[str, Any]:
    if _optimization_signal_metric(config) == "sinr":
        particles = unflatten_extended_chromosomes(chromosomes, encoding)
        batch_size = int(_csa_config(config)["evaluation_batch_size"])
        if batch_size <= 0 or batch_size >= particles.shape[0]:
            evaluation = evaluate_with_existing_context_sinr_asu_v2(
                decisions=particles,
                problem=problem,
                config=config,
                method_name="csa_extended",
            )
        else:
            packs = []
            for start in range(0, particles.shape[0], batch_size):
                packs.append(
                    evaluate_with_existing_context_sinr_asu_v2(
                        decisions=particles[start : start + batch_size],
                        problem=problem,
                        config=config,
                        method_name="csa_extended",
                    )
                )
            objectives = np.concatenate([np.asarray(pack.objectives, dtype=float) for pack in packs], axis=0)
            feasible = np.concatenate([np.asarray(pack.feasible, dtype=bool) for pack in packs], axis=0)
            asu_values = np.concatenate([np.asarray(pack.asu_values, dtype=float) for pack in packs], axis=0)
            records = [dict(row) for pack in packs for row in pack.metrics]
            return {
                "objectives": objectives,
                "feasible_mask": feasible,
                "asu_scores": asu_values,
                "asu_records": records,
            }
        return {
            "objectives": np.asarray(evaluation.objectives, dtype=float),
            "feasible_mask": np.asarray(evaluation.feasible, dtype=bool),
            "asu_scores": np.asarray(evaluation.asu_values, dtype=float),
            "asu_records": [dict(row) for row in evaluation.metrics],
        }
    evaluation = evaluate_extended_chromosomes(chromosomes, encoding, problem, config)
    scores = []
    records = []
    metrics = evaluation.metrics
    for i in range(evaluation.objectives.shape[0]):
        n_5g, n_5ga = _count_station_types(unflatten_extended_chromosomes(chromosomes[i : i + 1], encoding)[0])
        row = {
            "coverage_rate": metrics["coverage_rate"][i],
            "mean_snr_db": metrics["mean_snr_db"][i],
            "handover_count": metrics["handover_count"][i],
            "deployment_cost": metrics["deployment_cost"][i],
            "existing_route_continuous_coverage_rate": metrics["existing_route_continuous_coverage_rate"][i],
            "future_route_continuous_coverage_rate": metrics["future_route_continuous_coverage_rate"][i],
            "N_5G": n_5g,
            "N_5GA": n_5ga,
        }
        rec = asu_route_service_v2_from_metrics(row, config).as_dict()
        scores.append(float(rec["ASU"]))
        records.append(rec)
    return {
        "objectives": evaluation.objectives,
        "feasible_mask": evaluation.feasible_mask,
        "asu_scores": np.asarray(scores, dtype=float),
        "asu_records": records,
    }


def _count_station_types(particle: np.ndarray) -> Tuple[int, int]:
    type_idx = np.rint(np.asarray(particle, dtype=float)[:, 3]).astype(int)
    n_5ga = int(np.sum(type_idx == 1))
    n_5g = int(type_idx.size - n_5ga)
    return n_5g, n_5ga


def _initialize_population(pop_size: int, encoding: Any, problem: DeploymentProblem, config: Config, rng: np.random.Generator) -> np.ndarray:
    chromosomes = rng.uniform(encoding.lower_bounds, encoding.upper_bounds, size=(pop_size, encoding.num_variables))
    return repair_extended_chromosomes(chromosomes, encoding, problem.city_map, config, rng)


def _extended_config(config: Config) -> Config:
    cfg = json.loads(json.dumps(config))
    preset = ASU_ROUTE_SERVICE_V2_SINR if _optimization_signal_metric(cfg) == "sinr" else ASU_ROUTE_SERVICE_V2
    cfg["asu_preset"] = preset
    cfg.setdefault("airwayServiceUtility", {})["asu_preset"] = preset
    if preset == ASU_ROUTE_SERVICE_V2_SINR:
        cfg.setdefault("airwayServiceUtilityV2", {})["signal_metric"] = "sinr"
        cfg["airwayServiceUtilityV2"]["optimization_signal_metric"] = "sinr"
        cfg.setdefault("evaluation", {})["optimization_signal_metric"] = "sinr"
    cfg.setdefault("heterogeneousDeployment", {})["enabled"] = True
    cfg.setdefault("particleEncoding", {})
    cfg["particleEncoding"]["optimizeStationType"] = True
    cfg["particleEncoding"]["optimizeSectorDirection"] = True
    cfg.setdefault("channel", {})
    cfg["channel"]["sector_directions_deg"] = [float(v) for v in NSGA2_SECTOR_AZIMUTHS_DEG.tolist()]
    cfg.setdefault("nsga2", {}).setdefault("repair", {"enabled": True, "enforceNonBuilding": True})
    return cfg


def _optimization_signal_metric(config: Config) -> str:
    raw = (
        config.get("optimization_signal_metric")
        or config.get("evaluation", {}).get("optimization_signal_metric")
        or config.get("airwayServiceUtilityV2", {}).get("optimization_signal_metric")
        or "snr"
    )
    return str(raw).strip().lower()


def _csa_config(config: Config) -> Dict[str, Any]:
    raw = config.get("csa", {}).get("csa_extended", config.get("csa", {}))
    if not isinstance(raw, dict):
        raw = {}
    return {
        "population_size": int(raw.get("population_size", raw.get("populationSize", 30))),
        "max_iterations": int(raw.get("max_iterations", raw.get("maxIterations", 80))),
        "awareness_probability": float(raw.get("awareness_probability", raw.get("awarenessProbability", 0.1))),
        "flight_length": float(raw.get("flight_length", raw.get("flightLength", 2.0))),
        "evaluation_batch_size": int(raw.get("evaluation_batch_size", raw.get("evaluationBatchSize", 0))),
        "memory_safe_gc_interval": int(raw.get("memory_safe_gc_interval", raw.get("memorySafeGcInterval", 0))),
    }
