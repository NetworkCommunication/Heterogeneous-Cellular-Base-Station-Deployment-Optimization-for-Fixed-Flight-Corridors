from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Tuple

import numpy as np

from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.baselines.moead_extended.decomposition import (
    build_weight_neighborhoods,
    generate_weight_vectors,
    normalization_range,
    tchebycheff_scalar,
    update_ideal_point,
)
from src.baselines.nsga2_extended.adapter import _validate_station_type_mapping
from src.baselines.nsga2_extended.encoding import (
    NSGA2_SECTOR_AZIMUTHS_DEG,
    build_extended_deployment_encoding,
    unflatten_extended_chromosomes,
)
from src.baselines.nsga2_extended.evaluation import evaluate_extended_chromosomes
from src.baselines.nsga2_extended.initialization import initialize_extended_with_stage2_seeded_particles
from src.baselines.nsga2_extended.repair import repair_extended_chromosomes
from src.baselines.paper_01.nsga2 import assign_crowding_distance
from src.baselines.paper_01.operators import polynomial_mutation, simulated_binary_crossover
from src.data.types import Config
from src.experiments.multiobjective_metrics import nondominated_mask
from src.experiments.exploration_trace import capture_candidate_sets


class MOEADExtendedAdapter(BaselineAdapter):
    """MOEA/D baseline over `[x,y,z,type_idx,sector_idx]` station decisions."""

    method_key = "moead_extended"
    display_name = "MOEA/D-Ext"
    group = "fair_optimization_baseline"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        """Run one MOEA/D-Ext optimization on a shared deployment problem."""
        rng = np.random.default_rng(int(seed))
        method_cfg = _extended_config(config)
        _validate_station_type_mapping(method_cfg)
        cfg = _moead_config(method_cfg)
        encoding = build_extended_deployment_encoding(method_cfg)

        num_subproblems = int(cfg["num_subproblems"])
        max_gen = int(cfg["max_generations"])
        max_evals = cfg.get("max_evaluations", None)
        max_evals_int = None if max_evals is None else int(max_evals)
        mutation_prob = cfg.get("mutation_probability", None)
        if mutation_prob is None:
            mutation_prob = 1.0 / max(encoding.num_variables, 1)

        t0 = time.time()
        weights = generate_weight_vectors(num_subproblems, 4)
        neighborhoods = build_weight_neighborhoods(weights, int(cfg["neighborhood_size"]))
        chromosomes, init_stats = initialize_extended_with_stage2_seeded_particles(
            config=method_cfg,
            problem=problem,
            encoding=encoding,
            population_size=num_subproblems,
            rng=rng,
        )
        evaluation = evaluate_extended_chromosomes(chromosomes, encoding, problem, method_cfg)
        objectives = evaluation.objectives
        feasible_mask = evaluation.feasible_mask
        evaluations = int(chromosomes.shape[0])
        ideal = update_ideal_point(np.zeros((0,), dtype=float), objectives)
        archive_x, archive_obj, archive_feasible = _update_archive(
            np.zeros((0, encoding.num_variables), dtype=float),
            np.zeros((0, objectives.shape[1]), dtype=float),
            np.zeros((0,), dtype=bool),
            chromosomes,
            objectives,
            feasible_mask,
            int(cfg["archive_size"]),
        )
        history: List[Dict[str, float]] = []
        trace_logs: Dict[str, Any] = {}
        capture_candidate_sets(
            trace_logs, method_cfg, iteration=0, max_iterations=max_gen,
            candidate_sets=[
                {"candidate_source": "population", "decisions": unflatten_extended_chromosomes(chromosomes, encoding),
                 "objectives": objectives, "feasible": feasible_mask},
                {"candidate_source": "archive", "is_archive_member": True,
                 "decisions": unflatten_extended_chromosomes(archive_x, encoding), "objectives": archive_obj,
                 "feasible": archive_feasible},
            ],
        )

        for gen in range(max_gen):
            replacements = 0
            for subproblem_idx in range(num_subproblems):
                parent_idx = _choose_parent_indices(neighborhoods[subproblem_idx], num_subproblems, rng)
                offspring = _make_offspring(
                    chromosomes[parent_idx[0] : parent_idx[0] + 1],
                    chromosomes[parent_idx[1] : parent_idx[1] + 1],
                    encoding.lower_bounds,
                    encoding.upper_bounds,
                    cfg,
                    float(mutation_prob),
                    rng,
                )
                offspring = repair_extended_chromosomes(offspring, encoding, problem.city_map, method_cfg, rng)
                offspring_eval = evaluate_extended_chromosomes(offspring, encoding, problem, method_cfg)
                child_obj = offspring_eval.objectives[0]
                child_feasible = bool(offspring_eval.feasible_mask[0])
                evaluations += 1

                ideal = update_ideal_point(ideal, child_obj)
                candidate_obj = np.vstack([objectives, child_obj.reshape(1, -1)])
                norm_min, norm_max = normalization_range(candidate_obj, ideal)
                for neighbor_idx in neighborhoods[subproblem_idx]:
                    idx = int(neighbor_idx)
                    old_scalar = tchebycheff_scalar(
                        objectives[idx],
                        weights[idx],
                        ideal,
                        norm_min,
                        norm_max,
                        normalize=bool(cfg["objective_normalization"]),
                    )[0]
                    new_scalar = tchebycheff_scalar(
                        child_obj,
                        weights[idx],
                        ideal,
                        norm_min,
                        norm_max,
                        normalize=bool(cfg["objective_normalization"]),
                    )[0]
                    if float(new_scalar) <= float(old_scalar):
                        chromosomes[idx] = offspring[0]
                        objectives[idx] = child_obj
                        feasible_mask[idx] = child_feasible
                        replacements += 1

                archive_x, archive_obj, archive_feasible = _update_archive(
                    archive_x,
                    archive_obj,
                    archive_feasible,
                    offspring,
                    child_obj.reshape(1, -1),
                    np.asarray([child_feasible], dtype=bool),
                    int(cfg["archive_size"]),
                )
                if max_evals_int is not None and evaluations >= max_evals_int:
                    break

            nd_count = int(np.sum(nondominated_mask(objectives)))
            history.append(
                {
                    "generation": float(gen + 1),
                    "evaluations": float(evaluations),
                    "num_nondominated_current": float(nd_count),
                    "archive_size": float(archive_obj.shape[0]),
                    "feasibility_rate": float(np.mean(feasible_mask.astype(float))) if feasible_mask.size else 0.0,
                    "neighbor_replacements": float(replacements),
                    "ideal_handover_count": float(ideal[0]) if ideal.size > 0 else 0.0,
                    "ideal_deployment_cost": float(ideal[1]) if ideal.size > 1 else 0.0,
                }
            )
            capture_candidate_sets(
                trace_logs, method_cfg, iteration=gen + 1, max_iterations=max_gen,
                candidate_sets=[
                    {"candidate_source": "population", "decisions": unflatten_extended_chromosomes(chromosomes, encoding),
                     "objectives": objectives, "feasible": feasible_mask},
                    {"candidate_source": "archive", "is_archive_member": True,
                     "decisions": unflatten_extended_chromosomes(archive_x, encoding), "objectives": archive_obj,
                     "feasible": archive_feasible},
                ],
            )
            if max_evals_int is not None and evaluations >= max_evals_int:
                break

        if archive_obj.size == 0:
            current_nd = nondominated_mask(objectives)
            archive_x = chromosomes[current_nd]
            archive_obj = objectives[current_nd]
            archive_feasible = feasible_mask[current_nd]

        decision_variables = unflatten_extended_chromosomes(chromosomes, encoding)
        nd_decisions = unflatten_extended_chromosomes(archive_x, encoding)
        runtime = float(time.time() - t0)
        logs: Dict[str, Any] = {
            "paper": "Zhang and Li 2007 MOEA/D",
            "algorithm": "MOEA/D-Ext mixed continuous-discrete decomposition baseline",
            "baseline_label": "MOEA/D-Ext",
            "decision_space_label": "same-decision-space extended deployment",
            "chromosome_definition": "[x,y,z,station_type_index,sector_direction_index] per deployed station",
            "chromosome_length": int(encoding.num_variables),
            "optimized_decision_variables": [
                "station_x",
                "station_y",
                "station_z",
                "station_type_index",
                "5ga_sector_direction_index",
            ],
            "station_type_decision": "optimized as station_type_index gene",
            "sector_direction_decision": "optimized as 5ga_sector_direction_index gene",
            "station_type_mapping": {"0": "5G", "1": "5GA"},
            "sector_direction_mapping": {str(i): float(v) for i, v in enumerate(NSGA2_SECTOR_AZIMUTHS_DEG.tolist())},
            "decomposition": str(cfg["decomposition"]),
            "objective_normalization": bool(cfg["objective_normalization"]),
            "mixed_discrete_adaptation": (
                "SBX and polynomial mutation operate on real-valued genes; repair rounds/clips type_idx and "
                "sector_idx after initialization and variation."
            ),
            "deviation_from_paper": (
                "Original MOEA/D is adapted to the repository mixed continuous-discrete deployment encoding, "
                "uses stage-2 seeded initialization for fairness, and reports an external nondominated archive "
                "through the shared baseline schema."
            ),
            "uses_fixed_station_type_plan": False,
            "fair_optimization_table_eligible": True,
            "num_subproblems": num_subproblems,
            "population_size": num_subproblems,
            "neighborhood_size": int(cfg["neighborhood_size"]),
            "generations_completed": len(history),
            "evaluations": evaluations,
            "max_evaluations": "" if max_evals_int is None else int(max_evals_int),
            "crossover_probability": float(cfg["crossover_probability"]),
            "mutation_probability": float(mutation_prob),
            "sbx_distribution_index": float(cfg["sbx_distribution_index"]),
            "polynomial_mutation_distribution_index": float(cfg["polynomial_mutation_distribution_index"]),
            "archive_size": int(archive_obj.shape[0]),
            "feasibility_rate": float(np.mean(feasible_mask.astype(float))) if feasible_mask.size else 0.0,
            "nondominated_feasibility_rate": (
                float(np.mean(archive_feasible.astype(float))) if archive_feasible.size else 0.0
            ),
            "initialization_stats": init_stats,
            "history": history,
        }
        logs.update(trace_logs)
        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=objectives,
            decision_variables=decision_variables,
            nondominated_objectives=archive_obj,
            nondominated_decisions=nd_decisions,
            runtime_seconds=runtime,
            feasible_mask=feasible_mask,
            nondominated_feasible_mask=archive_feasible,
            logs=logs,
        )


def _moead_config(config: Config) -> Dict[str, Any]:
    raw = dict(config.get("moead", {}))
    pso = config.get("pso", {})
    num_subproblems = int(
        raw.get(
            "num_subproblems",
            raw.get("numSubproblems", raw.get("population_size", raw.get("populationSize", pso.get("numParticles", 50)))),
        )
    )
    max_generations = int(raw.get("max_generations", raw.get("maxGenerations", pso.get("maxIterations", 100))))
    decomposition = str(raw.get("decomposition", "tchebycheff")).strip().lower()
    if decomposition not in {"tchebycheff", "tchebycheff_normalized"}:
        raise ValueError("moead_extended currently supports moead.decomposition='tchebycheff'")
    return {
        "num_subproblems": max(2, num_subproblems),
        "neighborhood_size": int(raw.get("neighborhood_size", raw.get("neighborhoodSize", min(20, num_subproblems)))),
        "max_generations": max(0, max_generations),
        "max_evaluations": raw.get("max_evaluations", raw.get("maxEvaluations", None)),
        "decomposition": decomposition,
        "objective_normalization": bool(raw.get("objective_normalization", raw.get("objectiveNormalization", True))),
        "crossover_probability": float(raw.get("crossover_probability", raw.get("crossoverProbability", 1.0))),
        "mutation_probability": raw.get("mutation_probability", raw.get("mutationProbability", None)),
        "sbx_distribution_index": float(raw.get("sbx_distribution_index", raw.get("sbxDistributionIndex", 20.0))),
        "polynomial_mutation_distribution_index": float(
            raw.get("polynomial_mutation_distribution_index", raw.get("polynomialMutationDistributionIndex", 20.0))
        ),
        "archive_size": int(raw.get("archive_size", raw.get("archiveSize", max(num_subproblems, 20)))),
    }


def _extended_config(config: Config) -> Config:
    cfg = json.loads(json.dumps(config))
    cfg.setdefault("heterogeneousDeployment", {})
    cfg["heterogeneousDeployment"]["enabled"] = True
    cfg.setdefault("particleEncoding", {})
    cfg["particleEncoding"]["optimizeStationType"] = True
    cfg["particleEncoding"]["optimizeSectorDirection"] = True
    cfg.setdefault("channel", {})
    cfg["channel"]["sector_directions_deg"] = [float(v) for v in NSGA2_SECTOR_AZIMUTHS_DEG.tolist()]
    repair_cfg = cfg.get("moead", {}).get("repair", None)
    if repair_cfg is not None:
        cfg.setdefault("nsga2", {})["repair"] = dict(repair_cfg)
    return cfg


def _choose_parent_indices(neighborhood: np.ndarray, population_size: int, rng: np.random.Generator) -> Tuple[int, int]:
    candidates = np.asarray(neighborhood, dtype=int).reshape(-1)
    if candidates.size < 2:
        candidates = np.arange(int(population_size), dtype=int)
    replace = bool(candidates.size < 2)
    chosen = rng.choice(candidates, size=2, replace=replace)
    if int(chosen[0]) == int(chosen[1]) and int(population_size) > 1:
        alt = int(rng.integers(0, int(population_size)))
        chosen[1] = alt if alt != int(chosen[0]) else (alt + 1) % int(population_size)
    return int(chosen[0]), int(chosen[1])


def _make_offspring(
    parent_a: np.ndarray,
    parent_b: np.ndarray,
    lower_bounds: np.ndarray,
    upper_bounds: np.ndarray,
    cfg: Dict[str, Any],
    mutation_probability: float,
    rng: np.random.Generator,
) -> np.ndarray:
    c1, c2 = simulated_binary_crossover(
        parents_a=parent_a,
        parents_b=parent_b,
        lower_bounds=lower_bounds,
        upper_bounds=upper_bounds,
        crossover_probability=float(cfg["crossover_probability"]),
        distribution_index=float(cfg["sbx_distribution_index"]),
        rng=rng,
    )
    child = c1 if rng.random() <= 0.5 else c2
    return polynomial_mutation(
        chromosomes=child,
        lower_bounds=lower_bounds,
        upper_bounds=upper_bounds,
        mutation_probability=float(mutation_probability),
        distribution_index=float(cfg["polynomial_mutation_distribution_index"]),
        rng=rng,
    )


def _update_archive(
    archive_x: np.ndarray,
    archive_obj: np.ndarray,
    archive_feasible: np.ndarray,
    candidate_x: np.ndarray,
    candidate_obj: np.ndarray,
    candidate_feasible: np.ndarray,
    max_size: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    x = np.vstack([np.asarray(archive_x, dtype=float), np.asarray(candidate_x, dtype=float)])
    obj = np.vstack([np.asarray(archive_obj, dtype=float), np.asarray(candidate_obj, dtype=float)])
    feasible = np.concatenate([np.asarray(archive_feasible, dtype=bool), np.asarray(candidate_feasible, dtype=bool)])
    finite = np.isfinite(obj).all(axis=1)
    x = x[finite]
    obj = obj[finite]
    feasible = feasible[finite]
    if obj.size == 0:
        return x, obj, feasible

    keep = nondominated_mask(obj)
    x = x[keep]
    obj = obj[keep]
    feasible = feasible[keep]
    seen = set()
    unique_idx = []
    for idx, row in enumerate(np.round(np.hstack([obj, x]), decimals=8)):
        key = tuple(float(v) for v in row.tolist())
        if key in seen:
            continue
        seen.add(key)
        unique_idx.append(idx)
    unique_idx = np.asarray(unique_idx, dtype=int)
    x = x[unique_idx]
    obj = obj[unique_idx]
    feasible = feasible[unique_idx]
    if x.shape[0] > int(max_size):
        crowd = assign_crowding_distance(obj, [np.arange(obj.shape[0], dtype=int)])
        order = np.argsort(-crowd, kind="stable")[: int(max_size)]
        x = x[order]
        obj = obj[order]
        feasible = feasible[order]
    return x, obj, feasible
