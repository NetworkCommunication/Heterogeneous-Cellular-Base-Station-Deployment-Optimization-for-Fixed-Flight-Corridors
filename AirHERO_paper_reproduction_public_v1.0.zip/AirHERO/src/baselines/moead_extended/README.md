# MOEA/D-Ext

`moead_extended` is a paper-based fair optimization baseline adapted from
Zhang and Li's MOEA/D for the repository's shared TMC deployment problem.

The baseline optimizes exactly the same per-station decision vector used by
`proposed_method` and `nsga2_extended`:

```text
[x, y, z, station_type_index, sector_direction_index]
```

Objective vectors are evaluated with the shared deployment evaluator and use
the common minimization convention:

```text
[handover_count, deployment_cost, existing_route_continuity_loss, future_route_continuity_loss]
```

MOEA/D-Ext uses Tchebycheff decomposition by default, neighborhood updates
among weight vectors, objective normalization for scalar aggregation, and an
external nondominated archive for final export.

Deviation from the original paper: this implementation adapts MOEA/D to a
mixed continuous-discrete deployment encoding. SBX and polynomial mutation are
applied to real-valued genes, followed by repair that clips spatial variables
and rounds/clips station type and 5GA sector-direction indices. Initial
solutions use the repository's Stage-1/Stage-2 seeded initialization for fair
comparison with the other same-decision-space methods.
