from __future__ import annotations

from typing import Tuple

import numpy as np


def generate_weight_vectors(num_vectors: int, num_objectives: int) -> np.ndarray:
    """Generate deterministic simplex-lattice weight vectors."""
    n = int(max(num_vectors, 1))
    m = int(max(num_objectives, 1))
    if m == 1:
        return np.ones((n, 1), dtype=float)

    divisions = 1
    combos = _simplex_integer_compositions(divisions, m)
    while combos.shape[0] < n:
        divisions += 1
        combos = _simplex_integer_compositions(divisions, m)

    weights = combos.astype(float) / float(max(divisions, 1))
    if weights.shape[0] > n:
        idx = np.linspace(0, weights.shape[0] - 1, n).round().astype(int)
        weights = weights[idx]
    weights = np.maximum(weights, 0.0)
    sums = np.sum(weights, axis=1, keepdims=True)
    sums[sums <= 0.0] = 1.0
    return weights / sums


def build_weight_neighborhoods(weights: np.ndarray, neighborhood_size: int) -> np.ndarray:
    """Return nearest weight-vector indices for each MOEA/D subproblem."""
    w = np.asarray(weights, dtype=float)
    if w.ndim != 2 or w.shape[0] == 0:
        raise ValueError("weights must have shape [num_subproblems, num_objectives]")
    k = int(np.clip(neighborhood_size, 1, w.shape[0]))
    dist = np.linalg.norm(w[:, None, :] - w[None, :, :], axis=2)
    return np.argsort(dist, axis=1, kind="stable")[:, :k]


def update_ideal_point(current_ideal: np.ndarray, objectives: np.ndarray) -> np.ndarray:
    """Update the minimization ideal point with newly evaluated objectives."""
    obj = np.asarray(objectives, dtype=float)
    if obj.size == 0:
        return np.asarray(current_ideal, dtype=float).copy()
    if obj.ndim == 1:
        obj = obj.reshape(1, -1)
    if current_ideal.size == 0:
        return np.min(obj, axis=0)
    return np.minimum(np.asarray(current_ideal, dtype=float), np.min(obj, axis=0))


def normalization_range(objectives: np.ndarray, ideal: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Build a robust observed min/max range for scalarization."""
    obj = np.asarray(objectives, dtype=float)
    if obj.ndim == 1:
        obj = obj.reshape(1, -1)
    lo = np.minimum(np.min(obj, axis=0), np.asarray(ideal, dtype=float))
    hi = np.maximum(np.max(obj, axis=0), lo + 1e-12)
    return lo, hi


def tchebycheff_scalar(
    objectives: np.ndarray,
    weights: np.ndarray,
    ideal: np.ndarray,
    norm_min: np.ndarray,
    norm_max: np.ndarray,
    normalize: bool = True,
) -> np.ndarray:
    """Compute MOEA/D Tchebycheff scalar values for minimization objectives."""
    obj = np.asarray(objectives, dtype=float)
    if obj.ndim == 1:
        obj = obj.reshape(1, -1)
    w = np.asarray(weights, dtype=float)
    if w.ndim == 1:
        w = w.reshape(1, -1)

    z = np.asarray(ideal, dtype=float)
    if normalize:
        span = np.maximum(np.asarray(norm_max, dtype=float) - np.asarray(norm_min, dtype=float), 1e-12)
        obj = (obj - norm_min[None, :]) / span[None, :]
        z = (z - norm_min) / span

    weighted = np.maximum(w, 1e-12) * np.abs(obj - z[None, :])
    return np.max(weighted, axis=1)


def _simplex_integer_compositions(total: int, parts: int) -> np.ndarray:
    out = []
    current = [0] * int(parts)

    def rec(pos: int, remaining: int) -> None:
        if pos == parts - 1:
            current[pos] = remaining
            out.append(list(current))
            return
        for value in range(remaining + 1):
            current[pos] = value
            rec(pos + 1, remaining - value)

    rec(0, int(total))
    return np.asarray(out, dtype=int)

