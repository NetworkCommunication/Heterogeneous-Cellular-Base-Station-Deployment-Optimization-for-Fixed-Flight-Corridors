"""MOEA/D-Ext fair optimization baseline."""

