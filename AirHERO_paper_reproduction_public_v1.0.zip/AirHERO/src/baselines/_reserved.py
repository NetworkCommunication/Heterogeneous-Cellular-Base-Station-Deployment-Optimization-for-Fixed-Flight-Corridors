from __future__ import annotations

from src.baselines.base import BaselineAdapter, BaselineNotImplementedError, BaselineResult, DeploymentProblem
from src.data.types import Config


class ReservedPaperBaselineAdapter(BaselineAdapter):
    """Reserved slot for a future paper-specific baseline implementation."""

    implemented = False

    def __init__(self, method_key: str, display_name: str) -> None:
        self.method_key = method_key
        self.display_name = display_name
        self.group = "paper_baseline"

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        raise BaselineNotImplementedError(
            f"{self.method_key} is reserved for a future paper baseline and is not implemented yet."
        )
