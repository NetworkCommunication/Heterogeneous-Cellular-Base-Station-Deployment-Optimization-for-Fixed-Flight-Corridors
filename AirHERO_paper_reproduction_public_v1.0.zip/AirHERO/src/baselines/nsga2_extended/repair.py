from __future__ import annotations

import numpy as np

from src.algorithms.init_strategies import enforce_non_building_constraint
from src.baselines.nsga2_extended.encoding import (
    ExtendedDeploymentEncoding,
    flatten_extended_particles,
    unflatten_extended_chromosomes,
)
from src.data.types import CityMap, Config


def repair_extended_chromosomes(
    chromosomes: np.ndarray,
    encoding: ExtendedDeploymentEncoding,
    city_map: CityMap,
    config: Config,
    rng: np.random.Generator,
) -> np.ndarray:
    """Repair NSGA-II-extended chromosomes after initialization/crossover/mutation."""
    particles = unflatten_extended_chromosomes(chromosomes, encoding)
    repaired = particles.copy()
    repaired[..., :3] = np.clip(
        repaired[..., :3],
        encoding.min_position[None, None, :],
        encoding.max_position[None, None, :],
    )

    repair_cfg = config.get("nsga2", {}).get("repair", {})
    if bool(repair_cfg.get("enabled", True)) and bool(repair_cfg.get("enforceNonBuilding", True)):
        repaired[..., :3] = enforce_non_building_constraint(
            positions=repaired[..., :3],
            city_map=city_map,
            min_pos=encoding.min_position,
            max_pos=encoding.max_position,
            rng=rng,
        )
        repaired[..., :3] = np.clip(
            repaired[..., :3],
            encoding.min_position[None, None, :],
            encoding.max_position[None, None, :],
        )

    type_idx = np.rint(repaired[..., 3]).astype(int)
    sector_idx = np.rint(repaired[..., 4]).astype(int)
    repaired[..., 3] = np.clip(type_idx, 0, 1).astype(float)
    repaired[..., 4] = np.clip(sector_idx, 0, 7).astype(float)
    return flatten_extended_particles(repaired)
