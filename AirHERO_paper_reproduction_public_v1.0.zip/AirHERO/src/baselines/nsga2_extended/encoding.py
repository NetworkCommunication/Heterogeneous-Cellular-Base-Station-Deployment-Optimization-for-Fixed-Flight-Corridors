from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import numpy as np

from src.algorithms.particle_encoding import decode_particle_solution
from src.data.types import Config


NSGA2_EXTENDED_DIMS = 5
NSGA2_STATION_TYPE_MIN = 0
NSGA2_STATION_TYPE_MAX = 1
NSGA2_SECTOR_INDEX_MIN = 0
NSGA2_SECTOR_INDEX_MAX = 7
NSGA2_SECTOR_AZIMUTHS_DEG = np.asarray([0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0], dtype=float)


@dataclass(frozen=True)
class ExtendedDeploymentEncoding:
    """Mixed continuous-discrete NSGA-II chromosome encoding.

    Per station gene order is `[x, y, z, station_type_index, sector_direction_index]`.
    """

    num_base_stations: int
    min_position: np.ndarray
    max_position: np.ndarray

    @property
    def num_variables(self) -> int:
        return int(self.num_base_stations * NSGA2_EXTENDED_DIMS)

    @property
    def per_station_lower_bounds(self) -> np.ndarray:
        return np.asarray(
            [
                float(self.min_position[0]),
                float(self.min_position[1]),
                float(self.min_position[2]),
                float(NSGA2_STATION_TYPE_MIN),
                float(NSGA2_SECTOR_INDEX_MIN),
            ],
            dtype=float,
        )

    @property
    def per_station_upper_bounds(self) -> np.ndarray:
        return np.asarray(
            [
                float(self.max_position[0]),
                float(self.max_position[1]),
                float(self.max_position[2]),
                float(NSGA2_STATION_TYPE_MAX),
                float(NSGA2_SECTOR_INDEX_MAX),
            ],
            dtype=float,
        )

    @property
    def lower_bounds(self) -> np.ndarray:
        return np.tile(self.per_station_lower_bounds, self.num_base_stations)

    @property
    def upper_bounds(self) -> np.ndarray:
        return np.tile(self.per_station_upper_bounds, self.num_base_stations)


def build_extended_deployment_encoding(config: Config) -> ExtendedDeploymentEncoding:
    """Build the fixed 5-variable-per-station encoding from config bounds."""
    pso_cfg = config["pso"]
    return ExtendedDeploymentEncoding(
        num_base_stations=int(pso_cfg["numBaseStations"]),
        min_position=np.asarray(pso_cfg["minPosition"], dtype=float),
        max_position=np.asarray(pso_cfg["maxPosition"], dtype=float),
    )


def flatten_extended_particles(particles: np.ndarray) -> np.ndarray:
    """Convert `[population, stations, 5]` particles to chromosomes."""
    arr = np.asarray(particles, dtype=float)
    if arr.ndim != 3 or arr.shape[2] < NSGA2_EXTENDED_DIMS:
        raise ValueError("extended particles must have shape [population, num_base_stations, >=5]")
    return arr[..., :NSGA2_EXTENDED_DIMS].reshape(arr.shape[0], -1)


def unflatten_extended_chromosomes(chromosomes: np.ndarray, encoding: ExtendedDeploymentEncoding) -> np.ndarray:
    """Convert chromosomes to `[population, stations, 5]` extended particles."""
    arr = np.asarray(chromosomes, dtype=float)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    if arr.ndim != 2 or arr.shape[1] != encoding.num_variables:
        raise ValueError("chromosomes must have shape [population, num_base_stations * 5]")
    return arr.reshape(arr.shape[0], encoding.num_base_stations, NSGA2_EXTENDED_DIMS)


def decode_extended_chromosome(
    chromosome: np.ndarray,
    encoding: ExtendedDeploymentEncoding,
    config: Config,
) -> List[Dict[str, object]]:
    """Decode one extended chromosome for export or tests."""
    particle = unflatten_extended_chromosomes(np.asarray(chromosome, dtype=float), encoding)[0]
    return decode_particle_solution(particle, config)
