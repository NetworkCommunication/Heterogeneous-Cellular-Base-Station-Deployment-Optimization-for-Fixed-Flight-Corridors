# NSGA-II-extended

This module implements a fair optimization-algorithm baseline for Baseline
Paper 01:

- K. Deb, A. Pratap, S. Agarwal, and T. Meyarivan, "A Fast and Elitist
  Multiobjective Genetic Algorithm: NSGA-II," IEEE TEVC, 2002.

Chromosome definition:

- Each deployed station uses five genes:
  `[x, y, z, station_type_index, sector_direction_index]`.
- `station_type_index`: `0 = 5G`, `1 = 5GA`.
- `sector_direction_index`: `0..7` maps to
  `[0, 45, 90, 135, 180, 225, 270, 315]` degrees.

Mixed continuous-discrete adaptation:

- SBX crossover and polynomial mutation operate on all genes as bounded real
  values.
- Repair is applied after initialization and variation.
- Repair clips `x/y/z`, rounds and clips `station_type_index` to `{0, 1}`,
  and rounds and clips `sector_direction_index` to `[0, 7]`.

Deviations from the original paper:

- The original NSGA-II paper is not a 5G/5GA deployment model and does not
  include typed stations or sector-direction genes.
- This implementation adds mixed continuous-discrete decision repair.
- The first population uses the repository's stage-2 seeded initialization so
  it can run in the same experimental pipeline.

Fairness note:

`NSGA-II-extended` is eligible for the main fair optimization-algorithm
comparison because it optimizes the same decision variables used by the
extended proposed-method decision space: station location, station type, and
5GA sector direction. It uses the shared evaluator and does not use the fixed
`build_station_type_plan` path.
