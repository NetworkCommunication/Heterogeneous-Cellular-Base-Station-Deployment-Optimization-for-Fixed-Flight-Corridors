from __future__ import annotations

import json
import time
from typing import Any, Dict, List

import numpy as np

from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.baselines.nsga2_extended.encoding import (
    NSGA2_SECTOR_AZIMUTHS_DEG,
    build_extended_deployment_encoding,
    unflatten_extended_chromosomes,
)
from src.baselines.nsga2_extended.evaluation import evaluate_extended_chromosomes
from src.baselines.nsga2_extended.initialization import initialize_extended_with_stage2_seeded_particles
from src.baselines.nsga2_extended.repair import repair_extended_chromosomes
from src.baselines.paper_01.adapter import _nsga2_config
from src.baselines.paper_01.nsga2 import (
    crowded_tournament_select,
    environmental_selection,
    nondominated_indices,
    rank_population,
)
from src.baselines.paper_01.operators import polynomial_mutation, simulated_binary_crossover
from src.data.types import Config
from src.experiments.exploration_trace import capture_candidate_sets


class NSGA2ExtendedAdapter(BaselineAdapter):
    """Fair NSGA-II baseline over `[x,y,z,type_idx,sector_idx]` station decisions."""

    method_key = "nsga2_extended"
    display_name = "NSGA-II-extended"
    group = "fair_optimization_baseline"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        """Run one NSGA-II-extended optimization on a shared deployment problem."""
        rng = np.random.default_rng(int(seed))
        method_cfg = _extended_config(config)
        _validate_station_type_mapping(method_cfg)
        cfg = _nsga2_config(method_cfg)
        encoding = build_extended_deployment_encoding(method_cfg)
        pop_size = int(cfg["populationSize"])
        max_gen = int(cfg["maxGenerations"])
        max_evals = cfg.get("maxEvaluations", None)
        max_evals_int = None if max_evals is None else int(max_evals)
        mutation_prob = cfg.get("mutationProbability", None)
        if mutation_prob is None:
            mutation_prob = 1.0 / max(encoding.num_variables, 1)

        t0 = time.time()
        chromosomes, init_stats = initialize_extended_with_stage2_seeded_particles(
            config=method_cfg,
            problem=problem,
            encoding=encoding,
            population_size=pop_size,
            rng=rng,
        )
        evaluation = evaluate_extended_chromosomes(chromosomes, encoding, problem, method_cfg)
        objectives = evaluation.objectives
        feasible_mask = evaluation.feasible_mask
        evaluations = int(chromosomes.shape[0])
        history: List[Dict[str, float]] = []
        trace_logs: Dict[str, Any] = {}
        capture_candidate_sets(
            trace_logs, method_cfg, iteration=0, max_iterations=max_gen,
            candidate_sets=[{"candidate_source": "population", "decisions": unflatten_extended_chromosomes(chromosomes, encoding),
                             "objectives": objectives, "feasible": feasible_mask}],
        )

        for gen in range(max_gen):
            ranking = rank_population(objectives)
            selected_idx = crowded_tournament_select(
                ranks=ranking.ranks,
                crowding_distance=ranking.crowding_distance,
                rng=rng,
                num_select=pop_size,
            )
            parents = chromosomes[selected_idx]
            if parents.shape[0] % 2 == 1:
                parents = np.vstack([parents, parents[int(rng.integers(0, parents.shape[0]))]])

            pa = parents[0::2]
            pb = parents[1::2]
            c1, c2 = simulated_binary_crossover(
                parents_a=pa,
                parents_b=pb,
                lower_bounds=encoding.lower_bounds,
                upper_bounds=encoding.upper_bounds,
                crossover_probability=float(cfg["crossoverProbability"]),
                distribution_index=float(cfg["sbxDistributionIndex"]),
                rng=rng,
            )
            offspring = np.vstack([c1, c2])[:pop_size]
            offspring = polynomial_mutation(
                chromosomes=offspring,
                lower_bounds=encoding.lower_bounds,
                upper_bounds=encoding.upper_bounds,
                mutation_probability=float(mutation_prob),
                distribution_index=float(cfg["polynomialMutationDistributionIndex"]),
                rng=rng,
            )
            offspring = repair_extended_chromosomes(offspring, encoding, problem.city_map, method_cfg, rng)
            offspring_eval = evaluate_extended_chromosomes(offspring, encoding, problem, method_cfg)
            evaluations += int(offspring.shape[0])

            combined_x = np.vstack([chromosomes, offspring])
            combined_obj = np.vstack([objectives, offspring_eval.objectives])
            combined_feasible = np.concatenate([feasible_mask, offspring_eval.feasible_mask])
            chromosomes, objectives, feasible_mask, survival_ranking = environmental_selection(
                chromosomes=combined_x,
                objectives=combined_obj,
                feasible_mask=combined_feasible,
                population_size=pop_size,
            )
            chromosomes = repair_extended_chromosomes(chromosomes, encoding, problem.city_map, method_cfg, rng)
            nd_idx = nondominated_indices(objectives)
            history.append(
                {
                    "generation": float(gen + 1),
                    "evaluations": float(evaluations),
                    "num_nondominated": float(nd_idx.size),
                    "feasibility_rate": float(np.mean(feasible_mask.astype(float))) if feasible_mask.size else 0.0,
                    "front_count": float(len(survival_ranking.fronts)),
                }
            )
            capture_candidate_sets(
                trace_logs, method_cfg, iteration=gen + 1, max_iterations=max_gen,
                candidate_sets=[{"candidate_source": "population", "decisions": unflatten_extended_chromosomes(chromosomes, encoding),
                                 "objectives": objectives, "feasible": feasible_mask}],
            )
            if max_evals_int is not None and evaluations >= max_evals_int:
                break

        nd_idx = nondominated_indices(objectives)
        nd_chromosomes = chromosomes[nd_idx]
        nd_objectives = objectives[nd_idx]
        nd_feasible = feasible_mask[nd_idx]
        decision_variables = unflatten_extended_chromosomes(chromosomes, encoding)
        nd_decisions = unflatten_extended_chromosomes(nd_chromosomes, encoding)
        runtime = float(time.time() - t0)
        logs: Dict[str, Any] = {
            "paper": "Deb et al. 2002 NSGA-II",
            "algorithm": "mixed continuous-discrete real-coded NSGA-II",
            "baseline_label": "NSGA-II-extended",
            "decision_space_label": "same-decision-space extended deployment",
            "chromosome_definition": "[x,y,z,station_type_index,sector_direction_index] per deployed station",
            "chromosome_length": int(encoding.num_variables),
            "optimized_decision_variables": [
                "station_x",
                "station_y",
                "station_z",
                "station_type_index",
                "5ga_sector_direction_index",
            ],
            "station_type_mapping": {"0": "5G", "1": "5GA"},
            "sector_direction_mapping": {str(i): float(v) for i, v in enumerate(NSGA2_SECTOR_AZIMUTHS_DEG.tolist())},
            "mixed_discrete_adaptation": (
                "SBX and polynomial mutation operate on real-valued genes; repair rounds/clips type_idx and "
                "sector_idx after initialization and variation."
            ),
            "deviation_from_paper": (
                "Original NSGA-II is continuous real-coded. This baseline adds discrete station type and "
                "sector-index genes, repaired after variation, and uses repository stage-2 seeded initialization."
            ),
            "uses_fixed_station_type_plan": False,
            "fair_optimization_table_eligible": True,
            "population_size": pop_size,
            "generations_completed": len(history),
            "evaluations": evaluations,
            "crossover_probability": float(cfg["crossoverProbability"]),
            "mutation_probability": float(mutation_prob),
            "sbx_distribution_index": float(cfg["sbxDistributionIndex"]),
            "polynomial_mutation_distribution_index": float(cfg["polynomialMutationDistributionIndex"]),
            "feasibility_rate": float(np.mean(feasible_mask.astype(float))) if feasible_mask.size else 0.0,
            "nondominated_feasibility_rate": float(np.mean(nd_feasible.astype(float))) if nd_feasible.size else 0.0,
            "initialization_stats": init_stats,
            "history": history,
        }
        logs.update(trace_logs)
        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=objectives,
            decision_variables=decision_variables,
            nondominated_objectives=nd_objectives,
            nondominated_decisions=nd_decisions,
            runtime_seconds=runtime,
            feasible_mask=feasible_mask,
            nondominated_feasible_mask=nd_feasible,
            logs=logs,
        )


def _extended_config(config: Config) -> Config:
    cfg = json.loads(json.dumps(config))
    cfg.setdefault("heterogeneousDeployment", {})
    cfg["heterogeneousDeployment"]["enabled"] = True
    cfg.setdefault("particleEncoding", {})
    cfg["particleEncoding"]["optimizeStationType"] = True
    cfg["particleEncoding"]["optimizeSectorDirection"] = True
    cfg.setdefault("channel", {})
    cfg["channel"]["sector_directions_deg"] = [float(v) for v in NSGA2_SECTOR_AZIMUTHS_DEG.tolist()]
    return cfg


def _validate_station_type_mapping(config: Config) -> None:
    raw_types = config.get("heterogeneousDeployment", {}).get("stationTypes", [])
    names = [str(item.get("name", "")).strip().lower() for item in raw_types if isinstance(item, dict)]
    if len(names) < 2 or names[0] != "5g" or names[1] != "5ga":
        raise ValueError("nsga2_extended requires heterogeneousDeployment.stationTypes[0:2] to be 5G and 5GA")
