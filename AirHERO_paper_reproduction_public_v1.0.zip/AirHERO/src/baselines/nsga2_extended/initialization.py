from __future__ import annotations

from typing import Dict, Tuple

import numpy as np

from src.algorithms.stage1_deployment import deploy_stage1_blind_spots
from src.algorithms.stage2_seeded_initialization import build_stage2_seeded_particles
from src.baselines.base import DeploymentProblem
from src.baselines.nsga2_extended.encoding import ExtendedDeploymentEncoding, flatten_extended_particles
from src.baselines.nsga2_extended.repair import repair_extended_chromosomes
from src.baselines.paper_01.initialization import _load_existing_stations
from src.data.types import Config


def initialize_extended_with_stage2_seeded_particles(
    config: Config,
    problem: DeploymentProblem,
    encoding: ExtendedDeploymentEncoding,
    population_size: int,
    rng: np.random.Generator,
) -> Tuple[np.ndarray, Dict[str, float]]:
    """Initialize NSGA-II-extended particles using stage-1/stage-2 seeding plus random slots."""
    existing = _load_existing_stations(config=config, default_z=float(encoding.min_position[2]))
    stage1 = deploy_stage1_blind_spots(
        test_points=problem.test_points,
        existing_stations=existing,
        config=config,
        city_map=problem.city_map,
        channel_params=problem.channel_params,
        rng=rng,
    )
    stage2 = build_stage2_seeded_particles(
        stage1_sites=stage1.added_sites,
        existing_stations=existing,
        num_particles=population_size,
        num_base_stations=encoding.num_base_stations,
        min_position=encoding.min_position,
        max_position=encoding.max_position,
        config=config,
        rng=rng,
        city_map=problem.city_map,
        stage1_station_records=stage1.added_station_records,
    )
    chromosomes = flatten_extended_particles(stage2.particles)
    chromosomes = repair_extended_chromosomes(chromosomes, encoding, problem.city_map, config, rng)
    stats: Dict[str, float] = {}
    stats.update(stage1.stats)
    stats.update(stage2.stats)
    stats["nsga2_extended_initialization_uses_stage2_seeded_particles"] = 1.0
    return chromosomes, stats
