from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

import numpy as np

from src.algorithms.fitness_interface import evaluate_population_objectives
from src.baselines.base import DeploymentProblem
from src.baselines.nsga2_extended.encoding import ExtendedDeploymentEncoding, unflatten_extended_chromosomes
from src.baselines.paper_01.evaluation import build_deployment_minimization_objectives
from src.data.types import Config


@dataclass
class NSGA2ExtendedEvaluation:
    """Objective and feasibility outputs for NSGA-II-extended."""

    objectives: np.ndarray
    feasible_mask: np.ndarray
    metrics: Dict[str, np.ndarray]


def evaluate_extended_chromosomes(
    chromosomes: np.ndarray,
    encoding: ExtendedDeploymentEncoding,
    problem: DeploymentProblem,
    config: Config,
) -> NSGA2ExtendedEvaluation:
    """Evaluate extended chromosomes through the shared per-particle evaluator."""
    particles = unflatten_extended_chromosomes(chromosomes, encoding)
    batch = evaluate_population_objectives(
        positions=particles,
        test_points=problem.test_points,
        city_map=problem.city_map,
        channel_params=problem.channel_params,
        config=config,
        station_plan=None,
    )
    objectives = build_deployment_minimization_objectives(
        handover_count=batch.handover_count,
        deployment_cost=batch.deployment_cost,
        existing_route_continuous_coverage_rate=batch.existing_route_continuous_coverage_rate,
        future_route_continuous_coverage_rate=batch.future_route_continuous_coverage_rate,
    )
    feasible_mask = np.asarray(batch.constraint_penalty <= float(config.get("nsga2", {}).get("feasiblePenaltyTol", 1e-9)))
    metrics = {
        "constraint_penalty": np.asarray(batch.constraint_penalty, dtype=float),
        "coverage_rate": np.asarray(batch.coverage_rate, dtype=float),
        "mean_snr_db": np.asarray(batch.mean_snr_db, dtype=float),
        "handover_count": np.asarray(batch.handover_count, dtype=float),
        "deployment_cost": np.asarray(batch.deployment_cost, dtype=float),
        "existing_route_continuous_coverage_rate": np.asarray(
            batch.existing_route_continuous_coverage_rate, dtype=float
        ),
        "future_route_continuous_coverage_rate": np.asarray(batch.future_route_continuous_coverage_rate, dtype=float),
    }
    return NSGA2ExtendedEvaluation(objectives=objectives, feasible_mask=feasible_mask, metrics=metrics)
