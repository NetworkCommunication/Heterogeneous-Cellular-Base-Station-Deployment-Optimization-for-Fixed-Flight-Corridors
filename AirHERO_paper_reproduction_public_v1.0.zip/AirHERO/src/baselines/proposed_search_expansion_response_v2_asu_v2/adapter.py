from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, List, Sequence

import numpy as np

import src.baselines.proposed_search_expansion_response_v2.adapter as v2_module
from src.baselines.base import BaselineResult, DeploymentProblem
from src.data.types import Config
from src.experiments.asu_route_service_v2 import ASU_ROUTE_SERVICE_V2, ASU_ROUTE_SERVICE_KEY, asu_route_service_v2_from_metrics
from src.experiments.asu_route_service_v2_sinr import (
    ASU_ROUTE_SERVICE_V2_SINR,
    evaluate_with_existing_context_sinr_asu_v2,
)
from src.experiments.evaluation_consistency import evaluate_with_existing_context
from src.propagation.sector_geometry import DEFAULT_SECTOR_DIRECTIONS_DEG


@dataclass
class _ASUV2EvalPack:
    """Evaluation pack matching the structure consumed by the v2 search loop."""

    objectives: np.ndarray
    asu_values: np.ndarray
    metrics: List[Dict[str, float]]
    feasible: np.ndarray


class ProposedSearchExpansionResponseV2ASUV2Adapter(v2_module.ProposedSearchExpansionResponseV2Adapter):
    """Additive ASU-v2 compatible adapter for search-expansion response v2.

    The original v2 adapter is left untouched. This adapter reuses the v2 search
    loop while substituting only the config materialization and particle
    evaluation interfaces during its own run.
    """

    method_key = "proposed_method_search_expansion_response_v2_asu_v2"
    display_name = "Proposed Search Expansion Response V2 ASU-v2"
    group = "proposed_search_expansion_response_v2_asu_v2"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        original_method_config = v2_module._method_config
        original_evaluate_particles = v2_module._evaluate_particles
        try:
            v2_module._method_config = _method_config_asu_v2  # type: ignore[assignment]
            v2_module._evaluate_particles = _evaluate_particles_asu_v2  # type: ignore[assignment]
            result = super().run(problem, seed=seed, config=config)
        finally:
            v2_module._method_config = original_method_config  # type: ignore[assignment]
            v2_module._evaluate_particles = original_evaluate_particles  # type: ignore[assignment]

        result.method_name = self.method_key
        result.group = self.group
        result.logs["method_key"] = self.method_key
        result.logs["asu_preset"] = ASU_ROUTE_SERVICE_V2
        result.logs["uses_tmc_asu"] = False
        result.logs["old_v2_behavior_preserved"] = True
        result.logs["adapter_mode"] = "additive_asu_route_service_v2_compatibility"
        result.logs["response_count"] = int(result.logs.get("trigger_count", result.logs.get("response_count", 0)))
        for key in [
            "mild_response_count",
            "moderate_response_count",
            "severe_response_count",
            "restart_count",
            "pbest_preservation_count",
        ]:
            result.logs.setdefault(key, 0)
        _attach_best_chromosome(result, problem, config)
        return result


class ProposedSearchExpansionResponseV2ASUV2WithoutResponseAdapter(ProposedSearchExpansionResponseV2ASUV2Adapter):
    """ASU-v2 v2 adapter with stagnation response actions disabled.

    This additive ablation keeps the same ASU-v2 evaluation path and v2 search
    loop, while passing `response_enabled=False` through the existing v2 config
    hook. Stagnation indicators may still be logged, but response actions are
    not applied.
    """

    method_key = "v2_without_search_expansion_response_asu_v2"
    display_name = "V2 ASU-v2 without search-expansion response"
    group = "proposed_search_expansion_response_v2_asu_v2_ablation"
    response_enabled_default = False

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        result = super().run(problem, seed=seed, config=config)
        trigger_count = int(result.logs.get("trigger_count", 0) or 0)
        result.method_name = self.method_key
        result.group = self.group
        result.logs["method_key"] = self.method_key
        result.logs["stagnation_trigger_count"] = trigger_count
        result.logs["response_enabled"] = False
        result.logs["response_count"] = 0
        result.logs["response_action_count"] = 0
        result.logs["mild_response_count"] = 0
        result.logs["moderate_response_count"] = 0
        result.logs["severe_response_count"] = 0
        result.logs["restart_count"] = 0
        result.logs["response_restart_count"] = 0
        result.logs["other_restart_count"] = 0
        result.logs["adapter_mode"] = "additive_asu_route_service_v2_without_response_control"
        return result


class ProposedSearchExpansionResponseV2ASUV2FrozenStage1SequentialAdapter(ProposedSearchExpansionResponseV2ASUV2Adapter):
    """ASU-v2 v2 alias used by the frozen Stage-I sequential wrapper.

    The frozen behavior is enforced by the experiment wrapper: Stage-I decoded
    stations are appended to the Stage-II fixed infrastructure context, while
    Stage-II optimizes only the remaining K2 stations. This adapter keeps the
    optimizer behavior unchanged and only provides a distinct method key.
    """

    method_key = "v2_frozen_stage1_sequential_asu_v2"
    display_name = "V2 ASU-v2 frozen Stage-I sequential ablation"
    group = "proposed_search_expansion_response_v2_asu_v2_ablation"

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        result = super().run(problem, seed=seed, config=config)
        result.method_name = self.method_key
        result.group = self.group
        result.logs["method_key"] = self.method_key
        result.logs["adapter_mode"] = "additive_asu_route_service_v2_frozen_stage1_sequential_wrapper"
        result.logs["frozen_stage1_behavior_enforced_by_wrapper"] = True
        return result


def _method_config_asu_v2(
    config: Config,
    method_key: str,
    *,
    response_enabled: bool,
    mild_only: bool,
    severe_restart_fraction: float,
) -> Config:
    cfg = json.loads(json.dumps(config))
    cfg["asu_preset"] = ASU_ROUTE_SERVICE_V2
    cfg.setdefault("airwayServiceUtility", {})["asu_preset"] = ASU_ROUTE_SERVICE_V2
    cfg.setdefault("airwayServiceUtilityV2", {})
    cfg["airwayServiceUtilityV2"].setdefault("signal_metric", "snr")
    cfg["airwayServiceUtilityV2"].setdefault("w_current", 0.5)
    cfg["airwayServiceUtilityV2"].setdefault("w_future", 0.5)
    cfg["airwayServiceUtilityV2"].setdefault("C_5G", 1.0)
    cfg["airwayServiceUtilityV2"].setdefault("C_5GA", 1.35)
    cfg["airwayServiceUtilityV2"].setdefault("kappa_H", 0.01)
    cfg["airwayServiceUtilityV2"].setdefault("C_0", 1.0)
    if _optimization_signal_metric(cfg) == "sinr":
        cfg["asu_preset"] = ASU_ROUTE_SERVICE_V2_SINR
        cfg["airwayServiceUtility"]["asu_preset"] = ASU_ROUTE_SERVICE_V2_SINR
        cfg["airwayServiceUtilityV2"]["signal_metric"] = "sinr"
        cfg["airwayServiceUtilityV2"]["optimization_signal_metric"] = "sinr"
        cfg.setdefault("evaluation", {})["optimization_signal_metric"] = "sinr"
    cfg.setdefault("experiment", {})["method"] = method_key
    cfg["experiment"]["legacy_proposed_method_preserved_as"] = "proposed_method"
    cfg["experiment"]["asu_v2_adapter_additive"] = True
    cfg.setdefault("particleEncoding", {})["optimizeStationType"] = True
    cfg["particleEncoding"]["optimizeSectorDirection"] = True
    cfg.setdefault("channel", {})["sector_directions_deg"] = [float(v) for v in DEFAULT_SECTOR_DIRECTIONS_DEG]
    cfg.setdefault("asuAligned", {}).setdefault("stage1_ratio", 0.5)
    cfg["asuAligned"].setdefault("stage1_cap", 6)
    cfg["asuAligned"].setdefault("sector_repair_radius_m", 900.0)
    cfg["asuAligned"].setdefault("sector_repair_max_nearby_points", 80)
    v2 = cfg.setdefault("searchExpansionResponseV2", {})
    defaults = {
        "response_enabled": bool(response_enabled),
        "mild_only": bool(mild_only),
        "scoreWeights": {
            "coverage": 0.22,
            "novelty": 0.22,
            "entropy": 0.15,
            "nd": 0.15,
            "movement": 0.14,
            "pbest": 0.08,
            "leader": 0.02,
            "qe": 0.02,
        },
        "plateauWindow": 20,
        "escalationWindow": 40,
        "minIterationsBeforeResponse": 80,
        "responseCooldown": 40,
        "postResponseEvaluationWindow": 20,
        "maxResponsesPerRun": 5,
        "thresholdMild": 0.45,
        "thresholdModerate": 0.60,
        "thresholdSevere": 0.75,
        "moderateResponseFraction": 0.10,
        "severeRestartFraction": min(max(float(severe_restart_fraction), 0.0), 0.20),
        "mildBoostIterations": 20,
        "harmfulCooldownExtension": 20,
        "severeAsuDropRatio": 0.10,
        "asuGuardEnabled": False,
        "asuGuardDropRatio": 0.05,
        "asuGuardResponseFractionMultiplier": 0.50,
        "asuGuardResponseFractionScaleMin": 0.125,
        "v21GuardEnabled": False,
        "v21CumulativeAsuDownshiftRatio": 0.03,
        "v21CumulativeAsuSkipSevereRatio": 0.05,
        "v21SystemMetricHarmfulRatio": 0.02,
        "v21ResponseFractionMultiplier": 0.50,
        "v21ResponseFractionScaleMin": 0.125,
        "restartNoiseRatio": 0.08,
    }
    for key, value in defaults.items():
        v2.setdefault(key, value)
    v2["response_enabled"] = bool(response_enabled)
    v2["mild_only"] = bool(mild_only)
    v2["severeRestartFraction"] = min(max(float(severe_restart_fraction), 0.0), 0.20)
    return cfg


def _evaluate_particles_asu_v2(
    particles: np.ndarray,
    problem: DeploymentProblem,
    config: Config,
    method_key: str,
) -> _ASUV2EvalPack:
    if _optimization_signal_metric(config) == "sinr":
        evaluation = evaluate_with_existing_context_sinr_asu_v2(
            decisions=np.asarray(particles, dtype=float),
            problem=problem,
            config=config,
            method_name=method_key,
        )
        metrics = [dict(row) for row in evaluation.metrics]
        return _ASUV2EvalPack(
            objectives=np.asarray(evaluation.objectives, dtype=float),
            asu_values=np.asarray(evaluation.asu_values, dtype=float),
            metrics=metrics,
            feasible=np.asarray(evaluation.feasible, dtype=bool),
        )
    eval_info = evaluate_with_existing_context(
        decisions=np.asarray(particles, dtype=float),
        problem=problem,
        config=config,
        method_name=method_key,
    )
    metrics = [dict(row) for row in eval_info.metrics]
    asu_values: List[float] = []
    for i, row in enumerate(metrics):
        n_5g, n_5ga = _station_type_counts(np.asarray(particles[i], dtype=float))
        row["N_5G"] = float(n_5g)
        row["N_5GA"] = float(n_5ga)
        record = asu_route_service_v2_from_metrics(row, config).as_dict()
        row.update(record)
        asu_values.append(float(record["ASU"]))
    asu_arr = np.asarray(asu_values, dtype=float)
    objectives = _asu_v2_objectives(metrics, asu_arr)
    tol = float(config.get("nsga2", {}).get("feasiblePenaltyTol", 1e-9))
    feasible = np.asarray([float(row.get("constraint_penalty", 0.0)) <= tol for row in metrics], dtype=bool)
    return _ASUV2EvalPack(objectives=objectives, asu_values=asu_arr, metrics=metrics, feasible=feasible)


def _asu_v2_objectives(metrics: Sequence[Dict[str, float]], asu_values: np.ndarray) -> np.ndarray:
    rows: List[List[float]] = []
    for row, asu in zip(metrics, asu_values.tolist()):
        current = float(row.get("existing_route_continuous_coverage_rate", row.get("current_coverage", row.get("coverage_rate", 0.0))))
        future = float(row.get("future_route_continuous_coverage_rate", row.get("future_coverage", row.get("coverage_rate", 0.0))))
        rows.append(
            [
                -float(asu),
                float(row.get("handover_count", 0.0)),
                float(row.get("deployment_cost", row.get("C_dep", 0.0))),
                1.0 - current,
                1.0 - future,
            ]
        )
    return np.asarray(rows, dtype=float)


def _attach_best_chromosome(result: BaselineResult, problem: DeploymentProblem, config: Config) -> None:
    if result.decision_variables.size == 0:
        return
    cfg = json.loads(json.dumps(config))
    cfg["asu_preset"] = ASU_ROUTE_SERVICE_V2
    cfg.setdefault("airwayServiceUtility", {})["asu_preset"] = ASU_ROUTE_SERVICE_V2
    evaluation = _evaluate_particles_asu_v2(result.decision_variables, problem, cfg, result.method_name)
    idx = int(np.argmax(evaluation.asu_values))
    result.logs["best_ASU"] = float(evaluation.asu_values[idx])
    if _optimization_signal_metric(config) == "sinr":
        result.logs["asu_preset"] = ASU_ROUTE_SERVICE_V2_SINR
        result.logs["optimization_signal_metric"] = "sinr"
        result.logs["rho"] = float(config.get("evaluation", {}).get("rho", 0.10))
    result.logs["best_asu_record"] = {
        k: v for k, v in evaluation.metrics[idx].items() if k in {"ASU", ASU_ROUTE_SERVICE_KEY, "Q_current", "Q_future", "denominator", "C_dep", "handover_count"}
    }
    result.logs["best_chromosome"] = np.asarray(result.decision_variables[idx], dtype=float).reshape(-1).tolist()


def _station_type_counts(particle: np.ndarray) -> tuple[int, int]:
    arr = np.asarray(particle, dtype=float).reshape(-1, 5)
    type_idx = np.rint(arr[:, 3]).astype(int)
    n_5ga = int(np.sum(type_idx == 1))
    return int(type_idx.size - n_5ga), n_5ga


def _optimization_signal_metric(config: Config) -> str:
    raw = (
        config.get("optimization_signal_metric")
        or config.get("evaluation", {}).get("optimization_signal_metric")
        or config.get("airwayServiceUtilityV2", {}).get("optimization_signal_metric")
        or "snr"
    )
    return str(raw).strip().lower()
