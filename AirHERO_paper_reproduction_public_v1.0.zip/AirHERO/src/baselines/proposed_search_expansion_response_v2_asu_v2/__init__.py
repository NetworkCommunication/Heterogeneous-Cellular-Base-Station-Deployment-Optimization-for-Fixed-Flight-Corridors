"""ASU-v2 compatible adapter for search-expansion response v2."""

