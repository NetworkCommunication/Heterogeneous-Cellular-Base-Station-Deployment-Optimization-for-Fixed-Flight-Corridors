from __future__ import annotations

import math

import numpy as np

from src.baselines.bio_inspired_common import ASUV2BioInspiredAdapter, clip_to_bounds


class SSAExtendedAdapter(ASUV2BioInspiredAdapter):
    """Sparrow Search Algorithm baseline for ASU-v2 deployment."""

    method_key = "ssa_extended"
    display_name = "Sparrow Search Algorithm Extended"
    algorithm_name = "Sparrow Search Algorithm"
    implemented = True

    def _extra_algorithm_config(self, raw):
        return {
            "producer_fraction": float(raw.get("producer_fraction", raw.get("producerFraction", 0.2))),
            "warning_probability": float(raw.get("warning_probability", raw.get("warningProbability", 0.1))),
        }

    def _next_population(self, *, population, scores, iteration, max_iterations, encoding, problem, config, rng, state, alg_cfg):
        order = np.argsort(-scores)
        best = population[order[0]]
        worst = population[order[-1]]
        out = population.copy()
        n = population.shape[0]
        producers = max(1, int(round(n * float(alg_cfg["producer_fraction"]))))
        safe = float(rng.random()) > float(alg_cfg["warning_probability"])
        for rank, idx in enumerate(order):
            if rank < producers:
                if safe:
                    denom = max(float(rng.random()) * max_iterations, 1e-9)
                    out[idx] = population[idx] * math.exp(-float(rank + 1) / denom)
                else:
                    out[idx] = population[idx] + rng.normal(0.0, 0.12, size=population.shape[1]) * (
                        encoding.upper_bounds - encoding.lower_bounds
                    )
            else:
                if rank > n / 2:
                    out[idx] = rng.normal(0.0, 1.0, size=population.shape[1]) * np.exp(
                        (worst - population[idx]) / float((rank + 1) ** 2)
                    ) + population[idx]
                else:
                    step = np.abs(population[idx] - best)
                    signs = rng.choice([-1.0, 1.0], size=population.shape[1])
                    out[idx] = best + step * signs * rng.random(size=population.shape[1])
        return clip_to_bounds(out, encoding)
