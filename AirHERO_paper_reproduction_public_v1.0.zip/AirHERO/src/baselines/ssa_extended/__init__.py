from src.baselines.ssa_extended.adapter import SSAExtendedAdapter

__all__ = ["SSAExtendedAdapter"]
