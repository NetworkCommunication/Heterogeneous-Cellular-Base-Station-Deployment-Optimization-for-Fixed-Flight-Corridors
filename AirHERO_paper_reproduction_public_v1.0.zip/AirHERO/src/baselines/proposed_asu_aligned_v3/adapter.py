from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np

from src.algorithms.init_strategies import ensure_non_building
from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.data.types import Config
from src.experiments.airway_service_utility import ASU_SCORE_KEY, build_asu_record, materialize_asu_config
from src.experiments.evaluation_consistency import evaluate_with_existing_context
from src.experiments.multiobjective_metrics import nondominated_mask
from src.propagation.low_fidelity import compute_point_snr
from src.propagation.sector_geometry import DEFAULT_SECTOR_DIRECTIONS_DEG, nearest_supported_sector_direction_deg


@dataclass
class _EvalPack:
    objectives: np.ndarray
    asu_values: np.ndarray
    metrics: List[Dict[str, float]]
    asu_records: List[Dict[str, Any]]
    feasible: np.ndarray


class ProposedASUAlignedV3Adapter(BaselineAdapter):
    """ASU-component objective-vector optimizer kept separate from v1/v2 and legacy proposed_method."""

    method_key = "proposed_method_asu_aligned_v3"
    display_name = "Proposed Method ASU-Aligned V3"
    group = "proposed_asu_aligned_v3"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        cfg = _method_config(config)
        config.clear()
        config.update(json.loads(json.dumps(cfg)))
        rng = np.random.default_rng(int(seed))
        t0 = time.time()

        pso = cfg.get("pso", {})
        pop_size = int(pso.get("numParticles", 160))
        max_iter = int(pso.get("maxIterations", 80))
        k = int(pso.get("numBaseStations", cfg.get("stage1", {}).get("numNewStations", 1)))
        archive_size = int(cfg.get("mopso", {}).get("archiveSize", 40))
        min_pos = np.asarray(pso.get("minPosition", [0.0, 0.0, 20.0]), dtype=float)
        max_pos = np.asarray(pso.get("maxPosition", [problem.city_map.size_x, problem.city_map.size_y, 160.0]), dtype=float)

        logs: Dict[str, Any] = {
            "method_key": self.method_key,
            "legacy_proposed_preserved": True,
            "objective_mode": cfg["asuAlignedV3"]["objective_mode"],
            "asu_tie_break_used_count": 0,
            "sector_repair_log": [],
            "station_type_refinement_log": [],
            "stage1_seed_summary": [],
            "leader_selection_summary": [],
            "archive_asu_values": [],
            "v3_objective_vectors": [],
        }

        particles, stage1_summary = _initialize_population(problem, cfg, rng, pop_size, k, min_pos, max_pos)
        logs["stage1_seed_summary"].extend(stage1_summary)
        velocities = np.zeros((pop_size, k, 3), dtype=float)
        velocities[:] = (rng.random((pop_size, k, 3)) - 0.5) * (max_pos[:3] - min_pos[:3])[None, None, :] * 0.08

        pbest = particles.copy()
        pbest_eval = _evaluate_particles(pbest, problem, cfg)
        archive_p, archive_o, archive_asu, archive_metrics = _truncate_archive(
            pbest,
            pbest_eval.objectives,
            pbest_eval.asu_values,
            pbest_eval.metrics,
            archive_size,
            logs,
        )

        for iteration in range(max_iter):
            if archive_p.shape[0] == 0:
                leaders = pbest[rng.integers(0, pop_size, size=pop_size)]
                biased_count = 0
                leader_mode = "random_personal_best"
            else:
                leaders, biased_count, leader_mode = _select_leaders(archive_p, archive_asu, archive_metrics, pop_size, cfg, rng)
            logs["leader_selection_summary"].append(
                {
                    "iteration": int(iteration + 1),
                    "archive_size": int(archive_p.shape[0]),
                    "asu_biased_leader_count": int(biased_count),
                    "mean_archive_asu": float(np.mean(archive_asu)) if archive_asu.size else 0.0,
                    "leader_bias_mode": leader_mode,
                }
            )

            r1 = rng.random((pop_size, k, 3))
            r2 = rng.random((pop_size, k, 3))
            w = float(pso.get("w", 0.729)) * (0.995 ** iteration)
            c1 = float(pso.get("c1", 1.49445))
            c2 = float(pso.get("c2", 1.49445))
            velocities = w * velocities + c1 * r1 * (pbest[:, :, :3] - particles[:, :, :3]) + c2 * r2 * (leaders[:, :, :3] - particles[:, :, :3])
            vel_lim = (max_pos[:3] - min_pos[:3]) * float(cfg.get("mopso", {}).get("velocityLimitRatio", 0.2))
            velocities = np.clip(velocities, -vel_lim[None, None, :], vel_lim[None, None, :])
            particles[:, :, :3] = np.clip(particles[:, :, :3] + velocities, min_pos[:3][None, None, :], max_pos[:3][None, None, :])

            copy_mask = rng.random((pop_size, k)) < 0.20
            particles[:, :, 3] = np.where(copy_mask, leaders[:, :, 3], particles[:, :, 3])
            sector_copy = rng.random((pop_size, k)) < 0.25
            particles[:, :, 4] = np.where(sector_copy, leaders[:, :, 4], particles[:, :, 4])
            mutation = rng.random((pop_size, k)) < 0.04
            particles[:, :, 3] = np.where(mutation, rng.integers(0, _station_type_count(cfg), size=(pop_size, k)), particles[:, :, 3])
            sector_mut = rng.random((pop_size, k)) < 0.08
            particles[:, :, 4] = np.where(sector_mut, rng.integers(0, len(DEFAULT_SECTOR_DIRECTIONS_DEG), size=(pop_size, k)), particles[:, :, 4])
            particles = _repair_particles(particles, problem, cfg, rng, min_pos, max_pos)
            particles, sector_log = _repair_5ga_sectors(particles, problem, cfg)
            if sector_log:
                sector_log["iteration"] = int(iteration + 1)
                logs["sector_repair_log"].append(sector_log)
            particles, type_log = _refine_station_types(particles, problem, cfg, rng)
            if type_log:
                type_log["iteration"] = int(iteration + 1)
                logs["station_type_refinement_log"].append(type_log)

            curr_eval = _evaluate_particles(particles, problem, cfg)
            improve = _better_for_personal_best(curr_eval.objectives, curr_eval.asu_values, pbest_eval.objectives, pbest_eval.asu_values)
            if np.any(improve):
                pbest[improve] = particles[improve]
                pbest_eval.objectives[improve] = curr_eval.objectives[improve]
                pbest_eval.asu_values[improve] = curr_eval.asu_values[improve]
                for idx in np.where(improve)[0].tolist():
                    pbest_eval.metrics[idx] = curr_eval.metrics[idx]
                    pbest_eval.asu_records[idx] = curr_eval.asu_records[idx]
                    pbest_eval.feasible[idx] = curr_eval.feasible[idx]

            merged_p = np.concatenate([archive_p, particles, pbest], axis=0) if archive_p.size else np.concatenate([particles, pbest], axis=0)
            merged_o = np.vstack([archive_o, curr_eval.objectives, pbest_eval.objectives]) if archive_o.size else np.vstack([curr_eval.objectives, pbest_eval.objectives])
            merged_asu = np.concatenate([archive_asu, curr_eval.asu_values, pbest_eval.asu_values]) if archive_asu.size else np.concatenate([curr_eval.asu_values, pbest_eval.asu_values])
            merged_metrics = list(archive_metrics) + list(curr_eval.metrics) + list(pbest_eval.metrics)
            archive_p, archive_o, archive_asu, archive_metrics = _truncate_archive(
                merged_p,
                merged_o,
                merged_asu,
                merged_metrics,
                archive_size,
                logs,
            )

        final_eval = _evaluate_particles(archive_p, problem, cfg) if archive_p.size else pbest_eval
        final_p = archive_p if archive_p.size else pbest
        final_o = final_eval.objectives
        final_asu = final_eval.asu_values
        nd = nondominated_mask(final_o) if final_o.size else np.zeros((0,), dtype=bool)
        if not np.any(nd) and final_o.shape[0] > 0:
            nd[np.argmax(final_asu)] = True
        logs["archive_asu_values"] = [
            {"solution_id": int(i + 1), ASU_SCORE_KEY: float(v)}
            for i, v in enumerate(final_asu[nd].tolist() if np.any(nd) else [])
        ]
        if np.any(nd):
            nd_indices = np.where(nd)[0].tolist()
            logs["v3_objective_vectors"] = [
                {
                    "solution_id": int(pos + 1),
                    "objective_mode": str(cfg["asuAlignedV3"].get("objective_mode", "O5_service_quality")),
                    ASU_SCORE_KEY: float(final_asu[idx]),
                    **{f"f{j + 1}": float(value) for j, value in enumerate(final_o[idx].tolist())},
                }
                for pos, idx in enumerate(nd_indices)
            ]
        logs["final_archive_size"] = int(final_p[nd].shape[0])
        logs["best_archive_asu"] = float(np.max(final_asu[nd])) if np.any(nd) else 0.0
        feasible = final_eval.feasible[nd] if np.any(nd) else np.zeros((0,), dtype=bool)

        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=np.asarray(final_o, dtype=float),
            decision_variables=np.asarray(final_p, dtype=float),
            nondominated_objectives=np.asarray(final_o[nd], dtype=float),
            nondominated_decisions=np.asarray(final_p[nd], dtype=float),
            runtime_seconds=float(time.time() - t0),
            feasible_mask=np.asarray(final_eval.feasible, dtype=bool),
            nondominated_feasible_mask=np.asarray(feasible, dtype=bool),
            logs=logs,
        )


def _method_config(config: Config) -> Config:
    cfg = json.loads(json.dumps(config))
    materialize_asu_config(cfg)
    cfg.setdefault("experiment", {})["method"] = ProposedASUAlignedV3Adapter.method_key
    cfg["experiment"]["legacy_proposed_method_preserved_as"] = "proposed_method"
    cfg["experiment"]["proposed_asu_aligned_v1_preserved_as"] = "proposed_method_asu_aligned"
    cfg["experiment"]["proposed_asu_aligned_v2_preserved_as"] = "proposed_method_asu_aligned_v2"
    cfg.setdefault("particleEncoding", {})["optimizeStationType"] = True
    cfg["particleEncoding"]["optimizeSectorDirection"] = True
    cfg.setdefault("channel", {})["sector_directions_deg"] = [float(v) for v in DEFAULT_SECTOR_DIRECTIONS_DEG]
    cfg.setdefault("asuAlignedV3", {})
    defaults = {
        "objective_mode": "O5_service_quality",
        "continuity_current_weight": 0.55,
        "continuity_future_weight": 0.45,
        "coverage_pressure_mode": "max_hole_outage",
        "service_quality_component": "capacity_and_snr",
        "asu_leader_bias_enabled": True,
        "asu_leader_bias_probability": 0.3,
        "sector_repair_enabled": True,
        "sector_repair_mode": "local_route_service_proxy",
        "sector_repair_max_nearby_points": 80,
        "sector_repair_radius_m": 900.0,
        "station_type_refinement_enabled": True,
        "station_type_refinement_mode": "coverage_continuity_first_marginal_utility",
        "station_type_refinement_probability": 0.3,
        "station_type_refinement_radius_m": 650.0,
        "min_5ga_marginal_gain": 0.0,
        "saturation_min_5ga_marginal_gain": 0.02,
        "fivega_soft_regularization_enabled": False,
        "fivega_reference_ratio_low_coverage": 0.55,
        "fivega_reference_ratio_saturated": 0.40,
        "fivega_excess_penalty_weight": 0.05,
        "stage1_ratio": 0.5,
        "stage1_cap": 6,
        "objective_capacity_reference": cfg.get("baselineObjectives", {}).get("capacityReference", 3.0),
        "objective_snr_reference_db": 20.0,
    }
    for key, value in defaults.items():
        cfg["asuAlignedV3"].setdefault(key, value)
    cfg["asuAligned"] = json.loads(json.dumps(cfg["asuAlignedV3"]))
    return cfg


def _initialize_population(
    problem: DeploymentProblem,
    config: Config,
    rng: np.random.Generator,
    pop_size: int,
    k: int,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
) -> Tuple[np.ndarray, List[Dict[str, Any]]]:
    particles = np.zeros((pop_size, k, 5), dtype=float)
    route_pts = np.asarray(problem.test_points, dtype=float)
    blind = _blind_route_points(problem, config)
    target = blind if blind.shape[0] >= max(2, k) else route_pts
    stage1_k = min(int(np.ceil(float(config["asuAligned"]["stage1_ratio"]) * k)), int(config["asuAligned"]["stage1_cap"]), k)
    centers = _farthest_points(target, max(stage1_k, 1), rng)
    summary: List[Dict[str, Any]] = [
        {
            "stage1_seed_count": int(stage1_k),
            "stage2_diversity_station_count": int(k - stage1_k),
            "blind_route_point_count": int(blind.shape[0]),
            "target_point_count": int(target.shape[0]),
            "stage1_ratio": float(config["asuAligned"]["stage1_ratio"]),
            "stage1_cap": int(config["asuAligned"]["stage1_cap"]),
        }
    ]
    for p in range(pop_size):
        rows = np.zeros((k, 5), dtype=float)
        for i in range(k):
            if i < stage1_k and centers.size:
                anchor = centers[i % centers.shape[0]].copy()
                jitter = rng.normal(0.0, 90.0, size=2)
                x = float(anchor[0] + jitter[0])
                y = float(anchor[1] + jitter[1])
                z = float(anchor[2] if anchor.shape[0] > 2 else max_pos[2])
            else:
                anchor = route_pts[int(rng.integers(0, route_pts.shape[0]))] if route_pts.size else np.asarray(max_pos[:3])
                radius = 1300.0 * np.sqrt(float(rng.random()))
                theta = 2.0 * np.pi * float(rng.random())
                x = float(anchor[0] + radius * np.cos(theta))
                y = float(anchor[1] + radius * np.sin(theta))
                z = float(anchor[2] if anchor.shape[0] > 2 else max_pos[2])
            x = float(np.clip(x, min_pos[0], max_pos[0]))
            y = float(np.clip(y, min_pos[1], max_pos[1]))
            z = float(np.clip(z, min_pos[2], max_pos[2]))
            rows[i, :3] = ensure_non_building(x, y, z, problem.city_map, min_pos[:3], max_pos[:3], rng)
            rows[i, 3] = float(_initial_type_index(config, i, k, rng))
            rows[i, 4] = float(_best_sector_index(rows[i, :3], route_pts, config))
        particles[p] = rows
    return _repair_particles(particles, problem, config, rng, min_pos, max_pos), summary


def _blind_route_points(problem: DeploymentProblem, config: Config) -> np.ndarray:
    existing = np.asarray(config.get("heterogeneousDeployment", {}).get("existingStations", []), dtype=float)
    pts = np.asarray(problem.test_points, dtype=float)
    if existing.size == 0 or pts.size == 0:
        return pts
    existing = existing.reshape(-1, existing.shape[-1])[:, :3]
    try:
        snr = compute_point_snr(existing, pts, problem.city_map, problem.channel_params)
        threshold = float(problem.channel_params.get("snrThreshold", config.get("channel", {}).get("snrThreshold", 0.0)))
        blind = pts[np.asarray(snr, dtype=float) < threshold]
        return blind if blind.shape[0] else pts
    except Exception:
        return pts


def _evaluate_particles(particles: np.ndarray, problem: DeploymentProblem, config: Config) -> _EvalPack:
    eval_info = evaluate_with_existing_context(
        decisions=np.asarray(particles, dtype=float),
        problem=problem,
        config=config,
        method_name=ProposedASUAlignedV3Adapter.method_key,
    )
    metrics = [dict(row) for row in eval_info.metrics]
    asu_records = [
        build_asu_record(
            row,
            config,
            seed=0,
            method_name=ProposedASUAlignedV3Adapter.method_key,
            group="proposed_asu_aligned_v3_internal",
            solution_id=i + 1,
            source="asu_aligned_v3_internal_eval",
        )
        for i, row in enumerate(metrics)
    ]
    asu_values = np.asarray([float(row.get(ASU_SCORE_KEY, 0.0)) for row in asu_records], dtype=float)
    for row in metrics:
        row["saturation_state"] = _saturation_state(row)
    objectives = _asu_aligned_objectives(metrics, config, particles)
    tol = float(config.get("nsga2", {}).get("feasiblePenaltyTol", 1e-9))
    feasible = np.asarray([float(row.get("constraint_penalty", 0.0)) <= tol for row in metrics], dtype=bool)
    return _EvalPack(objectives=objectives, asu_values=asu_values, metrics=metrics, asu_records=asu_records, feasible=feasible)


def _asu_aligned_objectives(metrics: Sequence[Dict[str, float]], config: Config, particles: np.ndarray) -> np.ndarray:
    norm = config.get("airwayServiceUtility", {}).get("normalization", {})
    cost_ref = float(norm.get("cost_reference", config.get("baselineObjectives", {}).get("costReference", 1.0)))
    handover_ref = float(norm.get("handover_reference", 8.0))
    cap_ref = float(config["asuAligned"].get("objective_capacity_reference", norm.get("capacity_reference", 3.0)))
    snr_ref = float(config["asuAligned"].get("objective_snr_reference_db", norm.get("snr_reference_db", 20.0)))
    alpha = float(config["asuAligned"].get("continuity_current_weight", 0.55))
    beta = float(config["asuAligned"].get("continuity_future_weight", 0.45))
    mode = str(config["asuAligned"].get("objective_mode", "O5_service_quality"))
    rows: List[List[float]] = []
    for row in metrics:
        current = float(row.get("existing_route_continuous_coverage_rate", row.get("coverage_rate", 0.0)))
        future = float(row.get("future_route_continuous_coverage_rate", row.get("coverage_rate", 0.0)))
        coverage = float(row.get("coverage_rate", 0.0))
        hole = float(row.get("coverage_hole_rate", 1.0 - np.mean([current, future])))
        outage = float(row.get("outage_probability", 1.0 - coverage))
        cap = float(row.get("capacity_effective", 0.0))
        snr = float(row.get("mean_snr_db", 0.0))
        coverage_pressure = max(hole, outage)
        continuity_loss = alpha * (1.0 - current) + beta * (1.0 - future)
        cost_obj = float(row.get("deployment_cost", 0.0)) / max(cost_ref, 1e-9)
        handover_obj = float(row.get("handover_count", 0.0)) / max(handover_ref, 1e-9)
        capacity_loss = 1.0 - min(cap / max(cap_ref, 1e-9), 1.5) / 1.5
        snr_loss = 1.0 - min(max(snr, 0.0) / max(snr_ref, 1e-9), 1.5) / 1.5
        service_quality_loss = 0.65 * capacity_loss + 0.35 * snr_loss
        if mode == "O4_rebalanced":
            rows.append([coverage_pressure, continuity_loss, cost_obj, handover_obj])
        elif mode == "O6_split_continuity":
            rows.append([coverage_pressure, 1.0 - current, 1.0 - future, cost_obj, handover_obj, service_quality_loss])
        else:
            rows.append([coverage_pressure, continuity_loss, cost_obj, handover_obj, service_quality_loss])
    return np.asarray(rows, dtype=float)


def _saturation_state(row: Dict[str, float]) -> str:
    coverage = float(row.get("coverage_rate", 0.0))
    if coverage < 0.90:
        return "low_coverage"
    if coverage < 0.97:
        return "medium_coverage"
    return "saturated_coverage"


def _fivega_soft_penalty(particle: np.ndarray, config: Config, state: str) -> float:
    if not bool(config["asuAligned"].get("fivega_soft_regularization_enabled", True)):
        return 0.0
    arr = np.asarray(particle, dtype=float)
    if arr.size == 0 or arr.ndim != 2:
        return 0.0
    fivega_idx = _type_index(config, "5GA")
    ratio = float(np.mean(np.rint(arr[:, 3]).astype(int) == fivega_idx)) if arr.shape[0] else 0.0
    low_ref = float(config["asuAligned"].get("fivega_reference_ratio_low_coverage", 0.50))
    sat_ref = float(config["asuAligned"].get("fivega_reference_ratio_saturated", 0.25))
    ref = low_ref if state == "low_coverage" else (0.5 * (low_ref + sat_ref) if state == "medium_coverage" else sat_ref)
    weight = float(config["asuAligned"].get("fivega_excess_penalty_weight", 0.30))
    return float(weight * max(0.0, ratio - ref) ** 2)


def _truncate_archive(
    particles: np.ndarray,
    objectives: np.ndarray,
    asu_values: np.ndarray,
    metrics: Sequence[Dict[str, float]],
    archive_size: int,
    logs: Dict[str, Any],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, List[Dict[str, float]]]:
    if particles.size == 0:
        return particles, objectives, asu_values, []
    nd = nondominated_mask(objectives)
    p = particles[nd]
    o = objectives[nd]
    a = asu_values[nd]
    m = [dict(metrics[i]) for i in np.where(nd)[0].tolist()]
    if p.shape[0] <= archive_size:
        return p, o, a, m
    crowd = _crowding_distance(o)
    crowd_norm = crowd / max(float(np.nanmax(crowd[np.isfinite(crowd)])) if np.any(np.isfinite(crowd)) else 1.0, 1e-9)
    asu_norm = (a - float(np.min(a))) / max(float(np.max(a) - np.min(a)), 1e-9)
    score = crowd_norm + 0.15 * asu_norm
    keep = np.argsort(-score)[:archive_size]
    logs["asu_tie_break_used_count"] = int(logs.get("asu_tie_break_used_count", 0)) + int(max(p.shape[0] - archive_size, 0))
    return p[keep], o[keep], a[keep], [m[i] for i in keep.tolist()]


def _crowding_distance(objectives: np.ndarray) -> np.ndarray:
    n = objectives.shape[0]
    if n == 0:
        return np.zeros((0,), dtype=float)
    dist = np.zeros((n,), dtype=float)
    for j in range(objectives.shape[1]):
        order = np.argsort(objectives[:, j])
        dist[order[0]] = np.inf
        dist[order[-1]] = np.inf
        span = float(objectives[order[-1], j] - objectives[order[0], j])
        if span <= 1e-12:
            continue
        for pos in range(1, n - 1):
            dist[order[pos]] += float(objectives[order[pos + 1], j] - objectives[order[pos - 1], j]) / span
    return dist


def _select_leaders(
    archive_particles: np.ndarray,
    archive_asu: np.ndarray,
    archive_metrics: Sequence[Dict[str, float]],
    pop_size: int,
    config: Config,
    rng: np.random.Generator,
) -> Tuple[np.ndarray, int, str]:
    prob = float(config["asuAligned"].get("asu_leader_bias_probability", 0.3)) if config["asuAligned"].get("asu_leader_bias_enabled", True) else 0.0
    leaders = np.zeros((pop_size, archive_particles.shape[1], archive_particles.shape[2]), dtype=float)
    biased = 0
    states = [_saturation_state(dict(row)) for row in archive_metrics]
    saturated_share = float(np.mean([state == "saturated_coverage" for state in states])) if states else 0.0
    if saturated_share >= 0.50:
        costs = np.asarray([float(row.get("deployment_cost", 0.0)) for row in archive_metrics], dtype=float)
        handovers = np.asarray([float(row.get("handover_count", 0.0)) for row in archive_metrics], dtype=float)
        eff = np.asarray([float(row.get("cost_effectiveness", 0.0)) for row in archive_metrics], dtype=float)
        score = _normalize(archive_asu) + 0.20 * _normalize(eff) - 0.20 * _normalize(costs) - 0.15 * _normalize(handovers)
        mode = "saturated_higher_asu_lower_cost_handover"
    else:
        holes = np.asarray([float(row.get("coverage_hole_rate", 1.0)) for row in archive_metrics], dtype=float)
        outages = np.asarray([float(row.get("outage_probability", 1.0)) for row in archive_metrics], dtype=float)
        score = _normalize(archive_asu) - 0.25 * _normalize(np.maximum(holes, outages))
        mode = "coverage_hole_outage_reduction"
    weights = score - float(np.min(score)) + 1e-6
    weights = weights / float(np.sum(weights)) if float(np.sum(weights)) > 0.0 else np.ones_like(weights) / max(len(weights), 1)
    for i in range(pop_size):
        if float(rng.random()) < prob and archive_particles.shape[0] > 0:
            idx = int(rng.choice(np.arange(archive_particles.shape[0]), p=weights))
            biased += 1
        else:
            idx = int(rng.integers(0, archive_particles.shape[0]))
        leaders[i] = archive_particles[idx]
    return leaders, biased, mode


def _normalize(values: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    if arr.size == 0:
        return arr
    span = float(np.nanmax(arr) - np.nanmin(arr))
    if not np.isfinite(span) or span <= 1e-12:
        return np.zeros_like(arr, dtype=float)
    return (arr - float(np.nanmin(arr))) / span


def _better_for_personal_best(curr_obj: np.ndarray, curr_asu: np.ndarray, best_obj: np.ndarray, best_asu: np.ndarray) -> np.ndarray:
    curr_dom = np.all(curr_obj <= best_obj, axis=1) & np.any(curr_obj < best_obj, axis=1)
    non_dom_tie = ~(np.all(best_obj <= curr_obj, axis=1) & np.any(best_obj < curr_obj, axis=1))
    asu_better = curr_asu > best_asu + 1e-9
    return curr_dom | (non_dom_tie & asu_better)


def _repair_particles(
    particles: np.ndarray,
    problem: DeploymentProblem,
    config: Config,
    rng: np.random.Generator,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
) -> np.ndarray:
    out = np.asarray(particles, dtype=float).copy()
    out[:, :, :3] = np.clip(out[:, :, :3], min_pos[:3][None, None, :], max_pos[:3][None, None, :])
    type_count = _station_type_count(config)
    out[:, :, 3] = np.clip(np.rint(out[:, :, 3]), 0, max(type_count - 1, 0))
    out[:, :, 4] = np.clip(np.rint(out[:, :, 4]), 0, len(DEFAULT_SECTOR_DIRECTIONS_DEG) - 1)
    for p in range(out.shape[0]):
        for i in range(out.shape[1]):
            out[p, i, :3] = ensure_non_building(float(out[p, i, 0]), float(out[p, i, 1]), float(out[p, i, 2]), problem.city_map, min_pos[:3], max_pos[:3], rng)
    return out


def _repair_5ga_sectors(particles: np.ndarray, problem: DeploymentProblem, config: Config) -> Tuple[np.ndarray, Dict[str, Any]]:
    if not bool(config["asuAligned"].get("sector_repair_enabled", True)):
        return particles, {}
    out = np.asarray(particles, dtype=float).copy()
    pts = np.asarray(problem.test_points, dtype=float)
    changed = 0
    total = 0
    old_scores = []
    new_scores = []
    for p in range(out.shape[0]):
        for i in range(out.shape[1]):
            if _type_name(config, int(round(out[p, i, 3]))).upper() != "5GA":
                continue
            total += 1
            old = int(round(out[p, i, 4]))
            old_score = _sector_proxy_score(out[p, i, :3], old, pts, config)
            best = _best_sector_index(out[p, i, :3], pts, config)
            best_score = _sector_proxy_score(out[p, i, :3], best, pts, config)
            if best_score > old_score + 1e-9:
                out[p, i, 4] = float(best)
                changed += 1
            old_scores.append(old_score)
            new_scores.append(max(old_score, best_score))
    return out, {
        "candidate_5ga_station_count": int(total),
        "sector_repairs_applied": int(changed),
        "mean_proxy_gain": float(np.mean(np.asarray(new_scores) - np.asarray(old_scores))) if old_scores else 0.0,
    }


def _refine_station_types(particles: np.ndarray, problem: DeploymentProblem, config: Config, rng: np.random.Generator) -> Tuple[np.ndarray, Dict[str, Any]]:
    if not bool(config["asuAligned"].get("station_type_refinement_enabled", True)):
        return particles, {}
    out = np.asarray(particles, dtype=float).copy()
    prob = float(config["asuAligned"].get("station_type_refinement_probability", 0.3))
    pts = np.asarray(problem.test_points, dtype=float)
    fiveg_idx = _type_index(config, "5G")
    fivega_idx = _type_index(config, "5GA")
    changed_to_5ga = 0
    changed_to_5g = 0
    checked = 0
    rejected_5ga_low_gain = 0
    for p in range(out.shape[0]):
        current_fivega_ratio = float(np.mean(np.rint(out[p, :, 3]).astype(int) == fivega_idx)) if out.shape[1] else 0.0
        saturated_like = out.shape[1] >= 10 or current_fivega_ratio > float(config["asuAligned"].get("fivega_reference_ratio_saturated", 0.25))
        threshold = float(config["asuAligned"].get("saturation_min_5ga_marginal_gain", 0.05)) if saturated_like else float(config["asuAligned"].get("min_5ga_marginal_gain", 0.0))
        for i in range(out.shape[1]):
            if float(rng.random()) > prob:
                continue
            checked += 1
            local_density = _nearby_route_density(out[p, i, :3], pts, float(config["asuAligned"].get("station_type_refinement_radius_m", 650.0)))
            current = int(round(out[p, i, 3]))
            best_sector = _best_sector_index(out[p, i, :3], pts, config)
            fiveg_score = _station_type_proxy_score(out[p, i, :3], fiveg_idx, 0, pts, config, saturated_like)
            fivega_score = _station_type_proxy_score(out[p, i, :3], fivega_idx, best_sector, pts, config, saturated_like)
            marginal_gain = float(fivega_score - fiveg_score)
            if local_density >= 8 and marginal_gain > threshold and current != fivega_idx:
                out[p, i, 3] = float(fivega_idx)
                out[p, i, 4] = float(best_sector)
                changed_to_5ga += 1
            elif (local_density < 4 or marginal_gain <= threshold) and current != fiveg_idx:
                out[p, i, 3] = float(fiveg_idx)
                out[p, i, 4] = 0.0
                changed_to_5g += 1
                if marginal_gain <= threshold:
                    rejected_5ga_low_gain += 1
    return out, {
        "stations_checked": int(checked),
        "changed_to_5ga": int(changed_to_5ga),
        "changed_to_5g": int(changed_to_5g),
        "rejected_5ga_low_marginal_gain": int(rejected_5ga_low_gain),
        "refinement_mode": str(config["asuAligned"].get("station_type_refinement_mode", "marginal_asu_utility")),
    }


def _best_sector_index(site: np.ndarray, points: np.ndarray, config: Config) -> int:
    scores = [_sector_proxy_score(site, idx, points, config) for idx in range(len(DEFAULT_SECTOR_DIRECTIONS_DEG))]
    return int(np.argmax(scores)) if scores else 0


def _sector_proxy_score(site: np.ndarray, sector_idx: int, points: np.ndarray, config: Config) -> float:
    pts = np.asarray(points, dtype=float)
    if pts.size == 0:
        return 0.0
    radius = float(config["asuAligned"].get("sector_repair_radius_m", 900.0))
    max_pts = int(config["asuAligned"].get("sector_repair_max_nearby_points", 80))
    d = np.sqrt(np.sum((pts[:, :2] - np.asarray(site[:2], dtype=float)[None, :]) ** 2, axis=1))
    near_idx = np.argsort(d)[:max_pts]
    near_idx = near_idx[d[near_idx] <= radius] if near_idx.size else near_idx
    if near_idx.size == 0:
        near_idx = np.argsort(d)[: min(max_pts, pts.shape[0])]
    near = pts[near_idx]
    az = float(DEFAULT_SECTOR_DIRECTIONS_DEG[int(sector_idx) % len(DEFAULT_SECTOR_DIRECTIONS_DEG)])
    beam = float(config.get("channel", {}).get("sector_beamwidth_deg", 120.0))
    bearings = (np.degrees(np.arctan2(near[:, 0] - site[0], near[:, 1] - site[1])) + 360.0) % 360.0
    delta = np.abs((bearings - az + 180.0) % 360.0 - 180.0)
    inside = delta <= beam / 2.0
    weights = 1.0 / np.maximum(d[near_idx], 50.0)
    snr_proxy = np.clip((radius - d[near_idx]) / max(radius, 1e-9), 0.0, 1.0)
    continuity_proxy = 1.0 / max(float(near.shape[0]), 1.0)
    in_sector_score = np.sum((weights + 0.15 * snr_proxy + continuity_proxy)[inside])
    miss_penalty = 0.20 * float(np.sum(weights[~inside]))
    return float(in_sector_score - miss_penalty)


def _station_type_proxy_score(site: np.ndarray, type_idx: int, sector_idx: int, points: np.ndarray, config: Config, saturated_like: bool) -> float:
    pts = np.asarray(points, dtype=float)
    density = float(_nearby_route_density(site, pts, float(config["asuAligned"].get("station_type_refinement_radius_m", 650.0))))
    if _type_name(config, type_idx).upper() == "5GA":
        sector_score = _sector_proxy_score(site, sector_idx, pts, config)
        capacity_bonus = 0.22 if not saturated_like else 0.15
        cost_penalty = 0.30 if saturated_like else 0.16
        return float(0.12 * density + sector_score + capacity_bonus - cost_penalty)
    return float(0.12 * density + 0.18)


def _nearby_route_density(site: np.ndarray, points: np.ndarray, radius: float) -> int:
    pts = np.asarray(points, dtype=float)
    if pts.size == 0:
        return 0
    d = np.sqrt(np.sum((pts[:, :2] - np.asarray(site[:2], dtype=float)[None, :]) ** 2, axis=1))
    return int(np.sum(d <= float(radius)))


def _farthest_points(points: np.ndarray, count: int, rng: np.random.Generator) -> np.ndarray:
    pts = np.asarray(points, dtype=float)
    if pts.size == 0:
        return np.zeros((0, 3), dtype=float)
    selected = [int(rng.integers(0, pts.shape[0]))]
    while len(selected) < min(count, pts.shape[0]):
        sel = pts[selected, :2]
        d = np.min(np.sqrt(np.sum((pts[:, None, :2] - sel[None, :, :]) ** 2, axis=2)), axis=1)
        selected.append(int(np.argmax(d)))
    return pts[selected, :3]


def _initial_type_index(config: Config, station_idx: int, k: int, rng: np.random.Generator) -> int:
    fiveg = _type_index(config, "5G")
    fivega = _type_index(config, "5GA")
    if fivega == fiveg:
        return fiveg
    target_ratio = 0.40 if k <= 6 else 0.25
    random_ratio = 0.25 if k <= 6 else 0.12
    if station_idx < max(1, int(round(k * target_ratio))):
        return fivega
    return fivega if float(rng.random()) < random_ratio else fiveg


def _station_type_count(config: Config) -> int:
    return max(len(config.get("heterogeneousDeployment", {}).get("stationTypes", [])), 1)


def _type_index(config: Config, station_type: str) -> int:
    target = station_type.strip().lower()
    for idx, item in enumerate(config.get("heterogeneousDeployment", {}).get("stationTypes", [])):
        if str(item.get("name", "")).strip().lower() == target:
            return int(idx)
    return 0


def _type_name(config: Config, type_idx: int) -> str:
    specs = config.get("heterogeneousDeployment", {}).get("stationTypes", [])
    if 0 <= int(type_idx) < len(specs):
        return str(specs[int(type_idx)].get("name", "5G"))
    return "5G"
