from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.baselines.proposed_asu_aligned.adapter import (
    _best_sector_index,
    _initialize_population,
    _repair_particles,
    _station_type_count,
)
from src.data.types import Config
from src.experiments.airway_service_utility import ASU_SCORE_KEY, build_asu_record, materialize_asu_config
from src.experiments.evaluation_consistency import evaluate_with_existing_context
from src.experiments.multiobjective_metrics import hypervolume_minimization, nondominated_mask
from src.propagation.sector_geometry import DEFAULT_SECTOR_DIRECTIONS_DEG


@dataclass
class _EvalPack:
    objectives: np.ndarray
    asu_values: np.ndarray
    metrics: List[Dict[str, float]]
    feasible: np.ndarray


@dataclass
class _StagnationState:
    initial_qe: Optional[float] = None
    initial_velocity_norm: Optional[float] = None
    score_window: List[float] = None
    last_response_iter: int = -10_000
    hv_history: List[float] = None
    nd_history: List[int] = None
    spread_history: List[float] = None
    entropy_history: List[float] = None

    def __post_init__(self) -> None:
        self.score_window = [] if self.score_window is None else self.score_window
        self.hv_history = [] if self.hv_history is None else self.hv_history
        self.nd_history = [] if self.nd_history is None else self.nd_history
        self.spread_history = [] if self.spread_history is None else self.spread_history
        self.entropy_history = [] if self.entropy_history is None else self.entropy_history


class ProposedQECorrectedAdapter(BaselineAdapter):
    """QE-corrected stagnation-response diagnostic kept separate from legacy proposed_method."""

    method_key = "proposed_method_qe_corrected"
    display_name = "Proposed Method QE Corrected"
    group = "proposed_qe_corrected"
    implemented = True
    response_enabled_default = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        cfg = _method_config(config, self.method_key, response_enabled=self.response_enabled_default)
        config.clear()
        config.update(json.loads(json.dumps(cfg)))

        rng = np.random.default_rng(int(seed))
        t0 = time.time()
        pso = cfg.get("pso", {})
        pop_size = int(pso.get("numParticles", 160))
        max_iter = int(pso.get("maxIterations", 320))
        k = int(pso.get("numBaseStations", cfg.get("stage1", {}).get("numNewStations", 1)))
        archive_size = int(cfg.get("mopso", {}).get("archiveSize", 80))
        min_pos = np.asarray(pso.get("minPosition", [0.0, 0.0, 20.0]), dtype=float)
        max_pos = np.asarray(pso.get("maxPosition", [problem.city_map.size_x, problem.city_map.size_y, 160.0]), dtype=float)

        logs: Dict[str, Any] = {
            "method_key": self.method_key,
            "legacy_proposed_preserved": True,
            "qe_corrected_stagnation_enabled": True,
            "response_enabled": bool(cfg["qeCorrectedStagnation"].get("response_enabled", True)),
            "qe_input_semantics": "positive lower-is-better U_i_loss; ASU is not used",
            "qe_beta": float(cfg["qeCorrectedStagnation"].get("beta", 1.0 / 3.0)),
            "qe_theta": float(cfg["qeCorrectedStagnation"].get("theta", 0.95)),
            "stagnation_score_trace": [],
            "response_action_log": [],
            "response_target_particles": [],
            "protected_archive_log": [],
            "sparse_cell_injection_log": [],
            "leader_selection_summary": [],
            "stage1_seed_summary": [],
        }

        particles, stage1_summary = _initialize_population(problem, cfg, rng, pop_size, k, min_pos, max_pos)
        logs["stage1_seed_summary"].extend(stage1_summary)
        velocities = (rng.random((pop_size, k, 3)) - 0.5) * (max_pos[:3] - min_pos[:3])[None, None, :] * 0.08

        pbest = particles.copy()
        pbest_eval = _evaluate_particles(pbest, problem, cfg, self.method_key)
        archive_p, archive_o, archive_asu, archive_metrics = _truncate_archive(
            pbest, pbest_eval.objectives, pbest_eval.asu_values, pbest_eval.metrics, archive_size
        )
        state = _StagnationState()
        trigger_count = 0
        response_action_count = 0
        cumulative_population_movement = 0.0

        for iteration in range(1, max_iter + 1):
            previous_particles = particles.copy()
            previous_archive_p = archive_p.copy()
            previous_archive_o = archive_o.copy()
            leaders, leader_log = _select_leaders(archive_p, archive_o, pop_size, rng)
            leader_log["iteration"] = int(iteration)
            logs["leader_selection_summary"].append(leader_log)

            r1 = rng.random((pop_size, k, 3))
            r2 = rng.random((pop_size, k, 3))
            w = float(pso.get("w", 0.729)) * (0.996 ** (iteration - 1))
            c1 = float(pso.get("c1", 1.49445))
            c2 = float(pso.get("c2", 1.49445))
            velocities = w * velocities + c1 * r1 * (pbest[:, :, :3] - particles[:, :, :3]) + c2 * r2 * (leaders[:, :, :3] - particles[:, :, :3])
            vel_lim = (max_pos[:3] - min_pos[:3]) * float(cfg.get("mopso", {}).get("velocityLimitRatio", 0.2))
            velocities = np.clip(velocities, -vel_lim[None, None, :], vel_lim[None, None, :])
            particles[:, :, :3] = np.clip(particles[:, :, :3] + velocities, min_pos[:3][None, None, :], max_pos[:3][None, None, :])

            type_copy = rng.random((pop_size, k)) < 0.22
            sector_copy = rng.random((pop_size, k)) < 0.28
            particles[:, :, 3] = np.where(type_copy, leaders[:, :, 3], particles[:, :, 3])
            particles[:, :, 4] = np.where(sector_copy, leaders[:, :, 4], particles[:, :, 4])
            type_mut = rng.random((pop_size, k)) < 0.035
            sector_mut = rng.random((pop_size, k)) < 0.07
            particles[:, :, 3] = np.where(type_mut, rng.integers(0, _station_type_count(cfg), size=(pop_size, k)), particles[:, :, 3])
            particles[:, :, 4] = np.where(sector_mut, rng.integers(0, len(DEFAULT_SECTOR_DIRECTIONS_DEG), size=(pop_size, k)), particles[:, :, 4])
            particles = _repair_particles(particles, problem, cfg, rng, min_pos, max_pos)

            curr_eval = _evaluate_particles(particles, problem, cfg, self.method_key)
            improve = _better_for_personal_best(curr_eval.objectives, pbest_eval.objectives)
            pbest_update_rate = float(np.mean(improve.astype(float))) if improve.size else 0.0
            if np.any(improve):
                pbest[improve] = particles[improve]
                pbest_eval.objectives[improve] = curr_eval.objectives[improve]
                pbest_eval.asu_values[improve] = curr_eval.asu_values[improve]
                for idx in np.where(improve)[0].tolist():
                    pbest_eval.metrics[idx] = curr_eval.metrics[idx]
                    pbest_eval.feasible[idx] = curr_eval.feasible[idx]

            merged_p = np.concatenate([archive_p, particles, pbest], axis=0) if archive_p.size else np.concatenate([particles, pbest], axis=0)
            merged_o = np.vstack([archive_o, curr_eval.objectives, pbest_eval.objectives]) if archive_o.size else np.vstack([curr_eval.objectives, pbest_eval.objectives])
            merged_asu = np.concatenate([archive_asu, curr_eval.asu_values, pbest_eval.asu_values]) if archive_asu.size else np.concatenate([curr_eval.asu_values, pbest_eval.asu_values])
            merged_metrics = list(archive_metrics) + list(curr_eval.metrics) + list(pbest_eval.metrics)
            archive_p, archive_o, archive_asu, archive_metrics = _truncate_archive(merged_p, merged_o, merged_asu, merged_metrics, archive_size)

            score_info = _compute_multifactor_score(
                iteration=iteration,
                archive_o=archive_o,
                pbest_metrics=pbest_eval.metrics,
                velocity_norm=float(np.linalg.norm(velocities)),
                pbest_update_rate=pbest_update_rate,
                cfg=cfg,
                state=state,
            )
            level = _trigger_level(score_info, cfg, state, iteration)
            response_log: Dict[str, Any] = {"iteration": int(iteration), "trigger_level": level, "response_action": "none"}
            if level != "none":
                trigger_count += 1
                if bool(cfg["qeCorrectedStagnation"].get("response_enabled", True)):
                    particles, velocities, response_log = _apply_pareto_preserving_response(
                        particles=particles,
                        velocities=velocities,
                        curr_objectives=curr_eval.objectives,
                        archive_particles=archive_p,
                        archive_objectives=archive_o,
                        problem=problem,
                        cfg=cfg,
                        rng=rng,
                        min_pos=min_pos,
                        max_pos=max_pos,
                        iteration=iteration,
                        level=level,
                    )
                    response_action_count += int(response_log.get("target_particle_count", 0))
                    state.last_response_iter = int(iteration)
                    logs["response_action_log"].append(response_log)
                    logs["response_target_particles"].extend(response_log.get("target_particles", []))
                    logs["protected_archive_log"].append(response_log.get("protected_archive", {}))
                    logs["sparse_cell_injection_log"].extend(response_log.get("sparse_cell_injections", []))
                else:
                    response_log["response_action"] = "disabled"
                    logs["response_action_log"].append(response_log)

            score_row = dict(score_info)
            movement = _mean_population_movement(previous_particles, particles, min_pos, max_pos)
            cumulative_population_movement += movement
            decision_coverage = _decision_space_coverage(particles, min_pos, max_pos)
            archive_growth = int(archive_o.shape[0] - previous_archive_o.shape[0])
            score_row.update(
                {
                    "iteration": int(iteration),
                    "trigger_level": level,
                    "trigger_flag": bool(level != "none"),
                    "response_action": response_log.get("response_action", "none"),
                    "archive_size": int(archive_o.shape[0]),
                    "nondominated_count": int(archive_o.shape[0]),
                    "pbest_update_rate": float(pbest_update_rate),
                    "velocity_norm": float(np.linalg.norm(velocities)),
                    "leader_diversity": float(leader_log.get("leader_diversity", 0.0)),
                    "mean_population_movement_distance": float(movement),
                    "cumulative_population_movement_distance": float(cumulative_population_movement),
                    "decision_space_coverage_ratio": float(decision_coverage["coverage_ratio"]),
                    "occupied_decision_cells": int(decision_coverage["occupied_cells"]),
                    "mean_decision_archive_novelty": float(_archive_novelty(archive_p, previous_archive_p, min_pos, max_pos)),
                    "mean_objective_archive_novelty": float(_objective_archive_novelty(archive_o, previous_archive_o)),
                    "archive_growth": int(archive_growth),
                }
            )
            logs["stagnation_score_trace"].append(score_row)

        final_eval = _evaluate_particles(archive_p, problem, cfg, self.method_key) if archive_p.size else pbest_eval
        final_p = archive_p if archive_p.size else pbest
        final_o = final_eval.objectives
        nd = nondominated_mask(final_o) if final_o.size else np.zeros((0,), dtype=bool)
        if not np.any(nd) and final_o.shape[0] > 0:
            nd[0] = True

        logs["trigger_count"] = int(trigger_count)
        logs["response_action_count"] = int(response_action_count)
        logs["final_archive_size"] = int(final_p[nd].shape[0])
        logs["best_archive_asu"] = float(np.max(final_eval.asu_values[nd])) if np.any(nd) else float("nan")
        logs["sector_direction_set_valid"] = bool(_sector_values_valid(final_p[nd]))
        logs["implementation_revision"] = "qe_corrected_v2"

        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=np.asarray(final_o, dtype=float),
            decision_variables=np.asarray(final_p, dtype=float),
            nondominated_objectives=np.asarray(final_o[nd], dtype=float),
            nondominated_decisions=np.asarray(final_p[nd], dtype=float),
            runtime_seconds=float(time.time() - t0),
            feasible_mask=np.asarray(final_eval.feasible, dtype=bool),
            nondominated_feasible_mask=np.asarray(final_eval.feasible[nd], dtype=bool) if np.any(nd) else np.zeros((0,), dtype=bool),
            logs=logs,
        )


class ProposedQECorrectedResponseDisabledAdapter(ProposedQECorrectedAdapter):
    """Response-disabled ablation for the QE-corrected detector."""

    method_key = "proposed_method_qe_corrected_response_disabled"
    display_name = "Proposed QE Corrected Response Disabled"
    group = "proposed_qe_corrected_ablation"
    response_enabled_default = False


def _method_config(config: Config, method_key: str, response_enabled: bool) -> Config:
    cfg = json.loads(json.dumps(config))
    materialize_asu_config(cfg)
    cfg.setdefault("experiment", {})["method"] = method_key
    cfg["experiment"]["legacy_proposed_method_preserved_as"] = "proposed_method"
    cfg.setdefault("particleEncoding", {})["optimizeStationType"] = True
    cfg["particleEncoding"]["optimizeSectorDirection"] = True
    cfg.setdefault("channel", {})["sector_directions_deg"] = [float(v) for v in DEFAULT_SECTOR_DIRECTIONS_DEG]
    cfg.setdefault("asuAligned", {})
    cfg["asuAligned"].setdefault("stage1_ratio", 0.5)
    cfg["asuAligned"].setdefault("stage1_cap", 6)
    cfg["asuAligned"].setdefault("sector_repair_radius_m", 900.0)
    cfg["asuAligned"].setdefault("sector_repair_max_nearby_points", 80)
    qe_cfg = cfg.setdefault("qeCorrectedStagnation", {})
    defaults = {
        "response_enabled": bool(response_enabled),
        "theta": 0.95,
        "theta_reference_levels": [0.98, 0.95, 0.93],
        "beta": 1.0 / 3.0,
        "lossWeights": {"cost": 0.20, "handover": 0.15, "current": 0.25, "future": 0.25, "hole": 0.15},
        "stagnationWindow": 8,
        "stagnationThresholdMild": 0.98,
        "stagnationThresholdModerate": 0.95,
        "stagnationThresholdSevere": 0.93,
        "minIterationsBeforeResponse": 30,
        "responseCooldown": 20,
        "hvProxyEnabled": True,
        "archiveEntropyEnabled": True,
        "responseMode": "pareto_preserving_response",
        "responseFractions": {"mild": 0.10, "moderate": 0.20, "severe": 0.35},
        "hvStallEpsilon": 0.003,
        "spreadStallEpsilon": 0.003,
        "ndGrowthReference": 0.08,
        "pbestUpdateReference": 0.08,
        "leaderEntropyReference": 0.55,
        "restartNoiseRatio": 0.06,
        "lossEpsilon": 1e-9,
    }
    for key, value in defaults.items():
        qe_cfg.setdefault(key, value)
    return cfg


def _evaluate_particles(particles: np.ndarray, problem: DeploymentProblem, config: Config, method_key: str) -> _EvalPack:
    eval_info = evaluate_with_existing_context(
        decisions=np.asarray(particles, dtype=float),
        problem=problem,
        config=config,
        method_name=method_key,
    )
    metrics = [dict(row) for row in eval_info.metrics]
    asu_records = [
        build_asu_record(row, config, seed=0, method_name=method_key, group="qe_corrected_internal", solution_id=i + 1, source="internal_eval")
        for i, row in enumerate(metrics)
    ]
    asu_values = np.asarray([float(row.get(ASU_SCORE_KEY, 0.0)) for row in asu_records], dtype=float)
    objectives = _legacy_fair_objectives(metrics)
    tol = float(config.get("nsga2", {}).get("feasiblePenaltyTol", 1e-9))
    feasible = np.asarray([float(row.get("constraint_penalty", 0.0)) <= tol for row in metrics], dtype=bool)
    return _EvalPack(objectives=objectives, asu_values=asu_values, metrics=metrics, feasible=feasible)


def _legacy_fair_objectives(metrics: Sequence[Dict[str, float]]) -> np.ndarray:
    rows: List[List[float]] = []
    for row in metrics:
        current = float(row.get("existing_route_continuous_coverage_rate", row.get("current_priority_route_continuity", row.get("coverage_rate", 0.0))))
        future = float(row.get("future_route_continuous_coverage_rate", row.get("future_priority_route_continuity", row.get("coverage_rate", 0.0))))
        rows.append(
            [
                float(row.get("handover_count", 0.0)),
                float(row.get("deployment_cost", 0.0)),
                1.0 - current,
                1.0 - future,
            ]
        )
    return np.asarray(rows, dtype=float)


def _truncate_archive(
    particles: np.ndarray,
    objectives: np.ndarray,
    asu_values: np.ndarray,
    metrics: Sequence[Dict[str, float]],
    archive_size: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, List[Dict[str, float]]]:
    if particles.size == 0:
        return particles, objectives, asu_values, []
    nd = nondominated_mask(objectives)
    p = particles[nd]
    o = objectives[nd]
    a = asu_values[nd]
    m = [dict(metrics[i]) for i in np.where(nd)[0].tolist()]
    if p.shape[0] <= archive_size:
        return p, o, a, m
    crowd = _crowding_distance(o)
    finite = np.isfinite(crowd)
    score = crowd.copy()
    if np.any(finite):
        score[finite] = score[finite] / max(float(np.max(score[finite])), 1e-9)
    keep = np.argsort(-score, kind="stable")[:archive_size]
    return p[keep], o[keep], a[keep], [m[i] for i in keep.tolist()]


def _crowding_distance(objectives: np.ndarray) -> np.ndarray:
    arr = np.asarray(objectives, dtype=float)
    n = arr.shape[0]
    if n == 0:
        return np.zeros((0,), dtype=float)
    dist = np.zeros((n,), dtype=float)
    for j in range(arr.shape[1]):
        order = np.argsort(arr[:, j], kind="stable")
        dist[order[0]] = np.inf
        dist[order[-1]] = np.inf
        span = float(arr[order[-1], j] - arr[order[0], j])
        if span <= 1e-12:
            continue
        for pos in range(1, n - 1):
            dist[order[pos]] += float(arr[order[pos + 1], j] - arr[order[pos - 1], j]) / span
    return dist


def _select_leaders(archive_particles: np.ndarray, archive_objectives: np.ndarray, pop_size: int, rng: np.random.Generator) -> Tuple[np.ndarray, Dict[str, Any]]:
    if archive_particles.size == 0:
        raise ValueError("archive must be non-empty before leader selection")
    crowd = _crowding_distance(archive_objectives)
    finite = np.where(np.isfinite(crowd), crowd, np.nanmax(crowd[np.isfinite(crowd)]) if np.any(np.isfinite(crowd)) else 1.0)
    weights = finite - float(np.min(finite)) + 1e-6
    weights = weights / float(np.sum(weights)) if float(np.sum(weights)) > 0 else np.ones_like(weights) / len(weights)
    idx = rng.choice(np.arange(archive_particles.shape[0]), size=pop_size, replace=True, p=weights)
    leaders = archive_particles[idx]
    return leaders, {
        "archive_size": int(archive_particles.shape[0]),
        "leader_diversity": float(_objective_entropy(archive_objectives)),
        "selection_policy": "crowding_diversity_weighted",
    }


def _better_for_personal_best(curr_obj: np.ndarray, best_obj: np.ndarray) -> np.ndarray:
    curr_dom = np.all(curr_obj <= best_obj, axis=1) & np.any(curr_obj < best_obj, axis=1)
    best_dom = np.all(best_obj <= curr_obj, axis=1) & np.any(best_obj < curr_obj, axis=1)
    score_curr = _composite_min_scores(curr_obj)
    score_best = _composite_min_scores(best_obj)
    return curr_dom | (~best_dom & (score_curr < score_best - 1e-9))


def _composite_min_scores(objectives: np.ndarray) -> np.ndarray:
    arr = np.asarray(objectives, dtype=float)
    if arr.size == 0:
        return np.zeros((0,), dtype=float)
    lo = np.min(arr, axis=0)
    span = np.maximum(np.max(arr, axis=0) - lo, 1e-9)
    return np.mean((arr - lo[None, :]) / span[None, :], axis=1)


def _compute_multifactor_score(
    *,
    iteration: int,
    archive_o: np.ndarray,
    pbest_metrics: Sequence[Dict[str, float]],
    velocity_norm: float,
    pbest_update_rate: float,
    cfg: Config,
    state: _StagnationState,
) -> Dict[str, float]:
    qe_cfg = cfg["qeCorrectedStagnation"]
    losses = _qe_loss_values(pbest_metrics, qe_cfg)
    qe, qe_details = _qe_loss_entropy(losses, qe_cfg)
    if state.initial_qe is None:
        state.initial_qe = max(qe, 1e-12)
    if state.initial_velocity_norm is None:
        state.initial_velocity_norm = max(float(velocity_norm), 1e-12)
    qe_ratio = float(qe / max(state.initial_qe, 1e-12))
    theta = float(qe_cfg.get("theta", 0.95))
    # A lower QE_loss_ratio is stronger stagnation evidence in the CLPSO-LS
    # minimization convention; it is not an ASU or HV/GD/IGD quantity.
    s_qe = 1.0 if qe_ratio <= theta else 0.0

    hv_proxy = _hv_proxy(archive_o) if bool(qe_cfg.get("hvProxyEnabled", True)) else 0.0
    nd_count = int(archive_o.shape[0])
    spread = _objective_spread(archive_o)
    entropy = _objective_entropy(archive_o) if bool(qe_cfg.get("archiveEntropyEnabled", True)) else spread
    state.hv_history.append(float(hv_proxy))
    state.nd_history.append(nd_count)
    state.spread_history.append(float(spread))
    state.entropy_history.append(float(entropy))
    window = int(qe_cfg.get("stagnationWindow", 8))

    hv_gain = _window_gain(state.hv_history, window)
    nd_gain = float(max(state.nd_history[-1] - state.nd_history[-window], 0)) / max(float(qe_cfg.get("ndGrowthReference", 0.08)) * max(nd_count, 1), 1.0) if len(state.nd_history) > window else 1.0
    spread_gain = _window_gain(state.spread_history, window)

    s_hv = 1.0 - float(np.clip(hv_gain / max(float(qe_cfg.get("hvStallEpsilon", 0.003)), 1e-12), 0.0, 1.0))
    s_nd = 1.0 - float(np.clip(nd_gain, 0.0, 1.0))
    s_spread = 1.0 - float(np.clip(spread_gain / max(float(qe_cfg.get("spreadStallEpsilon", 0.003)), 1e-12), 0.0, 1.0))
    s_pbest = 1.0 - float(np.clip(pbest_update_rate / max(float(qe_cfg.get("pbestUpdateReference", 0.08)), 1e-12), 0.0, 1.0))
    s_velocity = 1.0 - float(np.clip(velocity_norm / max(float(state.initial_velocity_norm), 1e-12), 0.0, 1.0))
    s_leader = 1.0 - float(np.clip(entropy / max(float(qe_cfg.get("leaderEntropyReference", 0.55)), 1e-12), 0.0, 1.0))

    weights = {"qe": 1.0}
    comps = {
        "qe": s_qe,
    }
    total_w = max(float(sum(float(weights.get(k, 0.0)) for k in comps)), 1e-12)
    s_total = float(sum(float(weights.get(k, 0.0)) * v for k, v in comps.items()) / total_w)
    state.score_window.append(s_total)
    return {
        "S_total": s_total,
        "S_qe": s_qe,
        "S_hv": s_hv,
        "S_nd": s_nd,
        "S_spread": s_spread,
        "S_pbest": s_pbest,
        "S_velocity": s_velocity,
        "S_leader": s_leader,
        "QE_loss": float(qe),
        "QE_loss_ratio": qe_ratio,
        "QE_ratio": qe_ratio,
        "QE_loss_theta_0_98_crossed": bool(qe_ratio <= 0.98),
        "QE_loss_theta_0_95_crossed": bool(qe_ratio <= 0.95),
        "QE_loss_theta_0_93_crossed": bool(qe_ratio <= 0.93),
        "QE_loss_min_selected": float(qe_details.get("min_selected_loss", 0.0)),
        "QE_loss_q25_selected": float(qe_details.get("q25_selected_loss", 0.0)),
        "QE_loss_median_selected": float(qe_details.get("median_selected_loss", 0.0)),
        "QE_loss_q75_selected": float(qe_details.get("q75_selected_loss", 0.0)),
        "QE_loss_max_selected": float(qe_details.get("max_selected_loss", 0.0)),
        "QE_loss_mean_selected": float(qe_details.get("mean_selected_loss", 0.0)),
        "QE_loss_top_beta_count": int(qe_details.get("top_beta_count", 0)),
        "QE_loss_selected_particle_ids": ",".join(str(i) for i in qe_details.get("selected_indices", [])),
        "HV_proxy": float(hv_proxy),
        "archive_spread": float(spread),
        "archive_entropy": float(entropy),
    }


def _trigger_level(score_info: Dict[str, float], cfg: Config, state: _StagnationState, iteration: int) -> str:
    qe_cfg = cfg["qeCorrectedStagnation"]
    if iteration < int(qe_cfg.get("minIterationsBeforeResponse", 30)):
        return "none"
    if iteration - state.last_response_iter < int(qe_cfg.get("responseCooldown", 20)):
        return "none"
    window = int(qe_cfg.get("stagnationWindow", 8))
    if len(state.score_window) < window:
        return "none"
    recent = state.score_window[-window:]
    min_recent = float(min(recent))
    if min_recent >= 1.0 and float(score_info.get("QE_loss_ratio", 1.0)) <= float(qe_cfg.get("stagnationThresholdSevere", 0.93)):
        return "severe"
    if min_recent >= 1.0 and float(score_info.get("QE_loss_ratio", 1.0)) <= float(qe_cfg.get("stagnationThresholdModerate", 0.95)):
        return "moderate"
    if min_recent >= 1.0 and float(score_info.get("QE_loss_ratio", 1.0)) <= float(qe_cfg.get("stagnationThresholdMild", 0.98)):
        return "mild"
    return "none"


def _apply_pareto_preserving_response(
    *,
    particles: np.ndarray,
    velocities: np.ndarray,
    curr_objectives: np.ndarray,
    archive_particles: np.ndarray,
    archive_objectives: np.ndarray,
    problem: DeploymentProblem,
    cfg: Config,
    rng: np.random.Generator,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    iteration: int,
    level: str,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    out = np.asarray(particles, dtype=float).copy()
    vel = np.asarray(velocities, dtype=float).copy()
    qe_cfg = cfg["qeCorrectedStagnation"]
    frac = float(qe_cfg.get("responseFractions", {}).get(level, 0.10))
    pop_size = out.shape[0]
    dominated = ~nondominated_mask(curr_objectives)
    candidates = np.where(dominated)[0]
    if candidates.size == 0:
        score = _composite_min_scores(curr_objectives)
        candidates = np.argsort(-score, kind="stable")[: max(1, int(np.ceil(pop_size * frac)))]
    target_count = max(1, min(int(np.ceil(pop_size * frac)), candidates.size))
    targets = rng.choice(candidates, size=target_count, replace=False)
    sparse = _sparse_archive_indices(archive_objectives, max(target_count, 1))
    protected = _protected_archive_summary(archive_objectives)
    route_pts = np.asarray(problem.test_points, dtype=float)
    noise_ratio = float(qe_cfg.get("restartNoiseRatio", 0.06))
    span = max_pos[:3] - min_pos[:3]
    injections: List[Dict[str, Any]] = []
    for j, idx in enumerate(targets.tolist()):
        if archive_particles.size and sparse:
            base = archive_particles[sparse[j % len(sparse)]].copy()
        else:
            base = out[idx].copy()
        if route_pts.size and float(rng.random()) < 0.35:
            anchor = route_pts[int(rng.integers(0, route_pts.shape[0]))]
            station_idx = int(rng.integers(0, out.shape[1]))
            base[station_idx, :2] = anchor[:2] + rng.normal(0.0, 350.0, size=2)
            base[station_idx, 2] = anchor[2]
            base[station_idx, 4] = float(_best_sector_index(base[station_idx, :3], route_pts, cfg))
        base[:, :3] += rng.normal(0.0, noise_ratio, size=base[:, :3].shape) * span[None, :]
        out[idx] = base
        vel[idx] *= 0.35
        injections.append({"iteration": int(iteration), "particle_index": int(idx), "archive_source_index": int(sparse[j % len(sparse)]) if sparse else -1})
    out = _repair_particles(out, problem, cfg, rng, min_pos, max_pos)
    return out, vel, {
        "iteration": int(iteration),
        "trigger_level": level,
        "response_action": "pareto_preserving_response",
        "target_particle_count": int(target_count),
        "target_particles": [{"iteration": int(iteration), "particle_index": int(i), "reason": "dominated_or_low_contribution"} for i in targets.tolist()],
        "protected_archive": protected,
        "sparse_cell_injections": injections,
    }


def _qe_loss_values(metrics: Sequence[Dict[str, float]], qe_cfg: Config) -> np.ndarray:
    rows = [dict(row) for row in metrics]
    if not rows:
        return np.zeros((0,), dtype=float)
    cost = np.asarray([float(row.get("deployment_cost", 0.0)) for row in rows], dtype=float)
    handover = np.asarray([float(row.get("handover_count", 0.0)) for row in rows], dtype=float)
    current = np.asarray(
        [
            1.0
            - float(
                row.get(
                    "existing_route_continuous_coverage_rate",
                    row.get("current_priority_route_continuity", row.get("coverage_rate", 0.0)),
                )
            )
            for row in rows
        ],
        dtype=float,
    )
    future = np.asarray(
        [
            1.0
            - float(
                row.get(
                    "future_route_continuous_coverage_rate",
                    row.get("future_priority_route_continuity", row.get("coverage_rate", 0.0)),
                )
            )
            for row in rows
        ],
        dtype=float,
    )
    hole = np.asarray([float(row.get("coverage_hole_rate", 1.0 - float(row.get("coverage_rate", 0.0)))) for row in rows], dtype=float)
    penalty = np.asarray([float(row.get("constraint_penalty", 0.0)) for row in rows], dtype=float)
    weights = dict(qe_cfg.get("lossWeights", {}))
    eps = float(qe_cfg.get("lossEpsilon", 1e-9))
    loss = (
        float(weights.get("cost", 0.20)) * _minmax(cost)
        + float(weights.get("handover", 0.15)) * _minmax(handover)
        + float(weights.get("current", 0.25)) * np.clip(current, 0.0, 1.0)
        + float(weights.get("future", 0.25)) * np.clip(future, 0.0, 1.0)
        + float(weights.get("hole", 0.15)) * np.clip(hole, 0.0, 1.0)
        + _minmax(penalty)
    )
    return np.maximum(loss + eps, eps)


def _minmax(values: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    if arr.size == 0:
        return np.zeros((0,), dtype=float)
    lo = float(np.min(arr))
    span = max(float(np.max(arr) - lo), 1e-9)
    return (arr - lo) / span


def _qe_loss_entropy(loss_values: np.ndarray, qe_cfg: Config) -> Tuple[float, Dict[str, Any]]:
    arr = np.asarray(loss_values, dtype=float)
    if arr.size == 0:
        return 0.0, {"top_beta_count": 0, "selected_indices": []}
    eps = float(qe_cfg.get("lossEpsilon", 1e-9))
    beta = float(qe_cfg.get("beta", 1.0 / 3.0))
    n_top = max(1, int(np.ceil(arr.size * beta)))
    selected = np.argsort(arr, kind="stable")[:n_top]
    selected_losses = np.maximum(arr[selected], eps)
    prob = selected_losses / max(float(np.sum(selected_losses)), eps)
    qe = float(-np.sum(prob * np.log(prob + eps)))
    return qe, {
        "top_beta_count": int(n_top),
        "selected_indices": [int(i) for i in selected.tolist()],
        "min_selected_loss": float(np.min(selected_losses)),
        "q25_selected_loss": float(np.quantile(selected_losses, 0.25)),
        "median_selected_loss": float(np.median(selected_losses)),
        "q75_selected_loss": float(np.quantile(selected_losses, 0.75)),
        "max_selected_loss": float(np.max(selected_losses)),
        "mean_selected_loss": float(np.mean(selected_losses)),
    }


def _hv_proxy(objectives: np.ndarray) -> float:
    arr = np.asarray(objectives, dtype=float)
    if arr.size == 0:
        return 0.0
    nd = arr[nondominated_mask(arr)]
    lo = np.min(nd, axis=0)
    span = np.maximum(np.max(nd, axis=0) - lo, 1e-9)
    norm = (nd - lo[None, :]) / span[None, :]
    hv, _ = hypervolume_minimization(norm, np.ones(norm.shape[1], dtype=float) * 1.05, max_exact_points=12, num_samples=2048, seed=2026)
    return float(hv)


def _objective_spread(objectives: np.ndarray) -> float:
    arr = np.asarray(objectives, dtype=float)
    if arr.size == 0:
        return 0.0
    lo = np.min(arr, axis=0)
    span = np.maximum(np.max(arr, axis=0) - lo, 0.0)
    denom = np.maximum(np.abs(lo), 1.0)
    return float(np.mean(span / denom))


def _objective_entropy(objectives: np.ndarray, bins: int = 4) -> float:
    arr = np.asarray(objectives, dtype=float)
    if arr.size == 0 or arr.shape[0] < 2:
        return 0.0
    lo = np.min(arr, axis=0)
    span = np.maximum(np.max(arr, axis=0) - lo, 1e-9)
    norm = np.clip((arr - lo[None, :]) / span[None, :], 0.0, 0.999999)
    cells = np.floor(norm * bins).astype(int)
    keys, counts = np.unique(cells, axis=0, return_counts=True)
    prob = counts.astype(float) / float(np.sum(counts))
    entropy = -float(np.sum(prob * np.log(prob + 1e-12)))
    max_entropy = np.log(max(min(bins ** arr.shape[1], arr.shape[0]), 1))
    return float(entropy / max(max_entropy, 1e-12))


def _window_gain(values: Sequence[float], window: int) -> float:
    if len(values) <= window:
        return 1.0
    return max(float(values[-1]) - float(values[-window]), 0.0)


def _normalize_decisions(decisions: np.ndarray, min_pos: np.ndarray, max_pos: np.ndarray) -> np.ndarray:
    arr = np.asarray(decisions, dtype=float)
    if arr.size == 0:
        return np.zeros((0, 0), dtype=float)
    span = np.maximum(max_pos[:3] - min_pos[:3], 1e-9)
    norm = arr.copy()
    norm[:, :, :3] = (norm[:, :, :3] - min_pos[:3][None, None, :]) / span[None, None, :]
    norm[:, :, 3] = norm[:, :, 3] / max(float(_station_type_count_from_decisions(arr) - 1), 1.0)
    norm[:, :, 4] = norm[:, :, 4] / max(float(len(DEFAULT_SECTOR_DIRECTIONS_DEG) - 1), 1.0)
    return np.clip(norm, 0.0, 1.0).reshape(arr.shape[0], -1)


def _station_type_count_from_decisions(decisions: np.ndarray) -> int:
    arr = np.asarray(decisions, dtype=float)
    if arr.size == 0:
        return 2
    return max(2, int(np.max(arr[:, :, 3])) + 1)


def _mean_population_movement(before: np.ndarray, after: np.ndarray, min_pos: np.ndarray, max_pos: np.ndarray) -> float:
    a = _normalize_decisions(before, min_pos, max_pos)
    b = _normalize_decisions(after, min_pos, max_pos)
    if a.size == 0 or b.size == 0:
        return 0.0
    return float(np.mean(np.linalg.norm(b - a, axis=1)))


def _decision_space_coverage(decisions: np.ndarray, min_pos: np.ndarray, max_pos: np.ndarray, bins: int = 4) -> Dict[str, float]:
    norm = _normalize_decisions(decisions, min_pos, max_pos)
    if norm.size == 0:
        return {"occupied_cells": 0, "coverage_ratio": 0.0}
    station_features = norm.reshape(-1, 5)
    cells = np.floor(np.clip(station_features, 0.0, 0.999999) * bins).astype(int)
    occupied = int(np.unique(cells, axis=0).shape[0])
    return {"occupied_cells": occupied, "coverage_ratio": float(occupied / max(bins ** 5, 1))}


def _archive_novelty(current: np.ndarray, previous: np.ndarray, min_pos: np.ndarray, max_pos: np.ndarray) -> float:
    cur = _normalize_decisions(current, min_pos, max_pos)
    prev = _normalize_decisions(previous, min_pos, max_pos)
    if cur.size == 0 or prev.size == 0:
        return 0.0
    return float(np.mean(np.min(np.linalg.norm(cur[:, None, :] - prev[None, :, :], axis=2), axis=1)))


def _objective_archive_novelty(current: np.ndarray, previous: np.ndarray) -> float:
    cur = np.asarray(current, dtype=float)
    prev = np.asarray(previous, dtype=float)
    if cur.size == 0 or prev.size == 0:
        return 0.0
    merged = np.vstack([cur, prev])
    lo = np.min(merged, axis=0)
    span = np.maximum(np.max(merged, axis=0) - lo, 1e-9)
    cur_norm = (cur - lo[None, :]) / span[None, :]
    prev_norm = (prev - lo[None, :]) / span[None, :]
    return float(np.mean(np.min(np.linalg.norm(cur_norm[:, None, :] - prev_norm[None, :, :], axis=2), axis=1)))


def _sparse_archive_indices(objectives: np.ndarray, count: int) -> List[int]:
    arr = np.asarray(objectives, dtype=float)
    if arr.size == 0:
        return []
    crowd = _crowding_distance(arr)
    order = np.argsort(-crowd, kind="stable")
    return [int(i) for i in order[: max(1, min(count, len(order)))].tolist()]


def _protected_archive_summary(objectives: np.ndarray) -> Dict[str, Any]:
    arr = np.asarray(objectives, dtype=float)
    if arr.size == 0:
        return {"protected_count": 0}
    crowd = _crowding_distance(arr)
    protected = np.argsort(-crowd, kind="stable")[: min(10, arr.shape[0])]
    return {
        "protected_count": int(protected.size),
        "policy": "nondominated_archive_elites_not_perturbed; high-crowding members marked protected",
        "protected_indices": [int(i) for i in protected.tolist()],
    }


def _sector_values_valid(decisions: np.ndarray) -> bool:
    arr = np.asarray(decisions, dtype=float)
    if arr.size == 0 or arr.shape[-1] < 5:
        return True
    vals = set(int(round(v)) for v in arr[:, :, 4].reshape(-1).tolist())
    return vals.issubset(set(range(len(DEFAULT_SECTOR_DIRECTIONS_DEG))))
