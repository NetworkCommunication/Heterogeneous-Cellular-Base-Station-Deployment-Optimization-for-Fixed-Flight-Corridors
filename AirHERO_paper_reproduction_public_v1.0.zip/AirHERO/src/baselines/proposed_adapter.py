from __future__ import annotations

import time
from typing import Any, Dict

import numpy as np

from src.algorithms.improved_mopso import run_mopso_optimize
from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.data.types import Config


class ProposedMethodAdapter(BaselineAdapter):
    """Adapter around the frozen proposed MOPSO implementation."""

    method_key = "proposed_method"
    display_name = "Proposed Method"
    group = "proposed"
    implemented = True

    def run(self, problem: DeploymentProblem, seed: int, config: Config) -> BaselineResult:
        rng = np.random.default_rng(int(seed))
        verbose = bool(config.get("verbose", False))
        t0 = time.time()
        result = run_mopso_optimize(
            config=config,
            test_points=problem.test_points,
            city_map=problem.city_map,
            channel_params=problem.channel_params,
            rng=rng,
            verbose=verbose,
        )
        elapsed = float(time.time() - t0)
        logs: Dict[str, Any] = {
            "best_fitness": float(result.best_fitness),
            "pareto_size": int(result.pareto_objectives.shape[0]),
            "trigger_stats": dict(result.trigger_stats),
            "init_stats": dict(result.init_stats),
        }
        return BaselineResult(
            method_name=self.method_key,
            group=self.group,
            seed=int(seed),
            objective_vectors=np.asarray(result.pareto_objectives, dtype=float),
            decision_variables=np.asarray(result.pareto_positions, dtype=float),
            nondominated_objectives=np.asarray(result.pareto_objectives, dtype=float),
            nondominated_decisions=np.asarray(result.pareto_positions, dtype=float),
            runtime_seconds=elapsed,
            logs=logs,
        )
