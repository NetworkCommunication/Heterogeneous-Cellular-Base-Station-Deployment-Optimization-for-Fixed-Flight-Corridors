from __future__ import annotations

import math

import numpy as np

from src.baselines.bio_inspired_common import ASUV2BioInspiredAdapter, clip_to_bounds


class WOAExtendedAdapter(ASUV2BioInspiredAdapter):
    """Whale Optimization Algorithm baseline for ASU-v2 deployment."""

    method_key = "woa_extended"
    display_name = "Whale Optimization Algorithm Extended"
    algorithm_name = "Whale Optimization Algorithm"
    implemented = True

    def _extra_algorithm_config(self, raw):
        return {"spiral_b": float(raw.get("spiral_b", raw.get("spiralB", 1.0)))}

    def _next_population(self, *, population, scores, iteration, max_iterations, encoding, problem, config, rng, state, alg_cfg):
        best = state["best"]
        a = 2.0 - 2.0 * float(iteration) / max(float(max_iterations), 1.0)
        out = population.copy()
        for i in range(population.shape[0]):
            p = float(rng.random())
            if p < 0.5:
                A = 2.0 * a * rng.random(size=population.shape[1]) - a
                C = 2.0 * rng.random(size=population.shape[1])
                if np.linalg.norm(A) < 1.0:
                    target = best
                else:
                    target = population[int(rng.integers(0, population.shape[0]))]
                D = np.abs(C * target - population[i])
                out[i] = target - A * D
            else:
                D = np.abs(best - population[i])
                l = float(rng.uniform(-1.0, 1.0))
                b = float(alg_cfg["spiral_b"])
                out[i] = D * math.exp(b * l) * math.cos(2.0 * math.pi * l) + best
        return clip_to_bounds(out, encoding)
