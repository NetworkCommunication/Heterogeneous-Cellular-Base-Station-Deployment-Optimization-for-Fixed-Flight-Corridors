﻿"""TEVC deployment scaffold package."""
