from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

import numpy as np

from src.algorithms.fitness_interface import evaluate_population_objectives
from src.baselines.base import DeploymentProblem
from src.data.types import Config
from src.experiments.evaluation_consistency import evaluate_with_existing_context


ASU_METRIC_NAME = "Airway Service Utility"
ASU_SCORE_KEY = "airway_service_utility"
ASU_PRESET_LEGACY = "legacy_composite"
ASU_PRESET_TMC = "tmc_asu"
SUPPORTED_ASU_PRESETS = {ASU_PRESET_LEGACY, ASU_PRESET_TMC}


def materialize_asu_config(config: Config) -> Dict[str, Any]:
    """Write fixed ASU weights and formula metadata into a config snapshot."""
    asu_cfg = config.setdefault("airwayServiceUtility", {})
    asu_cfg["enabled"] = bool(asu_cfg.get("enabled", True))
    asu_cfg.setdefault("name", ASU_METRIC_NAME)
    preset = asu_preset_from_config(config)
    config["asu_preset"] = preset
    asu_cfg["asu_preset"] = preset
    asu_cfg["weights"] = asu_weights_from_config(config)
    asu_cfg["normalization"] = asu_normalization_from_config(config)
    asu_cfg["formula"] = asu_formula_text(preset)
    asu_cfg["preset_notes"] = {
        ASU_PRESET_LEGACY: (
            "Backward-compatible preset. It exactly preserves the existing objective_composite "
            "formula and is intended for regression checks and old result comparisons."
        ),
        ASU_PRESET_TMC: (
            "Paper-facing system-level preset. It combines normalized airway service components "
            "such as route coverage, continuous coverage, handover overhead, deployment cost, "
            "and outage/coverage-hole effects. It is not a replacement for HV/GD/IGD."
        ),
    }
    asu_cfg["component_mapping"] = asu_component_mapping()
    return asu_cfg


def asu_preset_from_config(config: Config) -> str:
    """Return the configured ASU preset."""
    top_level = config.get("asu_preset")
    nested = config.get("airwayServiceUtility", {}).get("asu_preset")
    if top_level is not None and str(top_level).strip().lower() != ASU_PRESET_LEGACY:
        raw = top_level
    elif nested is not None:
        raw = nested
    elif top_level is not None:
        raw = top_level
    else:
        raw = ASU_PRESET_LEGACY
    preset = str(raw).strip().lower()
    if preset not in SUPPORTED_ASU_PRESETS:
        raise ValueError(f"Unsupported asu_preset: {raw!r}; expected one of {sorted(SUPPORTED_ASU_PRESETS)}")
    return preset


def asu_weights_from_config(config: Config) -> Dict[str, float]:
    """Return fixed ASU weights for the selected preset."""
    preset = asu_preset_from_config(config)
    obj_cfg = config.get("baselineObjectives", {})
    override = config.get("airwayServiceUtility", {}).get("weights", {})
    if preset == ASU_PRESET_LEGACY:
        weights = {
            "coverage_score": float(obj_cfg.get("coverageWeight", 1.0)),
            "mean_snr_db": float(obj_cfg.get("signalQualityWeight", 0.2)),
            "deployment_cost_score": -float(obj_cfg.get("costWeight", 0.2)),
            "cost_effectiveness": float(obj_cfg.get("costEffectivenessWeight", 0.0)),
            "capacity_score": float(obj_cfg.get("capacityWeight", 0.0)),
            "constraint_penalty": -1.0,
            # Export-only airway-service components. Legacy composite has zero
            # default weights for these so old scores remain unchanged.
            "handover_count": -float(obj_cfg.get("handoverWeight", 0.0)),
            "continuous_coverage_rate": float(obj_cfg.get("continuousCoverageWeight", 0.0)),
            "route_coverage_rate": float(obj_cfg.get("routeCoverageWeight", 0.0)),
            "outage_probability": -float(obj_cfg.get("outageWeight", 0.0)),
            "coverage_hole_rate": -float(obj_cfg.get("coverageHoleWeight", 0.0)),
            "qos_satisfaction": float(obj_cfg.get("qosSatisfactionWeight", 0.0)),
        }
    else:
        weights = {
            "route_coverage_rate": 0.25,
            "continuous_coverage_rate": 0.25,
            "mean_snr_db": 0.10,
            "cost_effectiveness": 0.10,
            "capacity_score": 0.05,
            "handover_count": -0.10,
            "deployment_cost_score": -0.10,
            "outage_probability": -0.05,
            "coverage_hole_rate": -0.10,
            "constraint_penalty": -0.05,
            "coverage_score": 0.0,
            "qos_satisfaction": 0.0,
        }
    if isinstance(override, dict):
        for key, value in override.items():
            if key in weights:
                weights[key] = float(value)
    return weights


def asu_normalization_from_config(config: Config) -> Dict[str, float]:
    """Return deterministic normalization references used by tmc_asu exports."""
    obj_cfg = config.get("baselineObjectives", {})
    asu_cfg = config.get("airwayServiceUtility", {})
    norm_cfg = asu_cfg.get("normalization", {})
    if not isinstance(norm_cfg, dict):
        norm_cfg = {}
    pso_cfg = config.get("pso", {})
    default_handover = max(float(pso_cfg.get("numBaseStations", 1)) * 4.0, 1.0)
    return {
        "snr_min_db": float(norm_cfg.get("snr_min_db", obj_cfg.get("snrMinDb", 0.0))),
        "snr_max_db": float(norm_cfg.get("snr_max_db", obj_cfg.get("snrMaxDb", 30.0))),
        "cost_reference": float(norm_cfg.get("cost_reference", obj_cfg.get("costReference", 1.0))),
        "capacity_reference": float(norm_cfg.get("capacity_reference", obj_cfg.get("capacityReference", 1.0))),
        "cost_effectiveness_reference": float(
            norm_cfg.get("cost_effectiveness_reference", obj_cfg.get("costEffectivenessReference", 2.0))
        ),
        "handover_reference": float(norm_cfg.get("handover_reference", obj_cfg.get("handoverReference", default_handover))),
        "constraint_penalty_reference": float(
            norm_cfg.get("constraint_penalty_reference", obj_cfg.get("constraintPenaltyReference", 100.0))
        ),
    }


def asu_formula_text(preset: str) -> str:
    """Return the human-readable formula for one ASU preset."""
    if preset == ASU_PRESET_TMC:
        return (
            "ASU_tmc = 100 * ("
            "w_route*norm(route_coverage_rate) "
            "+ w_continuity*norm(continuous_coverage_rate) "
            "+ w_signal*norm(mean_snr_db) "
            "+ w_efficiency*norm(cost_effectiveness) "
            "+ w_capacity*norm(capacity_effective/capacityReference) "
            "- w_handover*norm(handover_count) "
            "- w_cost*norm(deployment_cost/costReference) "
            "- w_outage*norm(outage_probability) "
            "- w_hole*norm(coverage_hole_rate) "
            "- w_constraint*norm(constraint_penalty)); QoS is exported blank when unavailable."
        )
    return (
        "ASU_legacy = coverageWeight*(coverage_rate*100) "
        "+ signalQualityWeight*mean_snr_db "
        "+ costEffectivenessWeight*cost_effectiveness "
        "+ capacityWeight*(capacity_effective/capacityReference*100) "
        "- costWeight*(deployment_cost/costReference*100) "
        "- constraint_penalty"
    )


def asu_component_mapping() -> Dict[str, str]:
    """Document how existing evaluator factors map to ASU component names."""
    return {
        "coverage_score": "coverage_rate * 100 from ObjectiveBatch.coverage_rate",
        "route_coverage_rate": "ObjectiveBatch.coverage_rate; objective-vector fallback uses mean route continuity",
        "continuous_coverage_rate": (
            "mean(existing_route_continuous_coverage_rate, future_route_continuous_coverage_rate)"
        ),
        "handover_count": "ObjectiveBatch.handover_count / objective_handover_count",
        "deployment_cost_score": "deployment_cost / baselineObjectives.costReference * 100",
        "outage_probability": "1 - coverage_rate",
        "coverage_hole_rate": (
            "mean(existing_route_continuity_loss, future_route_continuity_loss), "
            "equivalent to 1 - continuous_coverage_rate"
        ),
        "mean_snr_db": "ObjectiveBatch.mean_snr_db",
        "cost_effectiveness": "ObjectiveBatch.cost_effectiveness",
        "capacity_score": "capacity_effective / baselineObjectives.capacityReference * 100",
        "qos_satisfaction": "not available in current evaluator; exported as blank unless provided by metrics",
        "constraint_penalty": "ObjectiveBatch.constraint_penalty",
    }


def build_asu_record(
    metrics: Dict[str, Any],
    config: Config,
    *,
    seed: Optional[int],
    method_name: str,
    group: str = "",
    solution_id: Optional[int] = None,
    source: str = "metrics",
) -> Dict[str, Any]:
    """Compute one ASU row from existing metric fields."""
    preset = asu_preset_from_config(config)
    weights = asu_weights_from_config(config)
    obj_cfg = config.get("baselineObjectives", {})
    cost_ref = float(obj_cfg.get("costReference", 1.0))
    capacity_ref = float(obj_cfg.get("capacityReference", 1.0))

    coverage_rate = _finite_float(metrics.get("coverage_rate"), 0.0)
    deployment_cost = _finite_float(metrics.get("deployment_cost"), 0.0)
    mean_snr_db = _finite_float(metrics.get("mean_snr_db"), 0.0)
    cost_effectiveness = _finite_float(metrics.get("cost_effectiveness"), 0.0)
    capacity_effective = _finite_float(metrics.get("capacity_effective"), 0.0)
    constraint_penalty = _finite_float(metrics.get("constraint_penalty"), 0.0)
    handover_count = _finite_float(metrics.get("handover_count"), 0.0)
    existing_cont = _finite_float(
        metrics.get("existing_route_continuous_coverage_rate"),
        _coverage_from_loss(metrics.get("existing_route_continuity_loss"), coverage_rate),
    )
    future_cont = _finite_float(
        metrics.get("future_route_continuous_coverage_rate"),
        _coverage_from_loss(metrics.get("future_route_continuity_loss"), coverage_rate),
    )
    continuous_coverage = float(np.mean([existing_cont, future_cont]))
    route_coverage = _finite_float(metrics.get("route_coverage_rate"), coverage_rate)
    outage_probability = _finite_float(metrics.get("outage_probability"), 1.0 - coverage_rate)
    coverage_hole_rate = _finite_float(metrics.get("coverage_hole_rate"), 1.0 - continuous_coverage)
    qos_satisfaction = _optional_float(metrics.get("qos_satisfaction"))

    coverage_score = coverage_rate * 100.0
    deployment_cost_score = deployment_cost / max(cost_ref, 1e-9) * 100.0
    capacity_score = capacity_effective / max(capacity_ref, 1e-9) * 100.0

    normalized = _normalized_components(
        config=config,
        coverage_rate=coverage_rate,
        route_coverage_rate=route_coverage,
        continuous_coverage_rate=continuous_coverage,
        existing_route_continuous_coverage_rate=existing_cont,
        future_route_continuous_coverage_rate=future_cont,
        handover_count=handover_count,
        deployment_cost=deployment_cost,
        outage_probability=outage_probability,
        coverage_hole_rate=coverage_hole_rate,
        mean_snr_db=mean_snr_db,
        cost_effectiveness=cost_effectiveness,
        capacity_score=capacity_score,
        constraint_penalty=constraint_penalty,
        qos_satisfaction=qos_satisfaction,
    )
    if preset == ASU_PRESET_TMC:
        terms = {
            "coverage_score": weights["coverage_score"] * normalized["coverage_score"],
            "mean_snr_db": weights["mean_snr_db"] * normalized["mean_snr_db"],
            "deployment_cost_score": weights["deployment_cost_score"] * normalized["deployment_cost"],
            "cost_effectiveness": weights["cost_effectiveness"] * normalized["cost_effectiveness"],
            "capacity_score": weights["capacity_score"] * normalized["capacity_score"],
            "constraint_penalty": weights["constraint_penalty"] * normalized["constraint_penalty"],
            "handover_count": weights["handover_count"] * normalized["handover_count"],
            "continuous_coverage_rate": weights["continuous_coverage_rate"] * normalized["continuous_coverage_rate"],
            "route_coverage_rate": weights["route_coverage_rate"] * normalized["route_coverage_rate"],
            "outage_probability": weights["outage_probability"] * normalized["outage_probability"],
            "coverage_hole_rate": weights["coverage_hole_rate"] * normalized["coverage_hole_rate"],
            "qos_satisfaction": weights["qos_satisfaction"] * (normalized["qos_satisfaction"] or 0.0),
        }
        asu_total = float(100.0 * sum(terms.values()))
    else:
        terms = {
            "coverage_score": weights["coverage_score"] * coverage_score,
            "mean_snr_db": weights["mean_snr_db"] * mean_snr_db,
            "deployment_cost_score": weights["deployment_cost_score"] * deployment_cost_score,
            "cost_effectiveness": weights["cost_effectiveness"] * cost_effectiveness,
            "capacity_score": weights["capacity_score"] * capacity_score,
            "constraint_penalty": weights["constraint_penalty"] * constraint_penalty,
            "handover_count": weights["handover_count"] * handover_count,
            "continuous_coverage_rate": weights["continuous_coverage_rate"] * continuous_coverage,
            "route_coverage_rate": weights["route_coverage_rate"] * route_coverage,
            "outage_probability": weights["outage_probability"] * outage_probability,
            "coverage_hole_rate": weights["coverage_hole_rate"] * coverage_hole_rate,
            "qos_satisfaction": weights["qos_satisfaction"] * (qos_satisfaction if qos_satisfaction is not None else 0.0),
        }
        asu_total = float(sum(terms.values()))

    row: Dict[str, Any] = {
        "seed": "" if seed is None else float(seed),
        "method_name": method_name,
        "group": group,
        "solution_id": "" if solution_id is None else int(solution_id),
        "source": source,
        "asu_preset": preset,
        ASU_SCORE_KEY: asu_total,
        "legacy_objective_composite": _optional_float(metrics.get("objective_composite")),
        "coverage_rate": coverage_rate,
        "coverage_score": coverage_score,
        "route_coverage_rate": route_coverage,
        "continuous_coverage_rate": continuous_coverage,
        "existing_route_continuous_coverage_rate": existing_cont,
        "future_route_continuous_coverage_rate": future_cont,
        "handover_count": handover_count,
        "deployment_cost": deployment_cost,
        "total_infrastructure_cost": _optional_float(metrics.get("total_infrastructure_cost")),
        "deployment_cost_scope": str(metrics.get("deployment_cost_scope", "")),
        "service_evaluation_stations": str(metrics.get("service_evaluation_stations", "")),
        "existing_station_count": _optional_float(metrics.get("existing_station_count")),
        "newly_deployed_station_count": _optional_float(metrics.get("newly_deployed_station_count")),
        "evaluation_station_count": _optional_float(metrics.get("evaluation_station_count")),
        "deployment_cost_score": deployment_cost_score,
        "outage_probability": outage_probability,
        "coverage_hole_rate": coverage_hole_rate,
        "mean_snr_db": mean_snr_db,
        "cost_effectiveness": cost_effectiveness,
        "capacity_effective": capacity_effective,
        "capacity_score": capacity_score,
        "qos_satisfaction": "" if qos_satisfaction is None else qos_satisfaction,
        "constraint_penalty": constraint_penalty,
    }
    for key, value in normalized.items():
        row[f"normalized_{key}"] = "" if value is None else float(value)
    for key, value in weights.items():
        row[f"weight_{key}"] = float(value)
    for key, value in terms.items():
        row[f"term_{key}"] = float(value)
    return row


def build_asu_records_from_metrics(
    metrics_rows: Sequence[Dict[str, Any]],
    config: Config,
    *,
    seed: Optional[int],
    method_name: str,
    group: str = "",
    source: str = "metrics",
) -> List[Dict[str, Any]]:
    """Build ASU component records from final-solution metric dictionaries."""
    return [
        build_asu_record(
            dict(metrics),
            config,
            seed=seed,
            method_name=method_name,
            group=group,
            solution_id=i + 1,
            source=source,
        )
        for i, metrics in enumerate(metrics_rows)
    ]


def build_asu_records_from_objectives(
    objectives: np.ndarray,
    config: Config,
    *,
    seed: Optional[int],
    method_name: str,
    group: str = "",
    source: str = "objective_vector_proxy",
) -> List[Dict[str, Any]]:
    """Build ASU records from existing four-objective vectors when metrics are unavailable."""
    obj = np.asarray(objectives, dtype=float)
    if obj.size == 0:
        return []
    if obj.ndim == 1:
        obj = obj.reshape(1, -1)
    records: List[Dict[str, Any]] = []
    for i in range(obj.shape[0]):
        handover = float(obj[i, 0]) if obj.shape[1] > 0 else 0.0
        cost = float(obj[i, 1]) if obj.shape[1] > 1 else 0.0
        existing_loss = float(obj[i, 2]) if obj.shape[1] > 2 else 1.0
        future_loss = float(obj[i, 3]) if obj.shape[1] > 3 else existing_loss
        existing_cont = 1.0 - existing_loss
        future_cont = 1.0 - future_loss
        route_cov = float(np.mean([existing_cont, future_cont]))
        metrics = {
            "handover_count": handover,
            "deployment_cost": cost,
            "coverage_rate": route_cov,
            "route_coverage_rate": route_cov,
            "existing_route_continuous_coverage_rate": existing_cont,
            "future_route_continuous_coverage_rate": future_cont,
            "coverage_hole_rate": float(np.mean([existing_loss, future_loss])),
            "outage_probability": 1.0 - route_cov,
        }
        records.append(
            build_asu_record(
                metrics,
                config,
                seed=seed,
                method_name=method_name,
                group=group,
                solution_id=i + 1,
                source=source,
            )
        )
    return records


def build_asu_records_from_decisions(
    decisions: np.ndarray,
    problem: DeploymentProblem,
    config: Config,
    *,
    seed: Optional[int],
    method_name: str,
    group: str = "",
) -> List[Dict[str, Any]]:
    """Evaluate final decisions through the shared evaluator and compute ASU rows."""
    arr = np.asarray(decisions, dtype=float)
    if arr.size == 0 or arr.ndim != 3:
        return []
    if bool(config.get("systemLevelEvaluation", {}).get("includeExistingStations", False)):
        eval_result = evaluate_with_existing_context(
            decisions=arr,
            problem=problem,
            config=config,
            method_name=method_name,
        )
        metrics_rows = eval_result.metrics
    else:
        batch = evaluate_population_objectives(
            positions=arr,
            test_points=problem.test_points,
            city_map=problem.city_map,
            channel_params=problem.channel_params,
            config=config,
            station_plan=None,
        )
        metrics_rows = [batch.at(i) for i in range(arr.shape[0])]
    return build_asu_records_from_metrics(
        metrics_rows,
        config,
        seed=seed,
        method_name=method_name,
        group=group,
        source="shared_evaluator",
    )


def export_asu_outputs(
    records: Sequence[Dict[str, Any]],
    output_dir: Path,
    config: Config,
    save_csv_fn: Callable[[Sequence[Dict[str, Any]], Path], None],
) -> Dict[str, str]:
    """Export ASU component, per-method, summary, and weight files."""
    output_dir.mkdir(parents=True, exist_ok=True)
    component_rows = _with_global_normalized_components([dict(r) for r in records])
    per_method_rows = _per_method_rows(component_rows)
    summary_rows = _summary_rows(per_method_rows)

    components_csv = output_dir / "asu_components.csv"
    per_method_csv = output_dir / "per_method_asu.csv"
    summary_csv = output_dir / "asu_summary.csv"
    weights_json = output_dir / "asu_weights.json"

    save_csv_fn(component_rows, components_csv)
    save_csv_fn(per_method_rows, per_method_csv)
    save_csv_fn(summary_rows, summary_csv)
    with open(weights_json, "w", encoding="utf-8") as f:
        json.dump(
            {
                "metric_name": ASU_METRIC_NAME,
                "score_key": ASU_SCORE_KEY,
                "asu_preset": asu_preset_from_config(config),
                "weights": asu_weights_from_config(config),
                "normalization": asu_normalization_from_config(config),
                "formula": materialize_asu_config(config)["formula"],
                "component_mapping": asu_component_mapping(),
                "preset_documentation": materialize_asu_config(config)["preset_notes"],
                "hv_gd_igd_note": "ASU is exported for system-level ranking only; it does not replace HV/GD/IGD.",
            },
            f,
            ensure_ascii=False,
            indent=2,
        )
    return {
        "asu_components_csv": str(components_csv.resolve()),
        "per_method_asu_csv": str(per_method_csv.resolve()),
        "asu_summary_csv": str(summary_csv.resolve()),
        "asu_weights_json": str(weights_json.resolve()),
    }


def _per_method_rows(records: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_seed: Dict[Any, List[Dict[str, Any]]] = {}
    by_key: Dict[tuple[Any, str], List[Dict[str, Any]]] = {}
    for row in records:
        seed = row.get("seed", "")
        method = str(row.get("method_name", ""))
        by_key.setdefault((seed, method), []).append(row)
    out: List[Dict[str, Any]] = []
    for (seed, method), rows in by_key.items():
        best = max(rows, key=lambda r: float(r.get(ASU_SCORE_KEY, -np.inf)))
        ranked_row = {
            "seed": seed,
            "method_name": method,
            "group": best.get("group", ""),
            "asu_preset": best.get("asu_preset", ""),
            "best_solution_id": best.get("solution_id", ""),
            ASU_SCORE_KEY: float(best.get(ASU_SCORE_KEY, 0.0)),
            "coverage_rate": float(best.get("coverage_rate", 0.0)),
            "continuous_coverage_rate": float(best.get("continuous_coverage_rate", 0.0)),
            "handover_count": float(best.get("handover_count", 0.0)),
            "deployment_cost": float(best.get("deployment_cost", 0.0)),
            "source": best.get("source", ""),
        }
        out.append(ranked_row)
        by_seed.setdefault(seed, []).append(ranked_row)

    for rows in by_seed.values():
        ranked = sorted(rows, key=lambda r: float(r.get(ASU_SCORE_KEY, -np.inf)), reverse=True)
        for rank, row in enumerate(ranked, start=1):
            row["asu_rank_within_seed"] = float(rank)
    out.sort(key=lambda r: (str(r.get("seed", "")), float(r.get("asu_rank_within_seed", 0.0)), str(r["method_name"])))
    return out


def _summary_rows(per_method_rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_method: Dict[str, List[Dict[str, Any]]] = {}
    for row in per_method_rows:
        by_method.setdefault(str(row["method_name"]), []).append(row)
    out: List[Dict[str, Any]] = []
    for method, rows in by_method.items():
        vals = np.asarray([float(r.get(ASU_SCORE_KEY, 0.0)) for r in rows], dtype=float)
        ranks = np.asarray([float(r.get("asu_rank_within_seed", 0.0)) for r in rows], dtype=float)
        out.append(
            {
                "method_name": method,
                "group": rows[0].get("group", ""),
                "asu_preset": rows[0].get("asu_preset", ""),
                "num_runs": float(len(rows)),
                f"{ASU_SCORE_KEY}_mean": float(np.mean(vals)) if vals.size else 0.0,
                f"{ASU_SCORE_KEY}_std": float(np.std(vals, ddof=1)) if vals.size > 1 else 0.0,
                "asu_rank_mean": float(np.mean(ranks)) if ranks.size else 0.0,
            }
        )
    out.sort(key=lambda r: float(r[f"{ASU_SCORE_KEY}_mean"]), reverse=True)
    for rank, row in enumerate(out, start=1):
        row["asu_summary_rank"] = float(rank)
    return out


def _with_global_normalized_components(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    benefit = ["coverage_rate", "continuous_coverage_rate", "route_coverage_rate", "cost_effectiveness", "qos_satisfaction"]
    cost = ["handover_count", "deployment_cost", "outage_probability", "coverage_hole_rate"]
    for key in benefit:
        _add_minmax_column(records, key, higher_is_better=True)
    for key in cost:
        _add_minmax_column(records, key, higher_is_better=False)
    return records


def _add_minmax_column(records: List[Dict[str, Any]], key: str, *, higher_is_better: bool) -> None:
    values = np.asarray([_finite_float(r.get(key), np.nan) for r in records], dtype=float)
    finite = np.isfinite(values)
    out_key = f"global_minmax_{key}"
    if not finite.any():
        for row in records:
            row[out_key] = ""
        return
    lo = float(np.min(values[finite]))
    hi = float(np.max(values[finite]))
    span = hi - lo
    for row, value in zip(records, values):
        if not math.isfinite(float(value)):
            row[out_key] = ""
        elif span <= 1e-12:
            row[out_key] = 1.0
        elif higher_is_better:
            row[out_key] = float((value - lo) / span)
        else:
            row[out_key] = float((hi - value) / span)


def _normalized_components(
    *,
    config: Config,
    coverage_rate: float,
    route_coverage_rate: float,
    continuous_coverage_rate: float,
    existing_route_continuous_coverage_rate: float,
    future_route_continuous_coverage_rate: float,
    handover_count: float,
    deployment_cost: float,
    outage_probability: float,
    coverage_hole_rate: float,
    mean_snr_db: float,
    cost_effectiveness: float,
    capacity_score: float,
    constraint_penalty: float,
    qos_satisfaction: Optional[float],
) -> Dict[str, Optional[float]]:
    norm_cfg = asu_normalization_from_config(config)
    snr_min = float(norm_cfg["snr_min_db"])
    snr_max = float(norm_cfg["snr_max_db"])
    return {
        "coverage_rate": _clip01(coverage_rate),
        "coverage_score": _clip01(coverage_rate),
        "route_coverage_rate": _clip01(route_coverage_rate),
        "continuous_coverage_rate": _clip01(continuous_coverage_rate),
        "existing_route_continuous_coverage_rate": _clip01(existing_route_continuous_coverage_rate),
        "future_route_continuous_coverage_rate": _clip01(future_route_continuous_coverage_rate),
        "handover_count": _clip01(handover_count / max(float(norm_cfg["handover_reference"]), 1e-9)),
        "deployment_cost": _clip01(deployment_cost / max(float(norm_cfg["cost_reference"]), 1e-9)),
        "deployment_cost_score": _clip01(deployment_cost / max(float(norm_cfg["cost_reference"]), 1e-9)),
        "outage_probability": _clip01(outage_probability),
        "coverage_hole_rate": _clip01(coverage_hole_rate),
        "mean_snr_db": _clip01((mean_snr_db - snr_min) / max(snr_max - snr_min, 1e-9)),
        "cost_effectiveness": _clip01(
            cost_effectiveness / max(float(norm_cfg["cost_effectiveness_reference"]), 1e-9)
        ),
        "capacity_score": _clip01(capacity_score / 100.0),
        "constraint_penalty": _clip01(
            constraint_penalty / max(float(norm_cfg["constraint_penalty_reference"]), 1e-9)
        ),
        "qos_satisfaction": None if qos_satisfaction is None else _clip01(qos_satisfaction),
    }


def _clip01(value: float) -> float:
    return float(np.clip(float(value), 0.0, 1.0))


def _coverage_from_loss(raw_loss: Any, default: float) -> float:
    val = _optional_float(raw_loss)
    if val is None:
        return float(default)
    return 1.0 - val


def _finite_float(value: Any, default: float) -> float:
    out = _optional_float(value)
    if out is None:
        return float(default)
    return out


def _optional_float(value: Any) -> Optional[float]:
    try:
        if value == "":
            return None
        out = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(out):
        return None
    return out
