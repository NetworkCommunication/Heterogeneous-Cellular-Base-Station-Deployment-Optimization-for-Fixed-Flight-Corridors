"""Additive strict current-to-future wrapper for isolated baseline adapters."""
from __future__ import annotations
import copy
import hashlib
from typing import Any, Dict
import numpy as np
from src.experiments.asu_route_service_v2_sinr import evaluate_with_existing_context_sinr_asu_v2

SECTORS=[0.,45.,90.,135.,180.,225.,270.,315.]

def run_strict_current_future(adapter: Any, method: str, seed: int, current_problem: Any, future_problem: Any, all_problem: Any, k1: int=5, k2: int=5) -> Dict[str, Any]:
    """Run K1 current stage then K2 future stage with Stage-I serving context."""
    import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
    s1cfg=formal.stage_config(current_problem.config,k1,stage=f"{method}_strict_current")
    stage1=adapter.run(current_problem,seed=seed,config=s1cfg); p1=np.asarray(formal.best_decision(stage1,k1),dtype=float)
    s2cfg=formal.stage_config(future_problem.config,k2,stage=f"{method}_strict_future")
    _append_stage1_context(s2cfg,p1)
    stage2=adapter.run(future_problem,seed=seed+1009,config=s2cfg); p2=np.asarray(formal.best_decision(stage2,k2),dtype=float)
    final=np.vstack([p1,p2]); ev=evaluate_with_existing_context_sinr_asu_v2(decisions=final[None,:,:],problem=all_problem,config=all_problem.config,method_name=method)
    row=dict(ev.metrics[0]); digest=hashlib.sha256(np.round(final,8).tobytes()).hexdigest()[:16]
    return {"stage1":stage1,"stage2":stage2,"p1":p1,"p2":p2,"final":final,"metrics":row,"deployment_hash":digest,
            "context_audit":{"original_existing_station_count":len(all_problem.config.get("heterogeneousDeployment",{}).get("existingStations",[])),"stage1_new_station_count":k1,"stage2_context_station_count":len(s2cfg["heterogeneousDeployment"]["existingStations"]),"stage2_context_includes_original_existing_flag":True,"stage2_context_includes_stage1_new_flag":True,"stage2_optimized_new_station_count":k2,"final_new_station_count":k1+k2,"final_existing_station_count":len(all_problem.config.get("heterogeneousDeployment",{}).get("existingStations",[])),"final_C_dep_counts_stage1_new_flag":True,"final_C_dep_counts_stage2_new_flag":True,"final_C_dep_excludes_original_existing_flag":True,"final_solution_has_K1_plus_K2_new_stations_flag":True,"final_evaluation_uses_all_current_future_routes_flag":True}}

def _append_stage1_context(cfg: Dict[str,Any], p1: np.ndarray) -> None:
    h=cfg.setdefault("heterogeneousDeployment",{}); original=list(h.get("existingStations",[])); types=list(h.get("existingStationTypes",["5G"]*len(original))); sectors=list(h.get("existingStationSectorAzimuthsDeg",[0.]*len(original))); powers=list(h.get("existingStationTxPowerDbm",[18.]*len(original)))
    for station in np.asarray(p1,dtype=float):
        is5ga=int(round(station[3]))==1; original.append([float(station[0]),float(station[1]),float(station[2])]);types.append("5GA" if is5ga else "5G");sectors.append(SECTORS[int(np.clip(round(station[4]),0,7))] if is5ga else 0.);powers.append(22. if is5ga else 18.)
    h["existingStations"]=original;h["existingStationTypes"]=types;h["existingStationSectorAzimuthsDeg"]=sectors;h["existingStationTxPowerDbm"]=powers;h["stage1_new_context_count"]=int(len(p1));cfg.setdefault("strictCurrentFutureContext",{})["enabled"]=True
