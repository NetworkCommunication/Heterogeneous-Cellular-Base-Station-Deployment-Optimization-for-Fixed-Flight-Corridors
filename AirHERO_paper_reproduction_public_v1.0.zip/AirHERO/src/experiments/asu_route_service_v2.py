from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict

import numpy as np

from src.data.types import Config


ASU_ROUTE_SERVICE_V2 = "asu_route_service_v2"
ASU_ROUTE_SERVICE_KEY = "airway_service_utility_v2"


@dataclass(frozen=True)
class ASURouteServiceV2Record:
    """Physical-cost ASU v2 components for one deployment solution."""

    ASU: float
    Q_current: float
    Q_future: float
    current_coverage: float
    future_coverage: float
    current_mean_log_rate: float
    future_mean_log_rate: float
    C_dep: float
    N_5G: int
    N_5GA: int
    C_5G: float
    C_5GA: float
    handover_count: float
    kappa_H: float
    C_0: float
    denominator: float
    w_current: float
    w_future: float
    signal_metric: str

    def as_dict(self) -> Dict[str, Any]:
        """Return CSV-friendly component mapping."""
        return {
            "ASU": self.ASU,
            ASU_ROUTE_SERVICE_KEY: self.ASU,
            "Q_current": self.Q_current,
            "Q_future": self.Q_future,
            "current_coverage": self.current_coverage,
            "future_coverage": self.future_coverage,
            "current_mean_log_rate": self.current_mean_log_rate,
            "future_mean_log_rate": self.future_mean_log_rate,
            "C_dep": self.C_dep,
            "N_5G": self.N_5G,
            "N_5GA": self.N_5GA,
            "C_5G": self.C_5G,
            "C_5GA": self.C_5GA,
            "handover_count": self.handover_count,
            "kappa_H": self.kappa_H,
            "C_0": self.C_0,
            "denominator": self.denominator,
            "w_current": self.w_current,
            "w_future": self.w_future,
            "signal_metric": self.signal_metric,
            "asu_preset": ASU_ROUTE_SERVICE_V2,
        }


def asu_route_service_v2_from_metrics(metrics: Dict[str, Any], config: Config) -> ASURouteServiceV2Record:
    """Compute physical-cost ASU v2 from shared evaluator metric fields.

    The current evaluator exports route-continuity/coverage summaries, not per-route
    SNR arrays. This first implementation therefore uses current/future continuity
    rates as coverage-aware route-service factors and the deployment mean SNR as
    the signal-quality proxy. The formula and denominator match the rebuild design.
    """
    params = _params(config)
    signal_metric = str(params.get("signal_metric", "snr")).strip().lower()
    if signal_metric != "snr":
        raise ValueError("asu_route_service_v2 first implementation supports signal_metric='snr' only")

    snr_db = _float(metrics.get("mean_snr_db"), 0.0)
    gamma = 10.0 ** (snr_db / 10.0)
    mean_log_rate = math.log2(1.0 + max(gamma, 0.0))

    fallback_cov = _clip01(_float(metrics.get("coverage_rate"), 0.0))
    current_coverage = _clip01(
        _float(
            metrics.get("current_coverage", metrics.get("existing_route_continuous_coverage_rate")),
            fallback_cov,
        )
    )
    future_coverage = _clip01(
        _float(
            metrics.get("future_coverage", metrics.get("future_route_continuous_coverage_rate")),
            fallback_cov,
        )
    )
    current_mean_log_rate = _float(metrics.get("current_mean_log_rate"), mean_log_rate)
    future_mean_log_rate = _float(metrics.get("future_mean_log_rate"), mean_log_rate)
    q_current = current_coverage * max(current_mean_log_rate, 0.0)
    q_future = future_coverage * max(future_mean_log_rate, 0.0)

    n_5g = int(round(_float(metrics.get("N_5G", metrics.get("selected_5G_count")), 0.0)))
    n_5ga = int(round(_float(metrics.get("N_5GA", metrics.get("selected_5GA_count")), 0.0)))
    c_dep_metric = metrics.get("C_dep", metrics.get("deployment_cost"))
    if c_dep_metric is None:
        c_dep = n_5g * float(params["C_5G"]) + n_5ga * float(params["C_5GA"])
    else:
        c_dep = _float(c_dep_metric, 0.0)
    handover = _float(metrics.get("handover_count"), 0.0)
    denominator = max(c_dep + float(params["kappa_H"]) * handover + float(params["C_0"]), 1e-12)
    asu = (float(params["w_current"]) * q_current + float(params["w_future"]) * q_future) / denominator

    return ASURouteServiceV2Record(
        ASU=float(asu),
        Q_current=float(q_current),
        Q_future=float(q_future),
        current_coverage=float(current_coverage),
        future_coverage=float(future_coverage),
        current_mean_log_rate=float(current_mean_log_rate),
        future_mean_log_rate=float(future_mean_log_rate),
        C_dep=float(c_dep),
        N_5G=int(n_5g),
        N_5GA=int(n_5ga),
        C_5G=float(params["C_5G"]),
        C_5GA=float(params["C_5GA"]),
        handover_count=float(handover),
        kappa_H=float(params["kappa_H"]),
        C_0=float(params["C_0"]),
        denominator=float(denominator),
        w_current=float(params["w_current"]),
        w_future=float(params["w_future"]),
        signal_metric=signal_metric,
    )


def _params(config: Config) -> Dict[str, float | str]:
    cfg = config.get("airwayServiceUtilityV2", config.get("asu_route_service_v2", {}))
    if not isinstance(cfg, dict):
        cfg = {}
    return {
        "w_current": float(cfg.get("w_current", cfg.get("w_c", 0.5))),
        "w_future": float(cfg.get("w_future", cfg.get("w_f", 0.5))),
        "C_5G": float(cfg.get("C_5G", 1.0)),
        "C_5GA": float(cfg.get("C_5GA", 1.35)),
        "kappa_H": float(cfg.get("kappa_H", 0.01)),
        "C_0": float(cfg.get("C_0", 1.0)),
        "signal_metric": str(cfg.get("signal_metric", "snr")),
    }


def _float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or str(value).strip() == "":
            return float(default)
        out = float(value)
        if not math.isfinite(out):
            return float(default)
        return out
    except (TypeError, ValueError):
        return float(default)


def _clip01(value: float) -> float:
    return float(np.clip(float(value), 0.0, 1.0))
