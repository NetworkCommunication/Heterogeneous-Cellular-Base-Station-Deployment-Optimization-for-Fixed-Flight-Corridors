from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import numpy as np

from src.algorithms.particle_encoding import decode_particle_solution
from src.data.types import Config, PSOResult
from src.experiments.multiobjective_metrics import DEFAULT_OBJECTIVE_NAMES


@dataclass(frozen=True)
class FinalNondominatedExport:
    """Paths and objective vectors produced by the final nondominated exporter."""

    nondominated_solutions_csv: Path
    objective_vectors_csv: Path
    decoded_deployments_csv: Path
    objective_vectors: np.ndarray


def export_final_nondominated_from_pso_result(
    pso_result: PSOResult,
    config: Config,
    output_dir: Path,
) -> FinalNondominatedExport:
    """Export the final nondominated archive carried by a PSO-compatible result."""
    objectives = pso_result.pareto_objectives
    positions = pso_result.pareto_positions
    metrics = pso_result.pareto_metrics
    decoded = pso_result.pareto_decoded_solutions

    if objectives is None or np.asarray(objectives).size == 0:
        objectives = _best_objective_vector_from_pso(pso_result)
    if positions is None or np.asarray(positions).size == 0:
        positions = np.asarray(pso_result.best_position, dtype=float)[None, :, :]
    if metrics is None:
        metrics = [dict(pso_result.best_objectives or {})]
    if decoded is None:
        decoded = [pso_result.decoded_solution or decode_particle_solution(pso_result.best_position, config)]

    return export_final_nondominated_solutions(
        output_dir=output_dir,
        config=config,
        objectives=np.asarray(objectives, dtype=float),
        decisions=np.asarray(positions, dtype=float),
        decoded_solutions=decoded,
        metrics=metrics,
    )


def export_final_nondominated_from_mopso_result(
    mopso_result: Any,
    config: Config,
    output_dir: Path,
) -> FinalNondominatedExport:
    """Export final nondominated files from a MOPSOResult-like object."""
    return export_final_nondominated_solutions(
        output_dir=output_dir,
        config=config,
        objectives=np.asarray(mopso_result.pareto_objectives, dtype=float),
        decisions=np.asarray(mopso_result.pareto_positions, dtype=float),
        decoded_solutions=list(mopso_result.pareto_decoded_solutions),
        metrics=list(mopso_result.pareto_metrics),
    )


def export_final_nondominated_from_baseline_result(
    baseline_result: Any,
    config: Config,
    output_dir: Path,
) -> FinalNondominatedExport:
    """Export final nondominated files from a BaselineResult-like object."""
    return export_final_nondominated_solutions(
        output_dir=output_dir,
        config=config,
        objectives=np.asarray(baseline_result.nondominated_objectives, dtype=float),
        decisions=np.asarray(baseline_result.nondominated_decisions, dtype=float),
        feasible_mask=baseline_result.nondominated_feasible_mask,
    )


def export_final_nondominated_solutions(
    output_dir: Path,
    config: Config,
    objectives: np.ndarray,
    decisions: Optional[np.ndarray] = None,
    decoded_solutions: Optional[Sequence[Sequence[Dict[str, Any]]]] = None,
    metrics: Optional[Sequence[Dict[str, Any]]] = None,
    feasible_mask: Optional[np.ndarray] = None,
    constraint_violations: Optional[np.ndarray] = None,
) -> FinalNondominatedExport:
    """Save canonical final nondominated solution, objective, and deployment CSVs.

    The three files are intentionally written from the same in-memory objective
    matrix so downstream HV/GD/IGD code can consume the exact exported vectors.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    obj = _ensure_2d_objectives(objectives, config)
    n = int(obj.shape[0])
    objective_names = _objective_names(config, obj.shape[1])
    decoded = _resolve_decoded_solutions(decisions, decoded_solutions, config, n)
    metric_rows = list(metrics or [])
    feasible_values = _resolve_feasible_values(feasible_mask, metric_rows, n)
    violations = _resolve_constraint_violations(constraint_violations, metric_rows, n)

    objective_vectors_csv = output_dir / "final_objective_vectors.csv"
    nondominated_solutions_csv = output_dir / "final_nondominated_solutions.csv"
    decoded_deployments_csv = output_dir / "final_decoded_deployments.csv"

    objective_headers = ["solution_id", *_objective_columns(objective_names)]
    with open(objective_vectors_csv, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=objective_headers)
        writer.writeheader()
        for i in range(n):
            writer.writerow(_objective_row(i, obj, objective_names))

    max_stations = max((len(rows) for rows in decoded), default=0)
    solution_headers = [
        "solution_id",
        *_objective_columns(objective_names),
        "feasible",
        "constraint_violation",
        "airway_service_utility",
        "objective_composite",
        "num_stations",
    ]
    for station_idx in range(max_stations):
        sid = station_idx + 1
        solution_headers.extend(
            [
                f"station_{sid}_id",
                f"station_{sid}_type",
                f"station_{sid}_x",
                f"station_{sid}_y",
                f"station_{sid}_height",
                f"station_{sid}_source",
                f"station_{sid}_sector_direction_index",
                f"station_{sid}_sector_azimuth_deg",
            ]
        )

    with open(nondominated_solutions_csv, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=solution_headers)
        writer.writeheader()
        for i in range(n):
            row = _solution_row(i, obj, objective_names, feasible_values, violations, metric_rows, decoded, config)
            writer.writerow(row)

    deployment_headers = [
        "solution_id",
        *_objective_columns(objective_names),
        "feasible",
        "constraint_violation",
        "station_id",
        "station_type",
        "x",
        "y",
        "height",
        "station_source",
        "sector_direction_index",
        "sector_azimuth_deg",
    ]
    with open(decoded_deployments_csv, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=deployment_headers)
        writer.writeheader()
        for i in range(n):
            base = _objective_row(i, obj, objective_names)
            base["feasible"] = feasible_values[i]
            base["constraint_violation"] = float(violations[i])
            stations = decoded[i] if i < len(decoded) else []
            sources = _station_sources(stations, config)
            for station_idx, station in enumerate(stations):
                row = dict(base)
                row.update(_station_row(station))
                row["station_source"] = sources[station_idx] if station_idx < len(sources) else "new_deployment"
                writer.writerow(row)

    return FinalNondominatedExport(
        nondominated_solutions_csv=nondominated_solutions_csv,
        objective_vectors_csv=objective_vectors_csv,
        decoded_deployments_csv=decoded_deployments_csv,
        objective_vectors=obj,
    )


def _ensure_2d_objectives(objectives: np.ndarray, config: Config) -> np.ndarray:
    arr = np.asarray(objectives, dtype=float)
    if arr.size == 0:
        return np.zeros((0, len(_objective_names(config, 0))), dtype=float)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    if arr.ndim != 2:
        raise ValueError("Final objective vectors must be a 2D array")
    finite = np.isfinite(arr).all(axis=1)
    return arr[finite]


def _best_objective_vector_from_pso(pso_result: PSOResult) -> np.ndarray:
    best = pso_result.best_objectives or {}
    return np.asarray(
        [
            [
                float(best.get("handover_count", 0.0)),
                float(best.get("deployment_cost", 0.0)),
                1.0 - float(best.get("existing_route_continuous_coverage_rate", best.get("coverage_rate", 0.0))),
                1.0 - float(best.get("future_route_continuous_coverage_rate", best.get("coverage_rate", 0.0))),
            ]
        ],
        dtype=float,
    )


def _objective_names(config: Config, dim: int) -> List[str]:
    configured = list(config.get("multiObjectiveMetrics", {}).get("objectiveNames", []))
    names = configured or list(DEFAULT_OBJECTIVE_NAMES)
    if dim <= 0:
        return names
    out = [str(names[i]) if i < len(names) else f"objective_{i + 1}" for i in range(dim)]
    return out


def _objective_columns(objective_names: Sequence[str]) -> List[str]:
    return [f"objective_{name}" for name in objective_names]


def _objective_row(idx: int, objectives: np.ndarray, objective_names: Sequence[str]) -> Dict[str, Any]:
    row: Dict[str, Any] = {"solution_id": int(idx + 1)}
    for j, name in enumerate(objective_names):
        row[f"objective_{name}"] = float(objectives[idx, j])
    return row


def _solution_row(
    idx: int,
    objectives: np.ndarray,
    objective_names: Sequence[str],
    feasible_values: List[Any],
    violations: np.ndarray,
    metrics: Sequence[Dict[str, Any]],
    decoded: Sequence[Sequence[Dict[str, Any]]],
    config: Config,
) -> Dict[str, Any]:
    row = _objective_row(idx, objectives, objective_names)
    row["feasible"] = feasible_values[idx]
    row["constraint_violation"] = float(violations[idx])
    metric = metrics[idx] if idx < len(metrics) else {}
    composite = _optional_float(metric.get("objective_composite", None))
    asu = _optional_float(metric.get("airway_service_utility", None))
    row["airway_service_utility"] = composite if asu is None else asu
    row["objective_composite"] = composite
    stations = decoded[idx] if idx < len(decoded) else []
    sources = _station_sources(stations, config)
    row["num_stations"] = int(len(stations))
    for station_idx, station in enumerate(stations):
        sid = station_idx + 1
        station_row = _station_row(station)
        row[f"station_{sid}_id"] = station_row["station_id"]
        row[f"station_{sid}_type"] = station_row["station_type"]
        row[f"station_{sid}_x"] = station_row["x"]
        row[f"station_{sid}_y"] = station_row["y"]
        row[f"station_{sid}_height"] = station_row["height"]
        row[f"station_{sid}_source"] = sources[station_idx] if station_idx < len(sources) else "new_deployment"
        row[f"station_{sid}_sector_direction_index"] = station_row["sector_direction_index"]
        row[f"station_{sid}_sector_azimuth_deg"] = station_row["sector_azimuth_deg"]
    return row


def _station_row(station: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "station_id": int(station.get("station_id", 0)),
        "station_type": str(station.get("station_type", "")),
        "x": _optional_float(station.get("x", None)),
        "y": _optional_float(station.get("y", None)),
        "height": _optional_float(station.get("height", station.get("z", None))),
        "sector_direction_index": _optional_int(station.get("sector_direction_index", None)),
        "sector_azimuth_deg": _none_text_or_float(station.get("sector_azimuth_deg", None)),
    }


def _station_sources(stations: Sequence[Dict[str, Any]], config: Config) -> List[str]:
    existing = np.asarray(config.get("heterogeneousDeployment", {}).get("existingStations", []), dtype=float)
    if existing.size == 0:
        return [str(station.get("source", "new_deployment")) for station in stations]
    if existing.ndim == 1:
        existing = existing.reshape(1, -1)
    existing = existing[:, :3]
    if len(stations) < existing.shape[0]:
        return [str(station.get("source", "new_deployment")) for station in stations]
    prefix = np.asarray(
        [[float(s.get("x", 0.0)), float(s.get("y", 0.0)), float(s.get("z", s.get("height", 0.0)))] for s in stations[: existing.shape[0]]],
        dtype=float,
    )
    if not np.allclose(prefix, existing, atol=1e-6, rtol=0.0):
        return [str(station.get("source", "new_deployment")) for station in stations]
    return ["existing" if idx < existing.shape[0] else str(station.get("source", "new_deployment")) for idx, station in enumerate(stations)]


def _resolve_decoded_solutions(
    decisions: Optional[np.ndarray],
    decoded_solutions: Optional[Sequence[Sequence[Dict[str, Any]]]],
    config: Config,
    num_solutions: int,
) -> List[List[Dict[str, Any]]]:
    if decoded_solutions is not None:
        return [[dict(station) for station in rows] for rows in decoded_solutions]
    if decisions is None:
        return [[] for _ in range(num_solutions)]

    arr = np.asarray(decisions, dtype=float)
    if arr.size == 0 or arr.ndim != 3:
        return [[] for _ in range(num_solutions)]
    out: List[List[Dict[str, Any]]] = []
    for i in range(min(num_solutions, arr.shape[0])):
        out.append(decode_particle_solution(arr[i], config))
    while len(out) < num_solutions:
        out.append([])
    return out


def _resolve_feasible_values(
    feasible_mask: Optional[np.ndarray],
    metrics: Sequence[Dict[str, Any]],
    num_solutions: int,
) -> List[Any]:
    if feasible_mask is not None:
        arr = np.asarray(feasible_mask, dtype=bool).reshape(-1)
        return [bool(arr[i]) if i < arr.size else "" for i in range(num_solutions)]
    out: List[Any] = []
    for i in range(num_solutions):
        metric = metrics[i] if i < len(metrics) else {}
        if "feasible" in metric:
            out.append(bool(metric["feasible"]))
        elif "constraint_penalty" in metric:
            out.append(bool(float(metric.get("constraint_penalty", 0.0)) <= 1e-12))
        else:
            out.append(True)
    return out


def _resolve_constraint_violations(
    constraint_violations: Optional[np.ndarray],
    metrics: Sequence[Dict[str, Any]],
    num_solutions: int,
) -> np.ndarray:
    if constraint_violations is not None:
        arr = np.asarray(constraint_violations, dtype=float).reshape(-1)
        out = np.zeros((num_solutions,), dtype=float)
        limit = min(num_solutions, arr.size)
        out[:limit] = arr[:limit]
        return out
    out = np.zeros((num_solutions,), dtype=float)
    for i in range(num_solutions):
        metric = metrics[i] if i < len(metrics) else {}
        out[i] = float(metric.get("constraint_violation", metric.get("constraint_penalty", 0.0)))
    return out


def _optional_float(value: Any) -> Any:
    if value is None:
        return "None"
    try:
        return float(value)
    except Exception:
        return "None"


def _optional_int(value: Any) -> Any:
    if value is None:
        return "None"
    try:
        return int(value)
    except Exception:
        return "None"


def _none_text_or_float(value: Any) -> Any:
    if value is None:
        return "None"
    try:
        return float(value)
    except Exception:
        return "None"
