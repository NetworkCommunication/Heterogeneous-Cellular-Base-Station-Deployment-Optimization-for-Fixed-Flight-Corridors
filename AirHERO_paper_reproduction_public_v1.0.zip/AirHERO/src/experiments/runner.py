﻿from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from src.algorithms.improved_mopso import run_improved_mopso_scaffold
from src.data.city_map_generator import generate_city_map
from src.data.route_source import build_air_route_from_config
from src.experiments.results_exporter import save_results
from src.plotting.table_export import export_summary_table
from src.propagation.sector_geometry import validate_proposed_sector_config
from src.utils.config import get_default_config, init_channel_params, load_and_merge_config


def run_experiment(
    config_path: Optional[str] = None,
    seed: int = 42,
    results_dir: str = "artifacts/run",
    verbose: bool = True,              # 是否打印详细运行信息
    use_real_map: Optional[bool] = None,  # 是否使用真实地图
    real_map_path: Optional[str] = None,  # 真实地图路径
    real_clip_bbox: Optional[List[float]] = None,   # 真实地图裁剪范围
) -> Dict[str, float]:
    """Run one experiment and persist reproducible artifacts."""
    rng = np.random.default_rng(seed)
    output_dir = Path(results_dir)             
    output_dir.mkdir(parents=True, exist_ok=True)

    start = time.time()
    config = load_and_merge_config(get_default_config(), config_path)
    if use_real_map is not None:
        config["map"]["useRealMap"] = bool(use_real_map)
    if real_map_path is not None:
        config["map"]["realMapPath"] = real_map_path
    if real_clip_bbox is not None:
        config["map"]["realClipBbox"] = [float(v) for v in real_clip_bbox]

    method = str(config.get("experiment", {}).get("method", "proposed")).lower().strip()
    if method != "proposed":
        raise ValueError(f"Unsupported experiment.method: {method}")
    validate_proposed_sector_config(config, method_name=method)

    if verbose:
        print("==================================================")
        print("TEVC Two-Stage Heterogeneous Deployment")
        print("==================================================")
        print(f"- method: {method}")
        print(f"- seed: {seed}")

    city_map = generate_city_map(config, rng)      # 生成城市环境模型
    if bool(config["pso"].get("autoSyncMapBounds", True)):
        pso_max = config["pso"].get("maxPosition", [0.0, 0.0, 45.0])
        if isinstance(pso_max, list) and len(pso_max) >= 3:
            pso_max[0] = float(city_map.size_x)
            pso_max[1] = float(city_map.size_y)
            config["pso"]["maxPosition"] = pso_max

    route_source_result = build_air_route_from_config(
        config=config,
        city_map=city_map,
        rng=rng,
        output_dir=output_dir,
    )
    air_route = route_source_result.air_route   # 根据配置选择真实/POI生成/代理生成航线
    config["runtimeRouteSource"] = route_source_result.metadata
    channel_params = init_channel_params(config)              # 初始化无线信道参数

    intermediate_metrics: Dict[str, float] = {
        "num_buildings": float(len(city_map.buildings)),
        "num_test_points": float(air_route.test_points.shape[0]),
        "route_source_code": float(route_source_result.metadata.get("route_source_code", -1.0)),
        "generated_future_route_count": float(route_source_result.metadata.get("generated_route_count", 0.0)),
        "generated_poi_count": float(route_source_result.metadata.get("generated_poi_count", 0.0)),
        "unreachable_target_count": float(route_source_result.metadata.get("unreachable_target_count", 0.0)),
    }

    if verbose:                                        #输出日志
        print(
            "- route source: "
            f"{route_source_result.metadata.get('route_source')} "
            f"({route_source_result.metadata.get('route_source_detail')})"
        )
        if route_source_result.metadata.get("warning"):
            print(f"  warning: {route_source_result.metadata['warning']}")
        if route_source_result.metadata.get("route_random_seed") is not None:
            print(f"  route random seed: {route_source_result.metadata['route_random_seed']}")
        print(f"  route count: {route_source_result.metadata.get('generated_route_count', 0)}")
        print("- running proposed method: stage-1 + stage-2 + stagnation-aware MOPSO")
    pso_result, proposed_meta = run_improved_mopso_scaffold(
        config=config,
        test_points=air_route.test_points,
        city_map=city_map,
        channel_params=channel_params,
        rng=rng,
        verbose=verbose,
    )
    intermediate_metrics.update(proposed_meta)

    if pso_result.init_stats is not None:
        intermediate_metrics.update({f"init_{k}": float(v) for k, v in pso_result.init_stats.items()})

    elapsed_time = time.time() - start
    save_cfg = config.get("save", {})

    if bool(save_cfg.get("saveFigures", True)):
        from src.plotting.visualization import visualize_results

        visualize_results(                                               # 可视化结果
            city_map=city_map,
            air_route=air_route,
            pso_result=pso_result,
            config=config,
            results_dir=output_dir,
            channel_params=channel_params,
        )

    if bool(save_cfg.get("saveData", True)) or bool(save_cfg.get("saveReport", True)):
        save_results(
            city_map=city_map,
            air_route=air_route,
            pso_result=pso_result,
            config=config,
            results_dir=output_dir,
            channel_params=channel_params,
            elapsed_time=elapsed_time,
        )

    summary: Dict[str, float] = {
        "seed": float(seed),
        "elapsed_seconds": float(elapsed_time),
        "best_fitness": float(pso_result.best_fitness),
        "num_test_points": float(air_route.test_points.shape[0]),
        "num_buildings": float(len(city_map.buildings)),
        "convergence_iteration": float(pso_result.convergence_iteration),
        "route_source_code": float(route_source_result.metadata.get("route_source_code", -1.0)),
        "generated_future_route_count": float(route_source_result.metadata.get("generated_route_count", 0.0)),
    }

    metadata: Dict[str, Any] = {
        "seed": seed,
        "method": method,
        "config_path": config_path,
        "results_dir": str(output_dir.resolve()),
        "summary": summary,
        "intermediate_metrics": intermediate_metrics,
        "route_source": route_source_result.metadata,
    }

    if bool(save_cfg.get("saveIntermediateMetrics", True)):
        with open(output_dir / "intermediate_metrics.json", "w", encoding="utf-8") as f:
            json.dump(intermediate_metrics, f, ensure_ascii=False, indent=2)

    with open(output_dir / "run_metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)

    export_summary_table(summary, output_dir / "summary_table.csv")

    if verbose:
        print(f"- best fitness: {summary['best_fitness']:.4f}")
        if pso_result.init_stats:
            print("- initialization stats:")
            for k, v in pso_result.init_stats.items():
                print(f"    {k}: {v:.4f}")
        print(f"- elapsed: {summary['elapsed_seconds']:.2f}s")
        print(f"- artifacts: {output_dir.resolve()}")

    return summary
