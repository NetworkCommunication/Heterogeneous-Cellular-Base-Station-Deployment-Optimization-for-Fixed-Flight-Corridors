from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from src.data.types import Config


DEFAULT_OBJECTIVE_NAMES = [
    "handover_count",
    "deployment_cost",
    "existing_route_continuity_loss",
    "future_route_continuity_loss",
]
DEFAULT_OBJECTIVE_DIRECTIONS = ["min", "min", "min", "min"]


@dataclass
class ObjectiveSetRecord:
    """Final Pareto set produced by one method under one seed."""

    seed: int
    method_name: str
    group: str
    objectives: np.ndarray


@dataclass
class MultiObjectiveMetricResult:
    """Post-experiment HV/GD/IGD outputs and shared metadata."""

    per_run_rows: List[Dict[str, Any]]
    summary_rows: List[Dict[str, Any]]
    comparison_rows: List[Dict[str, Any]]
    metadata: Dict[str, Any]


def evaluate_multiobjective_metrics(
    records: Sequence[ObjectiveSetRecord],
    config: Config,
) -> MultiObjectiveMetricResult:
    """Compute HV, GD, and IGD from final Pareto archives.

    The optimizer already stores all Pareto objectives as minimization values.
    This post-processing layer still reads objective directions explicitly from
    config so future mixed-direction objectives are not handled by assumption.
    If a true Pareto front is unavailable, the reference set is the empirical
    nondominated front obtained by merging all final archives across methods
    and seeds.
    """
    metrics_cfg = config.get("multiObjectiveMetrics", {})
    names = list(metrics_cfg.get("objectiveNames", DEFAULT_OBJECTIVE_NAMES))
    directions = [str(d).lower() for d in metrics_cfg.get("objectiveDirections", DEFAULT_OBJECTIVE_DIRECTIONS)]
    if len(names) != len(directions):
        raise ValueError("multiObjectiveMetrics.objectiveNames and objectiveDirections must have the same length")

    valid_records = [_sanitize_record(r, expected_dim=len(names)) for r in records]
    valid_records = [r for r in valid_records if r.objectives.size > 0]
    if not valid_records:
        metadata = {
            "objective_names": names,
            "objective_directions": directions,
            "reference_front_type": "empirical_merged_nondominated",
            "reference_front_size": 0,
            "normalization_enabled": bool(metrics_cfg.get("normalization", {}).get("enabled", True)),
        }
        return MultiObjectiveMetricResult([], [], [], metadata)

    converted_by_record = [
        ObjectiveSetRecord(
            seed=r.seed,
            method_name=r.method_name,
            group=r.group,
            objectives=convert_objectives_to_minimization(r.objectives, directions),
        )
        for r in valid_records
    ]

    merged = np.vstack([r.objectives for r in converted_by_record])
    reference_raw = merged[nondominated_mask(merged)]

    norm_cfg = metrics_cfg.get("normalization", {})
    normalization_enabled = bool(norm_cfg.get("enabled", True))
    norm_min, norm_max = _build_shared_normalization_range(
        objective_sets=[r.objectives for r in converted_by_record] + [reference_raw],
        normalization_enabled=normalization_enabled,
        configured_min=norm_cfg.get("min", None),
        configured_max=norm_cfg.get("max", None),
    )

    normalized_records = [
        ObjectiveSetRecord(
            seed=r.seed,
            method_name=r.method_name,
            group=r.group,
            objectives=normalize_minimization_objectives(r.objectives, norm_min, norm_max, normalization_enabled),
        )
        for r in converted_by_record
    ]
    reference_norm = normalize_minimization_objectives(reference_raw, norm_min, norm_max, normalization_enabled)
    reference_norm = reference_norm[nondominated_mask(reference_norm)]

    hv_cfg = metrics_cfg.get("hypervolume", {})
    reference_point = _resolve_hv_reference_point(
        all_points=np.vstack([r.objectives for r in normalized_records] + [reference_norm]),
        configured_reference=hv_cfg.get("referencePoint", None),
        auto_margin=float(hv_cfg.get("autoReferenceMargin", 0.05)),
    )
    max_exact_points = int(hv_cfg.get("maxExactPoints", 16))
    num_mc_samples = int(hv_cfg.get("numSamples", 120000))
    hv_seed = int(hv_cfg.get("seed", 2026))

    per_run_rows: List[Dict[str, Any]] = []
    for rec in normalized_records:
        approx = rec.objectives[nondominated_mask(rec.objectives)]
        hv_value, hv_method = hypervolume_minimization(
            approx,
            reference_point,
            max_exact_points=max_exact_points,
            num_samples=num_mc_samples,
            seed=hv_seed,
        )
        gd_value = generational_distance(approx, reference_norm)
        igd_value = inverted_generational_distance(approx, reference_norm)
        per_run_rows.append(
            {
                "seed": float(rec.seed),
                "method_name": rec.method_name,
                "group": rec.group,
                "hv": float(hv_value),
                "gd": float(gd_value),
                "igd": float(igd_value),
                "num_archive_points": float(rec.objectives.shape[0]),
                "num_nondominated_points": float(approx.shape[0]),
                "hv_method": hv_method,
                "reference_front_type": "empirical_merged_nondominated",
                "reference_front_size": float(reference_norm.shape[0]),
                "objective_directions": json.dumps(directions),
                "objective_names": json.dumps(names),
                "normalization_enabled": normalization_enabled,
                "normalization_min": json.dumps([float(v) for v in norm_min.tolist()]),
                "normalization_max": json.dumps([float(v) for v in norm_max.tolist()]),
                "hv_reference_point": json.dumps([float(v) for v in reference_point.tolist()]),
            }
        )

    summary_rows = summarize_metric_rows(per_run_rows)
    comparison_rows = build_metric_comparison_rows(summary_rows)
    metadata = {
        "objective_names": names,
        "objective_directions": directions,
        "objective_convention_for_metrics": "minimization",
        "normalization_enabled": normalization_enabled,
        "normalization_min": [float(v) for v in norm_min.tolist()],
        "normalization_max": [float(v) for v in norm_max.tolist()],
        "reference_front_type": "empirical_merged_nondominated",
        "reference_front_size": int(reference_norm.shape[0]),
        "hv_reference_point": [float(v) for v in reference_point.tolist()],
        "hv_note": "HV is exact for 2D or small fronts; otherwise deterministic Monte Carlo is logged in hv_method.",
        "gd_definition": "sqrt(mean(min Euclidean distance from approximation points to empirical reference front)^2)",
        "igd_definition": "sqrt(mean(min Euclidean distance from empirical reference points to approximation set)^2)",
    }
    return MultiObjectiveMetricResult(per_run_rows, summary_rows, comparison_rows, metadata)


def convert_objectives_to_minimization(objectives: np.ndarray, directions: Sequence[str]) -> np.ndarray:
    """Convert configured objective directions to a minimization convention."""
    arr = np.asarray(objectives, dtype=float)
    if arr.ndim != 2:
        raise ValueError("Objective array must have shape [num_points, num_objectives]")
    if arr.shape[1] != len(directions):
        raise ValueError("Objective dimension does not match configured objectiveDirections")

    out = arr.copy()
    for j, direction in enumerate(directions):
        d = str(direction).lower().strip()
        if d == "min":
            continue
        if d == "max":
            out[:, j] = -out[:, j]
            continue
        raise ValueError(f"Unsupported objective direction: {direction!r}; expected 'min' or 'max'")
    return out


def normalize_minimization_objectives(
    objectives: np.ndarray,
    norm_min: np.ndarray,
    norm_max: np.ndarray,
    enabled: bool,
) -> np.ndarray:
    """Apply a shared min-max normalization range across all methods."""
    arr = np.asarray(objectives, dtype=float)
    if not enabled:
        return arr.copy()
    span = np.maximum(np.asarray(norm_max, dtype=float) - np.asarray(norm_min, dtype=float), 1e-12)
    return (arr - norm_min[None, :]) / span[None, :]


def nondominated_mask(objectives: np.ndarray) -> np.ndarray:
    """Return nondominated mask for minimization objectives."""
    arr = np.asarray(objectives, dtype=float)
    if arr.size == 0:
        return np.zeros((arr.shape[0] if arr.ndim >= 1 else 0,), dtype=bool)
    n = arr.shape[0]
    keep = np.ones((n,), dtype=bool)
    for i in range(n):
        if not keep[i]:
            continue
        for j in range(n):
            if i == j or not keep[j]:
                continue
            if np.all(arr[j] <= arr[i]) and np.any(arr[j] < arr[i]):
                keep[i] = False
                break
    return keep


def hypervolume_minimization(
    points: np.ndarray,
    reference_point: np.ndarray,
    max_exact_points: int = 16,
    num_samples: int = 120000,
    seed: int = 2026,
) -> Tuple[float, str]:
    """Compute minimization hypervolume bounded by a worse reference point."""
    pts = _prepare_points_for_hv(points, reference_point)
    if pts.size == 0:
        return 0.0, "empty"

    if pts.shape[1] == 2:
        return float(_hypervolume_2d_exact(pts, reference_point)), "exact_2d"

    if pts.shape[0] <= int(max_exact_points):
        return float(_hypervolume_inclusion_exclusion_exact(pts, reference_point)), "exact_inclusion_exclusion"

    return float(_hypervolume_deterministic_monte_carlo(pts, reference_point, num_samples, seed)), "deterministic_monte_carlo"


def generational_distance(approximation: np.ndarray, reference_front: np.ndarray) -> float:
    """GD: RMS distance from each approximation point to the reference front."""
    return _rms_nearest_distance(approximation, reference_front)


def inverted_generational_distance(approximation: np.ndarray, reference_front: np.ndarray) -> float:
    """IGD: RMS distance from each reference-front point to the approximation set."""
    return _rms_nearest_distance(reference_front, approximation)


def summarize_metric_rows(rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Aggregate HV/GD/IGD mean and std per method."""
    by_method: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows:
        by_method.setdefault(str(row["method_name"]), []).append(row)

    out: List[Dict[str, Any]] = []
    for method, group_rows in by_method.items():
        first = group_rows[0]
        summary: Dict[str, Any] = {
            "method_name": method,
            "group": first.get("group", ""),
            "num_runs": float(len(group_rows)),
            "reference_front_type": first.get("reference_front_type", "empirical_merged_nondominated"),
            "reference_front_size": first.get("reference_front_size", 0.0),
            "hv_reference_point": first.get("hv_reference_point", ""),
        }
        for metric in ["hv", "gd", "igd", "num_archive_points", "num_nondominated_points"]:
            vals = np.asarray([float(r.get(metric, 0.0)) for r in group_rows], dtype=float)
            summary[f"{metric}_mean"] = float(np.mean(vals))
            summary[f"{metric}_std"] = float(np.std(vals, ddof=1)) if vals.size > 1 else 0.0
        out.append(summary)
    out.sort(key=lambda r: (0 if str(r.get("group", "")) == "main_group" else 1, str(r["method_name"])))
    return out


def build_metric_comparison_rows(summary_rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Create a compact publication-facing metric table with ranks."""
    rows = [dict(r) for r in summary_rows]
    hv_rank = _rank_values([float(r.get("hv_mean", 0.0)) for r in rows], higher_is_better=True)
    gd_rank = _rank_values([float(r.get("gd_mean", 0.0)) for r in rows], higher_is_better=False)
    igd_rank = _rank_values([float(r.get("igd_mean", 0.0)) for r in rows], higher_is_better=False)

    out: List[Dict[str, Any]] = []
    for i, row in enumerate(rows):
        out.append(
            {
                "method_name": row.get("method_name", ""),
                "group": row.get("group", ""),
                "hv_mean": row.get("hv_mean", 0.0),
                "hv_std": row.get("hv_std", 0.0),
                "hv_rank": float(hv_rank[i]),
                "gd_mean": row.get("gd_mean", 0.0),
                "gd_std": row.get("gd_std", 0.0),
                "gd_rank": float(gd_rank[i]),
                "igd_mean": row.get("igd_mean", 0.0),
                "igd_std": row.get("igd_std", 0.0),
                "igd_rank": float(igd_rank[i]),
            }
        )
    return out


def save_multiobjective_metric_outputs(
    result: MultiObjectiveMetricResult,
    output_dir: Path,
    save_csv_fn: Any,
    plot_path: Optional[Path] = None,
) -> Dict[str, str]:
    """Save per-seed, summary, comparison, metadata, and optional metric plot."""
    output_dir.mkdir(parents=True, exist_ok=True)
    per_seed_csv = output_dir / "multiobjective_metrics_per_seed.csv"
    summary_csv = output_dir / "multiobjective_metrics_summary.csv"
    comparison_csv = output_dir / "multiobjective_metric_comparison_table.csv"
    metadata_json = output_dir / "multiobjective_metrics_metadata.json"

    save_csv_fn(result.per_run_rows, per_seed_csv)
    save_csv_fn(result.summary_rows, summary_csv)
    save_csv_fn(result.comparison_rows, comparison_csv)
    with open(metadata_json, "w", encoding="utf-8") as f:
        json.dump(result.metadata, f, ensure_ascii=False, indent=2)

    outputs = {
        "multiobjective_metrics_per_seed_csv": str(per_seed_csv.resolve()),
        "multiobjective_metrics_summary_csv": str(summary_csv.resolve()),
        "multiobjective_metric_comparison_csv": str(comparison_csv.resolve()),
        "multiobjective_metrics_metadata_json": str(metadata_json.resolve()),
    }
    if plot_path is not None and result.summary_rows:
        _plot_metric_bars(result.summary_rows, plot_path)
        outputs["multiobjective_metric_plot"] = str(plot_path.resolve())
    return outputs


def _sanitize_record(record: ObjectiveSetRecord, expected_dim: int) -> ObjectiveSetRecord:
    arr = np.asarray(record.objectives, dtype=float)
    if arr.size == 0:
        arr = np.zeros((0, expected_dim), dtype=float)
    if arr.ndim != 2:
        raise ValueError("Pareto objective archive must be a 2D array")
    if arr.shape[1] != expected_dim:
        raise ValueError(
            f"Pareto objective archive dimension {arr.shape[1]} does not match configured dimension {expected_dim}"
        )
    finite_mask = np.isfinite(arr).all(axis=1)
    return ObjectiveSetRecord(
        seed=record.seed,
        method_name=record.method_name,
        group=record.group,
        objectives=arr[finite_mask],
    )


def _build_shared_normalization_range(
    objective_sets: Sequence[np.ndarray],
    normalization_enabled: bool,
    configured_min: Optional[Sequence[float]],
    configured_max: Optional[Sequence[float]],
) -> Tuple[np.ndarray, np.ndarray]:
    merged = np.vstack([np.asarray(x, dtype=float) for x in objective_sets if np.asarray(x).size > 0])
    if not normalization_enabled:
        dim = merged.shape[1]
        return np.zeros((dim,), dtype=float), np.ones((dim,), dtype=float)

    if configured_min is not None and configured_max is not None:
        lo = np.asarray(configured_min, dtype=float)
        hi = np.asarray(configured_max, dtype=float)
        if lo.shape != hi.shape or lo.size != merged.shape[1]:
            raise ValueError("Configured normalization min/max must match objective dimension")
        return lo, hi

    return np.min(merged, axis=0), np.max(merged, axis=0)


def _resolve_hv_reference_point(
    all_points: np.ndarray,
    configured_reference: Optional[Sequence[float]],
    auto_margin: float,
) -> np.ndarray:
    if configured_reference is not None:
        ref = np.asarray(configured_reference, dtype=float)
        if ref.ndim != 1 or ref.size != all_points.shape[1]:
            raise ValueError("hypervolume.referencePoint must match objective dimension")
        return ref

    worst = np.max(np.asarray(all_points, dtype=float), axis=0)
    best = np.min(np.asarray(all_points, dtype=float), axis=0)
    span = np.maximum(worst - best, 1.0)
    return worst + max(float(auto_margin), 0.0) * span


def _prepare_points_for_hv(points: np.ndarray, reference_point: np.ndarray) -> np.ndarray:
    pts = np.asarray(points, dtype=float)
    ref = np.asarray(reference_point, dtype=float)
    if pts.size == 0:
        return np.zeros((0, ref.size), dtype=float)
    if pts.ndim != 2 or pts.shape[1] != ref.size:
        raise ValueError("HV points must have shape [num_points, num_objectives]")
    finite_mask = np.isfinite(pts).all(axis=1)
    inside_mask = np.all(pts < ref[None, :], axis=1)
    pts = pts[finite_mask & inside_mask]
    if pts.size == 0:
        return np.zeros((0, ref.size), dtype=float)
    return pts[nondominated_mask(pts)]


def _hypervolume_2d_exact(points: np.ndarray, reference_point: np.ndarray) -> float:
    pts = points[nondominated_mask(points)]
    order = np.argsort(pts[:, 0], kind="stable")
    pts = pts[order]
    hv = 0.0
    for i in range(pts.shape[0]):
        next_x = float(pts[i + 1, 0]) if i + 1 < pts.shape[0] else float(reference_point[0])
        width = max(next_x - float(pts[i, 0]), 0.0)
        height = max(float(reference_point[1]) - float(pts[i, 1]), 0.0)
        hv += width * height
    return float(max(hv, 0.0))


def _hypervolume_inclusion_exclusion_exact(points: np.ndarray, reference_point: np.ndarray) -> float:
    pts = points[nondominated_mask(points)]
    n = int(pts.shape[0])
    hv = 0.0
    # Exact union of dominated hyperrectangles [point, reference] for small fronts.
    for mask in range(1, 1 << n):
        chosen = [i for i in range(n) if mask & (1 << i)]
        lower = np.max(pts[chosen], axis=0)
        side = np.maximum(reference_point - lower, 0.0)
        vol = float(np.prod(side))
        if len(chosen) % 2 == 1:
            hv += vol
        else:
            hv -= vol
    return float(max(hv, 0.0))


def _hypervolume_deterministic_monte_carlo(
    points: np.ndarray,
    reference_point: np.ndarray,
    num_samples: int,
    seed: int,
) -> float:
    pts = points[nondominated_mask(points)]
    lower = np.min(pts, axis=0)
    ref = np.asarray(reference_point, dtype=float)
    side = np.maximum(ref - lower, 0.0)
    box_volume = float(np.prod(side))
    if box_volume <= 0.0:
        return 0.0

    rng = np.random.default_rng(int(seed))
    samples = lower[None, :] + rng.random((max(int(num_samples), 1), pts.shape[1])) * side[None, :]
    dominated = np.any(np.all(pts[:, None, :] <= samples[None, :, :], axis=2), axis=0)
    return float(box_volume * np.mean(dominated.astype(float)))


def _rms_nearest_distance(source: np.ndarray, target: np.ndarray) -> float:
    src = np.asarray(source, dtype=float)
    tgt = np.asarray(target, dtype=float)
    if src.size == 0 or tgt.size == 0:
        return float("inf")
    diff = src[:, None, :] - tgt[None, :, :]
    dist = np.linalg.norm(diff, axis=2)
    nearest = np.min(dist, axis=1)
    return float(np.sqrt(np.mean(np.square(nearest))))


def _rank_values(values: Sequence[float], higher_is_better: bool) -> List[int]:
    vals = np.asarray(values, dtype=float)
    order = np.argsort(-vals if higher_is_better else vals, kind="stable")
    ranks = np.zeros((vals.size,), dtype=int)
    for rank, idx in enumerate(order, start=1):
        ranks[int(idx)] = int(rank)
    return [int(x) for x in ranks.tolist()]


def _plot_metric_bars(summary_rows: Sequence[Dict[str, Any]], output_path: Path) -> None:
    import matplotlib.pyplot as plt

    names = [str(r.get("method_name", "")) for r in summary_rows]
    x = np.arange(len(names), dtype=float)
    fig, axes = plt.subplots(1, 3, figsize=(14.0, 4.6))
    specs = [
        ("hv", "HV (higher is better)"),
        ("gd", "GD (lower is better)"),
        ("igd", "IGD (lower is better)"),
    ]
    for ax, (metric, title) in zip(axes, specs):
        mean = np.asarray([float(r.get(f"{metric}_mean", 0.0)) for r in summary_rows], dtype=float)
        std = np.asarray([float(r.get(f"{metric}_std", 0.0)) for r in summary_rows], dtype=float)
        ax.bar(x, mean, yerr=std, capsize=3, color="#4C78A8", alpha=0.86)
        ax.set_title(title)
        ax.set_xticks(x)
        ax.set_xticklabels(names, rotation=35, ha="right", fontsize=8)
        ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)
