from __future__ import annotations

import csv
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

_MPL_CACHE = Path(".mplcache").resolve()
_MPL_CACHE.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(_MPL_CACHE))

import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Wedge

from src.algorithms.fitness_interface import build_station_type_plan_from_particle
from src.algorithms.heterogeneous_deployment import parse_station_types
from src.algorithms.particle_encoding import decode_particle_solution, is_extended_particle_array, spatial_view
from src.data.types import AirRoute, CityMap, Config, PSOResult
from src.propagation.a2g_probabilistic import compute_population_per_bs_rx_power_a2g_dbm
from src.propagation.low_fidelity_legacy import compute_population_per_bs_rx_power_legacy_dbm
from src.propagation.sector_geometry import compute_sector_gain_matrix_db, nearest_supported_sector_direction_deg


def save_sector_aware_outputs(
    city_map: CityMap,
    air_route: AirRoute,
    pso_result: PSOResult,
    config: Config,
    results_dir: Path,
    channel_params: Config,
) -> Dict[str, float]:
    """Save post-optimization sector-aware logs and plots.

    These diagnostics are intentionally posthoc: they do not change objective
    values, dominance, archive maintenance, or particle updates.
    """
    out_dir = Path(results_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    analysis = _build_sector_analysis(city_map, air_route, pso_result, config, channel_params)
    _write_station_export(analysis, out_dir / "sector_station_solution.csv")
    _write_route_status(analysis, out_dir / "sector_route_coverage_status.csv")
    _write_summary(analysis, out_dir / "sector_summary_metrics.json")
    _plot_deployment_map(analysis, city_map, air_route, out_dir / "sector_deployment_map.png")
    _plot_route_coverage_before_after(analysis, air_route, out_dir / "route_coverage_before_after.png")
    _plot_sector_heatmap(analysis, city_map, air_route, out_dir / "sector_aware_coverage_heatmap.png")
    _plot_per_route_status(analysis, out_dir / "per_route_coverage_status.png")
    return {f"posthoc_sector_{k}": float(v) for k, v in analysis["summary_numeric"].items()}


def build_best_station_rows(
    pso_result: PSOResult,
    config: Config,
    city_map: Optional[CityMap] = None,
    air_route: Optional[AirRoute] = None,
    channel_params: Optional[Config] = None,
) -> List[Dict[str, object]]:
    """Return final station rows, enriched with route coverage diagnostics when context is available."""
    base_rows = pso_result.decoded_solution or decode_particle_solution(pso_result.best_position, config)
    rows = [dict(r) for r in base_rows]
    beamwidth = float(config.get("channel", {}).get("sector_beamwidth_deg", 90.0))
    for row in rows:
        row.setdefault("sector_beamwidth_deg", beamwidth if str(row.get("station_type", "")).lower() == "5ga" else "")
        row.setdefault("covered_route_points", 0)
        row.setdefault("covered_route_point_indices", "[]")
        row.setdefault("covered_route_ids", "[]")
        row.setdefault("coverage_contribution", 0.0)

    if city_map is None or air_route is None or channel_params is None or air_route.test_points.size == 0:
        return rows

    analysis = _build_sector_analysis(city_map, air_route, pso_result, config, channel_params)
    by_id = {int(r["station_id"]): r for r in analysis["station_rows"]}
    for row in rows:
        sid = int(row["station_id"])
        extra = by_id.get(sid)
        if extra is None:
            continue
        row.update(
            {
                "sector_beamwidth_deg": extra["sector_beamwidth_deg"],
                "covered_route_points": extra["covered_route_points"],
                "covered_route_point_indices": extra["covered_route_point_indices"],
                "covered_route_ids": extra["covered_route_ids"],
                "coverage_contribution": extra["coverage_contribution"],
            }
        )
    return rows


def _build_sector_analysis(
    city_map: CityMap,
    air_route: AirRoute,
    pso_result: PSOResult,
    config: Config,
    channel_params: Config,
) -> Dict[str, Any]:
    best_position = spatial_view(pso_result.best_position)
    station_plan = build_station_type_plan_from_particle(config, pso_result.best_position)
    route_ids, route_indices = _assign_route_ids(air_route)
    threshold = float(channel_params.get("snrThreshold", 0.0))

    rx_enforced = _per_bs_rx_power(
        positions=best_position,
        test_points=air_route.test_points,
        city_map=city_map,
        channel_params=channel_params,
        station_plan=station_plan,
        enforce_sectors=True,
    )
    snr_enforced = _snr_from_rx(rx_enforced, channel_params)
    covered_enforced = snr_enforced >= threshold
    serving_idx = np.argmax(rx_enforced, axis=0) if rx_enforced.size > 0 else np.zeros((0,), dtype=int)

    rx_ignored = _per_bs_rx_power(
        positions=best_position,
        test_points=air_route.test_points,
        city_map=city_map,
        channel_params=channel_params,
        station_plan=station_plan,
        enforce_sectors=False,
    )
    covered_ignored = _snr_from_rx(rx_ignored, channel_params) >= threshold

    no_5ga_mask = ~np.asarray(station_plan.sector_station_mask, dtype=bool)
    covered_without_5ga = _coverage_from_station_subset(rx_enforced, no_5ga_mask, channel_params, threshold)

    existing_pos, existing_plan = _existing_station_position_and_plan(config, channel_params)
    if existing_pos.size > 0:
        rx_before = _per_bs_rx_power(
            positions=existing_pos,
            test_points=air_route.test_points,
            city_map=city_map,
            channel_params=channel_params,
            station_plan=existing_plan,
            enforce_sectors=True,
        )
        covered_before = _snr_from_rx(rx_before, channel_params) >= threshold
    else:
        covered_before = np.zeros((air_route.test_points.shape[0],), dtype=bool)

    _, inside_5ga = compute_sector_gain_matrix_db(
        positions=best_position[None, :, :],
        test_points=air_route.test_points,
        sector_station_mask=station_plan.sector_station_mask,
        sector_azimuths_deg=station_plan.sector_azimuths_deg,
        sector_beamwidth_deg=station_plan.sector_beamwidth_deg,
        outside_sector_mode="no_coverage",
        side_lobe_attenuation_db=0.0,
    )
    if inside_5ga.size > 0 and np.any(station_plan.sector_station_mask):
        inside_any_5ga = np.any(inside_5ga[0, station_plan.sector_station_mask, :], axis=0)
    else:
        inside_any_5ga = np.zeros((air_route.test_points.shape[0],), dtype=bool)

    station_rows = _station_rows(
        pso_result=pso_result,
        config=config,
        station_plan=station_plan,
        serving_idx=serving_idx,
        covered_mask=covered_enforced,
        route_ids=route_ids,
        route_indices=route_indices,
    )
    route_rows = _route_rows(
        route_ids=route_ids,
        route_indices=route_indices,
        covered_before=covered_before,
        covered_after=covered_enforced,
        covered_without_5ga=covered_without_5ga,
        covered_ignored=covered_ignored,
        inside_any_5ga=inside_any_5ga,
    )
    summary_numeric, summary = _summary_metrics(
        station_plan=station_plan,
        route_rows=route_rows,
        covered_enforced=covered_enforced,
        covered_ignored=covered_ignored,
        covered_without_5ga=covered_without_5ga,
        inside_any_5ga=inside_any_5ga,
        total_points=air_route.test_points.shape[0],
    )
    return {
        "positions": best_position,
        "station_plan": station_plan,
        "station_rows": station_rows,
        "route_rows": route_rows,
        "route_ids": route_ids,
        "route_indices": route_indices,
        "snr_enforced": snr_enforced,
        "covered_before": covered_before,
        "covered_after": covered_enforced,
        "covered_without_5ga": covered_without_5ga,
        "covered_ignored": covered_ignored,
        "inside_any_5ga": inside_any_5ga,
        "summary": summary,
        "summary_numeric": summary_numeric,
    }


def _per_bs_rx_power(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    station_plan: Any,
    enforce_sectors: bool,
) -> np.ndarray:
    if positions.size == 0 or test_points.size == 0:
        return np.zeros((0, test_points.shape[0] if test_points.ndim == 2 else 0), dtype=float)
    sector_mask = station_plan.sector_station_mask if enforce_sectors else None
    sector_az = station_plan.sector_azimuths_deg if enforce_sectors else None
    mode = str(channel_params.get("lowFidelityModel", "a2g_probabilistic")).strip().lower()
    if mode in {"legacy", "legacy_low_fidelity"}:
        rx = compute_population_per_bs_rx_power_legacy_dbm(
            positions=positions[None, :, :],
            test_points=test_points,
            city_map=city_map,
            channel_params=channel_params,
            tx_power_offsets_db=station_plan.tx_power_offsets_db,
            coverage_boost_db=station_plan.coverage_boost_db,
            path_loss_offsets_db=station_plan.path_loss_offsets_db,
            nlos_penalty_factors=station_plan.nlos_penalty_factors,
            sector_station_mask=sector_mask,
            sector_azimuths_deg=sector_az,
            sector_beamwidth_deg=station_plan.sector_beamwidth_deg,
            outside_sector_mode=station_plan.outside_sector_mode,
            side_lobe_attenuation_db=station_plan.side_lobe_attenuation_db,
        )
    else:
        rx = compute_population_per_bs_rx_power_a2g_dbm(
            positions=positions[None, :, :],
            test_points=test_points,
            channel_params=channel_params,
            tx_power_offsets_db=station_plan.tx_power_offsets_db,
            coverage_boost_db=station_plan.coverage_boost_db,
            path_loss_offsets_db=station_plan.path_loss_offsets_db,
            sector_station_mask=sector_mask,
            sector_azimuths_deg=sector_az,
            sector_beamwidth_deg=station_plan.sector_beamwidth_deg,
            outside_sector_mode=station_plan.outside_sector_mode,
            side_lobe_attenuation_db=station_plan.side_lobe_attenuation_db,
        )[0]
    return np.asarray(rx[0], dtype=float)


def _snr_from_rx(rx_per_bs_dbm: np.ndarray, channel_params: Config) -> np.ndarray:
    rx = np.asarray(rx_per_bs_dbm, dtype=float)
    if rx.size == 0:
        return np.zeros((rx.shape[1] if rx.ndim == 2 else 0,), dtype=float)
    total_power_mw = np.sum(np.power(10.0, rx / 10.0), axis=0)
    return 10.0 * np.log10(total_power_mw + 1e-12) - float(channel_params.get("noisePower", -90.0))


def _coverage_from_station_subset(
    rx_per_bs_dbm: np.ndarray,
    station_mask: np.ndarray,
    channel_params: Config,
    threshold: float,
) -> np.ndarray:
    rx = np.asarray(rx_per_bs_dbm, dtype=float)
    mask = np.asarray(station_mask, dtype=bool)
    if rx.size == 0 or not np.any(mask):
        return np.zeros((rx.shape[1] if rx.ndim == 2 else 0,), dtype=bool)
    return _snr_from_rx(rx[mask, :], channel_params) >= float(threshold)


def _assign_route_ids(air_route: AirRoute) -> Tuple[np.ndarray, Dict[str, np.ndarray]]:
    points = np.asarray(air_route.test_points, dtype=float)
    n = int(points.shape[0]) if points.ndim == 2 else 0
    route_count = max(1, len(air_route.routes))
    labels = np.asarray([f"route_{i + 1:04d}" for i in range(route_count)], dtype=object)
    if n == 0:
        return np.zeros((0,), dtype=object), {str(v): np.zeros((0,), dtype=int) for v in labels.tolist()}

    if route_count == 1:
        route_ids = np.full((n,), labels[0], dtype=object)
    else:
        distances = np.zeros((route_count, n), dtype=float)
        for i, (start, end) in enumerate(air_route.routes):
            distances[i] = _distance_to_segment_xy(points[:, :2], np.asarray(start)[:2], np.asarray(end)[:2])
        idx = np.argmin(distances, axis=0)
        route_ids = labels[idx]

    route_indices: Dict[str, np.ndarray] = {}
    for label in labels.tolist():
        route_indices[str(label)] = np.where(route_ids == label)[0].astype(int)
    return route_ids, route_indices


def _distance_to_segment_xy(points_xy: np.ndarray, start_xy: np.ndarray, end_xy: np.ndarray) -> np.ndarray:
    p = np.asarray(points_xy, dtype=float)
    a = np.asarray(start_xy, dtype=float)
    b = np.asarray(end_xy, dtype=float)
    ab = b - a
    denom = max(float(np.dot(ab, ab)), 1e-12)
    t = np.clip(((p - a[None, :]) @ ab) / denom, 0.0, 1.0)
    proj = a[None, :] + t[:, None] * ab[None, :]
    return np.linalg.norm(p - proj, axis=1)


def _station_rows(
    pso_result: PSOResult,
    config: Config,
    station_plan: Any,
    serving_idx: np.ndarray,
    covered_mask: np.ndarray,
    route_ids: np.ndarray,
    route_indices: Dict[str, np.ndarray],
) -> List[Dict[str, object]]:
    decoded = pso_result.decoded_solution or decode_particle_solution(pso_result.best_position, config)
    total_covered = max(int(np.sum(covered_mask)), 1)
    rows: List[Dict[str, object]] = []
    for b, row in enumerate(decoded):
        mask = (serving_idx == b) & covered_mask
        point_idx = np.where(mask)[0].astype(int)
        covered_routes = sorted({str(route_ids[i]) for i in point_idx.tolist()}) if route_ids.size > 0 else []
        is_5ga = str(row.get("station_type", "")).strip().lower() == "5ga"
        rows.append(
            {
                "station_id": int(row["station_id"]),
                "x": float(row["x"]),
                "y": float(row["y"]),
                "z": float(row.get("z", 0.0)),
                "station_type": str(row["station_type"]),
                "station_type_index": int(row.get("station_type_index", b)),
                "sector_direction_index": row.get("sector_direction_index", "") if is_5ga else "",
                "sector_azimuth_deg": row.get("sector_azimuth_deg", "") if is_5ga else "",
                "sector_beamwidth_deg": float(station_plan.sector_beamwidth_deg) if is_5ga else "",
                "covered_route_points": int(point_idx.size),
                "covered_route_point_indices": json.dumps(point_idx.tolist()),
                "covered_route_ids": json.dumps(covered_routes, ensure_ascii=False),
                "coverage_contribution": float(point_idx.size / total_covered),
                "route_id_basis": "posthoc_nearest_route_geometry" if len(route_indices) > 1 else "single_route",
            }
        )
    return rows


def _route_rows(
    route_ids: np.ndarray,
    route_indices: Dict[str, np.ndarray],
    covered_before: np.ndarray,
    covered_after: np.ndarray,
    covered_without_5ga: np.ndarray,
    covered_ignored: np.ndarray,
    inside_any_5ga: np.ndarray,
) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    for route_id, idx in route_indices.items():
        n = int(idx.size)
        if n <= 0:
            before = after = without_5ga = ignored = main_lobe = 0.0
        else:
            before = float(np.mean(covered_before[idx].astype(float)))
            after = float(np.mean(covered_after[idx].astype(float)))
            without_5ga = float(np.mean(covered_without_5ga[idx].astype(float)))
            ignored = float(np.mean(covered_ignored[idx].astype(float)))
            main_lobe = float(np.mean((covered_after[idx] & inside_any_5ga[idx]).astype(float)))
        rows.append(
            {
                "route_id": str(route_id),
                "route_point_count": n,
                "covered_before_count": int(np.sum(covered_before[idx])) if n > 0 else 0,
                "covered_after_count": int(np.sum(covered_after[idx])) if n > 0 else 0,
                "coverage_rate_before": before,
                "coverage_rate_after": after,
                "coverage_rate_without_5ga": without_5ga,
                "coverage_rate_sector_ignored": ignored,
                "coverage_improvement_after_minus_before": after - before,
                "coverage_improvement_due_to_5ga": after - without_5ga,
                "sector_constraint_loss": ignored - after,
                "covered_by_5ga_main_lobe_rate": main_lobe,
                "status": "covered" if after >= 0.999 else ("partial" if after > 0.0 else "uncovered"),
            }
        )
    return rows


def _summary_metrics(
    station_plan: Any,
    route_rows: Sequence[Dict[str, object]],
    covered_enforced: np.ndarray,
    covered_ignored: np.ndarray,
    covered_without_5ga: np.ndarray,
    inside_any_5ga: np.ndarray,
    total_points: int,
) -> Tuple[Dict[str, float], Dict[str, object]]:
    sector_mask = np.asarray(station_plan.sector_station_mask, dtype=bool)
    selected_az = np.asarray(station_plan.sector_azimuths_deg, dtype=float)[sector_mask]
    direction_distribution: Dict[str, int] = {}
    for az in selected_az.tolist():
        key = f"{float(az):.1f}"
        direction_distribution[key] = direction_distribution.get(key, 0) + 1
    enforced_rate = float(np.mean(covered_enforced.astype(float))) if total_points > 0 else 0.0
    ignored_rate = float(np.mean(covered_ignored.astype(float))) if total_points > 0 else 0.0
    without_5ga_rate = float(np.mean(covered_without_5ga.astype(float))) if total_points > 0 else 0.0
    main_lobe_rate = float(np.mean((covered_enforced & inside_any_5ga).astype(float))) if total_points > 0 else 0.0
    avg_5ga_improvement = (
        float(np.mean([float(r["coverage_improvement_due_to_5ga"]) for r in route_rows])) if route_rows else 0.0
    )
    avg_constraint_loss = float(np.mean([float(r["sector_constraint_loss"]) for r in route_rows])) if route_rows else 0.0
    numeric = {
        "num_deployed_5ga_stations": float(np.sum(sector_mask.astype(float))),
        "route_points_covered_by_5ga_main_lobes_rate": main_lobe_rate,
        "average_route_coverage_improvement_due_to_5ga": avg_5ga_improvement,
        "coverage_loss_sector_ignored_vs_enforced": ignored_rate - enforced_rate,
        "average_route_coverage_loss_sector_ignored_vs_enforced": avg_constraint_loss,
        "coverage_rate_sector_enforced": enforced_rate,
        "coverage_rate_sector_ignored": ignored_rate,
        "coverage_rate_without_5ga": without_5ga_rate,
    }
    summary: Dict[str, object] = dict(numeric)
    summary["selected_sector_direction_distribution"] = direction_distribution
    summary["comparison_definitions"] = {
        "before": "existing stations only; zero coverage if no existing stations are configured",
        "without_5ga": "final deployment with all 5GA received-power contributions removed",
        "sector_ignored": "final deployment with 5GA sector masks disabled, equivalent to omnidirectional 5GA",
        "sector_enforced": "final deployment with configured 5GA sector constraints",
    }
    return numeric, summary


def _existing_station_position_and_plan(config: Config, channel_params: Config) -> Tuple[np.ndarray, Any]:
    raw = np.asarray(config.get("heterogeneousDeployment", {}).get("existingStations", []), dtype=float)
    if raw.size == 0:
        return np.zeros((0, 3), dtype=float), _ManualStationPlan.empty(channel_params)
    if raw.ndim == 1:
        raw = raw.reshape(1, -1)
    if raw.shape[1] == 2:
        default_z = float(config.get("pso", {}).get("minPosition", [0.0, 0.0, 10.0])[2])
        raw = np.hstack([raw, np.full((raw.shape[0], 1), default_z, dtype=float)])
    positions = raw[:, :3]
    return positions, _ManualStationPlan.from_existing(config, positions.shape[0], channel_params)


class _ManualStationPlan:
    def __init__(
        self,
        names: List[str],
        tx: np.ndarray,
        costs: np.ndarray,
        boost: np.ndarray,
        path_offsets: np.ndarray,
        nlos: np.ndarray,
        capacity: np.ndarray,
        sector_mask: np.ndarray,
        sector_azimuths: np.ndarray,
        beamwidth: float,
        outside_mode: str,
        side_lobe: float,
    ) -> None:
        self.station_type_names = names
        self.station_type_indices = np.arange(len(names), dtype=int)
        self.tx_power_offsets_db = tx
        self.deployment_costs = costs
        self.coverage_boost_db = boost
        self.path_loss_offsets_db = path_offsets
        self.nlos_penalty_factors = nlos
        self.capacity_units = capacity
        self.sector_station_mask = sector_mask
        self.sector_azimuths_deg = sector_azimuths
        self.sector_beamwidth_deg = beamwidth
        self.outside_sector_mode = outside_mode
        self.side_lobe_attenuation_db = side_lobe

    @classmethod
    def empty(cls, channel_params: Config) -> "_ManualStationPlan":
        return cls(
            [],
            np.zeros((0,), dtype=float),
            np.zeros((0,), dtype=float),
            np.zeros((0,), dtype=float),
            np.zeros((0,), dtype=float),
            np.zeros((0,), dtype=float),
            np.zeros((0,), dtype=float),
            np.zeros((0,), dtype=bool),
            np.zeros((0,), dtype=float),
            float(channel_params.get("sector_beamwidth_deg", 90.0)),
            str(channel_params.get("outside_sector_mode", "no_coverage")),
            float(channel_params.get("side_lobe_attenuation_db", 30.0)),
        )

    @classmethod
    def from_existing(cls, config: Config, num_stations: int, channel_params: Config) -> "_ManualStationPlan":
        specs = {str(s.name).lower(): s for s in parse_station_types(config)}
        raw_types = list(config.get("heterogeneousDeployment", {}).get("existingStationTypes", []))
        names = [str(raw_types[i]) if i < len(raw_types) and str(raw_types[i]).strip() else "5G" for i in range(num_stations)]
        defaults = specs.get("5g")
        tx = np.zeros((num_stations,), dtype=float)
        costs = np.ones((num_stations,), dtype=float)
        boost = np.zeros((num_stations,), dtype=float)
        path_offsets = np.zeros((num_stations,), dtype=float)
        nlos = np.ones((num_stations,), dtype=float)
        capacity = np.ones((num_stations,), dtype=float)
        for i, name in enumerate(names):
            spec = specs.get(str(name).lower(), defaults)
            if spec is None:
                continue
            tx[i] = spec.tx_power_offset_db
            costs[i] = max(spec.deployment_cost, 1e-9)
            boost[i] = spec.coverage_boost_db
            path_offsets[i] = spec.path_loss_offset_db
            nlos[i] = max(spec.nlos_penalty_factor, 1e-6)
            capacity[i] = max(spec.capacity_units, 1e-9)
        sector_mask = np.asarray([str(n).strip().lower() == "5ga" for n in names], dtype=bool)
        raw_az = np.asarray(
            config.get("heterogeneousDeployment", {}).get("existingStationSectorAzimuthsDeg", []),
            dtype=float,
        ).reshape(-1)
        az = np.zeros((num_stations,), dtype=float)
        if raw_az.size > 0:
            take = min(raw_az.size, num_stations)
            az[:take] = raw_az[:take]
        default_az = float(config.get("heterogeneousDeployment", {}).get("defaultSectorAzimuthDeg", 0.0))
        az[raw_az.size :] = default_az
        directions = np.asarray(channel_params.get("sector_directions_deg", [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]), dtype=float)
        az = np.asarray(nearest_supported_sector_direction_deg(az, directions), dtype=float)
        return cls(
            names,
            tx,
            costs,
            boost,
            path_offsets,
            nlos,
            capacity,
            sector_mask,
            az,
            float(channel_params.get("sector_beamwidth_deg", 90.0)),
            str(channel_params.get("outside_sector_mode", "no_coverage")),
            float(channel_params.get("side_lobe_attenuation_db", 30.0)),
        )


def _write_station_export(analysis: Dict[str, Any], output_path: Path) -> None:
    _write_csv(output_path, analysis["station_rows"])


def _write_route_status(analysis: Dict[str, Any], output_path: Path) -> None:
    _write_csv(output_path, analysis["route_rows"])


def _write_summary(analysis: Dict[str, Any], output_path: Path) -> None:
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(analysis["summary"], f, ensure_ascii=False, indent=2)


def _write_csv(output_path: Path, rows: Sequence[Dict[str, object]]) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    keys: List[str] = []
    for row in rows:
        for key in row.keys():
            if key not in keys:
                keys.append(key)
    with open(output_path, "w", encoding="utf-8", newline="") as f:
        if not keys:
            f.write("")
            return
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _plot_deployment_map(analysis: Dict[str, Any], city_map: CityMap, air_route: AirRoute, output_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7.4, 5.8))
    _draw_map_base(ax, city_map, air_route)
    _draw_stations_and_wedges(ax, analysis)
    ax.set_title("Deployment Map with 5GA Sectors")
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_xlim(0.0, city_map.size_x)
    ax.set_ylim(0.0, city_map.size_y)
    ax.set_aspect("equal", adjustable="box")
    ax.grid(alpha=0.18)
    ax.legend(loc="upper right", frameon=True, framealpha=0.92)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)


def _plot_route_coverage_before_after(analysis: Dict[str, Any], air_route: AirRoute, output_path: Path) -> None:
    pts = np.asarray(air_route.test_points, dtype=float)
    fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.8), sharex=True, sharey=True)
    for ax, key, title in [
        (axes[0], "covered_before", "Before Deployment"),
        (axes[1], "covered_after", "After Deployment"),
    ]:
        covered = np.asarray(analysis[key], dtype=bool)
        if pts.size > 0:
            ax.scatter(pts[~covered, 0], pts[~covered, 1], s=18, c="#BDBDBD", label="Uncovered", alpha=0.65)
            ax.scatter(pts[covered, 0], pts[covered, 1], s=22, c="#2CA25F", label="Covered", alpha=0.85)
        ax.set_title(title)
        ax.set_xlabel("X (m)")
        ax.grid(alpha=0.18)
    axes[0].set_ylabel("Y (m)")
    handles, labels = axes[1].get_legend_handles_labels()
    if handles:
        axes[1].legend(handles, labels, loc="upper right", frameon=True)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)


def _plot_sector_heatmap(analysis: Dict[str, Any], city_map: CityMap, air_route: AirRoute, output_path: Path) -> None:
    pts = np.asarray(air_route.test_points, dtype=float)
    snr = np.asarray(analysis["snr_enforced"], dtype=float)
    fig, ax = plt.subplots(figsize=(7.4, 5.8))
    _draw_map_base(ax, city_map, air_route, draw_points=False)
    if pts.size > 0:
        sc = ax.scatter(pts[:, 0], pts[:, 1], c=snr, cmap="viridis", s=26, alpha=0.9, label="Route SNR")
        cb = plt.colorbar(sc, ax=ax, fraction=0.046, pad=0.04)
        cb.set_label("Sector-aware SNR (dB)")
    _draw_stations_and_wedges(ax, analysis)
    ax.set_title("Sector-Aware Coverage Heatmap")
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_xlim(0.0, city_map.size_x)
    ax.set_ylim(0.0, city_map.size_y)
    ax.set_aspect("equal", adjustable="box")
    ax.grid(alpha=0.18)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)


def _plot_per_route_status(analysis: Dict[str, Any], output_path: Path) -> None:
    rows = list(analysis["route_rows"])
    labels = [str(r["route_id"]) for r in rows]
    x = np.arange(len(labels), dtype=float)
    width = 0.25
    before = [float(r["coverage_rate_before"]) for r in rows]
    after = [float(r["coverage_rate_after"]) for r in rows]
    no_5ga = [float(r["coverage_rate_without_5ga"]) for r in rows]
    fig, ax = plt.subplots(figsize=(max(6.4, len(labels) * 0.7), 4.6))
    ax.bar(x - width, before, width, label="Before", color="#9E9E9E")
    ax.bar(x, after, width, label="After", color="#2CA25F")
    ax.bar(x + width, no_5ga, width, label="Without 5GA", color="#3182BD")
    ax.set_ylim(0.0, 1.05)
    ax.set_ylabel("Coverage Rate")
    ax.set_title("Per-Route Coverage Status")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=35, ha="right")
    ax.grid(axis="y", alpha=0.2)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)


def _draw_map_base(ax: plt.Axes, city_map: CityMap, air_route: AirRoute, draw_points: bool = True) -> None:
    for b in city_map.buildings:
        rect = Rectangle((b.x, b.y), b.width, b.length, facecolor="#C6DBEF", edgecolor="#6B8FB3", alpha=0.35, linewidth=0.3)
        ax.add_patch(rect)
    for i, (start, end) in enumerate(air_route.routes):
        ax.plot([start[0], end[0]], [start[1], end[1]], color="#8E0152", linewidth=1.1, label="Route" if i == 0 else None)
    if draw_points and air_route.test_points.size > 0:
        ax.scatter(air_route.test_points[:, 0], air_route.test_points[:, 1], s=10, c="#756BB1", alpha=0.35, label="Route points")


def _draw_stations_and_wedges(ax: plt.Axes, analysis: Dict[str, Any]) -> None:
    positions = np.asarray(analysis["positions"], dtype=float)
    plan = analysis["station_plan"]
    if positions.size == 0:
        return
    sector_mask = np.asarray(plan.sector_station_mask, dtype=bool)
    non_sector = ~sector_mask
    if np.any(non_sector):
        ax.scatter(positions[non_sector, 0], positions[non_sector, 1], marker="^", s=85, c="#2166AC", edgecolor="black", label="5G station", zorder=7)
    if np.any(sector_mask):
        ax.scatter(positions[sector_mask, 0], positions[sector_mask, 1], marker="^", s=95, c="#1B7837", edgecolor="black", label="5GA station", zorder=8)
    radius = 0.18 * max(float(np.ptp(positions[:, 0])) if positions.shape[0] > 1 else 300.0, 300.0)
    radius = float(max(radius, 80.0))
    half_width = float(plan.sector_beamwidth_deg) * 0.5
    first = True
    for b, is_sector in enumerate(sector_mask.tolist()):
        if not is_sector:
            continue
        center_math_deg = 90.0 - float(plan.sector_azimuths_deg[b])
        ax.add_patch(
            Wedge(
                center=(float(positions[b, 0]), float(positions[b, 1])),
                r=radius,
                theta1=center_math_deg - half_width,
                theta2=center_math_deg + half_width,
                facecolor="#74ADD1",
                edgecolor="#2166AC",
                alpha=0.24,
                linewidth=0.9,
                label="5GA sector wedge" if first else None,
                zorder=5,
            )
        )
        first = False
