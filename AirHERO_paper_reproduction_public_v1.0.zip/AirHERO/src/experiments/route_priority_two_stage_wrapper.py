from __future__ import annotations

import copy
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

import numpy as np

from src.algorithms.particle_encoding import decode_particle_solution
from src.baselines.base import BaselineAdapter, BaselineResult, DeploymentProblem
from src.baselines.registry import get_method_adapter
from src.data.types import Config


@dataclass
class TwoStageRoutePriorityResult:
    """Sanity/result container for route-priority two-stage baseline wrappers."""

    method_name: str
    seed: int
    stage1_result: BaselineResult
    stage2_result: BaselineResult
    final_deployment: np.ndarray
    decoded_stations: List[Dict[str, Any]]
    runtime_seconds: float
    logs: Dict[str, Any]


def run_route_priority_two_stage(
    problem: DeploymentProblem,
    config: Config,
    *,
    seed: int,
    stage1_optimizer: str,
    stage2_optimizer: str,
    k1: int,
    k2: int,
) -> TwoStageRoutePriorityResult:
    """Run a sanity-level two-stage current/future wrapper with shared optimizer adapters."""
    t0 = time.time()
    s1_cfg = _stage_config(config, k1, stage="current")
    s2_cfg = _stage_config(config, k2, stage="future")
    stage1 = get_method_adapter(stage1_optimizer).run(problem, seed=int(seed), config=s1_cfg)
    stage2 = get_method_adapter(stage2_optimizer).run(problem, seed=int(seed) + 1009, config=s2_cfg)
    p1 = _best_decision(stage1)
    p2 = _best_decision(stage2)
    final = np.concatenate([p1, p2], axis=0)
    decoded = []
    for row in decode_particle_solution(final, _stage_config(config, k1 + k2, stage="all")):
        source = "stage1_current_priority" if int(row["station_id"]) <= int(k1) else "stage2_future_priority"
        item = dict(row)
        item["station_source"] = source
        decoded.append(item)
    logs = {
        "wrapper": "route_priority_two_stage",
        "stage1_optimizer": stage1_optimizer,
        "stage2_optimizer": stage2_optimizer,
        "method_name": _two_stage_method_name(stage1_optimizer, stage2_optimizer),
        "K": int(k1 + k2),
        "K1": int(k1),
        "K2": int(k2),
        "stage1_target": "current-priority route subset",
        "stage2_target": "future-priority route subset",
        "final_evaluation": "all current + future route points",
        "sanity_only": True,
        "asu_preset": "asu_route_service_v2",
    }
    return TwoStageRoutePriorityResult(
        method_name=str(logs["method_name"]),
        seed=int(seed),
        stage1_result=stage1,
        stage2_result=stage2,
        final_deployment=final,
        decoded_stations=decoded,
        runtime_seconds=float(time.time() - t0),
        logs=logs,
    )


def _stage_config(config: Config, k: int, *, stage: str) -> Config:
    cfg = copy.deepcopy(config)
    cfg.setdefault("pso", {})["numBaseStations"] = int(k)
    cfg["asu_preset"] = "asu_route_service_v2"
    cfg.setdefault("airwayServiceUtility", {})["asu_preset"] = "asu_route_service_v2"
    cfg.setdefault("routePriorityWrapper", {})["stage"] = stage
    if stage == "current":
        _force_route_split(cfg, existing_ratio=1.0)
    elif stage == "future":
        _force_route_split(cfg, existing_ratio=0.0)
    return cfg


def _two_stage_method_name(stage1_optimizer: str, stage2_optimizer: str) -> str:
    if stage1_optimizer == stage2_optimizer and stage1_optimizer.endswith("_extended"):
        return f"{stage1_optimizer.removesuffix('_extended')}_two_stage_current_future"
    return "route_priority_two_stage"


def _force_route_split(config: Config, existing_ratio: float) -> None:
    config.setdefault("routeObjectives", {})
    config["routeObjectives"]["splitMode"] = "index_ratio"
    config["routeObjectives"]["existingRatio"] = float(existing_ratio)


def _best_decision(result: BaselineResult) -> np.ndarray:
    history = result.logs.get("history", []) if isinstance(result.logs, dict) else []
    best = result.logs.get("best_chromosome") if isinstance(result.logs, dict) else None
    if best is not None:
        num = result.nondominated_decisions.shape[1] if result.nondominated_decisions.size else result.decision_variables.shape[1]
        return np.asarray(best, dtype=float).reshape(num, 5)
    if result.nondominated_decisions.size:
        return np.asarray(result.nondominated_decisions[0], dtype=float)
    return np.asarray(result.decision_variables[0], dtype=float)
