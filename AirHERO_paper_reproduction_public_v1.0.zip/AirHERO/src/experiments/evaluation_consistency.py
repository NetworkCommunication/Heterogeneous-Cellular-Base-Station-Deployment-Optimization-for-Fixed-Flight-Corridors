from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

import numpy as np

from src.algorithms.fitness_interface import (
    ObjectiveBatch,
    StationTypePlan,
    build_station_type_plan,
    build_station_type_plan_from_particle,
    evaluate_population_objectives,
)
from src.algorithms.heterogeneous_deployment import parse_station_types
from src.baselines.base import DeploymentProblem
from src.data.types import Config
from src.propagation.sector_geometry import DEFAULT_SECTOR_DIRECTIONS_DEG, nearest_supported_sector_direction_deg


@dataclass
class ConsistentEvaluationResult:
    """Evaluation result under the system-level existing+new convention."""

    particles: np.ndarray
    batch: ObjectiveBatch
    metrics: List[Dict[str, float]]
    existing_station_count: int
    newly_deployed_station_count: int
    total_station_count: int
    already_included_existing: bool
    power_mode: str = "global_channel_tx_power"
    assigned_tx_power_dbm: np.ndarray | None = None


def evaluate_with_existing_context(
    *,
    decisions: np.ndarray,
    problem: DeploymentProblem,
    config: Config,
    method_name: str,
    power_mode: str | None = None,
) -> ConsistentEvaluationResult:
    """Evaluate decisions with existing synthetic infrastructure plus new stations.

    Service metrics are computed using existing + new stations. Cost metrics are
    then normalized to count only newly deployed stations, treating existing
    synthetic infrastructure as sunk.
    """
    arr = _ensure_3d(decisions, config)
    existing = existing_station_particle(config, target_dims=max(arr.shape[2], 5))
    eval_particles, already = _combine_existing_and_new(arr, existing, method_name)
    mode = str(
        power_mode
        or config.get("evaluation", {}).get("power_mode")
        or config.get("channel", {}).get("power_mode")
        or "global_channel_tx_power"
    ).strip().lower()
    station_plan = None
    if mode == "station_file_preferred":
        station_plan = _station_file_preferred_plan(config, eval_particles[0], existing_count=int(existing.shape[0]))
    elif mode not in {"global_channel_tx_power", "global", "legacy"}:
        raise ValueError(f"Unsupported evaluation power_mode: {mode}")

    batch = evaluate_population_objectives(
        positions=eval_particles,
        test_points=problem.test_points,
        city_map=problem.city_map,
        channel_params=problem.channel_params,
        config=config,
        station_plan=station_plan,
    )
    existing_count = int(existing.shape[0])
    total_count = int(eval_particles.shape[1])
    new_count = max(total_count - existing_count, 0) if already or existing_count else int(arr.shape[1])
    metrics = _adjust_cost_metrics(
        batch=batch,
        particles=eval_particles,
        config=config,
        existing_count=existing_count if total_count >= existing_count else 0,
        new_count=new_count,
        method_name=method_name,
    )
    return ConsistentEvaluationResult(
        particles=eval_particles,
        batch=batch,
        metrics=metrics,
        existing_station_count=existing_count,
        newly_deployed_station_count=new_count,
        total_station_count=total_count,
        already_included_existing=already,
        power_mode=mode,
        assigned_tx_power_dbm=_assigned_tx_power_dbm(config, station_plan, total_count),
    )


def existing_station_particle(config: Config, *, target_dims: int = 5) -> np.ndarray:
    """Return configured existing stations as particle rows."""
    raw = config.get("heterogeneousDeployment", {}).get("existingStations", [])
    if not raw:
        return np.zeros((0, int(max(target_dims, 5))), dtype=float)
    spatial = np.asarray(raw, dtype=float)
    if spatial.ndim == 1:
        spatial = spatial.reshape(1, -1)
    spatial = spatial[:, :3]
    dims = int(max(target_dims, 5))
    out = np.zeros((spatial.shape[0], dims), dtype=float)
    out[:, :3] = spatial
    h_cfg = config.get("heterogeneousDeployment", {})
    type_names = list(h_cfg.get("existingStationTypes", []))
    if len(type_names) != spatial.shape[0]:
        type_names = ["5G"] * spatial.shape[0]
    raw_azimuths = list(h_cfg.get("existingStationSectorAzimuthsDeg", []))
    for i, name in enumerate(type_names):
        out[i, 3] = float(_type_index(config, str(name)))
        if str(name).strip().lower() == "5ga":
            raw_az = raw_azimuths[i] if i < len(raw_azimuths) else h_cfg.get("defaultSectorAzimuthDeg", 0.0)
            out[i, 4] = float(_sector_index(float(raw_az)))
    return out


def _assigned_tx_power_dbm(config: Config, station_plan: StationTypePlan | None, total_count: int) -> np.ndarray:
    channel_tx = float(config.get("channel", {}).get("txPower", 0.0))
    if station_plan is None:
        return np.full((int(total_count),), channel_tx, dtype=float)
    offsets = np.asarray(station_plan.tx_power_offsets_db, dtype=float).reshape(-1)
    if offsets.size < int(total_count):
        padded = np.zeros((int(total_count),), dtype=float)
        padded[: offsets.size] = offsets
        offsets = padded
    return channel_tx + offsets[: int(total_count)]


def _station_file_preferred_plan(config: Config, particle: np.ndarray, *, existing_count: int) -> StationTypePlan:
    """Build a station plan that preserves existing-station tx_power_dbm when present.

    The legacy evaluator interprets station transmit power as
    ``channel.txPower + station_type.txPowerOffsetDb``.  This additive adapter
    keeps that behavior for newly deployed stations, while converting existing
    stations with explicit ``tx_power_dbm`` into equivalent offsets relative to
    the same global channel power.
    """
    arr = np.asarray(particle, dtype=float)
    base_plan = build_station_type_plan_from_particle(config, arr) if arr.shape[1] >= 5 else build_station_type_plan(config, arr.shape[0])
    h_cfg = config.get("heterogeneousDeployment", {})
    raw_power = h_cfg.get("existingStationTxPowerDbm", h_cfg.get("existing_station_tx_power_dbm", []))
    existing_power = np.asarray(raw_power, dtype=float).reshape(-1) if raw_power else np.zeros((0,), dtype=float)
    count = int(min(max(existing_count, 0), arr.shape[0], existing_power.size))
    if count <= 0:
        return base_plan

    channel_tx = float(config.get("channel", {}).get("txPower", 0.0))
    tx_offsets = np.asarray(base_plan.tx_power_offsets_db, dtype=float).copy()
    tx_offsets[:count] = existing_power[:count] - channel_tx

    names = list(base_plan.station_type_names)
    type_indices = np.asarray(base_plan.station_type_indices, dtype=int).copy()
    raw_types = list(h_cfg.get("existingStationTypes", []))
    specs = parse_station_types(config)
    type_lookup = {str(spec.name).strip().lower(): idx for idx, spec in enumerate(specs)}
    for i in range(count):
        if i < len(raw_types):
            name = str(raw_types[i] or "5G")
            names[i] = name
            type_indices[i] = int(type_lookup.get(name.strip().lower(), type_indices[i]))

    return StationTypePlan(
        station_type_indices=type_indices,
        station_type_names=names,
        tx_power_offsets_db=tx_offsets,
        deployment_costs=np.asarray(base_plan.deployment_costs, dtype=float),
        coverage_boost_db=np.asarray(base_plan.coverage_boost_db, dtype=float),
        path_loss_offsets_db=np.asarray(base_plan.path_loss_offsets_db, dtype=float),
        nlos_penalty_factors=np.asarray(base_plan.nlos_penalty_factors, dtype=float),
        capacity_units=np.asarray(base_plan.capacity_units, dtype=float),
        sector_station_mask=np.asarray(base_plan.sector_station_mask, dtype=bool),
        sector_azimuths_deg=np.asarray(base_plan.sector_azimuths_deg, dtype=float),
        sector_beamwidth_deg=float(base_plan.sector_beamwidth_deg),
        outside_sector_mode=str(base_plan.outside_sector_mode),
        side_lobe_attenuation_db=float(base_plan.side_lobe_attenuation_db),
    )


def objective_vector_from_metrics(metrics: Dict[str, float]) -> List[float]:
    """Build the repository four-objective minimization vector from adjusted metrics."""
    existing = float(metrics.get("existing_route_continuous_coverage_rate", metrics.get("coverage_rate", 0.0)))
    future = float(metrics.get("future_route_continuous_coverage_rate", metrics.get("coverage_rate", 0.0)))
    return [
        float(metrics.get("handover_count", 0.0)),
        float(metrics.get("deployment_cost", 0.0)),
        1.0 - existing,
        1.0 - future,
    ]


def _ensure_3d(decisions: np.ndarray, config: Config) -> np.ndarray:
    arr = np.asarray(decisions, dtype=float)
    if arr.size == 0:
        return np.zeros((0, 0, 5), dtype=float)
    if arr.ndim != 3:
        raise ValueError("decisions must have shape [num_particles, num_stations, dims]")
    if arr.shape[2] >= 5:
        return arr
    return _extend_fixed_plan_decisions(arr, config)


def _extend_fixed_plan_decisions(arr: np.ndarray, config: Config) -> np.ndarray:
    out = np.zeros((arr.shape[0], arr.shape[1], 5), dtype=float)
    out[:, :, : arr.shape[2]] = arr
    plan = build_station_type_plan(config, arr.shape[1])
    out[:, :, 3] = np.asarray(plan.station_type_indices, dtype=float)[None, :]
    if plan.sector_azimuths_deg is not None:
        out[:, :, 4] = np.asarray(
            [_sector_index(float(v)) for v in np.asarray(plan.sector_azimuths_deg, dtype=float).tolist()],
            dtype=float,
        )[None, :]
    return out


def _combine_existing_and_new(arr: np.ndarray, existing: np.ndarray, method_name: str) -> tuple[np.ndarray, bool]:
    if arr.shape[0] == 0:
        return arr, False
    if existing.shape[0] == 0:
        return arr, False
    dims = int(max(arr.shape[2], existing.shape[1], 5))
    arr_ext = _pad_dims(arr, dims)
    existing_ext = _pad_dims(existing[None, :, :], dims)[0]
    if _has_existing_prefix(arr_ext, existing_ext):
        return arr_ext, True
    if str(method_name) == "existing_only":
        return existing_ext[None, :, :], True
    tiled_existing = np.repeat(existing_ext[None, :, :], arr_ext.shape[0], axis=0)
    return np.concatenate([tiled_existing, arr_ext], axis=1), False


def _pad_dims(arr: np.ndarray, dims: int) -> np.ndarray:
    data = np.asarray(arr, dtype=float)
    if data.shape[-1] >= dims:
        return data
    out = np.zeros((*data.shape[:-1], dims), dtype=float)
    out[..., : data.shape[-1]] = data
    return out


def _has_existing_prefix(arr: np.ndarray, existing: np.ndarray) -> bool:
    if existing.shape[0] == 0 or arr.shape[1] < existing.shape[0]:
        return False
    return bool(np.allclose(arr[:, : existing.shape[0], :3], existing[None, :, :3], atol=1e-6, rtol=0.0))


def _adjust_cost_metrics(
    *,
    batch: ObjectiveBatch,
    particles: np.ndarray,
    config: Config,
    existing_count: int,
    new_count: int,
    method_name: str,
) -> List[Dict[str, float]]:
    out: List[Dict[str, float]] = []
    for i in range(particles.shape[0]):
        row = batch.at(i)
        all_cost = _particle_cost(particles[i], config, start_idx=0)
        new_start = int(existing_count) if str(method_name) != "existing_only" else int(particles.shape[1])
        new_cost = _particle_cost(particles[i], config, start_idx=new_start)
        row["deployment_cost"] = float(new_cost)
        row["total_infrastructure_cost"] = float(all_cost)
        row["existing_station_count"] = float(existing_count)
        row["newly_deployed_station_count"] = float(new_count if str(method_name) != "existing_only" else 0)
        row["evaluation_station_count"] = float(particles.shape[1])
        row["service_evaluation_stations"] = "existing_only" if str(method_name) == "existing_only" else "existing_plus_new"
        row["deployment_cost_scope"] = "new_stations_only"
        capacity = float(row.get("capacity_effective", 0.0))
        row["cost_effectiveness"] = float(capacity / max(new_cost, 1e-9)) if new_cost > 0.0 else 0.0
        row["constraint_penalty"] = _adjusted_constraint_penalty(config, new_cost, float(row.get("coverage_rate", 0.0)))
        out.append(row)
    return out


def _particle_cost(particle: np.ndarray, config: Config, *, start_idx: int) -> float:
    arr = np.asarray(particle, dtype=float)
    if arr.size == 0 or int(start_idx) >= arr.shape[0]:
        return 0.0
    if arr.shape[1] >= 5:
        plan = build_station_type_plan_from_particle(config, arr)
    else:
        plan = build_station_type_plan(config, arr.shape[0])
    return float(np.sum(np.asarray(plan.deployment_costs[int(start_idx) :], dtype=float)))


def _adjusted_constraint_penalty(config: Config, deployment_cost: float, coverage_rate: float) -> float:
    constraints = config.get("heterogeneousConstraints", {})
    weights = constraints.get("penaltyWeights", {}) if isinstance(constraints.get("penaltyWeights", {}), dict) else {}
    penalty = 0.0
    budget = constraints.get("totalBudget")
    if budget is not None:
        budget_f = max(float(budget), 1e-9)
        exceed = max((float(deployment_cost) - budget_f) / budget_f, 0.0)
        penalty += float(weights.get("budgetPenalty", 50.0)) * exceed
    min_cov = constraints.get("minCoverageRate")
    if min_cov is not None:
        gap = max(float(min_cov) - float(coverage_rate), 0.0)
        penalty += float(weights.get("minCoveragePenalty", 80.0)) * gap
    return float(penalty)


def _type_index(config: Config, station_type: str) -> int:
    target = station_type.strip().lower()
    for idx, item in enumerate(config.get("heterogeneousDeployment", {}).get("stationTypes", [])):
        if str(item.get("name", "")).strip().lower() == target:
            return int(idx)
    return 0


def _sector_index(azimuth_deg: float) -> int:
    snapped = float(nearest_supported_sector_direction_deg(float(azimuth_deg), DEFAULT_SECTOR_DIRECTIONS_DEG))
    matches = np.where(np.isclose(DEFAULT_SECTOR_DIRECTIONS_DEG, snapped, atol=1e-9, rtol=0.0))[0]
    return int(matches[0]) if matches.size else 0
