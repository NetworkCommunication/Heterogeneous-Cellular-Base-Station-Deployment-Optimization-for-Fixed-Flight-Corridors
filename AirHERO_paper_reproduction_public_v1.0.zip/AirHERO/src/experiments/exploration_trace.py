"""Optional checkpoint tracing for optimizer exploration diagnostics.

The helpers in this module are intentionally observation-only.  Optimizers
call them only when an experiment config explicitly enables
``explorationTrace``; no decision, objective, or update rule is changed.
"""

from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Sequence

import numpy as np


def checkpoint_iterations(config: Mapping[str, Any], max_iterations: int) -> set[int]:
    """Return configured integer checkpoint iterations, including endpoints."""
    trace = config.get("explorationTrace", {}) if isinstance(config, Mapping) else {}
    if not isinstance(trace, Mapping) or not bool(trace.get("enabled", False)):
        return set()
    fractions = trace.get("fractions", [0.0, 0.25, 0.50, 0.75, 1.0])
    values = {int(round(float(frac) * max(int(max_iterations), 0))) for frac in fractions}
    values.update({0, max(int(max_iterations), 0)})
    return values


def capture_candidate_sets(
    logs: Dict[str, Any],
    config: Mapping[str, Any],
    *,
    iteration: int,
    max_iterations: int,
    candidate_sets: Iterable[Mapping[str, Any]],
) -> None:
    """Append checkpoint candidate sets to ``logs`` when tracing is enabled.

    Each set may contain decoded decisions, objective vectors, metric records,
    feasibility flags, and an explicit candidate source.  Arrays are converted
    to ordinary lists so experiment runners can export them without depending
    on a pickling format.
    """
    if int(iteration) not in checkpoint_iterations(config, max_iterations):
        return
    target: List[Dict[str, Any]] = logs.setdefault("exploration_candidate_trace", [])
    for item in candidate_sets:
        decisions = np.asarray(item.get("decisions", []), dtype=float)
        if decisions.size == 0:
            continue
        objectives = np.asarray(item.get("objectives", []), dtype=float)
        feasible = np.asarray(item.get("feasible", []), dtype=bool)
        metrics: Sequence[Mapping[str, Any]] = item.get("metrics", []) or []
        target.append(
            {
                "iteration": int(iteration),
                "max_iterations": int(max_iterations),
                "candidate_source": str(item.get("candidate_source", "population")),
                "is_archive_member": bool(item.get("is_archive_member", False)),
                "decisions": decisions.tolist(),
                "objectives": objectives.tolist(),
                "feasible": feasible.tolist(),
                "metrics": [dict(row) for row in metrics],
            }
        )
