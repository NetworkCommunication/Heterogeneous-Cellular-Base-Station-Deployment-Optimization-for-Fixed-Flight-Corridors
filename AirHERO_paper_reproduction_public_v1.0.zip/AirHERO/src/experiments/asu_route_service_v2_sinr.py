from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, List, Sequence

import numpy as np

from src.baselines.base import DeploymentProblem
from src.data.types import Config
from src.experiments.asu_route_service_v2 import ASU_ROUTE_SERVICE_KEY, ASU_ROUTE_SERVICE_V2, ASURouteServiceV2Record
from src.experiments.evaluation_consistency import _station_file_preferred_plan, existing_station_particle
from src.propagation.a2g_probabilistic import compute_population_per_bs_rx_power_a2g_dbm


ASU_ROUTE_SERVICE_V2_SINR = "asu_route_service_v2_sinr"


@dataclass(frozen=True)
class SINRASUV2Evaluation:
    """Population-level true-SINR ASU-v2 evaluation output."""

    particles: np.ndarray
    metrics: List[Dict[str, Any]]
    asu_values: np.ndarray
    objectives: np.ndarray
    feasible: np.ndarray
    existing_station_count: int
    newly_deployed_station_count: int
    total_station_count: int


def evaluate_with_existing_context_sinr_asu_v2(
    *,
    decisions: np.ndarray,
    problem: DeploymentProblem,
    config: Config,
    method_name: str,
) -> SINRASUV2Evaluation:
    """Evaluate new-station decisions with existing stations using true SINR.

    Existing stations participate in serving and interference, while deployment
    cost and station type counts are computed for newly deployed stations only.
    This is an additive evaluator; the existing SNR optimization path is left
    unchanged unless callers explicitly opt into this function.
    """
    del method_name
    new_particles = _ensure_3d(decisions)
    existing = existing_station_particle(config, target_dims=max(new_particles.shape[2] if new_particles.ndim == 3 else 5, 5))
    if new_particles.shape[0] == 0:
        empty = np.zeros((0,), dtype=float)
        return SINRASUV2Evaluation(
            particles=new_particles,
            metrics=[],
            asu_values=empty,
            objectives=np.zeros((0, 5), dtype=float),
            feasible=np.zeros((0,), dtype=bool),
            existing_station_count=int(existing.shape[0]),
            newly_deployed_station_count=0,
            total_station_count=int(existing.shape[0]),
        )

    existing_ext = _pad_2d(existing, max(new_particles.shape[2], 5))
    combined = np.concatenate([np.repeat(existing_ext[None, :, :], new_particles.shape[0], axis=0), _pad_3d(new_particles, existing_ext.shape[1])], axis=1)
    existing_count = int(existing_ext.shape[0])
    new_count = int(new_particles.shape[1])

    metrics: List[Dict[str, Any]] = []
    asu_values: List[float] = []
    for idx in range(combined.shape[0]):
        row = _evaluate_one_sinr(
            combined[idx],
            new_particles[idx],
            problem=problem,
            config=config,
            existing_count=existing_count,
        )
        metrics.append(row)
        asu_values.append(float(row["ASU"]))
    asu = np.asarray(asu_values, dtype=float)
    objectives = np.asarray([_objective_vector(row) for row in metrics], dtype=float)
    tol = float(config.get("nsga2", {}).get("feasiblePenaltyTol", 1e-9))
    feasible = np.asarray([float(row.get("constraint_penalty", 0.0)) <= tol for row in metrics], dtype=bool)
    return SINRASUV2Evaluation(
        particles=combined,
        metrics=metrics,
        asu_values=asu,
        objectives=objectives,
        feasible=feasible,
        existing_station_count=existing_count,
        newly_deployed_station_count=new_count,
        total_station_count=int(combined.shape[1]),
    )


def evaluate_population_sinr_asu_v2(
    *,
    particles: np.ndarray,
    problem: DeploymentProblem,
    config: Config,
    method_name: str = "sinr_asu_v2",
) -> SINRASUV2Evaluation:
    """Alias for optimization-time population evaluation with SINR ASU-v2."""
    return evaluate_with_existing_context_sinr_asu_v2(
        decisions=particles,
        problem=problem,
        config=config,
        method_name=method_name,
    )


def _evaluate_one_sinr(
    combined_particle: np.ndarray,
    new_particle: np.ndarray,
    *,
    problem: DeploymentProblem,
    config: Config,
    existing_count: int,
) -> Dict[str, Any]:
    cfg = _sinr_params(config)
    plan = _station_file_preferred_plan(config, np.asarray(combined_particle, dtype=float), existing_count=int(existing_count))
    rx_dbm, _ = compute_population_per_bs_rx_power_a2g_dbm(
        positions=np.asarray(combined_particle, dtype=float)[None, :, :3],
        test_points=problem.test_points,
        channel_params=problem.channel_params,
        tx_power_offsets_db=plan.tx_power_offsets_db,
        coverage_boost_db=plan.coverage_boost_db,
        path_loss_offsets_db=plan.path_loss_offsets_db,
        sector_station_mask=plan.sector_station_mask,
        sector_azimuths_deg=plan.sector_azimuths_deg,
        sector_beamwidth_deg=plan.sector_beamwidth_deg,
        outside_sector_mode=plan.outside_sector_mode,
        side_lobe_attenuation_db=plan.side_lobe_attenuation_db,
    )
    rx_dbm = np.asarray(rx_dbm[0], dtype=float)
    rx_mw = np.power(10.0, rx_dbm / 10.0)
    serving_idx = np.argmax(rx_dbm, axis=0)
    point_idx = np.arange(rx_dbm.shape[1])
    serving_mw = rx_mw[serving_idx, point_idx]
    total_mw = np.sum(rx_mw, axis=0)
    non_serving_mw = np.maximum(total_mw - serving_mw, 0.0)
    noise_mw = 10.0 ** (float(problem.channel_params.get("noisePower", config.get("channel", {}).get("noisePower", -90.0))) / 10.0)
    rho = float(cfg["rho"])
    sinr_linear = serving_mw / np.maximum(noise_mw + rho * non_serving_mw, 1e-30)
    sinr_db = 10.0 * np.log10(np.maximum(sinr_linear, 1e-30))
    covered = sinr_db >= float(cfg["threshold_main_db"])

    groups = _route_groups(problem.test_points, config)
    current_idx = groups["current"]
    future_idx = groups["future"]
    q_current, current_mean_log = _q_component(sinr_linear, covered, current_idx)
    q_future, future_mean_log = _q_component(sinr_linear, covered, future_idx)
    current_coverage = _coverage(sinr_db[current_idx], float(cfg["threshold_main_db"])) if current_idx.size else 0.0
    future_coverage = _coverage(sinr_db[future_idx], float(cfg["threshold_main_db"])) if future_idx.size else 0.0
    handover = _handover_count(serving_idx, problem.test_points, config)
    n_5g, n_5ga = _new_station_type_counts(new_particle)
    c_dep = n_5g * float(cfg["C_5G"]) + n_5ga * float(cfg["C_5GA"])
    denominator = max(c_dep + float(cfg["kappa_H"]) * float(handover) + float(cfg["C_0"]), 1e-12)
    numerator = float(cfg["w_current"]) * q_current + float(cfg["w_future"]) * q_future
    asu = numerator / denominator
    rec = ASURouteServiceV2Record(
        ASU=float(asu),
        Q_current=float(q_current),
        Q_future=float(q_future),
        current_coverage=float(current_coverage),
        future_coverage=float(future_coverage),
        current_mean_log_rate=float(current_mean_log),
        future_mean_log_rate=float(future_mean_log),
        C_dep=float(c_dep),
        N_5G=int(n_5g),
        N_5GA=int(n_5ga),
        C_5G=float(cfg["C_5G"]),
        C_5GA=float(cfg["C_5GA"]),
        handover_count=float(handover),
        kappa_H=float(cfg["kappa_H"]),
        C_0=float(cfg["C_0"]),
        denominator=float(denominator),
        w_current=float(cfg["w_current"]),
        w_future=float(cfg["w_future"]),
        signal_metric="sinr",
    )
    row = rec.as_dict()
    row.update(
        {
            "asu_preset": ASU_ROUTE_SERVICE_V2_SINR,
            ASU_ROUTE_SERVICE_KEY: float(asu),
            "ASU_numerator": float(numerator),
            "ASU_denominator": float(denominator),
            "coverage_rate": _coverage(sinr_db, float(cfg["threshold_main_db"])),
            "Coverage@0dB": _coverage(sinr_db, 0.0),
            "Coverage@5dB": _coverage(sinr_db, 5.0),
            "Coverage@10dB": _coverage(sinr_db, 10.0),
            "current_Coverage@0dB": _coverage(sinr_db[current_idx], 0.0) if current_idx.size else 0.0,
            "future_Coverage@0dB": _coverage(sinr_db[future_idx], 0.0) if future_idx.size else 0.0,
            "current_Coverage@5dB": _coverage(sinr_db[current_idx], 5.0) if current_idx.size else 0.0,
            "future_Coverage@5dB": _coverage(sinr_db[future_idx], 5.0) if future_idx.size else 0.0,
            "current_Coverage@10dB": _coverage(sinr_db[current_idx], 10.0) if current_idx.size else 0.0,
            "future_Coverage@10dB": _coverage(sinr_db[future_idx], 10.0) if future_idx.size else 0.0,
            "outage@0dB": 1.0 - _coverage(sinr_db, 0.0),
            "mean_SINR_db": float(np.mean(sinr_db)) if sinr_db.size else 0.0,
            "mean_snr_db": float(np.mean(sinr_db)) if sinr_db.size else 0.0,
            "p10_SINR_db": float(np.percentile(sinr_db, 10)) if sinr_db.size else 0.0,
            "median_SINR_db": float(np.percentile(sinr_db, 50)) if sinr_db.size else 0.0,
            "p90_SINR_db": float(np.percentile(sinr_db, 90)) if sinr_db.size else 0.0,
            "deployment_cost": float(c_dep),
            "handover_count": float(handover),
            "rho": rho,
            "threshold_main_db": float(cfg["threshold_main_db"]),
            "auxiliary_thresholds_db": ";".join(str(v) for v in cfg["auxiliary_thresholds_db"]),
            "power_mode": str(cfg["power_mode"]),
            "existing_stations_excluded_from_C_dep": True,
            "newly_deployed_station_count": int(new_particle.shape[0]),
            "evaluation_station_count": int(combined_particle.shape[0]),
            "constraint_penalty": 0.0,
        }
    )
    return row


def _sinr_params(config: Config) -> Dict[str, Any]:
    asu = config.get("airwayServiceUtilityV2", config.get("asu_route_service_v2", {}))
    eval_cfg = config.get("evaluation", {})
    return {
        "signal_metric": "sinr",
        "threshold_main_db": float(eval_cfg.get("threshold_main_db", config.get("channel", {}).get("snrThreshold", 0.0))),
        "auxiliary_thresholds_db": list(eval_cfg.get("auxiliary_thresholds_db", [5.0, 10.0])),
        "rho": float(eval_cfg.get("rho", asu.get("rho", 0.10) if isinstance(asu, dict) else 0.10)),
        "power_mode": str(eval_cfg.get("power_mode", "station_file_preferred")),
        "w_current": float(asu.get("w_current", asu.get("w_c", 0.5))) if isinstance(asu, dict) else 0.5,
        "w_future": float(asu.get("w_future", asu.get("w_f", 0.5))) if isinstance(asu, dict) else 0.5,
        "C_5G": float(asu.get("C_5G", 1.0)) if isinstance(asu, dict) else 1.0,
        "C_5GA": float(asu.get("C_5GA", 1.35)) if isinstance(asu, dict) else 1.35,
        "kappa_H": float(asu.get("kappa_H", 0.01)) if isinstance(asu, dict) else 0.01,
        "C_0": float(asu.get("C_0", 1.0)) if isinstance(asu, dict) else 1.0,
    }


def _objective_vector(row: Dict[str, Any]) -> List[float]:
    return [
        -float(row.get("ASU", 0.0)),
        float(row.get("handover_count", 0.0)),
        float(row.get("C_dep", row.get("deployment_cost", 0.0))),
        1.0 - float(row.get("current_coverage", row.get("coverage_rate", 0.0))),
        1.0 - float(row.get("future_coverage", row.get("coverage_rate", 0.0))),
    ]


def _ensure_3d(decisions: np.ndarray) -> np.ndarray:
    arr = np.asarray(decisions, dtype=float)
    if arr.size == 0:
        return np.zeros((0, 0, 5), dtype=float)
    if arr.ndim != 3:
        raise ValueError("decisions must have shape [num_particles, num_stations, dims]")
    if arr.shape[2] >= 5:
        return arr
    out = np.zeros((arr.shape[0], arr.shape[1], 5), dtype=float)
    out[:, :, : arr.shape[2]] = arr
    return out


def _pad_2d(arr: np.ndarray, dims: int) -> np.ndarray:
    data = np.asarray(arr, dtype=float)
    if data.shape[1] >= dims:
        return data
    out = np.zeros((data.shape[0], dims), dtype=float)
    out[:, : data.shape[1]] = data
    return out


def _pad_3d(arr: np.ndarray, dims: int) -> np.ndarray:
    data = np.asarray(arr, dtype=float)
    if data.shape[2] >= dims:
        return data
    out = np.zeros((data.shape[0], data.shape[1], dims), dtype=float)
    out[:, :, : data.shape[2]] = data
    return out


def _route_groups(test_points: np.ndarray, config: Config) -> Dict[str, np.ndarray]:
    n = int(test_points.shape[0])
    route_cfg = config.get("routeObjectives", {})
    if str(route_cfg.get("splitMode", "")).strip().lower() == "explicit_indices":
        current = _sanitize_indices(np.asarray(route_cfg.get("existingIndices", []), dtype=int), n)
        future = _sanitize_indices(np.asarray(route_cfg.get("futureIndices", []), dtype=int), n)
        if current.size or future.size:
            return {"current": current, "future": future}
    ratio = float(np.clip(route_cfg.get("existingRatio", 0.5), 0.0, 1.0))
    cut = int(np.clip(np.floor(ratio * n), 0, n))
    return {"current": np.arange(0, cut, dtype=int), "future": np.arange(cut, n, dtype=int)}


def _sanitize_indices(indices: np.ndarray, upper: int) -> np.ndarray:
    if indices.size == 0:
        return np.zeros((0,), dtype=int)
    return np.unique(indices[(indices >= 0) & (indices < int(upper))].astype(int))


def _q_component(signal_linear: np.ndarray, covered: np.ndarray, indices: np.ndarray) -> tuple[float, float]:
    if indices.size == 0:
        return 0.0, 0.0
    vals = np.asarray(signal_linear[indices], dtype=float)
    logs = np.log2(1.0 + np.maximum(vals, 0.0))
    return float(np.mean(covered[indices].astype(float) * logs)), float(np.mean(logs))


def _coverage(values_db: np.ndarray, threshold_db: float) -> float:
    arr = np.asarray(values_db, dtype=float)
    return float(np.mean(arr >= float(threshold_db))) if arr.size else 0.0


def _handover_count(serving_idx: np.ndarray, test_points: np.ndarray, config: Config) -> int:
    meta = config.get("routePointMetadata", {})
    n = int(test_points.shape[0])
    route_ids = np.asarray(meta.get("route_ids", [""] * n), dtype=object)
    point_indices = np.asarray(meta.get("point_indices", list(range(n))), dtype=int)
    if route_ids.shape[0] != n:
        route_ids = np.asarray([""] * n, dtype=object)
    if point_indices.shape[0] != n:
        point_indices = np.arange(n, dtype=int)
    count = 0
    for route_id in sorted(set(route_ids.tolist())):
        mask = np.where(route_ids == route_id)[0]
        if mask.size <= 1:
            continue
        order = mask[np.argsort(point_indices[mask], kind="stable")]
        seq = serving_idx[order]
        count += int(np.sum(seq[1:] != seq[:-1]))
    if count == 0 and serving_idx.size > 1 and len(set(route_ids.tolist())) <= 1:
        count = int(np.sum(serving_idx[1:] != serving_idx[:-1]))
    return count


def _new_station_type_counts(new_particle: np.ndarray) -> tuple[int, int]:
    if np.asarray(new_particle).size == 0:
        return 0, 0
    arr = np.asarray(new_particle, dtype=float).reshape(-1, new_particle.shape[-1])
    if arr.shape[1] < 4:
        return int(arr.shape[0]), 0
    type_idx = np.rint(arr[:, 3]).astype(int)
    n_5ga = int(np.sum(type_idx == 1))
    return int(arr.shape[0] - n_5ga), n_5ga
