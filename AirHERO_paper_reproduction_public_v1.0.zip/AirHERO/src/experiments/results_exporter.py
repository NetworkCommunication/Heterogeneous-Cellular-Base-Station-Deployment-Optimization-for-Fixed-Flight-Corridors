﻿from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from src.algorithms.fitness_interface import build_station_type_plan, build_station_type_plan_from_particle
from src.algorithms.particle_encoding import decode_particle_solution, is_extended_particle_array, spatial_view
from src.data.types import AirRoute, CityMap, Config, PSOResult
from src.experiments.final_solution_exporter import export_final_nondominated_from_pso_result
from src.experiments.sector_analysis_exporter import build_best_station_rows, save_sector_aware_outputs
from src.propagation.low_fidelity import compute_point_snr


def save_results(
    city_map: CityMap,
    air_route: AirRoute,
    pso_result: PSOResult,
    config: Config,
    results_dir: Path,
    channel_params: Config,
    elapsed_time: float,
) -> None:
    """Save result arrays and report text."""
    buildings_arr = np.array(
        [[b.x, b.y, b.width, b.length, b.height] for b in city_map.buildings],
        dtype=float,
    )

    station_plan = (
        build_station_type_plan_from_particle(config, pso_result.best_position)
        if is_extended_particle_array(pso_result.best_position)
        else build_station_type_plan(config, int(pso_result.best_position.shape[0]))
    )
    snr = compute_point_snr(
        spatial_view(pso_result.best_position),
        air_route.test_points,
        city_map,
        channel_params,
        tx_power_offsets_db=station_plan.tx_power_offsets_db,
        coverage_boost_db=station_plan.coverage_boost_db,
        path_loss_offsets_db=station_plan.path_loss_offsets_db,
        nlos_penalty_factors=station_plan.nlos_penalty_factors,
        sector_station_mask=station_plan.sector_station_mask,
        sector_azimuths_deg=station_plan.sector_azimuths_deg,
        sector_beamwidth_deg=station_plan.sector_beamwidth_deg,
        outside_sector_mode=station_plan.outside_sector_mode,
        side_lobe_attenuation_db=station_plan.side_lobe_attenuation_db,
    )
    snr_threshold = float(channel_params.get("snrThreshold", 0.0))
    covered = int(np.sum(snr >= snr_threshold))
    total = int(air_route.test_points.shape[0])
    coverage_rate = (covered / max(total, 1)) * 100.0

    np.savez(
        results_dir / "simulation_results.npz",
        config_json=np.array(json.dumps(config, ensure_ascii=False)),
        best_position=pso_result.best_position,
        best_fitness=np.array(pso_result.best_fitness),
        convergence_history=pso_result.convergence_history,
        test_points=air_route.test_points,
        buildings=buildings_arr,
        coverage_count=np.array(covered),
        coverage_rate=np.array(coverage_rate),
        elapsed_time=np.array(elapsed_time),
        landing_points=(
            city_map.landing_points if city_map.landing_points is not None else np.zeros((0, 3), dtype=float)
        ),
        takeoff_point=(city_map.takeoff_point if city_map.takeoff_point is not None else np.zeros(3, dtype=float)),
        touchdown_point=(
            city_map.touchdown_point if city_map.touchdown_point is not None else np.zeros(3, dtype=float)
        ),
    )
    export_final_nondominated_from_pso_result(
        pso_result=pso_result,
        config=config,
        output_dir=results_dir,
    )
    _save_best_station_deployments_csv(
        pso_result=pso_result,
        config=config,
        results_dir=results_dir,
        city_map=city_map,
        air_route=air_route,
        channel_params=channel_params,
    )
    if bool(config.get("sectorLogging", {}).get("enabled", False)):
        save_sector_aware_outputs(
            city_map=city_map,
            air_route=air_route,
            pso_result=pso_result,
            config=config,
            results_dir=results_dir,
            channel_params=channel_params,
        )

    if city_map.landing_points is not None and city_map.landing_points.size > 0:
        _save_landing_sites_csv(city_map, results_dir)

    report = _build_report_text(
        config=config,
        pso_result=pso_result,
        building_count=len(city_map.buildings),
        landing_count=(int(city_map.landing_points.shape[0]) if city_map.landing_points is not None else 0),
        takeoff_point=city_map.takeoff_point,
        touchdown_point=city_map.touchdown_point,
        total_points=total,
        covered_points=covered,
        coverage_rate=coverage_rate,
        snr_threshold=snr_threshold,
        elapsed_time=elapsed_time,
    )
    with open(results_dir / "simulation_report.txt", "w", encoding="utf-8") as f:
        f.write(report)


def _save_landing_sites_csv(city_map: CityMap, results_dir: Path) -> None:
    labels = city_map.landing_labels or []
    takeoff = city_map.takeoff_point
    touchdown = city_map.touchdown_point
    with open(results_dir / "landing_sites.csv", "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["site_id", "x", "y", "z", "label", "role"])
        for i, p in enumerate(city_map.landing_points, start=1):
            label = labels[i - 1] if i - 1 < len(labels) else ""
            role = ""
            if takeoff is not None and np.linalg.norm(p - takeoff) < 1e-6:
                role = "takeoff"
            if touchdown is not None and np.linalg.norm(p - touchdown) < 1e-6:
                role = "touchdown" if not role else "takeoff_touchdown"
            writer.writerow([i, f"{p[0]:.3f}", f"{p[1]:.3f}", f"{p[2]:.3f}", label, role])


def _save_best_station_deployments_csv(
    pso_result: PSOResult,
    config: Config,
    results_dir: Path,
    city_map: CityMap,
    air_route: AirRoute,
    channel_params: Config,
) -> None:
    rows = build_best_station_rows(
        pso_result=pso_result,
        config=config,
        city_map=city_map,
        air_route=air_route,
        channel_params=channel_params,
    )
    with open(results_dir / "best_station_deployments.csv", "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "station_id",
                "x",
                "y",
                "z",
                "station_type",
                "station_type_index",
                "sector_direction_index",
                "sector_azimuth_deg",
                "sector_beamwidth_deg",
                "covered_route_points",
                "covered_route_point_indices",
                "covered_route_ids",
                "coverage_contribution",
                "route_id_basis",
            ],
        )
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _build_report_text(
    config: Config,
    pso_result: PSOResult,
    building_count: int,
    landing_count: int,
    takeoff_point: np.ndarray | None,
    touchdown_point: np.ndarray | None,
    total_points: int,
    covered_points: int,
    coverage_rate: float,
    snr_threshold: float,
    elapsed_time: float,
) -> str:
    lines = [
        "==================================================",
        "   PSO Airport Base Station Optimization Report",
        "==================================================",
        "",
        "Simulation Parameters:",
        "---------",
        f"Map Size: {config['map']['sizeX']:.1f} x {config['map']['sizeY']:.1f} x {config['map']['sizeZ']:.1f} m",
        f"Number of Buildings: {building_count}",
        f"Landing Candidates: {landing_count}",
        f"Number of Test Points: {total_points}",
        f"PSO Particles: {int(config['pso']['numParticles'])}",
        f"PSO Iterations: {int(config['pso']['maxIterations'])}",
        f"Number of Base Stations: {int(config['pso']['numBaseStations'])}",
        "",
        "Best Base Station Positions:",
        "------------",
    ]
    decoded_rows = pso_result.decoded_solution or decode_particle_solution(pso_result.best_position, config)
    for i, p in enumerate(pso_result.best_position, start=1):
        if pso_result.station_type_names is not None and i - 1 < len(pso_result.station_type_names):
            stype = str(pso_result.station_type_names[i - 1])
        else:
            stype = "unknown"
        az = None
        if i - 1 < len(decoded_rows):
            az = decoded_rows[i - 1].get("sector_azimuth_deg")
        az_text = "" if az is None else f", sector_azimuth_deg={float(az):.1f}"
        lines.append(f"Base Station {i}: ({p[0]:.2f}, {p[1]:.2f}, {p[2]:.2f}) m, type={stype}{az_text}")

    if takeoff_point is not None:
        lines.append(f"Takeoff Point: ({takeoff_point[0]:.2f}, {takeoff_point[1]:.2f}, {takeoff_point[2]:.2f}) m")
    if touchdown_point is not None:
        lines.append(f"Touchdown Point: ({touchdown_point[0]:.2f}, {touchdown_point[1]:.2f}, {touchdown_point[2]:.2f}) m")

    lines.extend(
        [
            "",
            "Optimization Results:",
            "--------",
            f"Initial Best Fitness: {float(pso_result.convergence_history[0]):.3f}",
            f"Covered Points: {covered_points}",
            f"Total Test Points: {total_points}",
            f"Coverage Rate (SNR >= {snr_threshold:.1f} dB): {coverage_rate:.2f}%",
            f"Fitness Gain: {float(pso_result.best_fitness - pso_result.convergence_history[0]):.3f}",
            f"Convergence Iteration: {pso_result.convergence_iteration}",
            f"Elapsed Time: {elapsed_time:.2f} s",
            "",
        ]
    )
    return "\n".join(lines)
