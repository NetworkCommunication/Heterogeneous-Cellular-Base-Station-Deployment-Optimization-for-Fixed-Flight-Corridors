﻿from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import Any, Dict, List, Optional

import numpy as np

from src.data.types import CityMap, Config
from src.propagation.a2g_probabilistic import compute_population_snr_matrix_a2g
from src.propagation.high_fidelity import compute_population_snr_matrix_high_fidelity
from src.propagation.low_fidelity_legacy import compute_population_snr_matrix_legacy


@dataclass
class HeterogeneousPropagationParams:
    """每个站点的异构传播参数（可选）。"""

    tx_power_offsets_db: Optional[np.ndarray] = None
    coverage_boost_db: Optional[np.ndarray] = None
    path_loss_offsets_db: Optional[np.ndarray] = None
    nlos_penalty_factors: Optional[np.ndarray] = None
    sector_station_mask: Optional[np.ndarray] = None
    sector_azimuths_deg: Optional[np.ndarray] = None
    sector_beamwidth_deg: Optional[float] = None
    outside_sector_mode: Optional[str] = None
    side_lobe_attenuation_db: Optional[float] = None


@dataclass
class PropagationEvaluationStats:
    """一次传播评估批次的耗时与工作量统计。"""

    mode: str
    num_particles: int
    num_low_fidelity: int
    num_high_fidelity: int
    low_fidelity_seconds: float
    high_fidelity_seconds: float
    total_seconds: float
    elite_ratio: float
    elite_count_requested: int
    elite_count_applied: int
    elite_selection_rule: str
    elite_indices: List[int]
    low_fidelity_model: str = "unknown"
    sector_stats: Dict[str, Any] | None = None


@dataclass
class PropagationEvaluationResult:
    """传播评估输出，包含 SNR 结果和多保真统计信息。"""

    snr_matrix: np.ndarray
    stats: PropagationEvaluationStats


def evaluate_population_snr_multi_fidelity(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    config: Config,
    hetero_params: Optional[HeterogeneousPropagationParams] = None,
) -> PropagationEvaluationResult:
    """按配置执行多保真 SNR 评估。

    支持模式：
    - `all_low_fidelity`：全部粒子用低保真
    - `all_high_fidelity`：全部粒子用高保真
    - `elite_mixed_fidelity`：精英粒子高保真，其余低保真
    """
    num_particles = int(positions.shape[0])
    if hetero_params is None:
        hetero_params = HeterogeneousPropagationParams()

    mf_cfg = config.get("multiFidelity", {})
    mode = _normalize_mode(mf_cfg.get("mode", "all_low_fidelity"))
    low_fidelity_model = _resolve_low_fidelity_model(channel_params=channel_params, config=config)
    elite_ratio = float(np.clip(mf_cfg.get("eliteRatio", 0.15), 0.0, 1.0))
    elite_count_cfg = int(mf_cfg.get("eliteCount", -1)) if mf_cfg.get("eliteCount", None) is not None else -1
    min_elite = int(mf_cfg.get("minEliteCount", 1))
    selection_cfg = mf_cfg.get("eliteSelection", {})
    selection_rule = str(selection_cfg.get("metric", "coverage_mean_snr"))

    # 退化输入（无点或无粒子）时返回空矩阵，避免后续流程异常。
    if test_points.size == 0 or positions.size == 0:
        empty = np.zeros((num_particles, test_points.shape[0] if test_points.ndim == 2 else 0), dtype=float)
        stats = PropagationEvaluationStats(
            mode=mode,
            num_particles=num_particles,
            num_low_fidelity=0,
            num_high_fidelity=0,
            low_fidelity_seconds=0.0,
            high_fidelity_seconds=0.0,
            total_seconds=0.0,
            elite_ratio=elite_ratio,
            elite_count_requested=max(elite_count_cfg, 0),
            elite_count_applied=0,
            elite_selection_rule=selection_rule,
            elite_indices=[],
            low_fidelity_model=low_fidelity_model,
        )
        return PropagationEvaluationResult(snr_matrix=empty, stats=stats)

    low_secs = 0.0
    high_secs = 0.0
    elite_indices = np.zeros((0,), dtype=int)

    if mode == "all_low_fidelity":
        # 模式1：全低保真，速度最快。
        t0 = perf_counter()
        snr = _compute_low_fidelity_snr(
            positions,
            test_points,
            city_map,
            channel_params,
            hetero_params,
            low_fidelity_model=low_fidelity_model,
        )
        low_secs = perf_counter() - t0
        stats = _build_stats(
            mode=mode,
            num_particles=num_particles,
            num_low=num_particles,
            num_high=0,
            low_secs=low_secs,
            high_secs=high_secs,
            elite_ratio=elite_ratio,
            elite_count_requested=max(elite_count_cfg, 0),
            elite_count_applied=0,
            selection_rule=selection_rule,
            elite_indices=elite_indices,
            low_fidelity_model=low_fidelity_model,
        )
        return PropagationEvaluationResult(snr_matrix=snr, stats=stats)

    if mode == "all_high_fidelity":
        # 模式2：全高保真，精度更高但计算更慢。
        t0 = perf_counter()
        snr = _compute_high_fidelity_snr(
            positions,
            test_points,
            city_map,
            channel_params,
            hetero_params,
            high_fidelity_model_cfg=mf_cfg.get("highFidelityModel", {}),
        )
        high_secs = perf_counter() - t0
        stats = _build_stats(
            mode=mode,
            num_particles=num_particles,
            num_low=0,
            num_high=num_particles,
            low_secs=low_secs,
            high_secs=high_secs,
            elite_ratio=elite_ratio,
            elite_count_requested=max(elite_count_cfg, 0),
            elite_count_applied=num_particles,
            selection_rule=selection_rule,
            elite_indices=np.arange(num_particles, dtype=int),
            low_fidelity_model=low_fidelity_model,
        )
        return PropagationEvaluationResult(snr_matrix=snr, stats=stats)

    if mode != "elite_mixed_fidelity":
        raise ValueError(f"Unsupported multiFidelity.mode: {mode}")

    # 模式3：先全体低保真打分，再挑精英做高保真替换。
    t0 = perf_counter()
    snr_low = _compute_low_fidelity_snr(
        positions,
        test_points,
        city_map,
        channel_params,
        hetero_params,
        low_fidelity_model=low_fidelity_model,
    )
    low_secs = perf_counter() - t0

    elite_indices = _select_elite_particle_indices(
        snr_low=snr_low,
        channel_params=channel_params,
        elite_ratio=elite_ratio,
        elite_count=elite_count_cfg,
        min_elite=min_elite,
        selection_cfg=selection_cfg,
    )

    snr = snr_low.copy()
    if elite_indices.size > 0:
        t1 = perf_counter()
        elite_high = _compute_high_fidelity_snr(
            positions[elite_indices],
            test_points,
            city_map,
            channel_params,
            hetero_params,
            high_fidelity_model_cfg=mf_cfg.get("highFidelityModel", {}),
        )
        high_secs = perf_counter() - t1
        snr[elite_indices] = elite_high

    stats = _build_stats(
        mode=mode,
        num_particles=num_particles,
        num_low=num_particles - int(elite_indices.size),
        num_high=int(elite_indices.size),
        low_secs=low_secs,
        high_secs=high_secs,
        elite_ratio=elite_ratio,
        elite_count_requested=max(elite_count_cfg, 0),
        elite_count_applied=int(elite_indices.size),
        selection_rule=selection_rule,
        elite_indices=elite_indices,
        low_fidelity_model=low_fidelity_model,
    )
    return PropagationEvaluationResult(snr_matrix=snr, stats=stats)


def _normalize_mode(mode: object) -> str:
    """将多种简写统一到标准模式名。"""
    raw = str(mode).strip().lower()
    aliases = {
        "all_low": "all_low_fidelity",
        "low": "all_low_fidelity",
        "all_low_fidelity": "all_low_fidelity",
        "all_high": "all_high_fidelity",
        "high": "all_high_fidelity",
        "all_high_fidelity": "all_high_fidelity",
        "elite_mixed": "elite_mixed_fidelity",
        "mixed": "elite_mixed_fidelity",
        "elite_mixed_fidelity": "elite_mixed_fidelity",
    }
    return aliases.get(raw, raw)


def _resolve_low_fidelity_model(channel_params: Config, config: Config) -> str:
    """Resolve the concrete low-fidelity channel model used by this interface."""
    raw = channel_params.get("lowFidelityModel", config.get("channel", {}).get("lowFidelityModel", "a2g_probabilistic"))
    text = str(raw).strip().lower()
    aliases = {
        "a2g": "a2g_probabilistic",
        "a2g_probabilistic": "a2g_probabilistic",
        "paper_a2g_probabilistic": "a2g_probabilistic",
        "legacy": "legacy",
        "legacy_low_fidelity": "legacy",
    }
    return aliases.get(text, text)


def _compute_low_fidelity_snr(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    hetero_params: HeterogeneousPropagationParams,
    low_fidelity_model: str,
) -> np.ndarray:
    """低保真传播计算入口，显式调用配置选择的模型。"""
    if low_fidelity_model == "a2g_probabilistic":
        # 论文 A2G 概率信道：直接调用 a2g_probabilistic.py 中 Eq.(1)(2)(3) 实现。
        # nlos_penalty_factors 不传入 A2G 模型，避免改变论文公式。
        return compute_population_snr_matrix_a2g(
            positions=positions,
            test_points=test_points,
            channel_params=channel_params,
            tx_power_offsets_db=hetero_params.tx_power_offsets_db,
            coverage_boost_db=hetero_params.coverage_boost_db,
            path_loss_offsets_db=hetero_params.path_loss_offsets_db,
            sector_station_mask=hetero_params.sector_station_mask,
            sector_azimuths_deg=hetero_params.sector_azimuths_deg,
            sector_beamwidth_deg=hetero_params.sector_beamwidth_deg,
            outside_sector_mode=hetero_params.outside_sector_mode,
            side_lobe_attenuation_db=hetero_params.side_lobe_attenuation_db,
        )

    if low_fidelity_model == "legacy":
        return compute_population_snr_matrix_legacy(
            positions=positions,
            test_points=test_points,
            city_map=city_map,
            channel_params=channel_params,
            tx_power_offsets_db=hetero_params.tx_power_offsets_db,
            coverage_boost_db=hetero_params.coverage_boost_db,
            path_loss_offsets_db=hetero_params.path_loss_offsets_db,
            nlos_penalty_factors=hetero_params.nlos_penalty_factors,
            sector_station_mask=hetero_params.sector_station_mask,
            sector_azimuths_deg=hetero_params.sector_azimuths_deg,
            sector_beamwidth_deg=hetero_params.sector_beamwidth_deg,
            outside_sector_mode=hetero_params.outside_sector_mode,
            side_lobe_attenuation_db=hetero_params.side_lobe_attenuation_db,
        )

    raise ValueError(f"Unsupported channel.lowFidelityModel: {low_fidelity_model}")


def _compute_high_fidelity_snr(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    hetero_params: HeterogeneousPropagationParams,
    high_fidelity_model_cfg: Optional[Config],
) -> np.ndarray:
    """高保真传播计算入口。"""
    return compute_population_snr_matrix_high_fidelity(
        positions=positions,
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        tx_power_offsets_db=hetero_params.tx_power_offsets_db,
        coverage_boost_db=hetero_params.coverage_boost_db,
        path_loss_offsets_db=hetero_params.path_loss_offsets_db,
        nlos_penalty_factors=hetero_params.nlos_penalty_factors,
        sector_station_mask=hetero_params.sector_station_mask,
        sector_azimuths_deg=hetero_params.sector_azimuths_deg,
        sector_beamwidth_deg=hetero_params.sector_beamwidth_deg,
        outside_sector_mode=hetero_params.outside_sector_mode,
        side_lobe_attenuation_db=hetero_params.side_lobe_attenuation_db,
        model_params=high_fidelity_model_cfg,
    )


def _select_elite_particle_indices(
    snr_low: np.ndarray,
    channel_params: Config,
    elite_ratio: float,
    elite_count: int,
    min_elite: int,
    selection_cfg: Config,
) -> np.ndarray:
    """按配置从低保真结果中选择精英粒子索引。"""
    num_particles = snr_low.shape[0]
    if num_particles <= 0:
        return np.zeros((0,), dtype=int)

    if elite_count >= 0:
        target = elite_count
    else:
        target = int(np.ceil(elite_ratio * num_particles))
    target = int(np.clip(target, 0, num_particles))
    if target == 0 and min_elite > 0 and num_particles > 0:
        target = int(np.clip(min_elite, 0, num_particles))
    if target <= 0:
        return np.zeros((0,), dtype=int)

    score = _compute_elite_proxy_scores(snr_low, channel_params, selection_cfg)
    order = np.argsort(-score, kind="stable")
    elite_idx = order[:target]
    elite_idx.sort()
    return elite_idx.astype(int)


def _compute_elite_proxy_scores(snr_low: np.ndarray, channel_params: Config, selection_cfg: Config) -> np.ndarray:
    """基于覆盖率和平均 SNR 的代理分数计算精英排序分值。"""
    snr_threshold = float(channel_params.get("snrThreshold", 0.0))
    coverage_rate = np.mean(snr_low >= snr_threshold, axis=1)
    mean_snr = np.mean(snr_low, axis=1)

    cov_w = float(selection_cfg.get("coverageWeight", 1.0))
    snr_w = float(selection_cfg.get("snrWeight", 0.2))

    snr_min = float(np.min(mean_snr))
    snr_max = float(np.max(mean_snr))
    if snr_max > snr_min:
        mean_snr_norm = (mean_snr - snr_min) / (snr_max - snr_min)
    else:
        mean_snr_norm = np.zeros_like(mean_snr)

    return cov_w * coverage_rate * 100.0 + snr_w * mean_snr_norm * 100.0


def _build_stats(
    mode: str,
    num_particles: int,
    num_low: int,
    num_high: int,
    low_secs: float,
    high_secs: float,
    elite_ratio: float,
    elite_count_requested: int,
    elite_count_applied: int,
    selection_rule: str,
    elite_indices: np.ndarray,
    low_fidelity_model: str,
    sector_stats: Optional[Dict[str, Any]] = None,
) -> PropagationEvaluationStats:
    """组装统一的统计对象，便于实验导出与对比。"""
    total = float(low_secs + high_secs)
    return PropagationEvaluationStats(
        mode=mode,
        num_particles=num_particles,
        num_low_fidelity=int(max(num_low, 0)),
        num_high_fidelity=int(max(num_high, 0)),
        low_fidelity_seconds=float(low_secs),
        high_fidelity_seconds=float(high_secs),
        total_seconds=total,
        elite_ratio=float(elite_ratio),
        elite_count_requested=int(max(elite_count_requested, 0)),
        elite_count_applied=int(max(elite_count_applied, 0)),
        elite_selection_rule=selection_rule,
        elite_indices=[int(i) for i in elite_indices.tolist()],
        low_fidelity_model=str(low_fidelity_model),
        sector_stats=sector_stats,
    )
