from __future__ import annotations

from typing import Any, Dict, List, Tuple

import numpy as np

from src.data.types import CityMap, Config


def apply_low_latency_response(
    positions: np.ndarray,
    velocities: np.ndarray,
    response_cfg: Config,
    current_w: float,
    current_c1: float,
    current_c2: float,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, float | bool | List[str]]]:
    """轻度停滞响应：仅做参数自适应（低时延、低扰动）。"""
    cfg = dict(response_cfg or {})
    strategies: Dict[str, float | bool | List[str]] = {
        "updated_w": float(current_w),
        "updated_c1": float(current_c1),
        "updated_c2": float(current_c2),
        "low_latency_response": False,
        "applied": [],
    }

    # 轻度策略：增大惯性权重、增大认知项、减小社会项。
    inertia_boost = float(cfg.get("inertiaBoost", 1.03))
    c1_scale = float(cfg.get("c1Scale", 1.02))
    c2_scale = float(cfg.get("c2Scale", 0.99))

    strategies["updated_w"] = min(float(current_w * inertia_boost), float(cfg.get("wMax", 0.95)))
    strategies["updated_c1"] = min(float(current_c1 * c1_scale), float(cfg.get("c1Max", 2.4)))
    strategies["updated_c2"] = max(float(current_c2 * c2_scale), float(cfg.get("c2Min", 0.9)))
    strategies["applied"] = ["mild_parameter_adaptation"]

    strategies["low_latency_response"] = True
    return positions, velocities, strategies


def apply_high_stagnation_response(
    positions: np.ndarray,
    velocities: np.ndarray,
    pbest_pos: np.ndarray,
    pbest_obj: np.ndarray,
    pbest_comp: np.ndarray,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    archive: Any,
    city_map: CityMap,
    rng: np.random.Generator,
    response_cfg: Config,
    stage1_restart_sites: np.ndarray,
    particle_scores: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, float | bool | List[str]]]:
    """重度停滞响应：低适应度粒子重启（阶段一解 + 扰动 + 随机注入）。"""
    cfg = dict(response_cfg or {})
    strategies: Dict[str, float | bool | List[str]] = {
        "high_stagnation_response": False,
        "applied": [],
    }

    ratio = float(np.clip(cfg.get("restartRatio", 0.45), 0.0, 1.0))
    num = max(1, int(round(positions.shape[0] * ratio)))
    idx = _select_low_fitness_indices(particle_scores=particle_scores, num=num, rng=rng)

    # 基于阶段一候选点进行引导重启，并保留随机注入提升多样性。
    stage1_prob = float(np.clip(cfg.get("stage1SeedProb", 0.75), 0.0, 1.0))
    random_station_prob = float(np.clip(cfg.get("randomStationProb", 0.25), 0.0, 1.0))
    spatial_min = np.asarray(min_pos, dtype=float).reshape(-1)[:3]
    spatial_max = np.asarray(max_pos, dtype=float).reshape(-1)[:3]
    sigma = (spatial_max - spatial_min) * float(cfg.get("noiseSigmaRatio", 0.10))
    full_min = np.asarray(min_pos, dtype=float).reshape(-1)
    full_max = np.asarray(max_pos, dtype=float).reshape(-1)
    if full_min.size < positions.shape[2]:
        full_min = np.pad(full_min, (0, positions.shape[2] - full_min.size), constant_values=0.0)
    if full_max.size < positions.shape[2]:
        full_max = np.pad(full_max, (0, positions.shape[2] - full_max.size), constant_values=1.0)

    for i in idx:
        restarted = np.zeros_like(positions[i])
        for b in range(positions[i].shape[0]):
            restarted[b] = rng.uniform(low=full_min[: positions.shape[2]], high=full_max[: positions.shape[2]])
            use_stage1 = stage1_restart_sites.size > 0 and bool(rng.random() < stage1_prob)
            force_random = bool(rng.random() < random_station_prob)
            if use_stage1 and not force_random:
                sidx = int(rng.integers(0, stage1_restart_sites.shape[0]))
                base = np.asarray(stage1_restart_sites[sidx], dtype=float)[:3]
                noise = rng.normal(0.0, sigma, size=base.shape)
                restarted[b, :3] = np.clip(base + noise, spatial_min, spatial_max)
            else:
                restarted[b, :3] = rng.uniform(low=spatial_min, high=spatial_max, size=(3,))

        positions[i] = restarted

    span = full_max[: positions.shape[2]] - full_min[: positions.shape[2]]
    velocities[idx] = (rng.random(velocities[idx].shape) - 0.5) * span[None, None, :] * 0.1
    from src.algorithms.init_strategies import enforce_non_building_constraint

    positions = enforce_non_building_constraint(positions, city_map, min_pos, max_pos, rng)

    pbest_pos[idx] = positions[idx]
    pbest_obj[idx] = np.inf
    pbest_comp[idx] = -np.inf

    strategies["high_stagnation_response"] = True
    strategies["applied"] = ["low_fitness_restart_stage1_seeded_perturb"]
    return positions, velocities, strategies


def _select_low_fitness_indices(particle_scores: np.ndarray, num: int, rng: np.random.Generator) -> np.ndarray:
    """选择低适应度粒子索引用于重启。"""
    scores = np.asarray(particle_scores, dtype=float).reshape(-1)
    n = int(scores.size)
    if n <= 0:
        return np.zeros((0,), dtype=int)
    take = int(np.clip(num, 1, n))

    finite = np.isfinite(scores)
    if not np.any(finite):
        return rng.choice(n, size=take, replace=False).astype(int)

    # 低适应度定义：综合目标分数越低越差。
    safe_scores = scores.copy()
    safe_scores[~finite] = -np.inf
    order = np.argsort(safe_scores, kind="stable")
    return order[:take].astype(int)
