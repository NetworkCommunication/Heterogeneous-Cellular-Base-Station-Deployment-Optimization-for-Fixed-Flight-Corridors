from __future__ import annotations

from typing import Optional, Tuple

import numpy as np

from src.data.types import CityMap, Config
from src.propagation.a2g_probabilistic import (
    compute_population_best_link_path_loss_a2g_db,
    compute_population_snr_matrix_a2g,
    compute_population_strongest_station_indices_a2g,
)
from src.propagation.low_fidelity_legacy import (
    compute_population_best_link_path_loss_legacy_db,
    compute_population_snr_matrix_legacy,
    compute_population_strongest_station_indices_legacy,
)


def _resolve_low_fidelity_model(channel_params: Config) -> str:
    raw = str(channel_params.get("lowFidelityModel", "a2g_probabilistic")).strip().lower()
    aliases = {
        "a2g": "a2g_probabilistic",
        "a2g_probabilistic": "a2g_probabilistic",
        "paper_a2g_probabilistic": "a2g_probabilistic",
        "legacy": "legacy",
        "legacy_low_fidelity": "legacy",
    }
    return aliases.get(raw, raw)


def compute_population_snr_matrix(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    nlos_penalty_factors: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> np.ndarray:
    """Compute SNR matrix for particle population through configured low-fidelity model."""
    mode = _resolve_low_fidelity_model(channel_params)
    if mode == "legacy":
        return compute_population_snr_matrix_legacy(
            positions=positions,
            test_points=test_points,
            city_map=city_map,
            channel_params=channel_params,
            tx_power_offsets_db=tx_power_offsets_db,
            coverage_boost_db=coverage_boost_db,
            path_loss_offsets_db=path_loss_offsets_db,
            nlos_penalty_factors=nlos_penalty_factors,
            sector_station_mask=sector_station_mask,
            sector_azimuths_deg=sector_azimuths_deg,
            sector_beamwidth_deg=sector_beamwidth_deg,
            outside_sector_mode=outside_sector_mode,
            side_lobe_attenuation_db=side_lobe_attenuation_db,
        )
    if mode == "a2g_probabilistic":
        # Paper-faithful Eq.(1)(2)(3) path-loss core model; receiver projected to ground.
        # nlos_penalty_factors is intentionally not used in this mode to avoid changing paper equations.
        return compute_population_snr_matrix_a2g(
            positions=positions,
            test_points=test_points,
            channel_params=channel_params,
            tx_power_offsets_db=tx_power_offsets_db,
            coverage_boost_db=coverage_boost_db,
            path_loss_offsets_db=path_loss_offsets_db,
            sector_station_mask=sector_station_mask,
            sector_azimuths_deg=sector_azimuths_deg,
            sector_beamwidth_deg=sector_beamwidth_deg,
            outside_sector_mode=outside_sector_mode,
            side_lobe_attenuation_db=side_lobe_attenuation_db,
        )
    raise ValueError(f"Unsupported channel.lowFidelityModel: {mode}")


def compute_population_strongest_station_indices(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    nlos_penalty_factors: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> np.ndarray:
    """Return strongest-link station index for each particle-point pair."""
    mode = _resolve_low_fidelity_model(channel_params)
    if mode == "legacy":
        return compute_population_strongest_station_indices_legacy(
            positions=positions,
            test_points=test_points,
            city_map=city_map,
            channel_params=channel_params,
            tx_power_offsets_db=tx_power_offsets_db,
            coverage_boost_db=coverage_boost_db,
            path_loss_offsets_db=path_loss_offsets_db,
            nlos_penalty_factors=nlos_penalty_factors,
            sector_station_mask=sector_station_mask,
            sector_azimuths_deg=sector_azimuths_deg,
            sector_beamwidth_deg=sector_beamwidth_deg,
            outside_sector_mode=outside_sector_mode,
            side_lobe_attenuation_db=side_lobe_attenuation_db,
        )
    if mode == "a2g_probabilistic":
        return compute_population_strongest_station_indices_a2g(
            positions=positions,
            test_points=test_points,
            channel_params=channel_params,
            tx_power_offsets_db=tx_power_offsets_db,
            coverage_boost_db=coverage_boost_db,
            path_loss_offsets_db=path_loss_offsets_db,
            sector_station_mask=sector_station_mask,
            sector_azimuths_deg=sector_azimuths_deg,
            sector_beamwidth_deg=sector_beamwidth_deg,
            outside_sector_mode=outside_sector_mode,
            side_lobe_attenuation_db=side_lobe_attenuation_db,
        )
    raise ValueError(f"Unsupported channel.lowFidelityModel: {mode}")


def compute_population_best_link_path_loss_db(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    nlos_penalty_factors: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Return best-link path loss and serving station index under current low-fidelity model."""
    mode = _resolve_low_fidelity_model(channel_params)
    if mode == "legacy":
        return compute_population_best_link_path_loss_legacy_db(
            positions=positions,
            test_points=test_points,
            city_map=city_map,
            channel_params=channel_params,
            tx_power_offsets_db=tx_power_offsets_db,
            coverage_boost_db=coverage_boost_db,
            path_loss_offsets_db=path_loss_offsets_db,
            nlos_penalty_factors=nlos_penalty_factors,
            sector_station_mask=sector_station_mask,
            sector_azimuths_deg=sector_azimuths_deg,
            sector_beamwidth_deg=sector_beamwidth_deg,
            outside_sector_mode=outside_sector_mode,
            side_lobe_attenuation_db=side_lobe_attenuation_db,
        )
    if mode == "a2g_probabilistic":
        return compute_population_best_link_path_loss_a2g_db(
            positions=positions,
            test_points=test_points,
            channel_params=channel_params,
            tx_power_offsets_db=tx_power_offsets_db,
            coverage_boost_db=coverage_boost_db,
            path_loss_offsets_db=path_loss_offsets_db,
            sector_station_mask=sector_station_mask,
            sector_azimuths_deg=sector_azimuths_deg,
            sector_beamwidth_deg=sector_beamwidth_deg,
            outside_sector_mode=outside_sector_mode,
            side_lobe_attenuation_db=side_lobe_attenuation_db,
        )
    raise ValueError(f"Unsupported channel.lowFidelityModel: {mode}")


def fitness_batch(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
) -> np.ndarray:
    """Compute covered-point counts for each particle (SNR >= threshold)."""
    if test_points.size == 0:
        return np.zeros(positions.shape[0], dtype=float)
    snr_threshold = float(channel_params.get("snrThreshold", 0.0))
    snr = compute_population_snr_matrix(positions, test_points, city_map, channel_params)
    return np.sum(snr >= snr_threshold, axis=1).astype(float)


def compute_point_snr(
    best_position: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    nlos_penalty_factors: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> np.ndarray:
    """Compute per-point SNR for one deployment solution."""
    if best_position.size == 0 or test_points.size == 0:
        return np.zeros((test_points.shape[0],), dtype=float)
    one = best_position[None, :, :]
    snr = compute_population_snr_matrix(
        one,
        test_points,
        city_map,
        channel_params,
        tx_power_offsets_db=tx_power_offsets_db,
        coverage_boost_db=coverage_boost_db,
        path_loss_offsets_db=path_loss_offsets_db,
        nlos_penalty_factors=nlos_penalty_factors,
        sector_station_mask=sector_station_mask,
        sector_azimuths_deg=sector_azimuths_deg,
        sector_beamwidth_deg=sector_beamwidth_deg,
        outside_sector_mode=outside_sector_mode,
        side_lobe_attenuation_db=side_lobe_attenuation_db,
    )
    return snr[0]
