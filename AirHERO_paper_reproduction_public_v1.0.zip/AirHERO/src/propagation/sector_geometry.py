from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

import numpy as np


DEFAULT_SECTOR_DIRECTIONS_DEG = np.asarray([0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0], dtype=float)
PROPOSED_METHOD_NAMES = ("proposed", "proposed_method")
PROPOSED_STAGE1_MAIN_SECTOR_STRATEGIES = ("enumerate_best", "demand_weighted_best")
PROPOSED_STAGE1_RANDOM_SECTOR_STRATEGY = "random"
ABLATION_OR_DIAGNOSTIC_LABELS = ("ablation", "diagnostic")
OUTSIDE_SECTOR_NO_COVERAGE = "no_coverage"
OUTSIDE_SECTOR_SIDE_LOBE = "side_lobe"
OUTSIDE_SECTOR_BASELINE_5G = "baseline_5g"
VALID_OUTSIDE_SECTOR_MODES = (
    OUTSIDE_SECTOR_NO_COVERAGE,
    OUTSIDE_SECTOR_SIDE_LOBE,
    OUTSIDE_SECTOR_BASELINE_5G,
)


@dataclass(frozen=True)
class SectorGeometryConfig:
    """Configurable 5GA single-sector geometry assumptions."""

    sector_directions_deg: np.ndarray
    sector_beamwidth_deg: float
    outside_sector_mode: str
    side_lobe_attenuation_db: float


def normalize_azimuth_deg(azimuth_deg: float | np.ndarray) -> float | np.ndarray:
    """Normalize azimuth angles to [0, 360) degrees."""
    arr = np.mod(np.asarray(azimuth_deg, dtype=float), 360.0)
    if np.ndim(azimuth_deg) == 0:
        return float(arr)
    return arr.astype(float)


def normalize_sector_directions_deg(directions_deg: Sequence[float] | np.ndarray | None = None) -> np.ndarray:
    """Return finite, unique sector directions normalized to [0, 360).

    This helper intentionally remains flexible for isolated geometry demos and
    non-proposed experimental toys. Proposed-method runs must call
    `validate_proposed_sector_config` before optimization.
    """
    raw = DEFAULT_SECTOR_DIRECTIONS_DEG if directions_deg is None else directions_deg
    arr = np.asarray(raw, dtype=float).reshape(-1)
    if arr.size == 0:
        raise ValueError("sector_directions_deg must contain at least one direction")
    if not np.isfinite(arr).all():
        raise ValueError("sector_directions_deg must be finite")

    normalized = np.asarray(normalize_azimuth_deg(arr), dtype=float)
    unique: list[float] = []
    for value in normalized.tolist():
        if not any(np.isclose(value, existing, atol=1e-9, rtol=0.0) for existing in unique):
            unique.append(float(value))
    return np.asarray(unique, dtype=float)


def bearing_deg(station_xy: np.ndarray, point_xy: np.ndarray) -> np.ndarray:
    """Compute compass bearing from station to point.

    Convention: 0 deg points north (+Y), 90 deg points east (+X), and
    azimuth increases clockwise. Inputs are broadcast by NumPy and only the
    first two coordinates are used.
    """
    station = np.asarray(station_xy, dtype=float)[..., :2]
    point = np.asarray(point_xy, dtype=float)[..., :2]
    dx = point[..., 0] - station[..., 0]
    dy = point[..., 1] - station[..., 1]
    bearing = np.degrees(np.arctan2(dx, dy))
    return np.asarray(normalize_azimuth_deg(bearing), dtype=float)


def wrapped_angular_difference_deg(reference_deg: float | np.ndarray, target_deg: float | np.ndarray) -> float | np.ndarray:
    """Return signed wrapped difference `target - reference` in [-180, 180)."""
    reference = np.asarray(reference_deg, dtype=float)
    target = np.asarray(target_deg, dtype=float)
    diff = (target - reference + 180.0) % 360.0 - 180.0
    if np.ndim(diff) == 0:
        return float(diff)
    return diff.astype(float)


def absolute_wrapped_angular_difference_deg(
    reference_deg: float | np.ndarray,
    target_deg: float | np.ndarray,
) -> float | np.ndarray:
    """Return absolute wrapped angular difference in degrees."""
    diff = np.abs(np.asarray(wrapped_angular_difference_deg(reference_deg, target_deg), dtype=float))
    if np.ndim(diff) == 0:
        return float(diff)
    return diff.astype(float)


def inside_sector_mask(
    station_xy: np.ndarray,
    point_xy: np.ndarray,
    sector_azimuth_deg: float | np.ndarray,
    sector_beamwidth_deg: float,
) -> np.ndarray:
    """Return whether each point lies inside the single-sector beam."""
    beamwidth = _validate_sector_beamwidth_deg(sector_beamwidth_deg)
    bearings = bearing_deg(station_xy=station_xy, point_xy=point_xy)
    if beamwidth >= 360.0:
        return np.ones_like(bearings, dtype=bool)

    half_width = beamwidth * 0.5
    diff = absolute_wrapped_angular_difference_deg(sector_azimuth_deg, bearings)
    return np.asarray(diff <= half_width + 1e-9, dtype=bool)


def sector_gain_db(
    inside_sector: np.ndarray | bool,
    outside_sector_mode: str = OUTSIDE_SECTOR_NO_COVERAGE,
    side_lobe_attenuation_db: float = 30.0,
) -> np.ndarray | float:
    """Return per-point sector gain in dB.

    Inside-sector gain is 0 dB. Outside-sector behavior is configurable:
    `no_coverage` returns -inf dB, while `side_lobe` returns negative
    `side_lobe_attenuation_db`. Calibration-only `baseline_5g` also returns
    negative `side_lobe_attenuation_db`; callers set that attenuation equal
    to the configured in-sector enhancement so outside-sector links fall
    back to the 5G-like baseline instead of disappearing.
    """
    mode = _normalize_outside_sector_mode(outside_sector_mode)
    attenuation = float(side_lobe_attenuation_db)
    if attenuation < 0.0:
        raise ValueError("side_lobe_attenuation_db must be non-negative")

    mask = np.asarray(inside_sector, dtype=bool)
    if mode == OUTSIDE_SECTOR_NO_COVERAGE:
        outside_gain = -np.inf
    else:
        outside_gain = -attenuation

    gain = np.where(mask, 0.0, outside_gain).astype(float)
    if np.ndim(gain) == 0:
        return float(gain)
    return gain


def sector_gain_linear(
    inside_sector: np.ndarray | bool,
    outside_sector_mode: str = OUTSIDE_SECTOR_NO_COVERAGE,
    side_lobe_attenuation_db: float = 30.0,
) -> np.ndarray | float:
    """Return sector power multiplier from the configured outside-sector rule."""
    gain_db = np.asarray(
        sector_gain_db(
            inside_sector=inside_sector,
            outside_sector_mode=outside_sector_mode,
            side_lobe_attenuation_db=side_lobe_attenuation_db,
        ),
        dtype=float,
    )
    linear = np.where(np.isneginf(gain_db), 0.0, np.power(10.0, gain_db / 10.0))
    if np.ndim(linear) == 0:
        return float(linear)
    return linear.astype(float)


def compute_sector_gain_db(
    station_xy: np.ndarray,
    point_xy: np.ndarray,
    sector_azimuth_deg: float | np.ndarray,
    sector_beamwidth_deg: float,
    outside_sector_mode: str = OUTSIDE_SECTOR_NO_COVERAGE,
    side_lobe_attenuation_db: float = 30.0,
) -> np.ndarray | float:
    """Compute sector gain in dB directly from station/point geometry."""
    inside = inside_sector_mask(
        station_xy=station_xy,
        point_xy=point_xy,
        sector_azimuth_deg=sector_azimuth_deg,
        sector_beamwidth_deg=sector_beamwidth_deg,
    )
    return sector_gain_db(
        inside_sector=inside,
        outside_sector_mode=outside_sector_mode,
        side_lobe_attenuation_db=side_lobe_attenuation_db,
    )


def compute_sector_gain_matrix_db(
    positions: np.ndarray,
    test_points: np.ndarray,
    sector_station_mask: np.ndarray | None,
    sector_azimuths_deg: np.ndarray | None,
    sector_beamwidth_deg: float,
    outside_sector_mode: str = OUTSIDE_SECTOR_NO_COVERAGE,
    side_lobe_attenuation_db: float = 30.0,
) -> tuple[np.ndarray, np.ndarray]:
    """Build per-link sector gain and inside-main-lobe masks.

    Non-sector stations receive 0 dB gain for every point, preserving
    omnidirectional 5G behavior. Sector stations receive 0 dB inside the
    configured beam and either -inf dB or configured attenuation outside.
    """
    pos = np.asarray(positions, dtype=float)
    points = np.asarray(test_points, dtype=float)
    if pos.size == 0 or points.size == 0:
        n_particles = int(pos.shape[0]) if pos.ndim >= 1 else 0
        n_base = int(pos.shape[1]) if pos.ndim >= 2 else 0
        n_points = int(points.shape[0]) if points.ndim == 2 else 0
        shape = (n_particles, n_base, n_points)
        return np.zeros(shape, dtype=float), np.zeros(shape, dtype=bool)
    if pos.ndim != 3 or pos.shape[2] < 2:
        raise ValueError("positions must have shape [num_particles, num_base, >=2]")
    if points.ndim != 2 or points.shape[1] < 2:
        raise ValueError("test_points must have shape [num_points, >=2]")

    n_particles, n_base, _ = pos.shape
    n_points = int(points.shape[0])
    mask = _normalize_sector_station_mask(sector_station_mask, n_base)
    azimuths = _normalize_sector_azimuths(sector_azimuths_deg, n_base)

    gain = np.zeros((n_particles, n_base, n_points), dtype=float)
    inside = np.zeros((n_particles, n_base, n_points), dtype=bool)
    if not np.any(mask):
        return gain, inside

    for b in np.where(mask)[0]:
        station_xy = pos[:, b, None, :2]
        point_xy = points[None, :, :2]
        inside_b = inside_sector_mask(
            station_xy=station_xy,
            point_xy=point_xy,
            sector_azimuth_deg=float(azimuths[b]),
            sector_beamwidth_deg=sector_beamwidth_deg,
        )
        inside[:, b, :] = inside_b
        gain[:, b, :] = np.asarray(
            sector_gain_db(
                inside_sector=inside_b,
                outside_sector_mode=outside_sector_mode,
                side_lobe_attenuation_db=side_lobe_attenuation_db,
            ),
            dtype=float,
        )
    return gain, inside


def summarize_sector_masks(
    positions: np.ndarray,
    test_points: np.ndarray,
    sector_station_mask: np.ndarray | None,
    sector_azimuths_deg: np.ndarray | None,
    sector_beamwidth_deg: float,
) -> dict[str, np.ndarray]:
    """Summarize main-lobe geometry for logging and objective diagnostics."""
    _, inside = compute_sector_gain_matrix_db(
        positions=positions,
        test_points=test_points,
        sector_station_mask=sector_station_mask,
        sector_azimuths_deg=sector_azimuths_deg,
        sector_beamwidth_deg=sector_beamwidth_deg,
        outside_sector_mode=OUTSIDE_SECTOR_NO_COVERAGE,
        side_lobe_attenuation_db=0.0,
    )
    pos = np.asarray(positions, dtype=float)
    points = np.asarray(test_points, dtype=float)
    n_particles = int(pos.shape[0]) if pos.ndim >= 1 else 0
    n_base = int(pos.shape[1]) if pos.ndim >= 2 else 0
    n_points = int(points.shape[0]) if points.ndim == 2 else 0
    mask = _normalize_sector_station_mask(sector_station_mask, n_base)
    azimuths = _normalize_sector_azimuths(sector_azimuths_deg, n_base)

    if n_particles <= 0:
        inside_any_rate = np.zeros((0,), dtype=float)
        outside_all_count = np.zeros((0,), dtype=float)
    elif not np.any(mask) or n_points <= 0:
        inside_any_rate = np.zeros((n_particles,), dtype=float)
        outside_all_count = np.zeros((n_particles,), dtype=float)
    else:
        inside_any = np.any(inside[:, mask, :], axis=1)
        inside_any_rate = np.mean(inside_any.astype(float), axis=1)
        outside_all_count = np.sum(~inside_any, axis=1).astype(float)

    return {
        "sector_inside_mask": inside,
        "sector_station_mask": mask,
        "sector_azimuths_deg": azimuths,
        "sector_inside_any_5ga_rate": inside_any_rate,
        "sector_points_outside_all_5ga_count": outside_all_count,
        "sector_excluded_link_count": np.sum((~inside[:, mask, :]).astype(float), axis=(1, 2))
        if np.any(mask) and inside.size > 0
        else np.zeros((n_particles,), dtype=float),
    }


def is_supported_sector_direction_deg(
    azimuth_deg: float,
    sector_directions_deg: Sequence[float] | np.ndarray | None = None,
    atol: float = 1e-9,
) -> bool:
    """Return whether an azimuth is one of the configured sector directions."""
    candidate = float(normalize_azimuth_deg(azimuth_deg))
    directions = normalize_sector_directions_deg(sector_directions_deg)
    return bool(np.any(np.isclose(directions, candidate, atol=float(atol), rtol=0.0)))


def nearest_supported_sector_direction_deg(
    azimuth_deg: float | np.ndarray,
    sector_directions_deg: Sequence[float] | np.ndarray | None = None,
) -> float | np.ndarray:
    """Snap an arbitrary azimuth to the nearest configured sector direction."""
    candidate = np.asarray(normalize_azimuth_deg(azimuth_deg), dtype=float)
    directions = normalize_sector_directions_deg(sector_directions_deg)
    diff = absolute_wrapped_angular_difference_deg(candidate[..., None], directions[None, :])
    idx = np.argmin(np.asarray(diff, dtype=float), axis=-1)
    snapped = directions[idx]
    if np.ndim(azimuth_deg) == 0:
        return float(snapped)
    return snapped.astype(float)


def _normalize_sector_station_mask(mask: np.ndarray | None, num_base: int) -> np.ndarray:
    if mask is None:
        return np.zeros((num_base,), dtype=bool)
    arr = np.asarray(mask, dtype=bool).reshape(-1)
    if arr.size != int(num_base):
        raise ValueError("sector_station_mask length must equal number of base stations")
    return arr


def _normalize_sector_azimuths(azimuths_deg: np.ndarray | None, num_base: int) -> np.ndarray:
    if azimuths_deg is None:
        return np.zeros((num_base,), dtype=float)
    arr = np.asarray(azimuths_deg, dtype=float).reshape(-1)
    if arr.size != int(num_base):
        raise ValueError("sector_azimuths_deg length must equal number of base stations")
    if not np.isfinite(arr).all():
        raise ValueError("sector_azimuths_deg must be finite")
    return np.asarray(normalize_azimuth_deg(arr), dtype=float)


def sector_geometry_config_from_mapping(config: Mapping[str, object]) -> SectorGeometryConfig:
    """Parse sector geometry fields from a full config or channel config mapping."""
    raw_channel = config.get("channel", config)
    if not isinstance(raw_channel, Mapping):
        raise ValueError("sector geometry config must be a mapping")

    directions = normalize_sector_directions_deg(raw_channel.get("sector_directions_deg", DEFAULT_SECTOR_DIRECTIONS_DEG))
    beamwidth = _validate_sector_beamwidth_deg(float(raw_channel.get("sector_beamwidth_deg", 90.0)))
    mode = _normalize_outside_sector_mode(str(raw_channel.get("outside_sector_mode", OUTSIDE_SECTOR_NO_COVERAGE)))
    attenuation_key = (
        "baseline_5g_outside_sector_attenuation_db"
        if mode == OUTSIDE_SECTOR_BASELINE_5G
        else "side_lobe_attenuation_db"
    )
    attenuation = float(raw_channel.get(attenuation_key, raw_channel.get("side_lobe_attenuation_db", 30.0)))
    if attenuation < 0.0:
        raise ValueError("side_lobe_attenuation_db must be non-negative")
    return SectorGeometryConfig(
        sector_directions_deg=directions,
        sector_beamwidth_deg=beamwidth,
        outside_sector_mode=mode,
        side_lobe_attenuation_db=attenuation,
    )


def validate_proposed_sector_config(config: Mapping[str, object], method_name: str | None = None) -> None:
    """Validate the fixed 5GA sector assumptions required by proposed runs.

    Non-proposed toy/diagnostic code may still use flexible sector direction
    lists through `sector_geometry_config_from_mapping`. The proposed method is
    stricter: 5GA directions are a decision variable over the eight compass
    azimuths, and 360-degree beams are rejected because they make 5GA
    omnidirectional.
    """
    method = _normalize_method_name(method_name)
    if not method:
        method = _method_name_from_config(config)
    if method not in PROPOSED_METHOD_NAMES:
        return

    raw_channel = config.get("channel", {}) if isinstance(config, Mapping) else {}
    if not isinstance(raw_channel, Mapping):
        raise ValueError("Proposed method requires config.channel to be a mapping")

    _validate_exact_proposed_sector_directions(raw_channel.get("sector_directions_deg", DEFAULT_SECTOR_DIRECTIONS_DEG))

    beamwidth = float(raw_channel.get("sector_beamwidth_deg", 90.0))
    if not np.isfinite(beamwidth):
        raise ValueError("Proposed method requires finite channel.sector_beamwidth_deg")
    if beamwidth <= 0.0 or beamwidth >= 360.0:
        raise ValueError(
            "Proposed method requires directional 5GA sectors with 0 < "
            "channel.sector_beamwidth_deg < 360; 360-degree beams are invalid."
        )

    raw_encoding = config.get("particleEncoding", {}) if isinstance(config, Mapping) else {}
    if raw_encoding is None:
        raw_encoding = {}
    if not isinstance(raw_encoding, Mapping):
        raise ValueError("Proposed method requires config.particleEncoding to be a mapping")
    optimize_sector = bool(
        raw_encoding.get(
            "optimizeSectorDirection",
            raw_encoding.get("sectorDirectionDecision", True),
        )
    )
    if not optimize_sector:
        raise ValueError(
            "Proposed method requires particleEncoding.optimizeSectorDirection=True "
            "because 5GA sector direction is an optimized decision variable."
        )

    _validate_proposed_stage1_sector_strategy(config)


def _validate_sector_beamwidth_deg(sector_beamwidth_deg: float) -> float:
    beamwidth = float(sector_beamwidth_deg)
    if not np.isfinite(beamwidth):
        raise ValueError("sector_beamwidth_deg must be finite")
    if beamwidth <= 0.0 or beamwidth > 360.0:
        raise ValueError("sector_beamwidth_deg must be in (0, 360]")
    return beamwidth


def _normalize_outside_sector_mode(mode: str) -> str:
    normalized = str(mode).strip().lower()
    if normalized not in VALID_OUTSIDE_SECTOR_MODES:
        raise ValueError(f"outside_sector_mode must be one of {VALID_OUTSIDE_SECTOR_MODES}")
    return normalized


def _method_name_from_config(config: Mapping[str, object]) -> str:
    top_level = config.get("method")
    if top_level is not None:
        return _normalize_method_name(str(top_level))
    raw_experiment = config.get("experiment", {})
    if isinstance(raw_experiment, Mapping):
        return _normalize_method_name(raw_experiment.get("method", ""))
    return ""


def _normalize_method_name(method_name: object | None) -> str:
    return str(method_name or "").strip().lower().replace("-", "_")


def _validate_proposed_stage1_sector_strategy(config: Mapping[str, object]) -> None:
    raw_stage1 = config.get("stage1", {})
    if raw_stage1 is None:
        raw_stage1 = {}
    if not isinstance(raw_stage1, Mapping):
        raise ValueError("Proposed method requires config.stage1 to be a mapping when provided")

    strategy = _normalize_stage1_sector_strategy_name(
        raw_stage1.get(
            "stage1_5ga_direction_strategy",
            raw_stage1.get("fivegaDirectionStrategy", PROPOSED_STAGE1_MAIN_SECTOR_STRATEGIES[0]),
        )
    )
    if strategy in PROPOSED_STAGE1_MAIN_SECTOR_STRATEGIES:
        return
    if strategy == PROPOSED_STAGE1_RANDOM_SECTOR_STRATEGY and _explicitly_allows_stage1_random_sector_strategy(
        config,
        raw_stage1,
    ):
        return
    if strategy == PROPOSED_STAGE1_RANDOM_SECTOR_STRATEGY:
        raise ValueError(
            "Proposed main experiments require stage1_5ga_direction_strategy to be "
            "'enumerate_best' or 'demand_weighted_best'. Random Stage-1 5GA sector "
            "selection is only allowed when experiment group/type/scope is explicitly "
            "marked as ablation or diagnostic and allowRandomStage1SectorStrategy=True."
        )
    raise ValueError(
        "Proposed method requires stage1_5ga_direction_strategy to be "
        "'enumerate_best' or 'demand_weighted_best' for main experiments."
    )


def _normalize_stage1_sector_strategy_name(strategy: object) -> str:
    return str(strategy or "").strip().lower().replace("-", "_")


def _explicitly_allows_stage1_random_sector_strategy(
    config: Mapping[str, object],
    stage1_cfg: Mapping[str, object],
) -> bool:
    raw_experiment = config.get("experiment", {})
    if not isinstance(raw_experiment, Mapping):
        return False

    allow_random = bool(
        raw_experiment.get(
            "allowRandomStage1SectorStrategy",
            stage1_cfg.get("allowRandomSectorStrategy", False),
        )
    )
    if not allow_random:
        return False

    marker_values = [
        raw_experiment.get("group", ""),
        raw_experiment.get("scope", ""),
        raw_experiment.get("type", ""),
        raw_experiment.get("experimentType", ""),
        raw_experiment.get("purpose", ""),
    ]
    labels = {_normalize_stage1_sector_strategy_name(v) for v in marker_values}
    return bool(labels.intersection(ABLATION_OR_DIAGNOSTIC_LABELS))


def _validate_exact_proposed_sector_directions(directions_deg: object) -> None:
    try:
        arr = np.asarray(directions_deg, dtype=float).reshape(-1)
    except Exception as exc:
        raise ValueError(
            "Proposed method requires channel.sector_directions_deg to exactly match "
            "[0, 45, 90, 135, 180, 225, 270, 315]."
        ) from exc

    expected = DEFAULT_SECTOR_DIRECTIONS_DEG
    if arr.size != expected.size or not np.isfinite(arr).all():
        raise ValueError(
            "Proposed method requires channel.sector_directions_deg to exactly match "
            "[0, 45, 90, 135, 180, 225, 270, 315]."
        )

    if not np.allclose(arr, expected, atol=1e-9, rtol=0.0):
        raise ValueError(
            "Proposed method requires channel.sector_directions_deg to exactly match "
            "[0, 45, 90, 135, 180, 225, 270, 315] in this exact order; reordered "
            "direction lists change sector_direction_index semantics and are only "
            "allowed for non-proposed experimental toys."
        )
