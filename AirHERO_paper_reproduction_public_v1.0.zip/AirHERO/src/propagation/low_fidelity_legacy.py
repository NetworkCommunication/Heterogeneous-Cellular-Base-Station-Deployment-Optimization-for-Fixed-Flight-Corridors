from __future__ import annotations

from typing import Optional, Tuple

import numpy as np

from src.data.types import CityMap, Config
from src.propagation.sector_geometry import compute_sector_gain_matrix_db


def _sample_height_nearest(mid_xy: np.ndarray, city_map: CityMap) -> np.ndarray:
    """Read building height via nearest-neighbor sampling."""
    res = city_map.height_resolution
    ny, nx = city_map.height_matrix.shape
    x_idx = np.clip(np.rint(mid_xy[..., 0] / res).astype(int), 0, nx - 1)
    y_idx = np.clip(np.rint(mid_xy[..., 1] / res).astype(int), 0, ny - 1)
    return city_map.height_matrix[y_idx, x_idx]


def _normalize_per_bs_vector(values: Optional[np.ndarray], num_base: int, default: float = 0.0) -> np.ndarray:
    if values is None:
        return np.full((num_base,), default, dtype=float)
    vec = np.asarray(values, dtype=float).reshape(-1)
    if vec.size != num_base:
        raise ValueError("Per-base parameter length must equal number of base stations")
    return vec


def compute_population_per_bs_rx_power_legacy_dbm(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    nlos_penalty_factors: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> np.ndarray:
    """Legacy low-fidelity per-BS received power.

    Returns shape [num_particles, num_base, num_points] in dBm.
    """
    if positions.size == 0 or test_points.size == 0:
        n_particles = int(positions.shape[0]) if positions.ndim >= 1 else 0
        n_base = int(positions.shape[1]) if positions.ndim >= 2 else 0
        n_points = int(test_points.shape[0]) if test_points.ndim == 2 else 0
        return np.zeros((n_particles, n_base, n_points), dtype=float)

    tx_power = float(channel_params["txPower"])
    antenna_gain = float(channel_params.get("antennaGain", 0.0))
    penetration = float(channel_params["penetrationLoss"])
    wavelength = float(channel_params["wavelength"])

    num_particles, num_base, _ = positions.shape
    num_points = test_points.shape[0]
    rx_power = np.zeros((num_particles, num_base, num_points), dtype=float)

    tx_offsets = _normalize_per_bs_vector(tx_power_offsets_db, num_base, default=0.0)
    coverage_offsets = _normalize_per_bs_vector(coverage_boost_db, num_base, default=0.0)
    path_loss_offsets = _normalize_per_bs_vector(path_loss_offsets_db, num_base, default=0.0)
    nlos_factors = _normalize_per_bs_vector(nlos_penalty_factors, num_base, default=1.0)

    for b in range(num_base):
        bs = positions[:, b, :]
        diff = test_points[None, :, :] - bs[:, None, :]
        dist = np.maximum(np.linalg.norm(diff, axis=2), 1.0)

        mid_xy = 0.5 * (bs[:, None, :2] + test_points[None, :, :2])
        mid_h = _sample_height_nearest(mid_xy, city_map)
        line_mid_z = 0.5 * (bs[:, None, 2] + test_points[None, :, 2])
        los = line_mid_z > (mid_h + 5.0)

        fspl = 20.0 * np.log10(4.0 * np.pi * dist / wavelength)
        nlos_extra = (10.0 * 2.5 * np.log10(np.maximum(dist, 1.0)) + penetration) * max(nlos_factors[b], 1e-6)
        path_loss = np.where(los, fspl, fspl + nlos_extra)
        path_loss = path_loss + float(path_loss_offsets[b])

        effective_tx = tx_power + float(tx_offsets[b]) + float(coverage_offsets[b])
        rx_power[:, b, :] = effective_tx + antenna_gain - path_loss
    if sector_station_mask is not None:
        sector_gain, _ = compute_sector_gain_matrix_db(
            positions=positions,
            test_points=test_points,
            sector_station_mask=sector_station_mask,
            sector_azimuths_deg=sector_azimuths_deg,
            sector_beamwidth_deg=float(
                sector_beamwidth_deg
                if sector_beamwidth_deg is not None
                else channel_params.get("sector_beamwidth_deg", 90.0)
            ),
            outside_sector_mode=str(
                outside_sector_mode
                if outside_sector_mode is not None
                else channel_params.get("outside_sector_mode", "no_coverage")
            ),
            side_lobe_attenuation_db=float(
                side_lobe_attenuation_db
                if side_lobe_attenuation_db is not None
                else channel_params.get("side_lobe_attenuation_db", 30.0)
            ),
        )
        rx_power = rx_power + sector_gain
    return rx_power


def compute_population_snr_matrix_legacy(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    nlos_penalty_factors: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> np.ndarray:
    if positions.size == 0 or test_points.size == 0:
        return np.zeros((positions.shape[0], test_points.shape[0] if test_points.ndim == 2 else 0), dtype=float)

    noise_power = float(channel_params["noisePower"])
    rx_per_bs_dbm = compute_population_per_bs_rx_power_legacy_dbm(
        positions=positions,
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        tx_power_offsets_db=tx_power_offsets_db,
        coverage_boost_db=coverage_boost_db,
        path_loss_offsets_db=path_loss_offsets_db,
        nlos_penalty_factors=nlos_penalty_factors,
        sector_station_mask=sector_station_mask,
        sector_azimuths_deg=sector_azimuths_deg,
        sector_beamwidth_deg=sector_beamwidth_deg,
        outside_sector_mode=outside_sector_mode,
        side_lobe_attenuation_db=side_lobe_attenuation_db,
    )
    total_power_mw = np.sum(np.power(10.0, rx_per_bs_dbm / 10.0), axis=1)
    total_power_dbm = 10.0 * np.log10(total_power_mw + 1e-12)
    return total_power_dbm - noise_power


def compute_population_strongest_station_indices_legacy(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    nlos_penalty_factors: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> np.ndarray:
    if positions.size == 0 or test_points.size == 0:
        n_particles = int(positions.shape[0]) if positions.ndim >= 1 else 0
        n_points = int(test_points.shape[0]) if test_points.ndim == 2 else 0
        return np.zeros((n_particles, n_points), dtype=int)
    rx_per_bs_dbm = compute_population_per_bs_rx_power_legacy_dbm(
        positions=positions,
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        tx_power_offsets_db=tx_power_offsets_db,
        coverage_boost_db=coverage_boost_db,
        path_loss_offsets_db=path_loss_offsets_db,
        nlos_penalty_factors=nlos_penalty_factors,
        sector_station_mask=sector_station_mask,
        sector_azimuths_deg=sector_azimuths_deg,
        sector_beamwidth_deg=sector_beamwidth_deg,
        outside_sector_mode=outside_sector_mode,
        side_lobe_attenuation_db=side_lobe_attenuation_db,
    )
    return np.argmax(rx_per_bs_dbm, axis=1).astype(int)


def compute_population_best_link_path_loss_legacy_db(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    nlos_penalty_factors: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Return best-link path loss and serving index for legacy model.

    Path-loss is reconstructed from strongest received power:
        PL = P_tx_eff + G_ant - P_rx
    """
    if positions.size == 0 or test_points.size == 0:
        n_particles = int(positions.shape[0]) if positions.ndim >= 1 else 0
        n_points = int(test_points.shape[0]) if test_points.ndim == 2 else 0
        return np.zeros((n_particles, n_points), dtype=float), np.zeros((n_particles, n_points), dtype=int)

    tx_power = float(channel_params["txPower"])
    antenna_gain = float(channel_params.get("antennaGain", 0.0))
    num_base = int(positions.shape[1])
    tx_offsets = _normalize_per_bs_vector(tx_power_offsets_db, num_base, default=0.0)
    coverage_offsets = _normalize_per_bs_vector(coverage_boost_db, num_base, default=0.0)
    effective_tx_per_bs = tx_power + tx_offsets + coverage_offsets

    rx_per_bs_dbm = compute_population_per_bs_rx_power_legacy_dbm(
        positions=positions,
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        tx_power_offsets_db=tx_power_offsets_db,
        coverage_boost_db=coverage_boost_db,
        path_loss_offsets_db=path_loss_offsets_db,
        nlos_penalty_factors=nlos_penalty_factors,
        sector_station_mask=sector_station_mask,
        sector_azimuths_deg=sector_azimuths_deg,
        sector_beamwidth_deg=sector_beamwidth_deg,
        outside_sector_mode=outside_sector_mode,
        side_lobe_attenuation_db=side_lobe_attenuation_db,
    )
    serving_idx = np.argmax(rx_per_bs_dbm, axis=1).astype(int)

    n_particles, n_points = serving_idx.shape
    particle_idx = np.arange(n_particles)[:, None]
    point_idx = np.arange(n_points)[None, :]
    serving_rx = rx_per_bs_dbm[particle_idx, serving_idx, point_idx]
    serving_tx = effective_tx_per_bs[serving_idx]
    best_link_pl = serving_tx + antenna_gain - serving_rx
    return best_link_pl, serving_idx
