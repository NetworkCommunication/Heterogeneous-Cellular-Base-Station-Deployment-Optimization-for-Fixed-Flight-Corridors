from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

from src.data.types import Config
from src.propagation.sector_geometry import compute_sector_gain_matrix_db

LIGHT_SPEED_MPS = 3.0e8


@dataclass
class A2GEnvParams:
    """Probabilistic A2G environment parameters from the paper model."""

    a: float
    b: float
    eta_los_db: float
    eta_nlos_db: float


def parse_a2g_env_params(channel_params: Config) -> A2GEnvParams:
    cfg = channel_params.get("a2gProbabilistic", {})
    return A2GEnvParams(
        a=float(cfg.get("a", 9.61)),
        b=float(cfg.get("b", 0.16)),
        eta_los_db=float(cfg.get("etaLoS", 1.0)),
        eta_nlos_db=float(cfg.get("etaNLoS", 20.0)),
    )


def compute_probabilistic_a2g_terms(
    positions: np.ndarray,
    test_points: np.ndarray,
    channel_params: Config,
    env: Optional[A2GEnvParams] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Compute paper Eq.(1)(2)(3) terms for each BS-user pair.

    Returns:
        (p_los, p_nlos, pl_los_db, pl_nlos_db, expected_pl_db)
        all with shape [num_particles, num_base, num_points].

    Paper-faithful core equations:
    - Eq.(1): P_LoS = 1 / (1 + a exp(-b(180/pi * atan(H_j/r_ij) - a)))
              P_NLoS = 1 - P_LoS
    - Eq.(2): PL_LoS  = 20 log10(4 pi f_c d_ij / c) + eta_LoS
              PL_NLoS = 20 log10(4 pi f_c d_ij / c) + eta_NLoS
    - Eq.(3): PL = P_LoS * PL_LoS + P_NLoS * PL_NLoS
    """
    if env is None:
        env = parse_a2g_env_params(channel_params)

    if positions.size == 0 or test_points.size == 0:
        n_particles = int(positions.shape[0]) if positions.ndim >= 1 else 0
        n_base = int(positions.shape[1]) if positions.ndim >= 2 else 0
        n_points = int(test_points.shape[0]) if test_points.ndim == 2 else 0
        empty = np.zeros((n_particles, n_base, n_points), dtype=float)
        return empty, empty, empty, empty, empty

    if "frequency" in channel_params:
        fc_hz = float(channel_params["frequency"])
    elif "wavelength" in channel_params:
        wl = float(channel_params["wavelength"])
        fc_hz = LIGHT_SPEED_MPS / max(wl, 1e-12)
    else:
        raise KeyError("A2G probabilistic model requires channel_params['frequency'] or ['wavelength']")
    num_particles, num_base, _ = positions.shape
    num_points = int(test_points.shape[0])

    # Paper scope uses receiver at (x_i, y_i, 0); project evaluation points to ground.
    rx_xy = np.asarray(test_points[:, :2], dtype=float)
    bs_xy = np.asarray(positions[:, :, :2], dtype=float)
    h_bs = np.maximum(np.asarray(positions[:, :, 2], dtype=float), 1e-9)

    dx = bs_xy[:, :, None, 0] - rx_xy[None, None, :, 0]
    dy = bs_xy[:, :, None, 1] - rx_xy[None, None, :, 1]
    r_ij = np.maximum(np.sqrt(dx * dx + dy * dy), 1e-9)
    h_ij = h_bs[:, :, None]
    d_ij = np.sqrt(r_ij * r_ij + h_ij * h_ij)

    # Eq.(1): elevation angle in degree.
    elevation_deg = np.degrees(np.arctan2(h_ij, r_ij))
    p_los = 1.0 / (1.0 + env.a * np.exp(-env.b * (elevation_deg - env.a)))
    p_nlos = 1.0 - p_los

    # Eq.(2): LoS / NLoS path loss.
    fspl_db = 20.0 * np.log10((4.0 * np.pi * fc_hz * d_ij) / LIGHT_SPEED_MPS)
    pl_los_db = fspl_db + env.eta_los_db
    pl_nlos_db = fspl_db + env.eta_nlos_db

    # Eq.(3): expected probabilistic path loss.
    expected_pl_db = p_los * pl_los_db + p_nlos * pl_nlos_db

    assert p_los.shape == (num_particles, num_base, num_points)
    return p_los, p_nlos, pl_los_db, pl_nlos_db, expected_pl_db


def _normalize_per_bs_vector(values: Optional[np.ndarray], num_base: int, default: float = 0.0) -> np.ndarray:
    if values is None:
        return np.full((num_base,), default, dtype=float)
    vec = np.asarray(values, dtype=float).reshape(-1)
    if vec.size != num_base:
        raise ValueError("Per-base parameter length must equal number of base stations")
    return vec


def compute_population_per_bs_rx_power_a2g_dbm(
    positions: np.ndarray,
    test_points: np.ndarray,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute per-BS received power with Eq.(1)(2)(3) expected path loss.

    Returns:
      rx_power_dbm: [num_particles, num_base, num_points]
      expected_pl_db: [num_particles, num_base, num_points]
    """
    if positions.size == 0 or test_points.size == 0:
        n_particles = int(positions.shape[0]) if positions.ndim >= 1 else 0
        n_base = int(positions.shape[1]) if positions.ndim >= 2 else 0
        n_points = int(test_points.shape[0]) if test_points.ndim == 2 else 0
        empty = np.zeros((n_particles, n_base, n_points), dtype=float)
        return empty, empty

    num_base = int(positions.shape[1])
    tx_power = float(channel_params["txPower"])
    antenna_gain = float(channel_params.get("antennaGain", 0.0))
    tx_offsets = _normalize_per_bs_vector(tx_power_offsets_db, num_base, default=0.0)
    coverage_offsets = _normalize_per_bs_vector(coverage_boost_db, num_base, default=0.0)
    path_loss_offsets = _normalize_per_bs_vector(path_loss_offsets_db, num_base, default=0.0)

    _, _, _, _, expected_pl_db = compute_probabilistic_a2g_terms(
        positions=positions,
        test_points=test_points,
        channel_params=channel_params,
    )

    effective_tx_per_bs = tx_power + tx_offsets + coverage_offsets
    pl_total = expected_pl_db + path_loss_offsets[None, :, None]
    rx_power_dbm = effective_tx_per_bs[None, :, None] + antenna_gain - pl_total
    if sector_station_mask is not None:
        sector_gain, _ = compute_sector_gain_matrix_db(
            positions=positions,
            test_points=test_points,
            sector_station_mask=sector_station_mask,
            sector_azimuths_deg=sector_azimuths_deg,
            sector_beamwidth_deg=float(
                sector_beamwidth_deg
                if sector_beamwidth_deg is not None
                else channel_params.get("sector_beamwidth_deg", 90.0)
            ),
            outside_sector_mode=str(
                outside_sector_mode
                if outside_sector_mode is not None
                else channel_params.get("outside_sector_mode", "no_coverage")
            ),
            side_lobe_attenuation_db=float(
                side_lobe_attenuation_db
                if side_lobe_attenuation_db is not None
                else channel_params.get("side_lobe_attenuation_db", 30.0)
            ),
        )
        rx_power_dbm = rx_power_dbm + sector_gain
    return rx_power_dbm, expected_pl_db


def compute_population_snr_matrix_a2g(
    positions: np.ndarray,
    test_points: np.ndarray,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> np.ndarray:
    """Compute SNR matrix from probabilistic expected path loss."""
    if positions.size == 0 or test_points.size == 0:
        return np.zeros((positions.shape[0], test_points.shape[0] if test_points.ndim == 2 else 0), dtype=float)

    noise_power = float(channel_params["noisePower"])
    rx_per_bs_dbm, _ = compute_population_per_bs_rx_power_a2g_dbm(
        positions=positions,
        test_points=test_points,
        channel_params=channel_params,
        tx_power_offsets_db=tx_power_offsets_db,
        coverage_boost_db=coverage_boost_db,
        path_loss_offsets_db=path_loss_offsets_db,
        sector_station_mask=sector_station_mask,
        sector_azimuths_deg=sector_azimuths_deg,
        sector_beamwidth_deg=sector_beamwidth_deg,
        outside_sector_mode=outside_sector_mode,
        side_lobe_attenuation_db=side_lobe_attenuation_db,
    )
    total_power_mw = np.sum(np.power(10.0, rx_per_bs_dbm / 10.0), axis=1)
    total_power_dbm = 10.0 * np.log10(total_power_mw + 1e-12)
    return total_power_dbm - noise_power


def compute_population_strongest_station_indices_a2g(
    positions: np.ndarray,
    test_points: np.ndarray,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> np.ndarray:
    if positions.size == 0 or test_points.size == 0:
        n_particles = int(positions.shape[0]) if positions.ndim >= 1 else 0
        n_points = int(test_points.shape[0]) if test_points.ndim == 2 else 0
        return np.zeros((n_particles, n_points), dtype=int)
    rx_per_bs_dbm, _ = compute_population_per_bs_rx_power_a2g_dbm(
        positions=positions,
        test_points=test_points,
        channel_params=channel_params,
        tx_power_offsets_db=tx_power_offsets_db,
        coverage_boost_db=coverage_boost_db,
        path_loss_offsets_db=path_loss_offsets_db,
        sector_station_mask=sector_station_mask,
        sector_azimuths_deg=sector_azimuths_deg,
        sector_beamwidth_deg=sector_beamwidth_deg,
        outside_sector_mode=outside_sector_mode,
        side_lobe_attenuation_db=side_lobe_attenuation_db,
    )
    return np.argmax(rx_per_bs_dbm, axis=1).astype(int)


def compute_population_best_link_path_loss_a2g_db(
    positions: np.ndarray,
    test_points: np.ndarray,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Return best-link expected path loss and serving index for A2G model."""
    if positions.size == 0 or test_points.size == 0:
        n_particles = int(positions.shape[0]) if positions.ndim >= 1 else 0
        n_points = int(test_points.shape[0]) if test_points.ndim == 2 else 0
        return np.zeros((n_particles, n_points), dtype=float), np.zeros((n_particles, n_points), dtype=int)

    tx_power = float(channel_params["txPower"])
    antenna_gain = float(channel_params.get("antennaGain", 0.0))
    num_base = int(positions.shape[1])
    tx_offsets = _normalize_per_bs_vector(tx_power_offsets_db, num_base, default=0.0)
    coverage_offsets = _normalize_per_bs_vector(coverage_boost_db, num_base, default=0.0)
    effective_tx_per_bs = tx_power + tx_offsets + coverage_offsets

    rx_per_bs_dbm, _ = compute_population_per_bs_rx_power_a2g_dbm(
        positions=positions,
        test_points=test_points,
        channel_params=channel_params,
        tx_power_offsets_db=tx_power_offsets_db,
        coverage_boost_db=coverage_boost_db,
        path_loss_offsets_db=path_loss_offsets_db,
        sector_station_mask=sector_station_mask,
        sector_azimuths_deg=sector_azimuths_deg,
        sector_beamwidth_deg=sector_beamwidth_deg,
        outside_sector_mode=outside_sector_mode,
        side_lobe_attenuation_db=side_lobe_attenuation_db,
    )
    serving_idx = np.argmax(rx_per_bs_dbm, axis=1).astype(int)
    n_particles, n_points = serving_idx.shape
    particle_idx = np.arange(n_particles)[:, None]
    point_idx = np.arange(n_points)[None, :]
    serving_rx = rx_per_bs_dbm[particle_idx, serving_idx, point_idx]
    serving_tx = effective_tx_per_bs[serving_idx]
    best_link_pl = serving_tx + antenna_gain - serving_rx
    return best_link_pl, serving_idx
