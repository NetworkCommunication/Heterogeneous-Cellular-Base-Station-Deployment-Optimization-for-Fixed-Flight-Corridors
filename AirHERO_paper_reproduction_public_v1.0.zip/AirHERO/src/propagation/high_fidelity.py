﻿from __future__ import annotations

from typing import Optional

import numpy as np

from src.data.types import CityMap, Config
from src.propagation.sector_geometry import compute_sector_gain_matrix_db


def _sample_height_nearest(mid_xy: np.ndarray, city_map: CityMap) -> np.ndarray:
    """Read building height via nearest-neighbor sampling."""
    res = city_map.height_resolution
    ny, nx = city_map.height_matrix.shape
    x_idx = np.clip(np.rint(mid_xy[..., 0] / res).astype(int), 0, nx - 1)
    y_idx = np.clip(np.rint(mid_xy[..., 1] / res).astype(int), 0, ny - 1)
    return city_map.height_matrix[y_idx, x_idx]


def _normalize_per_bs_vector(values: Optional[np.ndarray], num_base: int, default: float = 0.0) -> np.ndarray:
    if values is None:
        return np.full((num_base,), default, dtype=float)
    vec = np.asarray(values, dtype=float).reshape(-1)
    if vec.size != num_base:
        raise ValueError("Per-base parameter length must equal number of base stations")
    return vec


def compute_population_snr_matrix_high_fidelity(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    tx_power_offsets_db: Optional[np.ndarray] = None,
    coverage_boost_db: Optional[np.ndarray] = None,
    path_loss_offsets_db: Optional[np.ndarray] = None,
    nlos_penalty_factors: Optional[np.ndarray] = None,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
    model_params: Optional[Config] = None,
) -> np.ndarray:
    """Compute higher-fidelity placeholder SNR matrix for a particle population.

    Placeholder high-fidelity approximation notice:
    - This is NOT a final engineering ray-tracing model.
    - It approximates extra blockage effects by sampling multiple points along
      each BS-to-demand line segment, then applying obstruction-dependent loss.
    - The interface is designed to be replaced by a calibrated model later.
    """
    if positions.size == 0 or test_points.size == 0:
        return np.zeros((positions.shape[0], test_points.shape[0] if test_points.ndim == 2 else 0), dtype=float)

    params = dict(model_params or {})
    num_samples = int(params.get("numPathSamples", 7))
    num_samples = max(num_samples, 3)
    clearance_margin = float(params.get("clearanceMarginM", 4.0))
    los_obstruction_threshold = float(params.get("losObstructionThreshold", 0.15))
    base_nlos_exp = float(params.get("baseNlosExponent", 2.7))
    obstruction_loss_db = float(params.get("obstructionLossDb", 18.0))
    diffraction_loss_db = float(params.get("diffractionLossDb", 10.0))

    tx_power = float(channel_params["txPower"])
    antenna_gain = float(channel_params.get("antennaGain", 0.0))
    noise_power = float(channel_params["noisePower"])
    penetration = float(channel_params["penetrationLoss"])
    wavelength = float(channel_params["wavelength"])

    num_particles, num_base, _ = positions.shape
    num_points = test_points.shape[0]
    total_power_mw = np.zeros((num_particles, num_points), dtype=float)

    tx_offsets = _normalize_per_bs_vector(tx_power_offsets_db, num_base, default=0.0)
    coverage_offsets = _normalize_per_bs_vector(coverage_boost_db, num_base, default=0.0)
    path_loss_offsets = _normalize_per_bs_vector(path_loss_offsets_db, num_base, default=0.0)
    nlos_factors = _normalize_per_bs_vector(nlos_penalty_factors, num_base, default=1.0)
    sector_gain_db = np.zeros((num_particles, num_base, num_points), dtype=float)
    if sector_station_mask is not None:
        sector_mask = np.asarray(sector_station_mask, dtype=bool).reshape(-1)
        if sector_mask.size != num_base:
            raise ValueError("sector_station_mask length must equal number of base stations")
        if np.any(sector_mask) and sector_azimuths_deg is None:
            raise ValueError("5GA high-fidelity evaluation requires sector_azimuths_deg")
        sector_gain_db, _ = compute_sector_gain_matrix_db(
            positions=positions,
            test_points=test_points,
            sector_station_mask=sector_station_mask,
            sector_azimuths_deg=sector_azimuths_deg,
            sector_beamwidth_deg=float(
                sector_beamwidth_deg
                if sector_beamwidth_deg is not None
                else channel_params.get("sector_beamwidth_deg", 90.0)
            ),
            outside_sector_mode=str(
                outside_sector_mode
                if outside_sector_mode is not None
                else channel_params.get("outside_sector_mode", "no_coverage")
            ),
            side_lobe_attenuation_db=float(
                side_lobe_attenuation_db
                if side_lobe_attenuation_db is not None
                else channel_params.get("side_lobe_attenuation_db", 30.0)
            ),
        )

    t = np.linspace(1.0 / (num_samples + 1), num_samples / (num_samples + 1), num_samples, dtype=float)
    t4 = t.reshape(1, 1, num_samples, 1)
    t3 = t.reshape(1, 1, num_samples)

    for b in range(num_base):
        bs = positions[:, b, :]
        diff = test_points[None, :, :] - bs[:, None, :]
        dist = np.maximum(np.linalg.norm(diff, axis=2), 1.0)

        bs_xy = bs[:, None, None, :2]
        tp_xy = test_points[None, :, None, :2]
        sample_xy = (1.0 - t4) * bs_xy + t4 * tp_xy

        bs_z = bs[:, None, None, 2]
        tp_z = test_points[None, :, None, 2]
        sample_z = (1.0 - t3) * bs_z + t3 * tp_z

        sample_h = _sample_height_nearest(sample_xy, city_map)
        blocked = sample_z <= (sample_h + clearance_margin)
        obstruction_ratio = np.mean(blocked.astype(float), axis=2)
        los = obstruction_ratio <= los_obstruction_threshold

        fspl = 20.0 * np.log10(4.0 * np.pi * dist / wavelength)

        distance_exp = base_nlos_exp + 0.7 * obstruction_ratio
        nlos_distance_loss = 10.0 * np.maximum(distance_exp - 2.0, 0.0) * np.log10(np.maximum(dist, 1.0))

        obstruction_loss = obstruction_loss_db * obstruction_ratio
        diffraction_loss = diffraction_loss_db * np.square(obstruction_ratio)
        nlos_extra = (penetration + nlos_distance_loss + obstruction_loss + diffraction_loss) * max(nlos_factors[b], 1e-6)
        los_extra = obstruction_loss * 0.2

        path_loss = np.where(los, fspl + los_extra, fspl + nlos_extra)
        path_loss = path_loss + float(path_loss_offsets[b])

        # Placeholder heterogeneity abstraction reused for consistency with low-fidelity model.
        effective_tx = tx_power + float(tx_offsets[b]) + float(coverage_offsets[b])
        altitude_bonus = np.clip((bs[:, None, 2] - test_points[None, :, 2]) * 0.015, -3.0, 4.0)

        rx_power_dbm = effective_tx + antenna_gain + altitude_bonus - path_loss + sector_gain_db[:, b, :]
        total_power_mw += np.power(10.0, rx_power_dbm / 10.0)

    total_power_dbm = 10.0 * np.log10(total_power_mw + 1e-12)
    return total_power_dbm - noise_power


def evaluate_elite_particles_high_fidelity(
    elite_positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    sector_station_mask: Optional[np.ndarray] = None,
    sector_azimuths_deg: Optional[np.ndarray] = None,
    sector_beamwidth_deg: Optional[float] = None,
    outside_sector_mode: Optional[str] = None,
    side_lobe_attenuation_db: Optional[float] = None,
) -> np.ndarray:
    """Return covered-point counts from the high-fidelity placeholder model.

    5GA stations must be supplied through `sector_station_mask` together with
    per-station `sector_azimuths_deg`; otherwise the core high-fidelity
    evaluator raises instead of silently treating directional stations as
    omnidirectional.
    """
    if elite_positions.size == 0 or test_points.size == 0:
        return np.zeros((elite_positions.shape[0],), dtype=float)
    snr = compute_population_snr_matrix_high_fidelity(
        positions=elite_positions,
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        sector_station_mask=sector_station_mask,
        sector_azimuths_deg=sector_azimuths_deg,
        sector_beamwidth_deg=sector_beamwidth_deg,
        outside_sector_mode=outside_sector_mode,
        side_lobe_attenuation_db=side_lobe_attenuation_db,
    )
    snr_threshold = float(channel_params.get("snrThreshold", 0.0))
    return np.sum(snr >= snr_threshold, axis=1).astype(float)
