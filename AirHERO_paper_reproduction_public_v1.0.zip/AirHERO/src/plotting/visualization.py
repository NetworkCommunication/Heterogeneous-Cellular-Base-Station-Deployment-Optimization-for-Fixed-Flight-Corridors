﻿from __future__ import annotations

import os
from pathlib import Path
from typing import Tuple

_MPL_CACHE = Path(".mplcache").resolve()
_MPL_CACHE.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(_MPL_CACHE))

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle, Wedge

from src.algorithms.fitness_interface import build_station_type_plan, build_station_type_plan_from_particle
from src.algorithms.particle_encoding import is_extended_particle_array, spatial_view
from src.propagation.low_fidelity import compute_point_snr
from src.data.types import AirRoute, CityMap, Config, PSOResult


def visualize_results(
    city_map: CityMap,
    air_route: AirRoute,
    pso_result: PSOResult,
    config: Config,
    results_dir: Path,
    channel_params: Config,
) -> None:
    """Generate both dashboard-style and paper-style figures."""
    _apply_plot_style(config)

    station_plan = (
        build_station_type_plan_from_particle(config, pso_result.best_position)
        if is_extended_particle_array(pso_result.best_position)
        else build_station_type_plan(config, int(pso_result.best_position.shape[0]))
    )
    snr = compute_point_snr(
        spatial_view(pso_result.best_position),
        air_route.test_points,
        city_map,
        channel_params,
        tx_power_offsets_db=station_plan.tx_power_offsets_db,
        coverage_boost_db=station_plan.coverage_boost_db,
        path_loss_offsets_db=station_plan.path_loss_offsets_db,
        nlos_penalty_factors=station_plan.nlos_penalty_factors,
        sector_station_mask=station_plan.sector_station_mask,
        sector_azimuths_deg=station_plan.sector_azimuths_deg,
        sector_beamwidth_deg=station_plan.sector_beamwidth_deg,
        outside_sector_mode=station_plan.outside_sector_mode,
        side_lobe_attenuation_db=station_plan.side_lobe_attenuation_db,
    )
    snr_threshold = float(channel_params.get("snrThreshold", 0.0))

    _save_dashboard_figure(
        city_map=city_map,
        air_route=air_route,
        pso_result=pso_result,
        config=config,
        results_dir=results_dir,
        snr=snr,
        snr_threshold=snr_threshold,
    )
    _save_top_side_view(
        city_map=city_map,
        air_route=air_route,
        pso_result=pso_result,
        config=config,
        results_dir=results_dir,
    )

    if bool(config["visualization"].get("paperStyle", True)):
        _save_paper_figures(
            city_map=city_map,
            air_route=air_route,
            pso_result=pso_result,
            config=config,
            results_dir=results_dir,
            snr=snr,
            snr_threshold=snr_threshold,
        )


def _apply_plot_style(config: Config) -> None:
    vis = config.get("visualization", {})
    family = str(vis.get("paperFontFamily", "Times New Roman"))
    plt.rcParams.update(
        {
            "font.family": family,
            "font.size": 10,
            "axes.labelsize": 10,
            "axes.titlesize": 11,
            "legend.fontsize": 9,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
        }
    )


def _save_dashboard_figure(
    city_map: CityMap,
    air_route: AirRoute,
    pso_result: PSOResult,
    config: Config,
    results_dir: Path,
    snr: np.ndarray,
    snr_threshold: float,
) -> None:
    fig_w, fig_h = config["visualization"].get("figureSize", [1200, 800])
    fig = plt.figure(figsize=(fig_w / 100.0, fig_h / 100.0))

    ax1 = fig.add_subplot(2, 2, 1, projection="3d")
    # Keep 3D plot readable by subsampling buildings when map is very dense.
    step_build = max(1, len(city_map.buildings) // 450)
    for b in city_map.buildings[::step_build]:
        ax1.bar3d(b.x, b.y, 0.0, b.width, b.length, b.height, alpha=0.12, color="#3B6EA8", shade=False)
    if air_route.test_points.size > 0:
        step = max(1, air_route.test_points.shape[0] // 7000)
        pts = air_route.test_points[::step]
        ax1.scatter(pts[:, 0], pts[:, 1], pts[:, 2], s=2, c="#B2182B", alpha=0.45)
    ax1.scatter(
        pso_result.best_position[:, 0],
        pso_result.best_position[:, 1],
        pso_result.best_position[:, 2],
        s=110,
        c="#0B8043",
        marker="^",
        edgecolor="black",
    )
    if city_map.takeoff_point is not None:
        p = city_map.takeoff_point
        ax1.scatter([p[0]], [p[1]], [p[2]], s=140, c="#1A9850", marker="o", edgecolor="black")
    if city_map.touchdown_point is not None:
        p = city_map.touchdown_point
        ax1.scatter([p[0]], [p[1]], [p[2]], s=150, c="#D73027", marker="X", edgecolor="black")
    ax1.set_title("3D City, Routes, and Facilities")
    ax1.set_xlabel("X (m)")
    ax1.set_ylabel("Y (m)")
    ax1.set_zlabel("Z (m)")
    ax1.view_init(28, 46)

    ax2 = fig.add_subplot(2, 2, 2)
    if air_route.test_points.size > 0:
        x = air_route.test_points[:, 0]
        y = air_route.test_points[:, 1]
        bins = 90
        sum_snr, xedges, yedges = np.histogram2d(x, y, bins=bins, weights=snr)
        cnt, _, _ = np.histogram2d(x, y, bins=bins)
        mean_snr = np.divide(sum_snr, np.maximum(cnt, 1.0))
        im = ax2.imshow(
            mean_snr.T,
            origin="lower",
            extent=[xedges[0], xedges[-1], yedges[0], yedges[-1]],
            aspect="auto",
            cmap="viridis",
        )
        cb = plt.colorbar(im, ax=ax2, fraction=0.046, pad=0.04)
        cb.set_label("SNR (dB)")
    ax2.set_title("SNR Heatmap in XY")
    ax2.set_xlabel("X (m)")
    ax2.set_ylabel("Y (m)")

    ax3 = fig.add_subplot(2, 2, 3)
    x_it = np.arange(1, pso_result.iteration + 1)
    y_fit = pso_result.convergence_history
    ax3.plot(x_it, y_fit, color="#CC4C02", linewidth=1.7, label="Best-so-far")
    ax3.scatter([1, pso_result.iteration], [y_fit[0], y_fit[-1]], s=20, color="#CC4C02")
    ax3.set_title("PSO Convergence")
    ax3.set_xlabel("Iteration")
    ax3.set_ylabel("Covered Points")
    ax3.grid(alpha=0.25)
    ax3.legend(loc="lower right", frameon=False)

    ax4 = fig.add_subplot(2, 2, 4)
    covered = int(np.sum(snr >= snr_threshold))
    total = int(air_route.test_points.shape[0])
    rate = (covered / max(total, 1)) * 100.0
    init_fit = float(pso_result.convergence_history[0]) if pso_result.convergence_history.size > 0 else 0.0
    fit_gain = float(pso_result.best_fitness - init_fit)
    lines = [
        f"Buildings: {len(city_map.buildings)}",
        f"Road Segments: {0 if city_map.road_segments is None else city_map.road_segments.shape[0]}",
        f"Test Points: {total}",
        f"Landing Candidates: {0 if city_map.landing_points is None else city_map.landing_points.shape[0]}",
        f"Init Fitness: {init_fit:.0f}",
        f"Best Fitness: {pso_result.best_fitness:.0f}",
        f"Fitness Gain: {fit_gain:.0f}",
        f"Coverage@{snr_threshold:.1f}dB: {rate:.2f}%",
    ]
    for i, line in enumerate(lines):
        ax4.text(0.02, 0.97 - i * 0.12, line, fontsize=10, va="top")
    ax4.axis("off")
    ax4.set_title("Experiment Summary")

    fig.tight_layout()
    fig.savefig(results_dir / "optimization_results.png", dpi=220)
    plt.close(fig)


def _save_top_side_view(
    city_map: CityMap,
    air_route: AirRoute,
    pso_result: PSOResult,
    config: Config,
    results_dir: Path,
) -> None:
    fig2, axes = plt.subplots(1, 2, figsize=(12, 5))
    ax_top, ax_side = axes
    x0, x1, y0, y1 = _local_window_xy(city_map, pso_result, config)
    if city_map.road_segments is not None and city_map.road_segments.size > 0:
        step = max(1, city_map.road_segments.shape[0] // 4500)
        for seg in city_map.road_segments[::step]:
            sx0, sx1 = float(np.min(seg[:, 0])), float(np.max(seg[:, 0]))
            sy0, sy1 = float(np.min(seg[:, 1])), float(np.max(seg[:, 1]))
            if sx1 < x0 or sx0 > x1 or sy1 < y0 or sy0 > y1:
                continue
            ax_top.plot(seg[:, 0], seg[:, 1], color="#7A7A7A", alpha=0.2, linewidth=0.45)
    for b in city_map.buildings:
        if b.x + b.width < x0 or b.x > x1 or b.y + b.length < y0 or b.y > y1:
            continue
        rect = Rectangle((b.x, b.y), b.width, b.length, facecolor="#4F81BD", alpha=0.13, edgecolor="none")
        ax_top.add_patch(rect)
    if air_route.test_points.size > 0:
        mask = (
            (air_route.test_points[:, 0] >= x0)
            & (air_route.test_points[:, 0] <= x1)
            & (air_route.test_points[:, 1] >= y0)
            & (air_route.test_points[:, 1] <= y1)
        )
        pts_all = air_route.test_points[mask]
        step = max(1, pts_all.shape[0] // 9000) if pts_all.size > 0 else 1
        pts = pts_all[::step] if pts_all.size > 0 else pts_all
        ax_top.scatter(pts[:, 0], pts[:, 1], s=2, c="#B2182B", alpha=0.35)

    ax_top.scatter(
        pso_result.best_position[:, 0],
        pso_result.best_position[:, 1],
        s=85,
        c="#0B8043",
        marker="^",
        edgecolor="black",
        label="BS",
    )
    _draw_sector_wedges(ax_top, pso_result, config, label_first=True)
    if city_map.landing_points is not None and city_map.landing_points.size > 0:
        ax_top.scatter(
            city_map.landing_points[:, 0],
            city_map.landing_points[:, 1],
            s=22,
            c="#1D4E89",
            marker="o",
            alpha=0.75,
            label="Landing candidates",
        )
    if city_map.takeoff_point is not None:
        p = city_map.takeoff_point
        ax_top.scatter([p[0]], [p[1]], s=100, c="#1A9850", marker="*", edgecolor="black", label="Takeoff")
    if city_map.touchdown_point is not None:
        p = city_map.touchdown_point
        ax_top.scatter([p[0]], [p[1]], s=90, c="#D73027", marker="X", edgecolor="black", label="Touchdown")
    ax_top.set_title("Top View (X-Y)")
    ax_top.set_xlabel("X (m)")
    ax_top.set_ylabel("Y (m)")
    ax_top.set_xlim(x0, x1)
    ax_top.set_ylim(y0, y1)
    ax_top.grid(alpha=0.2)
    if ax_top.get_legend_handles_labels()[0]:
        ax_top.legend(loc="upper right", frameon=True, framealpha=0.9)

    for b in city_map.buildings:
        if b.x + b.width < x0 or b.x > x1:
            continue
        x_center = b.x + b.width * 0.5
        rect = Rectangle(
            (x_center - b.width * 0.5, 0),
            b.width,
            b.height,
            facecolor="#4F81BD",
            alpha=0.13,
            edgecolor="none",
        )
        ax_side.add_patch(rect)
    if air_route.test_points.size > 0:
        mask = (air_route.test_points[:, 0] >= x0) & (air_route.test_points[:, 0] <= x1)
        pts_all = air_route.test_points[mask]
        step = max(1, pts_all.shape[0] // 9000) if pts_all.size > 0 else 1
        pts = pts_all[::step] if pts_all.size > 0 else pts_all
        ax_side.scatter(pts[:, 0], pts[:, 2], s=2, c="#B2182B", alpha=0.35)
    ax_side.scatter(
        pso_result.best_position[:, 0],
        pso_result.best_position[:, 2],
        s=85,
        c="#0B8043",
        marker="^",
        edgecolor="black",
    )
    if city_map.takeoff_point is not None:
        p = city_map.takeoff_point
        ax_side.scatter([p[0]], [p[2]], s=100, c="#1A9850", marker="*", edgecolor="black")
    if city_map.touchdown_point is not None:
        p = city_map.touchdown_point
        ax_side.scatter([p[0]], [p[2]], s=90, c="#D73027", marker="X", edgecolor="black")
    ax_side.set_title("Side View (X-Z, Local)")
    ax_side.set_xlabel("X (m)")
    ax_side.set_ylabel("Z (m)")
    ax_side.set_xlim(x0, x1)
    ax_side.set_ylim(0, min(city_map.size_z, 320.0))
    ax_side.grid(alpha=0.2)

    fig2.tight_layout()
    fig2.savefig(results_dir / "top_side_view.png", dpi=220)
    plt.close(fig2)


def _local_window_xy(city_map: CityMap, pso_result: PSOResult, config: Config) -> Tuple[float, float, float, float]:
    vis = config.get("visualization", {})
    local_km = float(vis.get("localViewKm", 3.0))
    window_m = max(local_km * 1000.0, 100.0)
    half = window_m * 0.5
    if pso_result.best_position.size > 0:
        center_x = float(np.mean(pso_result.best_position[:, 0]))
        center_y = float(np.mean(pso_result.best_position[:, 1]))
    else:
        center_x = city_map.size_x * 0.5
        center_y = city_map.size_y * 0.5

    x0 = center_x - half
    x1 = center_x + half
    y0 = center_y - half
    y1 = center_y + half

    if x0 < 0.0:
        x1 -= x0
        x0 = 0.0
    if y0 < 0.0:
        y1 -= y0
        y0 = 0.0
    if x1 > city_map.size_x:
        shift = x1 - city_map.size_x
        x0 -= shift
        x1 = city_map.size_x
    if y1 > city_map.size_y:
        shift = y1 - city_map.size_y
        y0 -= shift
        y1 = city_map.size_y

    x0 = max(0.0, x0)
    y0 = max(0.0, y0)
    return float(x0), float(x1), float(y0), float(y1)


def _save_paper_figures(
    city_map: CityMap,
    air_route: AirRoute,
    pso_result: PSOResult,
    config: Config,
    results_dir: Path,
    snr: np.ndarray,
    snr_threshold: float,
) -> None:
    dpi = int(config["visualization"].get("paperDpi", 300))
    _paper_map_overview(city_map, air_route, pso_result, config, results_dir, dpi=dpi)
    _paper_convergence(pso_result, results_dir, dpi=dpi)
    _paper_snr_cdf(snr, snr_threshold, results_dir, dpi=dpi)


def _paper_map_overview(
    city_map: CityMap,
    air_route: AirRoute,
    pso_result: PSOResult,
    config: Config,
    results_dir: Path,
    dpi: int,
) -> None:
    fig, ax = plt.subplots(figsize=(7.0, 5.6))
    to_km = 1.0 / 1000.0

    if city_map.road_segments is not None and city_map.road_segments.size > 0:
        step = max(1, city_map.road_segments.shape[0] // 6500)
        for seg in city_map.road_segments[::step]:
            ax.plot(seg[:, 0] * to_km, seg[:, 1] * to_km, color="#A0A0A0", alpha=0.22, linewidth=0.45, zorder=1)

    # Use thin outlines for publication clarity in dense urban scenes.
    step_build = max(1, len(city_map.buildings) // 3200)
    for b in city_map.buildings[::step_build]:
        rect = Rectangle(
            (b.x * to_km, b.y * to_km),
            b.width * to_km,
            b.length * to_km,
            facecolor="#BFD3E6",
            alpha=0.35,
            edgecolor="#6B8FB3",
            linewidth=0.2,
            zorder=2,
        )
        ax.add_patch(rect)

    if air_route.test_points.size > 0:
        step = max(1, air_route.test_points.shape[0] // 11000)
        pts = air_route.test_points[::step]
        ax.scatter(
            pts[:, 0] * to_km,
            pts[:, 1] * to_km,
            s=2,
            c="#CA0020",
            alpha=0.28,
            label="Route sample points",
            zorder=3,
        )

    # Plot route centerline(s) for geometric reference.
    for i, (rs, re) in enumerate(air_route.routes):
        ax.plot(
            [rs[0] * to_km, re[0] * to_km],
            [rs[1] * to_km, re[1] * to_km],
            color="#8E0152",
            linewidth=1.1,
            alpha=0.95,
            label="Route centerline" if i == 0 else None,
            zorder=4,
        )
    if air_route.routes:
        rs, re = air_route.routes[0]
        ax.scatter([rs[0] * to_km], [rs[1] * to_km], s=48, c="#4D9221", marker="o", label="Route start", zorder=8)
        ax.scatter([re[0] * to_km], [re[1] * to_km], s=52, c="#C51B7D", marker="X", label="Route end", zorder=8)

    ax.scatter(
        pso_result.best_position[:, 0] * to_km,
        pso_result.best_position[:, 1] * to_km,
        s=90,
        c="#0571B0",
        marker="^",
        edgecolor="black",
        linewidth=0.5,
        label="Optimized BS",
        zorder=5,
    )
    _draw_sector_wedges(ax, pso_result, config, xy_scale=to_km, label_first=True)

    if city_map.landing_points is not None and city_map.landing_points.size > 0:
        ax.scatter(
            city_map.landing_points[:, 0] * to_km,
            city_map.landing_points[:, 1] * to_km,
            s=26,
            c="#1B7837",
            marker="o",
            edgecolor="white",
            linewidth=0.25,
            alpha=0.85,
            label="Candidate roof sites",
            zorder=6,
        )

    if city_map.takeoff_point is not None:
        p = city_map.takeoff_point
        ax.scatter([p[0] * to_km], [p[1] * to_km], s=130, c="#1A9850", marker="*", edgecolor="black", label="Takeoff", zorder=7)
    if city_map.touchdown_point is not None:
        p = city_map.touchdown_point
        ax.scatter([p[0] * to_km], [p[1] * to_km], s=110, c="#D73027", marker="X", edgecolor="black", label="Touchdown", zorder=7)

    ax.set_title("Urban Map (True Distance Scale), Route, and UAV Sites")
    ax.set_xlabel("Easting (km)")
    ax.set_ylabel("Northing (km)")
    ax.set_xlim(0, city_map.size_x * to_km)
    ax.set_ylim(0, city_map.size_y * to_km)
    ax.grid(alpha=0.16, linewidth=0.4)
    ax.set_aspect("equal", adjustable="box")
    _add_scale_bar_km(ax, city_map.size_x * to_km, city_map.size_y * to_km)
    ax.legend(loc="upper right", frameon=True, framealpha=0.95)
    fig.tight_layout()
    fig.savefig(results_dir / "paper_fig_map_overview.png", dpi=dpi)
    plt.close(fig)


def _draw_sector_wedges(
    ax: plt.Axes,
    pso_result: PSOResult,
    config: Config,
    xy_scale: float = 1.0,
    label_first: bool = False,
) -> None:
    """Draw configured 5GA sector wedges on XY plots."""
    if pso_result.best_position.size == 0:
        return
    station_plan = (
        build_station_type_plan_from_particle(config, pso_result.best_position)
        if is_extended_particle_array(pso_result.best_position)
        else build_station_type_plan(config, int(pso_result.best_position.shape[0]))
    )
    if not np.any(station_plan.sector_station_mask):
        return

    vis = config.get("visualization", {})
    radius = float(vis.get("sectorDisplayRadiusM", 350.0)) * float(xy_scale)
    half_width = float(station_plan.sector_beamwidth_deg) * 0.5
    first = True
    for b, is_sector in enumerate(station_plan.sector_station_mask.tolist()):
        if not is_sector:
            continue
        x = float(pso_result.best_position[b, 0]) * float(xy_scale)
        y = float(pso_result.best_position[b, 1]) * float(xy_scale)
        azimuth = float(station_plan.sector_azimuths_deg[b])
        center_math_deg = 90.0 - azimuth
        ax.add_patch(
            Wedge(
                center=(x, y),
                r=radius,
                theta1=center_math_deg - half_width,
                theta2=center_math_deg + half_width,
                facecolor="#74ADD1",
                edgecolor="#2166AC",
                alpha=0.24,
                linewidth=0.9,
                label="5GA sector" if label_first and first else None,
                zorder=4,
            )
        )
        first = False


def _paper_convergence(pso_result: PSOResult, results_dir: Path, dpi: int) -> None:
    fig, ax = plt.subplots(figsize=(6.4, 4.0))
    x = np.arange(1, pso_result.iteration + 1)
    y = pso_result.convergence_history
    ax.plot(x, y, color="#C51B7D", linewidth=1.8, label="Global best")
    ax.scatter([1, len(x)], [y[0], y[-1]], color="#C51B7D", s=24, zorder=3)
    ax.annotate(f"Start {y[0]:.0f}", xy=(1, y[0]), xytext=(6, y[0]), fontsize=8)
    ax.annotate(f"End {y[-1]:.0f}", xy=(len(x), y[-1]), xytext=(max(1, len(x) - 25), y[-1]), fontsize=8)
    ax.set_title("PSO Convergence on Covered Test Points")
    ax.set_xlabel("Iteration")
    ax.set_ylabel("Covered Points")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False, loc="lower right")
    fig.tight_layout()
    fig.savefig(results_dir / "paper_fig_convergence.png", dpi=dpi)
    plt.close(fig)


def _paper_snr_cdf(snr: np.ndarray, snr_threshold: float, results_dir: Path, dpi: int) -> None:
    fig, ax = plt.subplots(figsize=(6.4, 4.0))
    if snr.size > 0:
        x = np.sort(snr)
        y = np.linspace(0.0, 1.0, num=x.size, endpoint=True)
        ax.plot(x, y, color="#2C7FB8", linewidth=1.8, label="SNR CDF")
        ax.axvline(snr_threshold, color="#D95F0E", linestyle="--", linewidth=1.2, label=f"Threshold {snr_threshold:.1f} dB")
    ax.set_title("CDF of Test-Point SNR")
    ax.set_xlabel("SNR (dB)")
    ax.set_ylabel("CDF")
    ax.set_ylim(0.0, 1.0)
    ax.grid(alpha=0.25)
    ax.legend(frameon=False, loc="lower right")
    fig.tight_layout()
    fig.savefig(results_dir / "paper_fig_snr_cdf.png", dpi=dpi)
    plt.close(fig)


def _add_scale_bar_km(ax: plt.Axes, max_x_km: float, max_y_km: float) -> None:
    """Add a simple horizontal scale bar in kilometers."""
    candidate = np.array([1, 2, 5, 10, 20, 25, 50], dtype=float)
    target = max(1.0, 0.18 * max_x_km)
    length = float(candidate[np.argmin(np.abs(candidate - target))])
    length = min(length, max_x_km * 0.5)
    x0 = max_x_km * 0.07
    y0 = max_y_km * 0.06
    ax.plot([x0, x0 + length], [y0, y0], color="black", linewidth=2.2, solid_capstyle="butt", zorder=10)
    ax.plot([x0, x0], [y0 - 0.005 * max_y_km, y0 + 0.005 * max_y_km], color="black", linewidth=1.4, zorder=10)
    ax.plot(
        [x0 + length, x0 + length],
        [y0 - 0.005 * max_y_km, y0 + 0.005 * max_y_km],
        color="black",
        linewidth=1.4,
        zorder=10,
    )
    ax.text(x0 + length * 0.5, y0 + 0.012 * max_y_km, f"{length:.0f} km", ha="center", va="bottom", fontsize=8.8)



