﻿from __future__ import annotations

import csv
from pathlib import Path
from typing import Dict


def export_summary_table(summary: Dict[str, float], output_path: Path) -> None:
    """Export scalar summary metrics to a one-row CSV table."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary.keys()))
        writer.writeheader()
        writer.writerow(summary)
