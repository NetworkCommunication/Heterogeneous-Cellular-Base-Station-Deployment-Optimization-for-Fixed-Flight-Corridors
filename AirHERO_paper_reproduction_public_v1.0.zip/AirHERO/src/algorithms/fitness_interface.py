﻿from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np

from src.algorithms.heterogeneous_deployment import (
    assign_station_type_indices,
    count_station_types,
    parse_station_types,
)
from src.algorithms.particle_encoding import (
    decode_particle_type_and_sector,
    is_extended_particle_array,
    spatial_view,
)
from src.data.types import CityMap, Config
from src.propagation.evaluation_interface import (
    HeterogeneousPropagationParams,
    evaluate_population_snr_multi_fidelity,
)
from src.propagation.low_fidelity import compute_population_strongest_station_indices
from src.propagation.sector_geometry import (
    nearest_supported_sector_direction_deg,
    sector_geometry_config_from_mapping,
    summarize_sector_masks,
)


@dataclass
class StationTypePlan:
    """Station-type assignment and per-slot attributes."""

    station_type_indices: np.ndarray
    station_type_names: List[str]
    tx_power_offsets_db: np.ndarray
    deployment_costs: np.ndarray
    coverage_boost_db: np.ndarray
    path_loss_offsets_db: np.ndarray
    nlos_penalty_factors: np.ndarray
    capacity_units: np.ndarray
    sector_station_mask: np.ndarray
    sector_azimuths_deg: np.ndarray
    sector_beamwidth_deg: float
    outside_sector_mode: str
    side_lobe_attenuation_db: float


@dataclass
class ObjectiveBatch:
    """Batch objective values for optimization."""

    composite: np.ndarray
    handover_count: np.ndarray
    coverage_count: np.ndarray
    coverage_rate: np.ndarray
    existing_route_continuous_coverage_rate: np.ndarray
    future_route_continuous_coverage_rate: np.ndarray
    mean_snr_db: np.ndarray
    deployment_cost: np.ndarray
    cost_effectiveness: np.ndarray
    capacity_effective: np.ndarray
    constraint_penalty: np.ndarray
    sector_inside_any_5ga_rate: Optional[np.ndarray] = None
    sector_points_outside_all_5ga_count: Optional[np.ndarray] = None
    sector_excluded_link_count: Optional[np.ndarray] = None
    per_station_covered_points: Optional[np.ndarray] = None
    sector_station_mask: Optional[np.ndarray] = None
    sector_azimuths_deg: Optional[np.ndarray] = None
    eval_meta: Optional[Dict[str, float]] = None
    propagation_mode: str = "all_low_fidelity"
    per_particle_metrics: Optional[List[Dict[str, float]]] = None

    def at(self, idx: int) -> Dict[str, float]:
        """Return scalar objective components for one particle index."""
        if self.per_particle_metrics is not None:
            return dict(self.per_particle_metrics[idx])
        out = {
            "objective_composite": float(self.composite[idx]),
            "handover_count": float(self.handover_count[idx]),
            "coverage_count": float(self.coverage_count[idx]),
            "coverage_rate": float(self.coverage_rate[idx]),
            "existing_route_continuous_coverage_rate": float(self.existing_route_continuous_coverage_rate[idx]),
            "future_route_continuous_coverage_rate": float(self.future_route_continuous_coverage_rate[idx]),
            "mean_snr_db": float(self.mean_snr_db[idx]),
            "deployment_cost": float(self.deployment_cost[idx]),
            "cost_effectiveness": float(self.cost_effectiveness[idx]),
            "capacity_effective": float(self.capacity_effective[idx]),
            "constraint_penalty": float(self.constraint_penalty[idx]),
        }
        if self.sector_inside_any_5ga_rate is not None:
            out["sector_inside_any_5ga_rate"] = float(self.sector_inside_any_5ga_rate[idx])
        if self.sector_points_outside_all_5ga_count is not None:
            out["sector_points_outside_all_5ga_count"] = float(self.sector_points_outside_all_5ga_count[idx])
        if self.sector_excluded_link_count is not None:
            out["sector_excluded_link_count"] = float(self.sector_excluded_link_count[idx])
        if self.per_station_covered_points is not None:
            for b in range(self.per_station_covered_points.shape[1]):
                out[f"station_{b + 1}_covered_points"] = float(self.per_station_covered_points[idx, b])
        if self.sector_station_mask is not None and self.sector_azimuths_deg is not None:
            for b, is_sector in enumerate(np.asarray(self.sector_station_mask, dtype=bool).tolist()):
                if is_sector:
                    out[f"station_{b + 1}_sector_azimuth_deg"] = float(self.sector_azimuths_deg[b])
        return out


def build_station_type_plan(config: Config, num_base_stations: int) -> StationTypePlan:
    """Build deterministic station-type plan from configurable ratios."""
    specs = parse_station_types(config)
    sector_cfg = sector_geometry_config_from_mapping(config)

    if not specs:
        indices = np.zeros((num_base_stations,), dtype=int)
        names = ["5G"] * num_base_stations
        tx_offsets = np.zeros((num_base_stations,), dtype=float)
        costs = np.ones((num_base_stations,), dtype=float)
        coverage_boost = np.zeros((num_base_stations,), dtype=float)
        path_loss_offsets = np.zeros((num_base_stations,), dtype=float)
        nlos_factors = np.ones((num_base_stations,), dtype=float)
        capacity_units = np.ones((num_base_stations,), dtype=float)
        sector_mask = np.zeros((num_base_stations,), dtype=bool)
        sector_azimuths = np.zeros((num_base_stations,), dtype=float)
        return StationTypePlan(
            station_type_indices=indices,
            station_type_names=names,
            tx_power_offsets_db=tx_offsets,
            deployment_costs=costs,
            coverage_boost_db=coverage_boost,
            path_loss_offsets_db=path_loss_offsets,
            nlos_penalty_factors=nlos_factors,
            capacity_units=capacity_units,
            sector_station_mask=sector_mask,
            sector_azimuths_deg=sector_azimuths,
            sector_beamwidth_deg=sector_cfg.sector_beamwidth_deg,
            outside_sector_mode=sector_cfg.outside_sector_mode,
            side_lobe_attenuation_db=sector_cfg.side_lobe_attenuation_db,
        )

    indices = assign_station_type_indices(num_base_stations, specs)
    names = [specs[i].name for i in indices]
    tx_offsets = np.asarray([specs[i].tx_power_offset_db for i in indices], dtype=float)
    costs = np.asarray([max(specs[i].deployment_cost, 1e-9) for i in indices], dtype=float)
    coverage_boost = np.asarray([specs[i].coverage_boost_db for i in indices], dtype=float)
    path_loss_offsets = np.asarray([specs[i].path_loss_offset_db for i in indices], dtype=float)
    nlos_factors = np.asarray([max(specs[i].nlos_penalty_factor, 1e-6) for i in indices], dtype=float)
    capacity_units = np.asarray([max(specs[i].capacity_units, 1e-9) for i in indices], dtype=float)
    sector_mask = np.asarray([str(n).strip().lower() == "5ga" for n in names], dtype=bool)
    sector_azimuths = _build_configured_sector_azimuths(config, names, sector_cfg.sector_directions_deg)
    return StationTypePlan(
        station_type_indices=indices,
        station_type_names=names,
        tx_power_offsets_db=tx_offsets,
        deployment_costs=costs,
        coverage_boost_db=coverage_boost,
        path_loss_offsets_db=path_loss_offsets,
        nlos_penalty_factors=nlos_factors,
        capacity_units=capacity_units,
        sector_station_mask=sector_mask,
        sector_azimuths_deg=sector_azimuths,
        sector_beamwidth_deg=sector_cfg.sector_beamwidth_deg,
        outside_sector_mode=sector_cfg.outside_sector_mode,
        side_lobe_attenuation_db=sector_cfg.side_lobe_attenuation_db,
    )


def evaluate_population_objectives(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    config: Config,
    station_plan: Optional[StationTypePlan] = None,
    activation: Optional[np.ndarray] = None,
) -> ObjectiveBatch:
    """Evaluate baseline objectives for particle population.

    Interface is reusable by future MOPSO implementations.

    Placeholder abstraction notice:
    - Heterogeneous coverage/propagation/capacity effects are parameterized for
      replacement by engineering-calibrated formulas later.
    """
    positions = np.asarray(positions, dtype=float)
    if positions.ndim != 3:
        raise ValueError("positions must have shape [num_particles, num_base, >=3]")

    num_particles, num_base, _ = positions.shape
    if is_extended_particle_array(positions) and station_plan is None:
        return _evaluate_encoded_population_objectives(
            positions=positions,
            test_points=test_points,
            city_map=city_map,
            channel_params=channel_params,
            config=config,
            activation=activation,
        )

    spatial_positions = spatial_view(positions)
    if station_plan is None:
        station_plan = build_station_type_plan(config, num_base)

    if test_points.size == 0:
        zeros = np.zeros((num_particles,), dtype=float)
        return ObjectiveBatch(
            composite=zeros,
            handover_count=zeros,
            coverage_count=zeros,
            coverage_rate=zeros,
            existing_route_continuous_coverage_rate=zeros,
            future_route_continuous_coverage_rate=zeros,
            mean_snr_db=zeros,
            deployment_cost=zeros,
            cost_effectiveness=zeros,
            capacity_effective=zeros,
            constraint_penalty=zeros,
            eval_meta=_empty_eval_meta(config, num_particles),
            propagation_mode=str(config.get("multiFidelity", {}).get("mode", "all_low_fidelity")),
        )

    if activation is None:
        activation = np.ones((num_particles, num_base), dtype=float)
    else:
        activation = np.asarray(activation, dtype=float)
        if activation.shape != (num_particles, num_base):
            raise ValueError("activation must have shape [num_particles, num_base]")

    hetero_params = HeterogeneousPropagationParams(
        tx_power_offsets_db=station_plan.tx_power_offsets_db,
        coverage_boost_db=station_plan.coverage_boost_db,
        path_loss_offsets_db=station_plan.path_loss_offsets_db,
        nlos_penalty_factors=station_plan.nlos_penalty_factors,
        sector_station_mask=station_plan.sector_station_mask,
        sector_azimuths_deg=station_plan.sector_azimuths_deg,
        sector_beamwidth_deg=station_plan.sector_beamwidth_deg,
        outside_sector_mode=station_plan.outside_sector_mode,
        side_lobe_attenuation_db=station_plan.side_lobe_attenuation_db,
    )
    propagation_result = evaluate_population_snr_multi_fidelity(
        positions=spatial_positions,
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        config=config,
        hetero_params=hetero_params,
    )
    snr_matrix = propagation_result.snr_matrix

    snr_threshold = float(channel_params.get("snrThreshold", 0.0))
    coverage_count = np.sum(snr_matrix >= snr_threshold, axis=1).astype(float)
    coverage_rate = coverage_count / max(test_points.shape[0], 1)
    mean_snr_db = np.mean(snr_matrix, axis=1)

    # Multi-objective support: strongest-link handover count and route continuity rates.
    serving_station_idx = compute_population_strongest_station_indices(
        positions=spatial_positions,
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        tx_power_offsets_db=station_plan.tx_power_offsets_db,
        coverage_boost_db=station_plan.coverage_boost_db,
        path_loss_offsets_db=station_plan.path_loss_offsets_db,
        nlos_penalty_factors=station_plan.nlos_penalty_factors,
        sector_station_mask=station_plan.sector_station_mask,
        sector_azimuths_deg=station_plan.sector_azimuths_deg,
        sector_beamwidth_deg=station_plan.sector_beamwidth_deg,
        outside_sector_mode=station_plan.outside_sector_mode,
        side_lobe_attenuation_db=station_plan.side_lobe_attenuation_db,
    )
    sector_summary = summarize_sector_masks(
        positions=spatial_positions,
        test_points=test_points,
        sector_station_mask=station_plan.sector_station_mask,
        sector_azimuths_deg=station_plan.sector_azimuths_deg,
        sector_beamwidth_deg=station_plan.sector_beamwidth_deg,
    )
    route_groups = _build_route_point_groups(test_points=test_points, config=config)
    existing_idx = route_groups["existing"]
    future_idx = route_groups["future"]

    handover_count = _compute_handover_count_per_particle(
        serving_station_idx=serving_station_idx,
        existing_idx=existing_idx,
        future_idx=future_idx,
    )
    per_station_covered_points = _compute_per_station_covered_points(
        serving_station_idx=serving_station_idx,
        covered_mask=snr_matrix >= snr_threshold,
        num_base=num_base,
    )
    existing_route_cont_rate = _compute_continuous_coverage_rate_per_particle(
        snr_matrix=snr_matrix,
        snr_threshold=snr_threshold,
        point_indices=existing_idx,
    )
    future_route_cont_rate = _compute_continuous_coverage_rate_per_particle(
        snr_matrix=snr_matrix,
        snr_threshold=snr_threshold,
        point_indices=future_idx,
    )

    cost_per_particle = activation * station_plan.deployment_costs[None, :]
    deployment_cost = np.sum(cost_per_particle, axis=1)

    capacity_total = np.sum(activation * station_plan.capacity_units[None, :], axis=1)
    # Placeholder abstraction: effective capacity scales with achieved coverage.
    capacity_effective = capacity_total * coverage_rate
    cost_effectiveness = capacity_effective / np.maximum(deployment_cost, 1e-9)

    obj_cfg = config.get("baselineObjectives", {})
    coverage_w = float(obj_cfg.get("coverageWeight", 1.0))
    signal_w = float(obj_cfg.get("signalQualityWeight", 0.2))
    cost_w = float(obj_cfg.get("costWeight", 0.2))
    efficiency_w = float(obj_cfg.get("costEffectivenessWeight", 0.0))
    capacity_w = float(obj_cfg.get("capacityWeight", 0.0))
    cost_ref = float(obj_cfg.get("costReference", max(float(np.max(deployment_cost)), 1e-9)))
    capacity_ref = float(obj_cfg.get("capacityReference", max(float(np.max(capacity_effective)), 1e-9)))

    coverage_score = coverage_rate * 100.0
    cost_score = (deployment_cost / max(cost_ref, 1e-9)) * 100.0
    capacity_score = (capacity_effective / max(capacity_ref, 1e-9)) * 100.0

    constraint_penalty = _evaluate_constraint_penalty(
        config=config,
        station_plan=station_plan,
        activation=activation,
        deployment_cost=deployment_cost,
        coverage_rate=coverage_rate,
    )

    composite = (                                                                          #综合适应度
        coverage_w * coverage_score
        + signal_w * mean_snr_db
        + efficiency_w * cost_effectiveness
        + capacity_w * capacity_score
        - cost_w * cost_score
        - constraint_penalty
    )

    stats = propagation_result.stats
    eval_meta = {
        "propagation_mode_code": float(_propagation_mode_code(stats.mode)),
        "propagation_low_fidelity_seconds": float(stats.low_fidelity_seconds),
        "propagation_high_fidelity_seconds": float(stats.high_fidelity_seconds),
        "propagation_total_seconds": float(stats.total_seconds),
        "propagation_low_fidelity_particles": float(stats.num_low_fidelity),
        "propagation_high_fidelity_particles": float(stats.num_high_fidelity),
        "propagation_elite_count_applied": float(stats.elite_count_applied),
        "propagation_elite_ratio": float(stats.elite_ratio),
        "existing_route_points": float(existing_idx.size),
        "future_route_points": float(future_idx.size),
        "sector_num_5ga_stations": float(np.sum(station_plan.sector_station_mask.astype(float))),
        "sector_inside_any_5ga_rate_mean": float(np.mean(sector_summary["sector_inside_any_5ga_rate"])),
        "sector_points_outside_all_5ga_count_mean": float(
            np.mean(sector_summary["sector_points_outside_all_5ga_count"])
        ),
        "sector_excluded_link_count_mean": float(np.mean(sector_summary["sector_excluded_link_count"])),
    }
    for b in range(num_base):
        eval_meta[f"station_{b + 1}_covered_points_mean"] = float(np.mean(per_station_covered_points[:, b]))
        if bool(station_plan.sector_station_mask[b]):
            eval_meta[f"station_{b + 1}_sector_azimuth_deg"] = float(station_plan.sector_azimuths_deg[b])

    return ObjectiveBatch(
        composite=composite,
        handover_count=handover_count,
        coverage_count=coverage_count,
        coverage_rate=coverage_rate,
        existing_route_continuous_coverage_rate=existing_route_cont_rate,
        future_route_continuous_coverage_rate=future_route_cont_rate,
        mean_snr_db=mean_snr_db,
        deployment_cost=deployment_cost,
        cost_effectiveness=cost_effectiveness,
        capacity_effective=capacity_effective,
        constraint_penalty=constraint_penalty,
        sector_inside_any_5ga_rate=np.asarray(sector_summary["sector_inside_any_5ga_rate"], dtype=float),
        sector_points_outside_all_5ga_count=np.asarray(
            sector_summary["sector_points_outside_all_5ga_count"], dtype=float
        ),
        sector_excluded_link_count=np.asarray(sector_summary["sector_excluded_link_count"], dtype=float),
        per_station_covered_points=per_station_covered_points,
        sector_station_mask=station_plan.sector_station_mask,
        sector_azimuths_deg=station_plan.sector_azimuths_deg,
        eval_meta=eval_meta,
        propagation_mode=stats.mode,
    )


def build_station_type_plan_from_particle(config: Config, particle: np.ndarray) -> StationTypePlan:
    """Build a per-particle station-type plan from extended decision variables."""
    type_indices, names, _, sector_azimuths = decode_particle_type_and_sector(particle, config)
    specs = parse_station_types(config)
    if not specs:
        return build_station_type_plan(config, int(np.asarray(particle).shape[0]))

    type_indices = np.asarray(type_indices, dtype=int)
    tx_offsets = np.asarray([specs[int(i)].tx_power_offset_db for i in type_indices], dtype=float)
    costs = np.asarray([max(specs[int(i)].deployment_cost, 1e-9) for i in type_indices], dtype=float)
    coverage_boost = np.asarray([specs[int(i)].coverage_boost_db for i in type_indices], dtype=float)
    path_loss_offsets = np.asarray([specs[int(i)].path_loss_offset_db for i in type_indices], dtype=float)
    nlos_factors = np.asarray([max(specs[int(i)].nlos_penalty_factor, 1e-6) for i in type_indices], dtype=float)
    capacity_units = np.asarray([max(specs[int(i)].capacity_units, 1e-9) for i in type_indices], dtype=float)
    sector_cfg = sector_geometry_config_from_mapping(config)
    sector_mask = np.asarray([str(n).strip().lower() == "5ga" for n in names], dtype=bool)
    return StationTypePlan(
        station_type_indices=type_indices,
        station_type_names=names,
        tx_power_offsets_db=tx_offsets,
        deployment_costs=costs,
        coverage_boost_db=coverage_boost,
        path_loss_offsets_db=path_loss_offsets,
        nlos_penalty_factors=nlos_factors,
        capacity_units=capacity_units,
        sector_station_mask=sector_mask,
        sector_azimuths_deg=np.asarray(sector_azimuths, dtype=float),
        sector_beamwidth_deg=sector_cfg.sector_beamwidth_deg,
        outside_sector_mode=sector_cfg.outside_sector_mode,
        side_lobe_attenuation_db=sector_cfg.side_lobe_attenuation_db,
    )


def _evaluate_encoded_population_objectives(
    positions: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    config: Config,
    activation: Optional[np.ndarray],
) -> ObjectiveBatch:
    """Evaluate extended particles with per-particle station type/sector plans."""
    arr = np.asarray(positions, dtype=float)
    num_particles, num_base, _ = arr.shape
    if activation is not None:
        activation = np.asarray(activation, dtype=float)
        if activation.shape != (num_particles, num_base):
            raise ValueError("activation must have shape [num_particles, num_base]")

    batches: List[ObjectiveBatch] = []
    metrics: List[Dict[str, float]] = []
    for i in range(num_particles):
        station_plan = build_station_type_plan_from_particle(config, arr[i])
        one_activation = activation[i : i + 1] if activation is not None else None
        batch = evaluate_population_objectives(
            positions=spatial_view(arr[i : i + 1]),
            test_points=test_points,
            city_map=city_map,
            channel_params=channel_params,
            config=config,
            station_plan=station_plan,
            activation=one_activation,
        )
        row = batch.at(0)
        batches.append(batch)
        metrics.append(row)

    def cat(name: str) -> np.ndarray:
        values = []
        for b in batches:
            raw = getattr(b, name)
            if raw is None:
                values.append(np.asarray([0.0], dtype=float))
            else:
                values.append(np.asarray(raw, dtype=float).reshape(1))
        return np.concatenate(values, axis=0)

    per_station = np.vstack(
        [
            b.per_station_covered_points[0]
            if b.per_station_covered_points is not None
            else np.zeros((num_base,), dtype=float)
            for b in batches
        ]
    )
    return ObjectiveBatch(
        composite=cat("composite"),
        handover_count=cat("handover_count"),
        coverage_count=cat("coverage_count"),
        coverage_rate=cat("coverage_rate"),
        existing_route_continuous_coverage_rate=cat("existing_route_continuous_coverage_rate"),
        future_route_continuous_coverage_rate=cat("future_route_continuous_coverage_rate"),
        mean_snr_db=cat("mean_snr_db"),
        deployment_cost=cat("deployment_cost"),
        cost_effectiveness=cat("cost_effectiveness"),
        capacity_effective=cat("capacity_effective"),
        constraint_penalty=cat("constraint_penalty"),
        sector_inside_any_5ga_rate=cat("sector_inside_any_5ga_rate"),
        sector_points_outside_all_5ga_count=cat("sector_points_outside_all_5ga_count"),
        sector_excluded_link_count=cat("sector_excluded_link_count"),
        per_station_covered_points=per_station,
        eval_meta=batches[-1].eval_meta if batches else _empty_eval_meta(config, num_particles),
        propagation_mode=batches[-1].propagation_mode if batches else str(config.get("multiFidelity", {}).get("mode", "all_low_fidelity")),
        per_particle_metrics=metrics,
    )


def evaluate_solution_objectives(
    position: np.ndarray,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    config: Config,
    station_plan: Optional[StationTypePlan] = None,
) -> Dict[str, float]:
    """Evaluate objective values for one deployment solution."""
    batch = evaluate_population_objectives(
        positions=position[None, :, :],
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        config=config,
        station_plan=station_plan,
    )
    return batch.at(0)


def summarize_station_type_counts(station_plan: StationTypePlan) -> Dict[str, int]:
    """Return type counts for logging/reporting."""
    return count_station_types(station_plan.station_type_names)


def _build_configured_sector_azimuths(config: Config, station_type_names: List[str], directions_deg: np.ndarray) -> np.ndarray:
    """Build fixed per-slot 5GA sector azimuths until optimizer encoding is added."""
    num_base = len(station_type_names)
    h_cfg = config.get("heterogeneousDeployment", {})
    explicit = h_cfg.get("sectorAzimuthsDeg", h_cfg.get("sector_azimuths_deg"))
    if explicit is not None:
        arr = np.asarray(explicit, dtype=float).reshape(-1)
        if arr.size != num_base:
            raise ValueError("heterogeneousDeployment.sectorAzimuthsDeg length must equal pso.numBaseStations")
        return np.asarray(nearest_supported_sector_direction_deg(arr, directions_deg), dtype=float)

    type_defaults: Dict[str, float] = {}
    for item in h_cfg.get("stationTypes", []):
        if not isinstance(item, dict):
            continue
        name = str(item.get("name", "")).strip().lower()
        raw_az = item.get("sectorAzimuthDeg", item.get("sector_azimuth_deg"))
        if name and raw_az is not None:
            type_defaults[name] = float(raw_az)

    default_azimuth = h_cfg.get("defaultSectorAzimuthDeg", h_cfg.get("default_sector_azimuth_deg", directions_deg[0]))
    out = np.zeros((num_base,), dtype=float)
    for idx, name in enumerate(station_type_names):
        if str(name).strip().lower() == "5ga":
            raw = type_defaults.get("5ga", float(default_azimuth))
            out[idx] = float(nearest_supported_sector_direction_deg(float(raw), directions_deg))
    return out


def _compute_per_station_covered_points(
    serving_station_idx: np.ndarray,
    covered_mask: np.ndarray,
    num_base: int,
) -> np.ndarray:
    """Count covered points served by each strongest-link station."""
    serving = np.asarray(serving_station_idx, dtype=int)
    covered = np.asarray(covered_mask, dtype=bool)
    n_particles = int(serving.shape[0]) if serving.ndim >= 1 else 0
    out = np.zeros((n_particles, int(num_base)), dtype=float)
    if serving.size == 0 or covered.size == 0:
        return out
    for b in range(int(num_base)):
        out[:, b] = np.sum((serving == b) & covered, axis=1).astype(float)
    return out


def _evaluate_constraint_penalty(
    config: Config,
    station_plan: StationTypePlan,
    activation: np.ndarray,
    deployment_cost: np.ndarray,
    coverage_rate: np.ndarray,
) -> np.ndarray:
    """Compute configurable constraint penalties for each particle.

    Supported constraints:
    - max number of 5GA stations
    - total budget
    - minimum coverage requirement
    """
    num_particles = activation.shape[0]
    penalty = np.zeros((num_particles,), dtype=float)

    c_cfg = config.get("heterogeneousConstraints", {})
    p_cfg = c_cfg.get("penalties", {})
    max5ga_penalty = float(p_cfg.get("max5gaPenalty", 50.0))
    budget_penalty = float(p_cfg.get("budgetPenalty", 50.0))
    mincov_penalty = float(p_cfg.get("minCoveragePenalty", 80.0))

    max_5ga = c_cfg.get("maxNum5GA")
    if max_5ga is not None:
        mask_5ga = np.array([str(n).lower() == "5ga" for n in station_plan.station_type_names], dtype=float)
        num_5ga = np.sum(activation * mask_5ga[None, :], axis=1)
        exceed = np.maximum(num_5ga - float(max_5ga), 0.0)
        penalty += max5ga_penalty * exceed

    total_budget = c_cfg.get("totalBudget")
    if total_budget is not None:
        budget = float(total_budget)
        exceed_ratio = np.maximum((deployment_cost - budget) / max(budget, 1e-9), 0.0)
        penalty += budget_penalty * 100.0 * exceed_ratio

    min_coverage = c_cfg.get("minCoverageRate")
    if min_coverage is not None:
        min_cov = float(min_coverage)
        gap = np.maximum(min_cov - coverage_rate, 0.0)
        penalty += mincov_penalty * 100.0 * gap

    return penalty


def _build_route_point_groups(test_points: np.ndarray, config: Config) -> Dict[str, np.ndarray]:
    """Build index groups for existing/future route objective evaluation.

    Supported split modes:
    - index_ratio: split by ordered point index with `existingRatio`.
    - explicit_indices: use configured index lists.
    """
    n = int(test_points.shape[0])
    if n <= 0:
        return {"existing": np.zeros((0,), dtype=int), "future": np.zeros((0,), dtype=int)}

    route_cfg = config.get("routeObjectives", {})
    mode = str(route_cfg.get("splitMode", "index_ratio")).strip().lower()

    if mode == "explicit_indices":
        raw_existing = np.asarray(route_cfg.get("existingIndices", []), dtype=int).reshape(-1)
        raw_future = np.asarray(route_cfg.get("futureIndices", []), dtype=int).reshape(-1)
        existing = _sanitize_indices(raw_existing, upper=n)
        future = _sanitize_indices(raw_future, upper=n)
        if existing.size == 0 and future.size == 0:
            mode = "index_ratio"
        else:
            if existing.size == 0:
                mask = np.ones((n,), dtype=bool)
                mask[future] = False
                existing = np.where(mask)[0]
            if future.size == 0:
                mask = np.ones((n,), dtype=bool)
                mask[existing] = False
                future = np.where(mask)[0]
            return {"existing": np.sort(existing), "future": np.sort(future)}

    ratio = float(np.clip(route_cfg.get("existingRatio", 0.5), 0.0, 1.0))
    cut = int(np.floor(ratio * n))
    cut = int(np.clip(cut, 0, n))
    existing = np.arange(0, cut, dtype=int)
    future = np.arange(cut, n, dtype=int)
    if existing.size == 0 and future.size > 0:
        existing = future.copy()
    if future.size == 0 and existing.size > 0:
        future = existing.copy()
    return {"existing": existing, "future": future}


def _sanitize_indices(indices: np.ndarray, upper: int) -> np.ndarray:
    if indices.size == 0:
        return np.zeros((0,), dtype=int)
    idx = indices[(indices >= 0) & (indices < int(upper))]
    if idx.size == 0:
        return np.zeros((0,), dtype=int)
    return np.unique(idx.astype(int))


def _compute_handover_count_per_particle(
    serving_station_idx: np.ndarray,
    existing_idx: np.ndarray,
    future_idx: np.ndarray,
) -> np.ndarray:
    """Count strongest-link station switches for each particle."""
    n_particles = int(serving_station_idx.shape[0])
    counts = np.zeros((n_particles,), dtype=float)
    if serving_station_idx.size == 0:
        return counts

    for i in range(n_particles):
        c = 0
        if existing_idx.size > 1:
            seq = serving_station_idx[i, existing_idx]
            c += int(np.sum(seq[1:] != seq[:-1]))
        if future_idx.size > 1:
            seq = serving_station_idx[i, future_idx]
            c += int(np.sum(seq[1:] != seq[:-1]))
        counts[i] = float(c)
    return counts


def _compute_continuous_coverage_rate_per_particle(
    snr_matrix: np.ndarray,
    snr_threshold: float,
    point_indices: np.ndarray,
) -> np.ndarray:
    """Compute continuous coverage rate as covered-adjacent-pair ratio."""
    n_particles = int(snr_matrix.shape[0])
    out = np.zeros((n_particles,), dtype=float)
    if point_indices.size == 0:
        return out

    covered = snr_matrix[:, point_indices] >= float(snr_threshold)
    n = int(point_indices.size)
    if n == 1:
        return covered[:, 0].astype(float)

    adjacent_ok = covered[:, 1:] & covered[:, :-1]
    return np.mean(adjacent_ok.astype(float), axis=1)


def _propagation_mode_code(mode: str) -> int:
    m = str(mode).strip().lower()
    if m == "all_low_fidelity":
        return 0
    if m == "all_high_fidelity":
        return 1
    if m == "elite_mixed_fidelity":
        return 2
    return 99


def _empty_eval_meta(config: Config, num_particles: int) -> Dict[str, float]:
    mode = str(config.get("multiFidelity", {}).get("mode", "all_low_fidelity"))
    return {
        "propagation_mode_code": float(_propagation_mode_code(mode)),
        "propagation_low_fidelity_seconds": 0.0,
        "propagation_high_fidelity_seconds": 0.0,
        "propagation_total_seconds": 0.0,
        "propagation_low_fidelity_particles": float(num_particles),
        "propagation_high_fidelity_particles": 0.0,
        "propagation_elite_count_applied": 0.0,
        "propagation_elite_ratio": float(config.get("multiFidelity", {}).get("eliteRatio", 0.0)),
    }
