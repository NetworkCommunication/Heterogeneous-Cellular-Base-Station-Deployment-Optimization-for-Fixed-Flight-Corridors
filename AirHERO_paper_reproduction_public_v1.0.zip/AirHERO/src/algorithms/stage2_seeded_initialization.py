﻿from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Mapping, Optional, Sequence

import numpy as np

from src.algorithms.heterogeneous_deployment import parse_station_types
from src.algorithms.init_strategies import enforce_non_building_constraint
from src.algorithms.particle_encoding import (
    SECTOR_INDEX_COL,
    TYPE_INDEX_COL,
    extend_particles_with_decisions,
    is_extended_particle_array,
    repair_particle_encoding,
    spatial_view,
)
from src.data.types import CityMap, Config
from src.propagation.sector_geometry import DEFAULT_SECTOR_DIRECTIONS_DEG, nearest_supported_sector_direction_deg


STAGE2_SECTOR_MODE_PRESERVE = "preserve"
STAGE2_SECTOR_MODE_NEIGHBOR = "neighbor"
STAGE2_SECTOR_MODE_RANDOM = "random"


@dataclass(frozen=True)
class Stage2AnchorSite:
    """Typed Stage-2 anchor carrying Stage-1 sector metadata when available."""

    x: float
    y: float
    z: float
    station_type: Optional[str] = None
    station_type_index: Optional[int] = None
    sector_direction_index: Optional[int] = None
    sector_azimuth_deg: Optional[float] = None
    source: str = "stage2_anchor"

    @property
    def position(self) -> np.ndarray:
        return np.asarray([self.x, self.y, self.z], dtype=float)

    @property
    def is_5ga(self) -> bool:
        return str(self.station_type or "").strip().lower() == "5ga"


@dataclass
class Stage2SeededInitResult:
    """Stage-2 particle initialization outputs and statistics."""

    particles: np.ndarray
    stats: Dict[str, float]


def build_stage2_seeded_particles(
    stage1_sites: np.ndarray,
    existing_stations: Optional[np.ndarray],
    num_particles: int,
    num_base_stations: int,
    min_position: np.ndarray,
    max_position: np.ndarray,
    config: Config,
    rng: np.random.Generator,
    city_map: Optional[CityMap] = None,
    stage1_station_records: Optional[Sequence[Mapping[str, Any]]] = None,
) -> Stage2SeededInitResult:
    """Build stage-2 particles with per-particle partial seeding.

    Updated rule:
    - Every particle contains a subset of station slots seeded from stage-1 key
      candidate sites (with perturbation).
    - The remaining slots in the same particle stay random for diversity.
    """
    stage2_cfg = config.get("stage2", {})
    seeded_ratio = float(np.clip(stage2_cfg.get("seededParticleRatio", 0.4), 0.0, 1.0))
    sigma_xy = float(stage2_cfg.get("perturbationXY", stage2_cfg.get("perturbationStrengthXY", 35.0)))
    sigma_z = float(stage2_cfg.get("perturbationZ", stage2_cfg.get("perturbationStrengthZ", 10.0)))
    use_existing_anchors = bool(stage2_cfg.get("useExistingAnchors", True))
    sector_mode = _stage2_sector_perturbation_mode(config)

    # Interpret seededParticleRatio as per-particle slot ratio.
    num_seeded_slots = int(round(num_base_stations * seeded_ratio))
    if seeded_ratio > 0.0 and num_seeded_slots <= 0:
        num_seeded_slots = 1
    num_seeded_slots = int(np.clip(num_seeded_slots, 0, num_base_stations))
    num_random_slots = int(num_base_stations - num_seeded_slots)

    min_spatial = spatial_view(np.asarray(min_position, dtype=float).reshape(1, 1, -1))[0, 0]
    max_spatial = spatial_view(np.asarray(max_position, dtype=float).reshape(1, 1, -1))[0, 0]
    particles = rng.uniform(low=min_spatial, high=max_spatial, size=(num_particles, num_base_stations, 3))

    anchors = _build_anchor_sites(
        stage1_sites=stage1_sites,
        stage1_station_records=stage1_station_records,
        existing_stations=existing_stations,
        config=config,
        use_existing_anchors=use_existing_anchors,
        fallback_min=min_spatial,
        fallback_max=max_spatial,
        rng=rng,
    )

    seeded_anchor_grid: List[List[Optional[Stage2AnchorSite]]] = [
        [None for _ in range(num_base_stations)] for _ in range(num_particles)
    ]
    if num_seeded_slots > 0 and len(anchors) > 0:
        for i in range(num_particles):
            if num_seeded_slots >= num_base_stations:
                seeded_slot_idx = np.arange(num_base_stations, dtype=int)
            else:
                seeded_slot_idx = rng.choice(num_base_stations, size=num_seeded_slots, replace=False)

            for b in seeded_slot_idx:
                anchor = anchors[int(rng.integers(0, len(anchors)))]
                jitter = np.array(
                    [rng.normal(0.0, sigma_xy), rng.normal(0.0, sigma_xy), rng.normal(0.0, sigma_z)],
                    dtype=float,
                )
                particles[i, b] = np.clip(anchor.position + jitter, min_spatial, max_spatial)
                seeded_anchor_grid[i][int(b)] = anchor

    if city_map is not None:
        particles = enforce_non_building_constraint(particles, city_map, min_spatial, max_spatial, rng)

    particles = extend_particles_with_decisions(particles, config=config, rng=rng)
    particles, sector_stats = _apply_seeded_anchor_decisions(
        particles=particles,
        seeded_anchor_grid=seeded_anchor_grid,
        config=config,
        rng=rng,
        sector_mode=sector_mode,
    )

    seeded_particles = num_particles if (num_seeded_slots > 0 and len(anchors) > 0) else 0
    random_particles = num_particles - seeded_particles
    stats = {
        "stage2_seeded_ratio": float(seeded_ratio),
        "stage2_seeded_particles": float(seeded_particles),
        "stage2_random_particles": float(random_particles),
        "stage2_seeded_slots_per_particle": float(num_seeded_slots),
        "stage2_random_slots_per_particle": float(num_random_slots),
        "stage2_seeded_slots_total": float(num_seeded_slots * num_particles),
        "stage2_random_slots_total": float(num_random_slots * num_particles),
        "stage2_num_anchors": float(len(anchors)),
        "stage2_perturbation_xy": float(sigma_xy),
        "stage2_perturbation_z": float(sigma_z),
        "stage2_sector_direction_mode_code": float(_stage2_sector_mode_code(sector_mode)),
    }
    stats.update(sector_stats)
    return Stage2SeededInitResult(particles=particles, stats=stats)


def _build_anchor_sites(
    stage1_sites: np.ndarray,
    stage1_station_records: Optional[Sequence[Mapping[str, Any]]],
    existing_stations: Optional[np.ndarray],
    config: Config,
    use_existing_anchors: bool,
    fallback_min: np.ndarray,
    fallback_max: np.ndarray,
    rng: np.random.Generator,
) -> List[Stage2AnchorSite]:
    record_anchors = _anchors_from_stage1_records(stage1_station_records)
    if record_anchors:
        return record_anchors

    anchors: List[Stage2AnchorSite] = []
    s1 = np.asarray(stage1_sites, dtype=float)
    if s1.size > 0:
        if s1.ndim == 1:
            s1 = s1.reshape(1, -1)
        # Stage-1 key candidates have priority.
        return [
            Stage2AnchorSite(
                x=float(row[0]),
                y=float(row[1]),
                z=float(row[2]),
                station_type=None,
                source="stage1_legacy_coordinates",
            )
            for row in s1[:, :3]
        ]

    if use_existing_anchors and existing_stations is not None:
        ex = np.asarray(existing_stations, dtype=float)
        if ex.size > 0:
            if ex.ndim == 1:
                ex = ex.reshape(1, -1)
            existing_types = list(config.get("heterogeneousDeployment", {}).get("existingStationTypes", []))
            existing_az = list(config.get("heterogeneousDeployment", {}).get("existingStationSectorAzimuthsDeg", []))
            for idx, row in enumerate(ex[:, :3]):
                station_type = str(existing_types[idx]) if idx < len(existing_types) and str(existing_types[idx]).strip() else None
                sector_idx: Optional[int] = None
                sector_az: Optional[float] = None
                if station_type and station_type.strip().lower() == "5ga":
                    raw_az = float(existing_az[idx]) if idx < len(existing_az) else 0.0
                    sector_idx = _sector_index_from_azimuth(raw_az)
                    sector_az = float(DEFAULT_SECTOR_DIRECTIONS_DEG[sector_idx])
                anchors.append(
                    Stage2AnchorSite(
                        x=float(row[0]),
                        y=float(row[1]),
                        z=float(row[2]),
                        station_type=station_type,
                        sector_direction_index=sector_idx,
                        sector_azimuth_deg=sector_az,
                        source="existing_station",
                    )
                )

    if anchors:
        return anchors

    center = (fallback_min + fallback_max) * 0.5
    jitter = rng.normal(0.0, [30.0, 30.0, 8.0], size=(3,))
    point = np.clip(center + jitter, fallback_min, fallback_max)
    return [
        Stage2AnchorSite(
            x=float(point[0]),
            y=float(point[1]),
            z=float(point[2]),
            station_type=None,
            source="fallback_center",
        )
    ]


def _anchors_from_stage1_records(
    records: Optional[Sequence[Mapping[str, Any]]],
) -> List[Stage2AnchorSite]:
    if not records:
        return []
    anchors: List[Stage2AnchorSite] = []
    for record in records:
        z_value = record.get("z", record.get("height"))
        if z_value is None:
            raise ValueError("Stage-2 Stage-1 anchor record requires z or height")
        station_type = str(record.get("station_type", "")).strip() or None
        sector_idx: Optional[int] = None
        sector_az: Optional[float] = None
        if station_type and station_type.lower() == "5ga":
            raw_idx = record.get("sector_direction_index")
            raw_az = record.get("sector_azimuth_deg")
            if raw_idx is None or raw_idx == "" or raw_az is None or raw_az == "":
                raise ValueError("Stage-2 cannot seed from a Stage-1 5GA anchor without sector direction")
            sector_idx = int(raw_idx)
            sector_az = float(raw_az)
            if sector_idx < 0 or sector_idx >= DEFAULT_SECTOR_DIRECTIONS_DEG.size:
                raise ValueError("Stage-1 5GA anchor sector_direction_index must be in [0, 7]")
            expected = float(DEFAULT_SECTOR_DIRECTIONS_DEG[sector_idx])
            if not np.isclose(float(nearest_supported_sector_direction_deg(sector_az)), expected, atol=1e-9, rtol=0.0):
                raise ValueError("Stage-1 5GA anchor sector_azimuth_deg must match sector_direction_index")

        anchors.append(
            Stage2AnchorSite(
                x=float(record["x"]),
                y=float(record["y"]),
                z=float(z_value),
                station_type=station_type,
                station_type_index=(
                    None
                    if record.get("station_type_index") in (None, "")
                    else int(record.get("station_type_index"))
                ),
                sector_direction_index=sector_idx,
                sector_azimuth_deg=sector_az,
                source=str(record.get("source", "stage1_record")),
            )
        )
    return anchors


def _apply_seeded_anchor_decisions(
    particles: np.ndarray,
    seeded_anchor_grid: Sequence[Sequence[Optional[Stage2AnchorSite]]],
    config: Config,
    rng: np.random.Generator,
    sector_mode: str,
) -> tuple[np.ndarray, Dict[str, float]]:
    if not is_extended_particle_array(particles):
        return particles, _empty_stage2_sector_stats()

    out = np.asarray(particles, dtype=float).copy()
    optimize_station_type = bool(config.get("particleEncoding", {}).get("optimizeStationType", False))
    preserved = 0
    neighbor_perturbed = 0
    random_perturbed = 0
    seeded_5ga = 0

    for i, row in enumerate(seeded_anchor_grid):
        for b, anchor in enumerate(row):
            if anchor is None:
                continue
            if anchor.station_type and (optimize_station_type or anchor.is_5ga):
                type_idx = _station_type_index(anchor.station_type, config, fallback=anchor.station_type_index)
                out[i, b, TYPE_INDEX_COL] = float(type_idx)
            if not anchor.is_5ga:
                continue
            if anchor.sector_direction_index is None:
                raise ValueError("Stage-2 5GA anchor requires sector_direction_index")
            seeded_5ga += 1
            selected_sector = _stage2_sector_index_from_anchor(
                int(anchor.sector_direction_index),
                sector_mode=sector_mode,
                rng=rng,
            )
            out[i, b, SECTOR_INDEX_COL] = float(selected_sector)
            if selected_sector == int(anchor.sector_direction_index):
                preserved += 1
            elif sector_mode == STAGE2_SECTOR_MODE_NEIGHBOR:
                neighbor_perturbed += 1
            elif sector_mode == STAGE2_SECTOR_MODE_RANDOM:
                random_perturbed += 1

    out = repair_particle_encoding(out, config=config)
    return out, {
        "stage2_seeded_5ga_anchor_slots": float(seeded_5ga),
        "stage2_preserved_stage1_5ga_sector_count": float(preserved),
        "stage2_neighbor_perturbed_stage1_5ga_sector_count": float(neighbor_perturbed),
        "stage2_random_perturbed_stage1_5ga_sector_count": float(random_perturbed),
    }


def _empty_stage2_sector_stats() -> Dict[str, float]:
    return {
        "stage2_seeded_5ga_anchor_slots": 0.0,
        "stage2_preserved_stage1_5ga_sector_count": 0.0,
        "stage2_neighbor_perturbed_stage1_5ga_sector_count": 0.0,
        "stage2_random_perturbed_stage1_5ga_sector_count": 0.0,
    }


def _stage2_sector_perturbation_mode(config: Config) -> str:
    stage2_cfg = config.get("stage2", {})
    mode = str(
        stage2_cfg.get(
            "stage1SectorDirectionMode",
            stage2_cfg.get("stage1_5ga_sector_direction_mode", STAGE2_SECTOR_MODE_PRESERVE),
        )
    ).strip().lower()
    if mode not in {STAGE2_SECTOR_MODE_PRESERVE, STAGE2_SECTOR_MODE_NEIGHBOR, STAGE2_SECTOR_MODE_RANDOM}:
        raise ValueError("stage2.stage1SectorDirectionMode must be preserve, neighbor, or random")
    return mode


def _stage2_sector_index_from_anchor(
    anchor_idx: int,
    sector_mode: str,
    rng: np.random.Generator,
) -> int:
    base = int(anchor_idx) % int(DEFAULT_SECTOR_DIRECTIONS_DEG.size)
    if sector_mode == STAGE2_SECTOR_MODE_PRESERVE:
        return base
    if sector_mode == STAGE2_SECTOR_MODE_NEIGHBOR:
        candidates = np.asarray([(base - 1) % 8, (base + 1) % 8], dtype=int)
        return int(candidates[int(rng.integers(0, candidates.size))])
    if sector_mode == STAGE2_SECTOR_MODE_RANDOM:
        return int(rng.integers(0, DEFAULT_SECTOR_DIRECTIONS_DEG.size))
    raise ValueError("Unsupported Stage-2 sector perturbation mode")


def _station_type_index(station_type: str, config: Config, fallback: Optional[int]) -> int:
    specs = parse_station_types(config)
    if specs:
        lookup = {str(spec.name).strip().lower(): idx for idx, spec in enumerate(specs)}
        key = str(station_type).strip().lower()
        if key not in lookup:
            raise ValueError(f"Stage-2 anchor station_type {station_type!r} is not configured")
        return int(lookup[key])
    if fallback is not None:
        return int(fallback)
    return 0


def _sector_index_from_azimuth(azimuth_deg: float) -> int:
    snapped = float(nearest_supported_sector_direction_deg(float(azimuth_deg), DEFAULT_SECTOR_DIRECTIONS_DEG))
    diff = np.abs((DEFAULT_SECTOR_DIRECTIONS_DEG - snapped + 180.0) % 360.0 - 180.0)
    return int(np.argmin(diff))


def _stage2_sector_mode_code(mode: str) -> int:
    if mode == STAGE2_SECTOR_MODE_PRESERVE:
        return 0
    if mode == STAGE2_SECTOR_MODE_NEIGHBOR:
        return 1
    if mode == STAGE2_SECTOR_MODE_RANDOM:
        return 2
    return 99
