﻿from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from src.algorithms.fitness_interface import (
    build_station_type_plan,
    build_station_type_plan_from_particle,
    evaluate_population_objectives,
)
from src.algorithms.init_strategies import enforce_non_building_constraint
from src.algorithms.kmeans_initializer import kmeans_initialize_particles
from src.algorithms.particle_encoding import (
    decode_particle_solution,
    encoding_min_max,
    extend_particles_with_decisions,
    is_extended_particle_array,
    particle_encoding_spec,
    repair_particle_encoding,
    station_sector_azimuth_list,
)
from src.algorithms.stage1_deployment import deploy_stage1_blind_spots, stage1_added_sites_array
from src.algorithms.stage2_seeded_initialization import build_stage2_seeded_particles
from src.data.types import CityMap, Config, PSOResult
from src.propagation.sector_geometry import validate_proposed_sector_config
from src.propagation.stagnation_responses import apply_high_stagnation_response, apply_low_latency_response


@dataclass
class MOPSOResult:                                                         #输出结果
    """MOPSO output for analysis and experiment export."""

    best_position: np.ndarray
    best_fitness: float
    convergence_history: np.ndarray
    convergence_iteration: int
    iteration: int
    best_objectives: Dict[str, float]
    objective_history: Dict[str, np.ndarray]
    pareto_positions: np.ndarray
    pareto_objectives: np.ndarray
    pareto_composite_scores: np.ndarray
    pareto_metrics: List[Dict[str, float]]
    diversity_history: np.ndarray
    archive_size_history: np.ndarray
    velocity_norm_history: np.ndarray
    stagnation_logs: List[Dict[str, float | str]]
    stagnation_events: List[Dict[str, float | str]]
    trigger_stats: Dict[str, float]
    init_stats: Dict[str, float]
    station_type_indices: np.ndarray
    station_type_names: List[str]
    station_sector_azimuths_deg: List[Optional[float]]
    best_decoded_solution: List[Dict[str, object]]
    pareto_decoded_solutions: List[List[Dict[str, object]]]


@dataclass
class StagnationIndicators:                                  #停滞因子
    """Measured stagnation indicators at one iteration."""

    quasi_entropy: float
    quasi_entropy_q0: float
    quasi_entropy_theta: float
    quasi_entropy_trigger: bool
    quasi_entropy_non_positive_replaced: int
    quasi_entropy_selected_count: int
    quasi_entropy_ratio: float
    global_best_change_rate: float
    non_dominated_front_change_rate: float
    population_radius: float
    pbest_improvement_rate: float
    velocity_norm: float
    leader_archive_diversity: float
    objective_space_spread: float


@dataclass
class AdaptiveWeightState:
    """State for adaptive non-QE stagnation weights."""

    weights: Dict[str, float]
    smoothed_signal: Dict[str, float]
    last_update_iteration: int = -1


class ParetoArchive:                                                 #pareto前沿档案
    """Bounded Pareto archive with crowding-distance pruning."""

    def __init__(self, max_size: int) -> None:
        self.max_size = int(max(2, max_size))
        self.positions = np.zeros((0, 0, 3), dtype=float)
        self.objectives = np.zeros((0, 0), dtype=float)
        self.composite_scores = np.zeros((0,), dtype=float)
        self.metrics: List[Dict[str, float]] = []

    def __len__(self) -> int:
        return int(self.objectives.shape[0])

    def update(
        self,
        candidate_positions: np.ndarray,
        candidate_objectives: np.ndarray,
        candidate_composite: np.ndarray,
        candidate_metrics: Sequence[Dict[str, float]],
    ) -> None:
        if candidate_positions.size == 0:
            return

        cand_positions = np.asarray(candidate_positions, dtype=float)
        cand_objectives = np.asarray(candidate_objectives, dtype=float)
        cand_composite = np.asarray(candidate_composite, dtype=float)
        cand_metrics = list(candidate_metrics)

        if len(self) == 0:
            all_positions = cand_positions
            all_objectives = cand_objectives
            all_composite = cand_composite
            all_metrics = cand_metrics
        else:
            all_positions = np.concatenate([self.positions, cand_positions], axis=0)
            all_objectives = np.concatenate([self.objectives, cand_objectives], axis=0)
            all_composite = np.concatenate([self.composite_scores, cand_composite], axis=0)
            all_metrics = self.metrics + cand_metrics

        keep_idx = _deduplicate_candidates(all_objectives, all_composite)
        all_positions = all_positions[keep_idx]
        all_objectives = all_objectives[keep_idx]
        all_composite = all_composite[keep_idx]
        all_metrics = [all_metrics[i] for i in keep_idx]

        nd_mask = _nondominated_mask(all_objectives)
        nd_idx = np.where(nd_mask)[0]

        positions_nd = all_positions[nd_idx]
        objectives_nd = all_objectives[nd_idx]
        composite_nd = all_composite[nd_idx]
        metrics_nd = [all_metrics[i] for i in nd_idx]

        if objectives_nd.shape[0] > self.max_size:
            crowd = _crowding_distance(objectives_nd)
            order = np.argsort(-crowd, kind="stable")
            chosen = order[: self.max_size]
            chosen.sort()
            positions_nd = positions_nd[chosen]
            objectives_nd = objectives_nd[chosen]
            composite_nd = composite_nd[chosen]
            metrics_nd = [metrics_nd[i] for i in chosen]

        self.positions = positions_nd
        self.objectives = objectives_nd
        self.composite_scores = composite_nd
        self.metrics = metrics_nd

    def select_leaders(self, rng: np.random.Generator, num_leaders: int) -> np.ndarray:
        if len(self) == 0:
            raise ValueError("Archive is empty; cannot select leaders")

        crowd = _crowding_distance(self.objectives)
        finite = np.isfinite(crowd)
        if not np.any(finite):
            idx = rng.choice(len(self), size=num_leaders, replace=True)
            return self.positions[idx]

        inf_mask = np.isinf(crowd)
        if np.any(inf_mask):
            elite_idx = np.where(inf_mask)[0]
            idx = rng.choice(elite_idx, size=num_leaders, replace=True)
            return self.positions[idx]

        prob = np.maximum(crowd, 0.0) + 1e-12
        s = float(np.sum(prob))
        if s <= 0.0 or not np.isfinite(s):
            idx = rng.choice(len(self), size=num_leaders, replace=True)
            return self.positions[idx]
        prob = prob / s
        idx = rng.choice(len(self), size=num_leaders, replace=True, p=prob)
        return self.positions[idx]


def run_mopso_optimize(                                                #主优化循环
    config: Config,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    rng: np.random.Generator,                                        # 随机数生成器
    verbose: bool = True,
) -> MOPSOResult:
    """改进 MOPSO 主流程。

    对应论文结构（简化版）：
    - Step A: 维护 Pareto 档案
    - Step B: 计算停滞指标
    - Step C: 触发分级停滞响应
    - Step D: 依据档案领导者更新速度和位置
    """
    validate_proposed_sector_config(config, method_name="proposed_method")

    pso_cfg = config["pso"]
    mopso_cfg = config.get("mopso", {})

    num_particles = int(pso_cfg["numParticles"])
    max_iterations = int(pso_cfg["maxIterations"])
    num_base = int(pso_cfg["numBaseStations"])

    w = float(pso_cfg.get("w", 0.729))
    c1 = float(pso_cfg.get("c1", 1.49445))
    c2 = float(pso_cfg.get("c2", 1.49445))
    wdamp = float(pso_cfg.get("wdamp", 0.99))

    spatial_min_pos = np.asarray(pso_cfg["minPosition"], dtype=float)
    spatial_max_pos = np.asarray(pso_cfg["maxPosition"], dtype=float)
    encoding_spec = particle_encoding_spec(config, num_base)
    min_pos, max_pos = encoding_min_max(spatial_min_pos, spatial_max_pos, encoding_spec)

    archive_size = int(mopso_cfg.get("archiveSize", 80))
    archive = ParetoArchive(max_size=archive_size)
    stagnation_cfg = mopso_cfg.get("stagnation", {})

    station_plan = build_station_type_plan(config=config, num_base_stations=num_base)
    evaluation_station_plan = None if encoding_spec.enabled else station_plan

    positions, init_stats = _initialize_particles(
        config=config,
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        rng=rng,
        num_particles=num_particles,
        num_base=num_base,
        min_pos=spatial_min_pos,
        max_pos=spatial_max_pos,
    )
    positions = extend_particles_with_decisions(positions, config=config, rng=rng)
    positions = _enforce_deployment_constraints(
        positions=positions,
        city_map=city_map,
        min_pos=spatial_min_pos,
        max_pos=spatial_max_pos,
        config=config,
        rng=rng,
    )
    stage1_restart_sites = _prepare_stage1_restart_sites(
        config=config,
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        min_pos=spatial_min_pos,
        rng=rng,
    )

    vel_scale = (max_pos - min_pos) * 0.1
    velocities = (rng.random(positions.shape) - 0.5) * vel_scale[None, None, :]

    pbest_pos = positions.copy()
    pbest_obj = np.full((num_particles, 4), np.inf, dtype=float)
    pbest_comp = np.full((num_particles,), -np.inf, dtype=float)
    pbest_metrics: List[Dict[str, float]] = [
        {
            "objective_composite": -np.inf,
            "handover_count": float("inf"),
            "coverage_count": 0.0,
            "coverage_rate": 0.0,
            "existing_route_continuous_coverage_rate": 0.0,
            "future_route_continuous_coverage_rate": 0.0,
            "mean_snr_db": 0.0,
            "deployment_cost": float("inf"),
            "cost_effectiveness": 0.0,
            "capacity_effective": 0.0,
            "constraint_penalty": 0.0,
        }
        for _ in range(num_particles)
    ]

    convergence = np.zeros((max_iterations,), dtype=float)
    handover_hist = np.zeros((max_iterations,), dtype=float)
    coverage_hist = np.zeros((max_iterations,), dtype=float)
    existing_route_cont_hist = np.zeros((max_iterations,), dtype=float)
    future_route_cont_hist = np.zeros((max_iterations,), dtype=float)
    cost_hist = np.zeros((max_iterations,), dtype=float)
    diversity_hist = np.zeros((max_iterations,), dtype=float)
    archive_size_hist = np.zeros((max_iterations,), dtype=float)
    quasi_entropy_hist = np.zeros((max_iterations,), dtype=float)
    quasi_entropy_ratio_hist = np.zeros((max_iterations,), dtype=float)
    quasi_entropy_trigger_hist = np.zeros((max_iterations,), dtype=float)
    quasi_entropy_selected_count_hist = np.zeros((max_iterations,), dtype=float)
    quasi_entropy_replaced_count_hist = np.zeros((max_iterations,), dtype=float)
    global_best_change_hist = np.zeros((max_iterations,), dtype=float)
    nd_front_change_hist = np.zeros((max_iterations,), dtype=float)
    population_radius_hist = np.zeros((max_iterations,), dtype=float)
    pbest_improvement_rate_hist = np.zeros((max_iterations,), dtype=float)
    velocity_norm_hist = np.zeros((max_iterations,), dtype=float)
    leader_archive_diversity_hist = np.zeros((max_iterations,), dtype=float)
    objective_space_spread_hist = np.zeros((max_iterations,), dtype=float)
    stagnation_score_hist = np.zeros((max_iterations,), dtype=float)
    non_qe_factor_keys = _non_qe_stagnation_factor_keys(stagnation_cfg)
    factor_histories = {key: np.zeros((max_iterations,), dtype=float) for key in non_qe_factor_keys}
    weight_histories = {key: np.zeros((max_iterations,), dtype=float) for key in non_qe_factor_keys}

    prev_best_composite: Optional[float] = None
    prev_archive_objectives = np.zeros((0, 0), dtype=float)
    qe_initial: Optional[float] = None
    adaptive_weight_state = _init_adaptive_weight_state(stagnation_cfg)
    stagnation_logs: List[Dict[str, float | str]] = []
    stagnation_events: List[Dict[str, float | str]] = []
    trigger_stats = {
        "mild": 0.0,
        "moderate": 0.0,
        "severe": 0.0,
        "low_latency": 0.0,
        "high_stagnation": 0.0,
    }
    search_diag = _search_space_diagonal(min_pos=min_pos, max_pos=max_pos, num_base=num_base)

    for it in range(max_iterations):
        # 惯性权重递减，兼顾前期探索和后期收敛。
        w *= wdamp

        # 评估当前粒子群，并更新个体历史最优。
        batch = evaluate_population_objectives(
            positions=positions,
            test_points=test_points,
            city_map=city_map,
            channel_params=channel_params,
            config=config,
            station_plan=evaluation_station_plan,
        )
        curr_comp = np.asarray(batch.composite, dtype=float)
        curr_obj = _build_multi_objectives(
            handover_count=batch.handover_count,
            deployment_cost=batch.deployment_cost,
            existing_route_continuous_coverage_rate=batch.existing_route_continuous_coverage_rate,
            future_route_continuous_coverage_rate=batch.future_route_continuous_coverage_rate,
        )
        curr_metrics = [batch.at(i) for i in range(num_particles)]

        pbest_update_count = 0
        for i in range(num_particles):
            if _should_update_personal_best(
                current_obj=curr_obj[i],
                current_comp=float(curr_comp[i]),
                best_obj=pbest_obj[i],
                best_comp=float(pbest_comp[i]),                          
            ):
                pbest_obj[i] = curr_obj[i]
                pbest_comp[i] = float(curr_comp[i])                     # 更新个体最优适应度
                pbest_pos[i] = positions[i]
                pbest_metrics[i] = curr_metrics[i]
                pbest_update_count += 1

        # 更新全局 Pareto 档案（仅保留有效个体）。
        finite_mask = np.isfinite(pbest_obj).all(axis=1)               # 过滤无效解
        archive.update(
            candidate_positions=pbest_pos[finite_mask],                # 候选位置
            candidate_objectives=pbest_obj[finite_mask],               # 候选目标值
            candidate_composite=pbest_comp[finite_mask],               # 候选综合适应度
            candidate_metrics=[pbest_metrics[i] for i in np.where(finite_mask)[0]],
        )

        if len(archive) > 0:
            best_idx = int(np.argmax(archive.composite_scores))
            best_comp = float(archive.composite_scores[best_idx])
            best_metrics = archive.metrics[best_idx]
        else:
            best_idx = int(np.argmax(curr_comp))
            best_comp = float(curr_comp[best_idx])
            best_metrics = curr_metrics[best_idx]

        # 计算停滞监测指标（准熵、全局最优变化率、前沿变化率、种群半径）。
        # Paper mapping (Section III-C, Eq.15/16):
        #   Q_E^t = -sum_i P_i^t log(P_i^t),  P_i^t = U_i^t / sum_i U_i^t
        #   U_i^t uses selected particles' pbest fitness; selected by top-beta ranking.
        quasi_entropy, qe_meta = _compute_quasi_entropy_from_pbest(
            pbest_comp=pbest_comp,
            stagnation_cfg=stagnation_cfg,
        )
        if qe_initial is None:
            # Paper mapping (Section III-E, Eq.21): Q_E^0 from initial population.
            qe_initial = float(quasi_entropy)
        qe_theta = float(qe_meta["theta"])
        quasi_entropy_trigger = _is_quasi_entropy_triggered(
            qe_t=float(quasi_entropy),
            qe_0=float(qe_initial),
            theta=qe_theta,
        )
        quasi_entropy_ratio = float(quasi_entropy) / max(float(qe_initial), 1e-12)
        global_best_change_rate = _compute_global_best_change_rate(
            previous_best=prev_best_composite,
            current_best=best_comp,
        )
        nd_front_change_rate = _compute_nondominated_front_change_rate(
            previous_front=prev_archive_objectives,
            current_front=archive.objectives if len(archive) > 0 else np.zeros((0, 0), dtype=float),
        )
        population_radius = _compute_population_radius(positions=positions, search_diag=search_diag)
        pbest_improvement_rate = float(pbest_update_count) / float(max(num_particles, 1))
        velocity_norm = _compute_velocity_norm(velocities=velocities, search_diag=search_diag)
        leader_archive_diversity = _compute_objective_space_spread(
            archive.objectives if len(archive) > 0 else np.zeros((0, curr_obj.shape[1]), dtype=float)
        )
        objective_space_spread = _compute_objective_space_spread(curr_obj)

        convergence[it] = best_comp
        handover_hist[it] = float(best_metrics.get("handover_count", 0.0))
        coverage_hist[it] = float(best_metrics.get("coverage_rate", 0.0))
        existing_route_cont_hist[it] = float(best_metrics.get("existing_route_continuous_coverage_rate", 0.0))
        future_route_cont_hist[it] = float(best_metrics.get("future_route_continuous_coverage_rate", 0.0))
        cost_hist[it] = float(best_metrics.get("deployment_cost", 0.0))
        diversity_hist[it] = population_radius
        archive_size_hist[it] = float(len(archive))
        quasi_entropy_hist[it] = quasi_entropy
        quasi_entropy_ratio_hist[it] = quasi_entropy_ratio
        quasi_entropy_trigger_hist[it] = 1.0 if quasi_entropy_trigger else 0.0
        quasi_entropy_selected_count_hist[it] = float(qe_meta["selected_count"])
        quasi_entropy_replaced_count_hist[it] = float(qe_meta["replaced_non_positive_count"])
        global_best_change_hist[it] = global_best_change_rate
        nd_front_change_hist[it] = nd_front_change_rate
        population_radius_hist[it] = population_radius
        pbest_improvement_rate_hist[it] = pbest_improvement_rate
        velocity_norm_hist[it] = velocity_norm
        leader_archive_diversity_hist[it] = leader_archive_diversity
        objective_space_spread_hist[it] = objective_space_spread

        indicators = StagnationIndicators(                                              #停滞检测
            quasi_entropy=quasi_entropy,
            quasi_entropy_q0=float(qe_initial),
            quasi_entropy_theta=qe_theta,
            quasi_entropy_trigger=quasi_entropy_trigger,
            quasi_entropy_non_positive_replaced=int(qe_meta["replaced_non_positive_count"]),
            quasi_entropy_selected_count=int(qe_meta["selected_count"]),
            quasi_entropy_ratio=quasi_entropy_ratio,
            global_best_change_rate=global_best_change_rate,
            non_dominated_front_change_rate=nd_front_change_rate,
            population_radius=population_radius,
            pbest_improvement_rate=pbest_improvement_rate,
            velocity_norm=velocity_norm,
            leader_archive_diversity=leader_archive_diversity,
            objective_space_spread=objective_space_spread,
        )
        severity, activated_indicator_names, stagnation_score, stagnation_diag = _classify_stagnation_severity(
            indicators,
            stagnation_cfg,
            it,
            adaptive_weight_state,
        )
        stagnation_score_hist[it] = float(stagnation_score)
        for key in non_qe_factor_keys:
            factor_histories[key][it] = float(stagnation_diag.get("factors", {}).get(key, 0.0))
            weight_histories[key][it] = float(stagnation_diag.get("weights", {}).get(key, 0.0))

        strategies: Dict[str, float | bool | List[str]] = {
            "updated_w": float(w),
            "updated_c1": float(c1),
            "updated_c2": float(c2),
            "low_latency_response": False,
            "high_stagnation_response": False,
            "applied": [],
        }
        if severity != "none":
            # 停滞响应后再次做部署约束，确保道路禁放/建筑避让始终生效。
            trigger_stats[severity] += 1.0
            positions, velocities, strategies = _apply_stagnation_response(
                severity=severity,
                positions=positions,
                velocities=velocities,
                pbest_pos=pbest_pos,
                pbest_obj=pbest_obj,
                pbest_comp=pbest_comp,
                min_pos=min_pos,
                max_pos=max_pos,
                archive=archive,
                city_map=city_map,
                rng=rng,
                config=config,
                current_w=w,
                current_c1=c1,
                current_c2=c2,
                stage1_restart_sites=stage1_restart_sites,
                particle_scores=curr_comp,
            )
            positions = _enforce_deployment_constraints(
                positions=positions,
                city_map=city_map,
                min_pos=spatial_min_pos,
                max_pos=spatial_max_pos,
                config=config,
                rng=rng,
            )
            pbest_pos = repair_particle_encoding(pbest_pos, config=config)
            w = strategies.get("updated_w", w)
            c1 = strategies.get("updated_c1", c1)
            c2 = strategies.get("updated_c2", c2)

            if strategies.get("low_latency_response", False):
                trigger_stats["low_latency"] += 1.0
            if strategies.get("high_stagnation_response", False):
                trigger_stats["high_stagnation"] += 1.0

            if verbose:
                print(
                    "       - Stagnation detected: "
                    f"iter={it + 1}, level={severity}, "
                    f"score={stagnation_score:.3f}, "
                    f"indicators={','.join(activated_indicator_names)}, "
                    f"strategies={','.join(str(k) for k in strategies.get('applied', []))}"
                )

        log_entry = _build_stagnation_log_entry(
            iteration=it + 1,
            severity=severity,
            score=stagnation_score,
            indicators=indicators,
            diagnostics=stagnation_diag,
            triggered_indicator_names=activated_indicator_names,
            strategies=strategies,
        )
        stagnation_logs.append(log_entry)
        if severity != "none":
            stagnation_events.append(log_entry)

        prev_best_composite = float(best_comp)
        prev_archive_objectives = np.asarray(archive.objectives, dtype=float).copy()

        # 领导者来自 Pareto 档案；若档案为空则退化为个体最优引导。
        leaders = None
        if len(archive) > 0:
            leaders = archive.select_leaders(rng=rng, num_leaders=num_particles)
        else:
            leaders = pbest_pos

        r1 = rng.random(positions.shape)
        r2 = rng.random(positions.shape)
        cognitive = c1 * r1 * (pbest_pos - positions)
        social = c2 * r2 * (leaders - positions)
        velocities = w * velocities + cognitive + social

        vel_lim = (max_pos - min_pos) * float(mopso_cfg.get("velocityLimitRatio", 0.2))
        velocities = np.clip(velocities, -vel_lim[None, None, :], vel_lim[None, None, :])

        # 速度-位置更新后统一约束修复（边界、建筑、道路禁放）。
        positions = positions + velocities
        positions = np.clip(positions, min_pos[None, None, :], max_pos[None, None, :])
        positions = repair_particle_encoding(positions, config=config)
        positions = _enforce_deployment_constraints(
            positions=positions,
            city_map=city_map,
            min_pos=spatial_min_pos,
            max_pos=spatial_max_pos,
            config=config,
            rng=rng,
        )

        if verbose and ((it + 1) % 10 == 0 or it == max_iterations - 1):
            print(
                "       - MOPSO Iteration "
                f"{it + 1}/{max_iterations}, "
                f"archive={len(archive)}, best_composite={best_comp:.3f}, "
                f"coverage={coverage_hist[it] * 100.0:.2f}%, radius={population_radius:.3f}"
            )

    if len(archive) == 0:
        fallback_idx = int(np.argmax(pbest_comp))
        pareto_positions = pbest_pos[fallback_idx : fallback_idx + 1]
        pareto_objectives = pbest_obj[fallback_idx : fallback_idx + 1]
        pareto_scores = pbest_comp[fallback_idx : fallback_idx + 1]
        pareto_metrics = [pbest_metrics[fallback_idx]]
    else:
        pareto_positions = archive.positions
        pareto_objectives = archive.objectives
        pareto_scores = archive.composite_scores
        pareto_metrics = archive.metrics

    best_idx = int(np.argmax(pareto_scores))
    best_position = pareto_positions[best_idx]
    best_fitness = float(pareto_scores[best_idx])
    best_obj = dict(pareto_metrics[best_idx])
    best_station_plan = (
        build_station_type_plan_from_particle(config, best_position)
        if is_extended_particle_array(best_position)
        else station_plan
    )
    best_decoded_solution = decode_particle_solution(best_position, config)
    pareto_decoded_solutions = [decode_particle_solution(p, config) for p in pareto_positions]

    objective_history = {
        "best_composite": convergence,
        "best_handover_count": handover_hist,
        "best_coverage_rate": coverage_hist,
        "best_existing_route_continuous_coverage_rate": existing_route_cont_hist,
        "best_future_route_continuous_coverage_rate": future_route_cont_hist,
        "best_deployment_cost": cost_hist,
        "population_radius": diversity_hist,
        "archive_size": archive_size_hist,
        "quasi_entropy": quasi_entropy_hist,
        "quasi_entropy_ratio": quasi_entropy_ratio_hist,
        "quasi_entropy_trigger": quasi_entropy_trigger_hist,
        "quasi_entropy_selected_count": quasi_entropy_selected_count_hist,
        "quasi_entropy_replaced_non_positive": quasi_entropy_replaced_count_hist,
        "global_best_change_rate": global_best_change_hist,
        "non_dominated_front_change_rate": nd_front_change_hist,
        "stagnation_score": stagnation_score_hist,
        "pbest_improvement_rate": pbest_improvement_rate_hist,
        "velocity_norm": velocity_norm_hist,
        "leader_archive_diversity": leader_archive_diversity_hist,
        "objective_space_spread": objective_space_spread_hist,
        # Legacy compatibility alias
        "diversity_ratio": diversity_hist,
    }
    for key in non_qe_factor_keys:
        objective_history[f"stagnation_factor_{key}"] = factor_histories[key]
        objective_history[f"stagnation_weight_{key}"] = weight_histories[key]

    convergence_iteration = int(np.argmax(convergence) + 1)

    return MOPSOResult(
        best_position=best_position,
        best_fitness=best_fitness,
        convergence_history=convergence,
        convergence_iteration=convergence_iteration,
        iteration=max_iterations,
        best_objectives=best_obj,
        objective_history=objective_history,
        pareto_positions=pareto_positions,
        pareto_objectives=pareto_objectives,
        pareto_composite_scores=pareto_scores,
        pareto_metrics=pareto_metrics,
        diversity_history=diversity_hist,
        archive_size_history=archive_size_hist,
        velocity_norm_history=velocity_norm_hist,
        stagnation_logs=stagnation_logs,
        stagnation_events=stagnation_events,
        trigger_stats=trigger_stats,
        init_stats=init_stats,
        station_type_indices=best_station_plan.station_type_indices,
        station_type_names=best_station_plan.station_type_names,
        station_sector_azimuths_deg=station_sector_azimuth_list(best_position, config),
        best_decoded_solution=best_decoded_solution,
        pareto_decoded_solutions=pareto_decoded_solutions,
    )


def run_improved_mopso_scaffold(                                    #主算法
    config: Config,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    rng: np.random.Generator,
    verbose: bool = True,
) -> Tuple[PSOResult, Dict[str, float]]:
    """Compatibility wrapper: run proposed MOPSO and return PSOResult-style output."""
    cfg = _clone_config(config)
    cfg.setdefault("initialization", {})
    cfg["initialization"]["mode"] = "two_stage"
    cfg.setdefault("mopso", {})
    cfg["mopso"]["enabled"] = True
    cfg["mopso"].setdefault("stagnation", {})
    cfg["mopso"]["stagnation"]["enabled"] = True

    if verbose:
        print("       - Proposed method: stage-1/stage-2 initialization + stagnation-aware MOPSO")

    mopso_res = run_mopso_optimize(
        config=cfg,
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        rng=rng,
        verbose=verbose,
    )
    pso_res = _as_pso_result(mopso_res)

    meta: Dict[str, float] = {
        "mopso_pareto_size": float(mopso_res.pareto_positions.shape[0]),
        "mopso_trigger_mild": float(mopso_res.trigger_stats.get("mild", 0.0)),
        "mopso_trigger_moderate": float(mopso_res.trigger_stats.get("moderate", 0.0)),
        "mopso_trigger_severe": float(mopso_res.trigger_stats.get("severe", 0.0)),
    }
    meta.update(mopso_res.init_stats)
    return pso_res, meta


def _build_multi_objectives(
    handover_count: np.ndarray,
    deployment_cost: np.ndarray,
    existing_route_continuous_coverage_rate: np.ndarray,
    future_route_continuous_coverage_rate: np.ndarray,
) -> np.ndarray:                                                           #多目标建立
    """Build minimization objectives for Pareto dominance.

    Objective 1 (min): UAV handover count with strongest-link association
    Objective 2 (min): deployment cost
    Objective 3 (min): existing-route continuity coverage loss
    Objective 4 (min): future-route continuity coverage loss
    """
    handover = np.asarray(handover_count, dtype=float)
    cost = np.asarray(deployment_cost, dtype=float)
    existing_loss = 1.0 - np.asarray(existing_route_continuous_coverage_rate, dtype=float)
    future_loss = 1.0 - np.asarray(future_route_continuous_coverage_rate, dtype=float)
    return np.column_stack([handover, cost, existing_loss, future_loss])


def _should_update_personal_best(                                 #个体最佳更新
    current_obj: np.ndarray,
    current_comp: float,
    best_obj: np.ndarray,
    best_comp: float,
) -> bool:
    if not np.isfinite(best_obj).all():
        return True
    if _dominates(current_obj, best_obj):
        return True
    if _dominates(best_obj, current_obj):
        return False
    # Tie-break for non-dominated relation.
    return bool(current_comp > best_comp)


def _classify_stagnation_severity(
    indicators: StagnationIndicators,
    stagnation_cfg: Config,
    iteration_idx: int,
    adaptive_state: Optional[AdaptiveWeightState] = None,
) -> Tuple[str, List[str], float, Dict[str, Dict[str, float] | float | str]]:
    """Classify stagnation with QE-gated non-QE adaptive weighting.

    Design mapping:
    - QE is a gate / phase-transition indicator only.
    - The QE gate is exactly Q_E^t <= theta * Q_E^0.
    - After the gate opens, normalized non-QE factors are combined with either
      fixed or adaptive weights.
    """
    if not bool(stagnation_cfg.get("enabled", True)):
        return "none", [], 0.0, _empty_stagnation_diag(stagnation_cfg)

    mode = str(stagnation_cfg.get("detectionMode", "qe_gate_adaptive")).strip().lower()
    if mode in {"legacy", "legacy_weighted", "weighted_qe"}:
        mode = "legacy_weighted_qe"
    if mode in {"fixed", "qe_gate_fixed_weights"}:
        mode = "qe_gate_fixed"
    if mode in {"adaptive", "qe_gate_adaptive_weights"}:
        mode = "qe_gate_adaptive"

    min_iter = int(stagnation_cfg.get("minIterationsBeforeCheck", 5))
    if iteration_idx + 1 < min_iter:
        factors = _build_non_qe_stagnation_factors(indicators, stagnation_cfg)
        if mode == "legacy_weighted_qe":
            factors = {"quasiEntropy": 1.0 if indicators.quasi_entropy_trigger else 0.0, **factors}
            weights = {"quasiEntropy": float(stagnation_cfg.get("weights", {}).get("quasiEntropy", 1.0))}
            weights.update(_fixed_non_qe_weights(stagnation_cfg, factors.keys()))
        elif mode == "qe_gate_adaptive":
            adaptive_state = adaptive_state if adaptive_state is not None else _init_adaptive_weight_state(stagnation_cfg)
            weights = {k: float(adaptive_state.weights.get(k, 1.0)) for k in factors.keys()}
        else:
            weights = _fixed_non_qe_weights(stagnation_cfg, factors.keys())
        score = _weighted_stagnation_score(factors, weights)
        active = [_metric_key_to_label(k) for k, v in factors.items() if float(v) > 1e-9]
        return "none", active, score, _build_stagnation_diag(mode, bool(indicators.quasi_entropy_trigger), factors, weights)

    if mode == "legacy_weighted_qe":
        severity, active, score = _classify_legacy_weighted_qe(indicators, stagnation_cfg)
        factors = _build_non_qe_stagnation_factors(indicators, stagnation_cfg)
        weights = _fixed_non_qe_weights(stagnation_cfg, factors.keys())
        factors = {"quasiEntropy": 1.0 if indicators.quasi_entropy_trigger else 0.0, **factors}
        weights = {"quasiEntropy": float(stagnation_cfg.get("weights", {}).get("quasiEntropy", 1.0)), **weights}
        return severity, active, score, _build_stagnation_diag(mode, indicators.quasi_entropy_trigger, factors, weights)

    non_qe_factors = _build_non_qe_stagnation_factors(indicators, stagnation_cfg)
    adaptive_state = adaptive_state if adaptive_state is not None else _init_adaptive_weight_state(stagnation_cfg)
    if mode == "qe_gate_adaptive":
        weights = _update_adaptive_stagnation_weights(
            factors=non_qe_factors,
            stagnation_cfg=stagnation_cfg,
            iteration_idx=iteration_idx,
            state=adaptive_state,
        )
    else:
        weights = _fixed_non_qe_weights(stagnation_cfg, non_qe_factors.keys())

    score = _weighted_stagnation_score(non_qe_factors, weights)
    score_thresholds = stagnation_cfg.get("scoreThresholds", {})
    mild_score_th = float(score_thresholds.get("mild", 0.25))
    moderate_score_th = float(score_thresholds.get("moderate", 0.40))
    severe_score_th = float(score_thresholds.get("severe", 0.60))
    ordered = sorted([mild_score_th, moderate_score_th, severe_score_th])
    mild_score_th, moderate_score_th, severe_score_th = ordered[0], ordered[1], ordered[2]

    active_names = [_metric_key_to_label(k) for k, v in non_qe_factors.items() if float(v) > 1e-9]
    qe_gate_active = bool(indicators.quasi_entropy_trigger)
    diag = _build_stagnation_diag(mode, qe_gate_active, non_qe_factors, weights)

    if not qe_gate_active:
        policy = str(stagnation_cfg.get("beforeGatePolicy", "none")).strip().lower()
        if policy == "mild" and score >= mild_score_th:
            return "mild", active_names, score, diag
        return "none", active_names, score, diag

    if score >= severe_score_th:
        return "severe", active_names, score, diag
    if score >= moderate_score_th:
        return "moderate", active_names, score, diag
    if score >= mild_score_th:
        return "mild", active_names, score, diag
    return "none", active_names, score, diag


def _classify_legacy_weighted_qe(
    indicators: StagnationIndicators,
    stagnation_cfg: Config,
) -> Tuple[str, List[str], float]:
    """Previous behavior: QE trigger participates as an ordinary weighted factor."""
    thresholds = stagnation_cfg.get("thresholds", {})
    score_thresholds = stagnation_cfg.get("scoreThresholds", {})
    weights_cfg = stagnation_cfg.get("weights", {})
    default_thresholds = {
        "globalBestChangeRate": {"mild": 0.020, "severe": 0.004},
        "nonDominatedFrontChangeRate": {"mild": 0.25, "severe": 0.08},
        "populationRadius": {"mild": 0.22, "severe": 0.08},
    }

    def _th(metric_key: str, level: str) -> float:
        if metric_key in thresholds and isinstance(thresholds.get(metric_key), dict):
            return float(thresholds[metric_key].get(level, default_thresholds[metric_key][level]))
        return float(default_thresholds[metric_key][level])

    # QE 分量严格按论文 Section III-E Eq.(21) 触发，不再用区间阈值映射。
    # trigger: Q_E^t <= theta * Q_E^0
    components: Dict[str, float] = {
        "quasiEntropy": 1.0 if indicators.quasi_entropy_trigger else 0.0,
        "globalBestChangeRate": _stagnation_component(
            value=float(indicators.global_best_change_rate),
            mild_th=_th("globalBestChangeRate", "mild"),
            severe_th=_th("globalBestChangeRate", "severe"),
        ),
        "nonDominatedFrontChangeRate": _stagnation_component(
            value=float(indicators.non_dominated_front_change_rate),
            mild_th=_th("nonDominatedFrontChangeRate", "mild"),
            severe_th=_th("nonDominatedFrontChangeRate", "severe"),
        ),
        "populationRadius": _stagnation_component(
            value=float(indicators.population_radius),
            mild_th=_th("populationRadius", "mild"),
            severe_th=_th("populationRadius", "severe"),
        ),
    }

    default_weights = {
        "quasiEntropy": 1.0,
        "globalBestChangeRate": 1.0,
        "nonDominatedFrontChangeRate": 1.0,
        "populationRadius": 1.0,
    }
    raw_weights: Dict[str, float] = {}
    for key, default_w in default_weights.items():
        raw_weights[key] = float(max(weights_cfg.get(key, default_w), 0.0))
    sum_w = float(sum(raw_weights.values()))
    if sum_w <= 1e-12:
        raw_weights = {k: 1.0 for k in default_weights.keys()}
        sum_w = float(len(default_weights))

    score = 0.0
    for key, comp in components.items():
        score += raw_weights[key] * comp
    score = float(score / sum_w)

    mild_score_th = float(score_thresholds.get("mild", 0.25))
    severe_score_th = float(score_thresholds.get("severe", 0.50))
    if severe_score_th < mild_score_th:
        severe_score_th, mild_score_th = mild_score_th, severe_score_th

    # 触发指标用于日志解释：列出对分数有贡献的指标。
    active_names: List[str] = []
    for key in ["quasiEntropy", "globalBestChangeRate", "nonDominatedFrontChangeRate", "populationRadius"]:
        if components[key] > 1e-9:
            active_names.append(_metric_key_to_label(key))

    if score >= severe_score_th:
        return "severe", active_names, score
    if score >= mild_score_th:
        return "mild", active_names, score
    return "none", active_names, score


def _non_qe_stagnation_factor_keys(stagnation_cfg: Config) -> List[str]:
    """Ordered non-QE stagnation factors used after the QE gate opens."""
    factor_cfg = stagnation_cfg.get("nonQeFactors", {})
    keys = [
        "globalBestStall",
        "archiveStall",
        "pbestStall",
        "swarmDiversityLoss",
        "velocityDecay",
        "leaderArchiveDiversityLoss",
    ]
    if bool(factor_cfg.get("enableObjectiveSpaceSpread", True)):
        keys.append("objectiveSpaceSpreadLoss")
    return keys


def _init_adaptive_weight_state(stagnation_cfg: Config) -> AdaptiveWeightState:
    keys = _non_qe_stagnation_factor_keys(stagnation_cfg)
    base = _fixed_non_qe_weights(stagnation_cfg, keys)
    return AdaptiveWeightState(
        weights={k: float(base.get(k, 1.0)) for k in keys},
        smoothed_signal={k: 0.0 for k in keys},
        last_update_iteration=-1,
    )


def _build_non_qe_stagnation_factors(
    indicators: StagnationIndicators,
    stagnation_cfg: Config,
) -> Dict[str, float]:
    """Normalize all non-QE stagnation factors to [0, 1]."""
    thresholds = stagnation_cfg.get("thresholds", {})
    defaults = {
        "globalBestChangeRate": {"mild": 0.020, "severe": 0.004},
        "archiveImprovementRate": {"mild": 0.25, "severe": 0.08},
        "pbestImprovementRate": {"mild": 0.12, "severe": 0.02},
        "populationRadius": {"mild": 0.22, "severe": 0.08},
        "velocityNorm": {"mild": 0.035, "severe": 0.008},
        "leaderArchiveDiversity": {"mild": 0.20, "severe": 0.05},
        "objectiveSpaceSpread": {"mild": 0.20, "severe": 0.05},
    }

    def th(metric_key: str, level: str) -> float:
        fallback = defaults[metric_key][level]
        # Backward-compatible alias: archive improvement used to be named front change.
        cfg_key = metric_key
        if metric_key == "archiveImprovementRate" and metric_key not in thresholds:
            cfg_key = "nonDominatedFrontChangeRate"
        if cfg_key in thresholds and isinstance(thresholds.get(cfg_key), dict):
            return float(thresholds[cfg_key].get(level, fallback))
        return float(fallback)

    factors = {
        "globalBestStall": _stagnation_component(
            indicators.global_best_change_rate,
            th("globalBestChangeRate", "mild"),
            th("globalBestChangeRate", "severe"),
        ),
        "archiveStall": _stagnation_component(
            indicators.non_dominated_front_change_rate,
            th("archiveImprovementRate", "mild"),
            th("archiveImprovementRate", "severe"),
        ),
        "pbestStall": _stagnation_component(
            indicators.pbest_improvement_rate,
            th("pbestImprovementRate", "mild"),
            th("pbestImprovementRate", "severe"),
        ),
        "swarmDiversityLoss": _stagnation_component(
            indicators.population_radius,
            th("populationRadius", "mild"),
            th("populationRadius", "severe"),
        ),
        "velocityDecay": _stagnation_component(
            indicators.velocity_norm,
            th("velocityNorm", "mild"),
            th("velocityNorm", "severe"),
        ),
        "leaderArchiveDiversityLoss": _stagnation_component(
            indicators.leader_archive_diversity,
            th("leaderArchiveDiversity", "mild"),
            th("leaderArchiveDiversity", "severe"),
        ),
    }
    if bool(stagnation_cfg.get("nonQeFactors", {}).get("enableObjectiveSpaceSpread", True)):
        factors["objectiveSpaceSpreadLoss"] = _stagnation_component(
            indicators.objective_space_spread,
            th("objectiveSpaceSpread", "mild"),
            th("objectiveSpaceSpread", "severe"),
        )
    return {k: float(np.clip(v, 0.0, 1.0)) for k, v in factors.items()}


def _fixed_non_qe_weights(stagnation_cfg: Config, keys: Sequence[str]) -> Dict[str, float]:
    weight_cfg = stagnation_cfg.get("weights", {})
    adaptive_cfg = stagnation_cfg.get("adaptiveWeights", {})
    base_cfg = adaptive_cfg.get("baseWeights", {})
    defaults = {
        "globalBestStall": 1.0,
        "archiveStall": float(weight_cfg.get("nonDominatedFrontChangeRate", 1.0)),
        "pbestStall": 1.0,
        "swarmDiversityLoss": float(weight_cfg.get("populationRadius", 1.0)),
        "velocityDecay": 1.0,
        "leaderArchiveDiversityLoss": 1.0,
        "objectiveSpaceSpreadLoss": 0.8,
    }
    defaults["globalBestStall"] = float(weight_cfg.get("globalBestChangeRate", defaults["globalBestStall"]))
    return {k: float(max(base_cfg.get(k, defaults.get(k, 1.0)), 0.0)) for k in keys}


def _update_adaptive_stagnation_weights(
    factors: Dict[str, float],
    stagnation_cfg: Config,
    iteration_idx: int,
    state: AdaptiveWeightState,
) -> Dict[str, float]:
    """Update non-QE weights from recent normalized factor signal strength.

    Formula:
        s_k^t in [0,1] is the normalized stagnation factor.
        r_k^t = alpha*s_k^t + (1-alpha)*r_k^(t-1)
        w_k^t = clip(base_k * (w_min + (w_max-w_min)*r_k^t), w_min, w_max)
    Missing/non-finite factors are treated as unreliable and receive w_min.
    """
    cfg = stagnation_cfg.get("adaptiveWeights", {})
    min_w = float(cfg.get("minWeight", 0.4))
    max_w = float(cfg.get("maxWeight", 2.2))
    if max_w < min_w:
        max_w, min_w = min_w, max_w
    alpha = float(np.clip(cfg.get("smoothingFactor", 0.35), 0.0, 1.0))
    interval = int(max(1, cfg.get("updateInterval", 1)))
    base = _fixed_non_qe_weights(stagnation_cfg, factors.keys())

    if state.last_update_iteration >= 0 and (iteration_idx - state.last_update_iteration) < interval:
        return {k: float(state.weights.get(k, base.get(k, 1.0))) for k in factors.keys()}

    for key, value in factors.items():
        v = float(value)
        if not np.isfinite(v):
            state.smoothed_signal[key] = 0.0
            state.weights[key] = min_w
            continue
        signal = float(np.clip(v, 0.0, 1.0))
        prev = float(state.smoothed_signal.get(key, signal))
        smooth = alpha * signal + (1.0 - alpha) * prev
        state.smoothed_signal[key] = float(np.clip(smooth, 0.0, 1.0))
        target = float(base.get(key, 1.0)) * (min_w + (max_w - min_w) * state.smoothed_signal[key])
        state.weights[key] = float(np.clip(target, min_w, max_w))
    state.last_update_iteration = int(iteration_idx)
    return {k: float(state.weights.get(k, base.get(k, 1.0))) for k in factors.keys()}


def _weighted_stagnation_score(factors: Dict[str, float], weights: Dict[str, float]) -> float:
    denom = 0.0
    numer = 0.0
    for key, factor in factors.items():
        w = float(max(weights.get(key, 0.0), 0.0))
        f = float(np.clip(factor, 0.0, 1.0))
        denom += w
        numer += w * f
    if denom <= 1e-12:
        return 0.0
    return float(np.clip(numer / denom, 0.0, 1.0))


def _empty_stagnation_diag(stagnation_cfg: Config) -> Dict[str, Dict[str, float] | float | str]:
    return _build_stagnation_diag(
        mode=str(stagnation_cfg.get("detectionMode", "qe_gate_adaptive")),
        qe_gate_active=False,
        factors={},
        weights={},
    )


def _build_stagnation_diag(
    mode: str,
    qe_gate_active: bool,
    factors: Dict[str, float],
    weights: Dict[str, float],
) -> Dict[str, Dict[str, float] | float | str]:
    return {
        "mode": str(mode),
        "qe_gate_active": 1.0 if qe_gate_active else 0.0,
        "factors": {k: float(v) for k, v in factors.items()},
        "weights": {k: float(v) for k, v in weights.items()},
    }


def _stagnation_component(value: float, mild_th: float, severe_th: float) -> float:
    """将单指标数值映射为停滞强度分量（0=不滞，1=重滞）。"""
    v = float(value)
    mild = float(mild_th)
    severe = float(severe_th)

    # 本项目四个指标都是“越小越停滞”，若阈值顺序异常则自动校正。
    if severe > mild:
        severe, mild = mild, severe

    if v <= severe:
        return 1.0
    if v >= mild:
        return 0.0
    span = max(mild - severe, 1e-12)
    return float((mild - v) / span)


def _metric_key_to_label(metric_key: str) -> str:
    mapping = {
        "quasiEntropy": "quasi_entropy_triggered",
        "globalBestChangeRate": "global_best_change_low",
        "nonDominatedFrontChangeRate": "non_dominated_front_change_low",
        "populationRadius": "population_radius_low",
        "globalBestStall": "global_best_stall",
        "archiveStall": "archive_stall",
        "pbestStall": "pbest_stall",
        "swarmDiversityLoss": "swarm_diversity_loss",
        "velocityDecay": "velocity_decay",
        "leaderArchiveDiversityLoss": "leader_archive_diversity_loss",
        "objectiveSpaceSpreadLoss": "objective_space_spread_loss",
    }
    return str(mapping.get(metric_key, metric_key))


def _apply_stagnation_response(
    severity: str,
    positions: np.ndarray,
    velocities: np.ndarray,
    pbest_pos: np.ndarray,
    pbest_obj: np.ndarray,
    pbest_comp: np.ndarray,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    archive: ParetoArchive,
    city_map: CityMap,
    rng: np.random.Generator,
    config: Config,
    current_w: float,
    current_c1: float,
    current_c2: float,
    stage1_restart_sites: np.ndarray,
    particle_scores: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, float | bool | List[str]]]:
    strategies: Dict[str, float | bool | List[str]] = {
        "updated_w": float(current_w),
        "updated_c1": float(current_c1),
        "updated_c2": float(current_c2),
        "low_latency_response": False,
        "high_stagnation_response": False,
        "applied": [],
    }

    s_cfg = config.get("mopso", {}).get("stagnation", {})
    resp_cfg = s_cfg.get("responses", {})

    low_cfg = resp_cfg.get("lowLatency", {})
    moderate_cfg = resp_cfg.get("moderate", {})
    high_cfg = resp_cfg.get("highStagnation", {})

    # Backward compatibility: map old mild/moderate/severe config keys to new strategy groups.
    if not low_cfg and severity == "mild":
        low_cfg = dict(resp_cfg.get("mild", {}))
    if not high_cfg:
        high_cfg = dict(resp_cfg.get("severe", {}))

    if severity == "mild" and bool(low_cfg.get("enabled", True)):
        positions, velocities, low_strategies = apply_low_latency_response(
            positions=positions,
            velocities=velocities,
            response_cfg=low_cfg,
            current_w=current_w,
            current_c1=current_c1,
            current_c2=current_c2,
        )
        strategies.update(low_strategies)
        return positions, velocities, strategies

    if severity == "moderate":
        cfg = moderate_cfg if moderate_cfg else low_cfg
        if bool(cfg.get("enabled", True)):
            positions, velocities, moderate_strategies = apply_low_latency_response(
                positions=positions,
                velocities=velocities,
                response_cfg=cfg,
                current_w=current_w,
                current_c1=current_c1,
                current_c2=current_c2,
            )
            strategies.update(moderate_strategies)
            strategies.setdefault("applied", [])
            if "moderate_low_latency_response" not in strategies["applied"]:
                strategies["applied"].append("moderate_low_latency_response")
            return positions, velocities, strategies

    if severity == "severe" and bool(high_cfg.get("enabled", True)):
        positions, velocities, high_strategies = apply_high_stagnation_response(
            positions=positions,
            velocities=velocities,
            pbest_pos=pbest_pos,
            pbest_obj=pbest_obj,
            pbest_comp=pbest_comp,
            min_pos=min_pos,
            max_pos=max_pos,
            archive=archive,
            city_map=city_map,
            rng=rng,
            response_cfg=high_cfg,
            stage1_restart_sites=stage1_restart_sites,
            particle_scores=particle_scores,
        )
        strategies.update(high_strategies)
        return positions, velocities, strategies

    return positions, velocities, strategies


def _search_space_diagonal(min_pos: np.ndarray, max_pos: np.ndarray, num_base: int) -> float:
    span = np.maximum(np.asarray(max_pos, dtype=float) - np.asarray(min_pos, dtype=float), 1e-9)
    tiled = np.tile(span, int(max(num_base, 1)))
    return float(max(np.linalg.norm(tiled), 1e-9))


def _compute_population_radius(positions: np.ndarray, search_diag: float) -> float:
    if positions.shape[0] <= 1:
        return 0.0
    flat = positions.reshape(positions.shape[0], -1)
    center = np.mean(flat, axis=0)
    radius = np.mean(np.linalg.norm(flat - center[None, :], axis=1))
    return float(radius / max(search_diag, 1e-9))


def _compute_velocity_norm(velocities: np.ndarray, search_diag: float) -> float:
    """Mean normalized velocity norm; low values indicate velocity decay."""
    if velocities.size == 0:
        return 0.0
    flat = np.asarray(velocities, dtype=float).reshape(velocities.shape[0], -1)
    return float(np.mean(np.linalg.norm(flat, axis=1)) / max(search_diag, 1e-9))


def _compute_objective_space_spread(objectives: np.ndarray) -> float:
    """Normalized objective-space spread in [0, ~0.5] for archive/current front diversity."""
    obj = np.asarray(objectives, dtype=float)
    if obj.size == 0 or obj.ndim != 2 or obj.shape[0] <= 1:
        return 0.0
    finite = obj[np.isfinite(obj).all(axis=1)]
    if finite.shape[0] <= 1:
        return 0.0
    lo = np.min(finite, axis=0)
    hi = np.max(finite, axis=0)
    span = np.maximum(hi - lo, 1e-12)
    norm = (finite - lo[None, :]) / span[None, :]
    return float(np.mean(np.std(norm, axis=0)))


def _build_stagnation_log_entry(
    iteration: int,
    severity: str,
    score: float,
    indicators: StagnationIndicators,
    diagnostics: Dict[str, Dict[str, float] | float | str],
    triggered_indicator_names: Sequence[str],
    strategies: Dict[str, float | bool | List[str]],
) -> Dict[str, float | str]:
    """Build one per-iteration stagnation log row."""
    factors = diagnostics.get("factors", {})
    weights = diagnostics.get("weights", {})
    if not isinstance(factors, dict):
        factors = {}
    if not isinstance(weights, dict):
        weights = {}

    row: Dict[str, float | str] = {
        "iteration": float(iteration),
        "severity": severity,
        "stagnation_level": severity,
        "stagnation_score": float(score),
        "detection_mode": str(diagnostics.get("mode", "")),
        "quasi_entropy": float(indicators.quasi_entropy),
        "quasi_entropy_q0": float(indicators.quasi_entropy_q0),
        "quasi_entropy_theta": float(indicators.quasi_entropy_theta),
        "quasi_entropy_ratio": float(indicators.quasi_entropy_ratio),
        "quasi_entropy_gate_active": "1" if indicators.quasi_entropy_trigger else "0",
        "quasi_entropy_trigger": "1" if indicators.quasi_entropy_trigger else "0",
        "quasi_entropy_selected_count": float(indicators.quasi_entropy_selected_count),
        "quasi_entropy_replaced_non_positive": float(indicators.quasi_entropy_non_positive_replaced),
        "global_best_change_rate": float(indicators.global_best_change_rate),
        "non_dominated_front_change_rate": float(indicators.non_dominated_front_change_rate),
        "population_radius": float(indicators.population_radius),
        "pbest_improvement_rate": float(indicators.pbest_improvement_rate),
        "velocity_norm": float(indicators.velocity_norm),
        "leader_archive_diversity": float(indicators.leader_archive_diversity),
        "objective_space_spread": float(indicators.objective_space_spread),
        "trigger_indicators": ",".join(str(x) for x in triggered_indicator_names),
        "strategies": ",".join(str(k) for k in strategies.get("applied", [])),
    }
    for key, value in factors.items():
        row[f"factor_{key}"] = float(value)
    for key, value in weights.items():
        row[f"weight_{key}"] = float(value)
    return row


def _compute_quasi_entropy_from_pbest(pbest_comp: np.ndarray, stagnation_cfg: Config) -> Tuple[float, Dict[str, float]]:
    """Compute paper-style quasi-entropy from selected pbest fitness values.

    Paper mapping:
    - Section III-C / Eq.(15): Q_E^t = -sum_i P_i^t * log(P_i^t)
    - Section III-C / Eq.(16): P_i^t = U_i^t / sum_i U_i^t
    - U_i^t uses selected particles' pbest fitness, where selected set is top-beta.
    """
    values = np.asarray(pbest_comp, dtype=float).reshape(-1)
    num_particles = int(values.size)

    qe_cfg = stagnation_cfg.get("quasiEntropyAdaptive", {})
    beta = float(np.clip(qe_cfg.get("beta", 1.0 / 3.0), 0.0, 1.0))
    theta = float(qe_cfg.get("theta", 0.7))
    eps = float(max(qe_cfg.get("nonPositiveEps", 1e-12), 1e-18))

    if num_particles <= 0:
        return 0.0, {
            "beta": beta,
            "theta": theta,
            "selected_count": 0.0,
            "replaced_non_positive_count": 0.0,
            "eps": eps,
        }

    # Top-beta selection by pbest fitness ranking (higher composite is better in this codebase).
    # If beta=0 is configured, keep at least one particle to avoid an empty selected set.
    selected_count = int(np.ceil(beta * num_particles))
    selected_count = int(np.clip(selected_count, 1, num_particles))
    order = np.argsort(-values, kind="stable")
    selected = np.asarray(values[order[:selected_count]], dtype=float)

    # Engineering-compatibility patch agreed by user:
    # Eq.(16) requires positive U_i^t for valid probability/log terms.
    # For selected U_i^t <= 0 (or non-finite), replace with a very small positive epsilon.
    invalid = ~(np.isfinite(selected) & (selected > 0.0))
    replaced_non_positive_count = int(np.sum(invalid))
    if replaced_non_positive_count > 0:
        selected = selected.copy()
        selected[invalid] = eps

    # Eq.(16): P_i^t = U_i^t / sum U_i^t
    u_sum = float(np.sum(selected))
    if u_sum <= 0.0:
        # Defensive fallback; should not happen after epsilon replacement.
        probs = np.full((selected_count,), 1.0 / float(max(selected_count, 1)), dtype=float)
    else:
        probs = selected / u_sum

    # Eq.(15): Q_E^t = -sum_i P_i^t * log(P_i^t)
    qe_t = -float(np.sum(probs * np.log(probs)))
    return qe_t, {
        "beta": float(beta),
        "theta": float(theta),
        "selected_count": float(selected_count),
        "replaced_non_positive_count": float(replaced_non_positive_count),
        "eps": float(eps),
    }


def _is_quasi_entropy_triggered(qe_t: float, qe_0: float, theta: float) -> bool:
    """Paper Section III-E Eq.(21): trigger if Q_E^t <= theta * Q_E^0."""
    lhs = float(qe_t)
    rhs = float(theta) * float(qe_0)
    return bool(lhs <= rhs)


def _compute_global_best_change_rate(previous_best: Optional[float], current_best: float) -> float:
    if previous_best is None:
        return 1.0
    denom = max(abs(float(previous_best)), 1e-9)
    return float(abs(float(current_best) - float(previous_best)) / denom)


def _compute_nondominated_front_change_rate(previous_front: np.ndarray, current_front: np.ndarray) -> float:
    prev = np.asarray(previous_front, dtype=float)
    curr = np.asarray(current_front, dtype=float)

    if prev.size == 0 and curr.size == 0:
        return 0.0
    if prev.size == 0 or curr.size == 0:
        return 1.0

    prev_set = {tuple(row.tolist()) for row in np.round(prev, decimals=6)}
    curr_set = {tuple(row.tolist()) for row in np.round(curr, decimals=6)}

    union = prev_set | curr_set
    if not union:
        return 0.0
    intersection = prev_set & curr_set
    return float(1.0 - len(intersection) / len(union))


def _enforce_deployment_constraints(
    positions: np.ndarray,
    city_map: CityMap,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    config: Config,
    rng: np.random.Generator,
) -> np.ndarray:
    """统一部署约束：建筑避让 +（可选）道路中心线禁放。"""
    corrected = enforce_non_building_constraint(positions, city_map, min_pos, max_pos, rng)
    corrected = repair_particle_encoding(corrected, config=config)
    if not _is_road_center_avoidance_enabled(config=config, city_map=city_map):
        return corrected

    spatial_min = np.asarray(min_pos, dtype=float).reshape(-1)[:3]
    spatial_max = np.asarray(max_pos, dtype=float).reshape(-1)[:3]
    stage1_cfg = config.get("stage1", {})
    for i in range(corrected.shape[0]):
        for b in range(corrected.shape[1]):
            x, y, z = corrected[i, b, :3]
            x, y, z = _snap_point_off_road_centerline(
                x=float(x),
                y=float(y),
                z=float(z),
                city_map=city_map,
                min_pos=spatial_min,
                max_pos=spatial_max,
                stage1_cfg=stage1_cfg,
                rng=rng,
            )
            corrected[i, b, :3] = [x, y, z]
    corrected = enforce_non_building_constraint(corrected, city_map, min_pos, max_pos, rng)
    return repair_particle_encoding(corrected, config=config)


def _is_road_center_avoidance_enabled(config: Config, city_map: CityMap) -> bool:
    """判断当前场景是否启用道路中心线禁放。"""
    if city_map.road_segments is None:
        return False
    segs = np.asarray(city_map.road_segments, dtype=float)
    if segs.size == 0:
        return False
    stage1_cfg = config.get("stage1", {})
    return bool(stage1_cfg.get("avoidRoadCenter", True))


def _snap_point_off_road_centerline(
    x: float,
    y: float,
    z: float,
    city_map: CityMap,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    stage1_cfg: Config,
    rng: np.random.Generator,
) -> Tuple[float, float, float]:
    """将落在道路禁放区的点位移动到最近可行区域。"""
    clearance = float(stage1_cfg.get("roadCenterClearanceM", 12.0))
    if clearance <= 0.0:
        return x, y, z

    d = _distance_to_nearest_road_centerline(x=x, y=y, road_segments=city_map.road_segments)
    if not np.isfinite(d) or d > clearance:
        return x, y, z

    max_radius = float(stage1_cfg.get("roadSnapMaxRadiusM", max(80.0, clearance * 8.0)))
    step = float(stage1_cfg.get("roadSnapStepM", max(3.0, clearance * 0.5)))
    num_angles = int(max(8, stage1_cfg.get("roadSnapAngles", 24)))

    radii = np.arange(step, max_radius + 1e-9, step, dtype=float)
    for r in radii:
        best_xy: Optional[Tuple[float, float]] = None
        best_d = -np.inf
        for k in range(num_angles):
            theta = 2.0 * np.pi * float(k) / float(num_angles)
            cx = float(np.clip(x + r * np.cos(theta), min_pos[0], max_pos[0]))
            cy = float(np.clip(y + r * np.sin(theta), min_pos[1], max_pos[1]))
            cd = _distance_to_nearest_road_centerline(x=cx, y=cy, road_segments=city_map.road_segments)
            if not np.isfinite(cd) or cd <= clearance:
                continue
            if cd > best_d:
                best_d = cd
                best_xy = (cx, cy)
        if best_xy is not None:
            return best_xy[0], best_xy[1], float(np.clip(z, min_pos[2], max_pos[2]))

    # 回退策略：随机局部搜索，尽量找到合法位置。
    for _ in range(80):
        rr = float(rng.uniform(step, max_radius))
        theta = float(rng.uniform(0.0, 2.0 * np.pi))
        cx = float(np.clip(x + rr * np.cos(theta), min_pos[0], max_pos[0]))
        cy = float(np.clip(y + rr * np.sin(theta), min_pos[1], max_pos[1]))
        cd = _distance_to_nearest_road_centerline(x=cx, y=cy, road_segments=city_map.road_segments)
        if np.isfinite(cd) and cd > clearance:
            return cx, cy, float(np.clip(z, min_pos[2], max_pos[2]))

    return x, y, z


def _distance_to_nearest_road_centerline(x: float, y: float, road_segments: Optional[np.ndarray]) -> float:
    """计算二维点到道路中心线段集合的最短距离。"""
    if road_segments is None:
        return float("inf")
    segs = np.asarray(road_segments, dtype=float)
    if segs.size == 0 or segs.ndim != 3 or segs.shape[1:] != (2, 2):
        return float("inf")

    p = np.asarray([x, y], dtype=float)
    p0 = segs[:, 0, :]
    p1 = segs[:, 1, :]
    v = p1 - p0
    vv = np.sum(v * v, axis=1)
    valid = vv > 1e-12
    if not np.any(valid):
        return float("inf")

    w = p[None, :] - p0
    t = np.zeros_like(vv)
    t[valid] = np.clip(np.sum(w[valid] * v[valid], axis=1) / vv[valid], 0.0, 1.0)
    proj = p0 + t[:, None] * v
    dist = np.linalg.norm(proj - p[None, :], axis=1)
    return float(np.min(dist))


def _deduplicate_candidates(objectives: np.ndarray, composite: np.ndarray) -> List[int]:
    keys = np.round(objectives, decimals=8)
    best_by_key: Dict[Tuple[float, ...], int] = {}
    for i in range(keys.shape[0]):
        k = tuple(float(v) for v in keys[i])
        prev = best_by_key.get(k)
        if prev is None or float(composite[i]) > float(composite[prev]):
            best_by_key[k] = i
    idx = sorted(best_by_key.values())
    return idx


def _nondominated_mask(objectives: np.ndarray) -> np.ndarray:
    n = objectives.shape[0]
    mask = np.ones((n,), dtype=bool)
    for i in range(n):
        if not mask[i]:
            continue
        for j in range(n):
            if i == j or not mask[j]:
                continue
            if _dominates(objectives[j], objectives[i]):
                mask[i] = False
                break
    return mask


def _dominates(a: np.ndarray, b: np.ndarray) -> bool:
    return bool(np.all(a <= b) and np.any(a < b))


def _crowding_distance(objectives: np.ndarray) -> np.ndarray:
    n = objectives.shape[0]
    if n == 0:
        return np.zeros((0,), dtype=float)
    if n <= 2:
        return np.full((n,), 1e9, dtype=float)

    m = objectives.shape[1]
    dist = np.zeros((n,), dtype=float)
    for k in range(m):
        order = np.argsort(objectives[:, k], kind="stable")
        vals = objectives[order, k]
        dist[order[0]] = np.inf
        dist[order[-1]] = np.inf

        span = vals[-1] - vals[0]
        if span <= 1e-12:
            continue
        for i in range(1, n - 1):
            dist[order[i]] += (vals[i + 1] - vals[i - 1]) / span
    return dist


def _as_pso_result(mopso_res: MOPSOResult) -> PSOResult:
    evaluation_stats = {
        "mopso_pareto_size": float(mopso_res.pareto_positions.shape[0]),
        "mopso_trigger_stats": mopso_res.trigger_stats,
        "mopso_stagnation_logs": mopso_res.stagnation_logs,
        "mopso_stagnation_events": mopso_res.stagnation_events,
    }

    return PSOResult(
        best_position=mopso_res.best_position,
        best_fitness=float(mopso_res.best_fitness),
        convergence_history=mopso_res.convergence_history,
        iteration=int(mopso_res.iteration),
        convergence_iteration=int(mopso_res.convergence_iteration),
        best_objectives=mopso_res.best_objectives,
        objective_history=mopso_res.objective_history,
        station_type_indices=mopso_res.station_type_indices,
        station_type_names=mopso_res.station_type_names,
        station_sector_azimuths_deg=mopso_res.station_sector_azimuths_deg,
        decoded_solution=mopso_res.best_decoded_solution,
        pareto_positions=np.asarray(mopso_res.pareto_positions, dtype=float),
        pareto_objectives=np.asarray(mopso_res.pareto_objectives, dtype=float),
        pareto_composite_scores=np.asarray(mopso_res.pareto_composite_scores, dtype=float),
        pareto_metrics=[dict(m) for m in mopso_res.pareto_metrics],
        pareto_decoded_solutions=[[dict(station) for station in rows] for rows in mopso_res.pareto_decoded_solutions],
        init_stats=mopso_res.init_stats,
        evaluation_stats=evaluation_stats,
    )


def _initialize_particles(
    config: Config,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    rng: np.random.Generator,
    num_particles: int,
    num_base: int,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
) -> tuple[np.ndarray, Dict[str, float]]:
    init_cfg = config.get("initialization", {})
    init_mode = str(init_cfg.get("mode", "kmeans")).lower().strip()

    if init_mode == "random":
        pos = rng.uniform(low=min_pos, high=max_pos, size=(num_particles, num_base, 3))
        pos = enforce_non_building_constraint(pos, city_map, min_pos, max_pos, rng)
        return pos, {
            "init_mode": 0.0,
            "init_random_particles": float(num_particles),
            "init_seeded_particles": 0.0,
        }

    if init_mode == "kmeans":
        pos = kmeans_initialize_particles(test_points, num_particles, config, city_map, rng)
        pos = enforce_non_building_constraint(pos, city_map, min_pos, max_pos, rng)
        ratio = float(np.clip(config.get("kmeans", {}).get("kmeansInitRatio", 0.0), 0.0, 1.0))
        return pos, {
            "init_mode": 1.0,
            "init_random_particles": float(num_particles * (1.0 - ratio)),
            "init_seeded_particles": float(num_particles * ratio),
        }

    if init_mode == "two_stage":
        existing = _load_existing_stations(config=config, default_z=float(min_pos[2]))
        stage1 = deploy_stage1_blind_spots(
            test_points=test_points,
            existing_stations=existing,
            config=config,
            city_map=city_map,
            channel_params=channel_params,
            rng=rng,
        )
        stage2 = build_stage2_seeded_particles(
            stage1_sites=stage1_added_sites_array(stage1),
            existing_stations=existing,
            num_particles=num_particles,
            num_base_stations=num_base,
            min_position=min_pos,
            max_position=max_pos,
            config=config,
            rng=rng,
            city_map=city_map,
            stage1_station_records=stage1.added_station_records,
        )
        stats = {"init_mode": 2.0}
        stats.update(stage1.stats)
        stats.update(stage2.stats)
        return stage2.particles, stats

    raise ValueError(f"Unsupported initialization.mode: {init_mode}")


def _prepare_stage1_restart_sites(
    config: Config,
    test_points: np.ndarray,
    city_map: CityMap,
    channel_params: Config,
    min_pos: np.ndarray,
    rng: np.random.Generator,
) -> np.ndarray:
    """Prepare stage-1 deployment seeds for severe-stagnation restart."""
    stage1_cfg = config.get("stage1", {})
    if not bool(stage1_cfg.get("enabled", False)):
        return np.zeros((0, 3), dtype=float)

    num_new = int(stage1_cfg.get("numNewStations", stage1_cfg.get("numAdditions", 0)))
    if num_new <= 0:
        return np.zeros((0, 3), dtype=float)

    existing = _load_existing_stations(config=config, default_z=float(min_pos[2]))
    stage1 = deploy_stage1_blind_spots(
        test_points=test_points,
        existing_stations=existing,
        config=config,
        city_map=city_map,
        channel_params=channel_params,
        rng=rng,
    )
    restart_sites = stage1_added_sites_array(stage1)
    if restart_sites.size == 0:
        return np.zeros((0, 3), dtype=float)
    return np.asarray(restart_sites, dtype=float)


def _load_existing_stations(config: Config, default_z: float) -> np.ndarray:
    raw = config.get("heterogeneousDeployment", {}).get("existingStations", [])
    arr = np.asarray(raw, dtype=float)
    if arr.size == 0:
        return np.zeros((0, 3), dtype=float)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    if arr.shape[1] == 2:
        z = np.full((arr.shape[0], 1), default_z, dtype=float)
        arr = np.hstack([arr, z])
    if arr.shape[1] < 3:
        raise ValueError("heterogeneousDeployment.existingStations must contain [x,y,z] or [x,y]")
    return arr[:, :3]


def _clone_config(config: Config) -> Config:
    import json

    return json.loads(json.dumps(config))
