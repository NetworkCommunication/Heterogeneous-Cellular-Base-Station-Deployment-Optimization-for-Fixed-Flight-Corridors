﻿from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import numpy as np

from src.data.types import Config


@dataclass
class StationTypeSpec:
    """Configurable heterogeneous station type parameters.

    Notes:
    - The fields below are parameterized abstractions for early-stage research.
    - They are placeholders and can be replaced by engineering-calibrated models.
    """

    name: str
    ratio: float
    tx_power_offset_db: float
    deployment_cost: float
    # Placeholder abstraction: positive value loosely means wider effective coverage.
    coverage_boost_db: float
    # Placeholder abstraction: additional path-loss bias for this type.
    path_loss_offset_db: float
    # Placeholder abstraction: multiplier on NLOS extra loss term.
    nlos_penalty_factor: float
    # Placeholder abstraction: capacity units for objective balancing.
    capacity_units: float


def parse_station_types(config: Config) -> List[StationTypeSpec]:
    """Parse station type specs from config."""
    raw = config.get("heterogeneousDeployment", {}).get("stationTypes", [])
    specs: List[StationTypeSpec] = []
    for item in raw:
        specs.append(
            StationTypeSpec(
                name=str(item.get("name", "unknown")),
                ratio=float(item.get("ratio", 0.0)),
                tx_power_offset_db=float(item.get("txPowerOffsetDb", 0.0)),
                deployment_cost=float(item.get("deploymentCost", 1.0)),
                coverage_boost_db=float(item.get("coverageBoostDb", 0.0)),
                path_loss_offset_db=float(item.get("pathLossOffsetDb", 0.0)),
                nlos_penalty_factor=float(item.get("nlosPenaltyFactor", 1.0)),
                capacity_units=float(item.get("capacityUnits", 1.0)),
            )
        )
    return specs


def assign_station_type_indices(num_base_stations: int, specs: List[StationTypeSpec]) -> np.ndarray:
    """Assign station-type indices for each base-station slot by ratio."""
    if num_base_stations <= 0 or not specs:
        return np.zeros((0,), dtype=int)

    ratios = np.array([max(s.ratio, 0.0) for s in specs], dtype=float)
    if float(ratios.sum()) <= 0.0:
        ratios = np.ones_like(ratios)
    ratios = ratios / ratios.sum()

    counts = np.floor(ratios * num_base_stations).astype(int)
    while counts.sum() < num_base_stations:
        counts[int(np.argmax(ratios - counts / max(num_base_stations, 1)))] += 1

    assigned: List[int] = []
    for idx, c in enumerate(counts.tolist()):
        assigned.extend([idx] * c)
    return np.asarray(assigned[:num_base_stations], dtype=int)


def count_station_types(type_names: List[str]) -> Dict[str, int]:
    """Count station occurrences by type name."""
    out: Dict[str, int] = {}
    for n in type_names:
        key = str(n)
        out[key] = out.get(key, 0) + 1
    return out
