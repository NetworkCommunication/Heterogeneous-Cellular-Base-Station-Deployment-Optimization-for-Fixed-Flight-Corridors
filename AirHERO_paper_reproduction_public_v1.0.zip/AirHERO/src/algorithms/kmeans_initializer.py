﻿from __future__ import annotations

import numpy as np

from src.algorithms.init_strategies import kmeans_init
from src.data.types import CityMap, Config


def kmeans_initialize_particles(
    test_points: np.ndarray,
    num_particles: int,
    config: Config,
    city_map: CityMap,
    rng: np.random.Generator,
) -> np.ndarray:
    """Generate particle initialization using KMeans-guided strategy."""
    return kmeans_init(
        test_points=test_points,
        num_particles=num_particles,
        config=config,
        city_map=city_map,
        rng=rng,
    )
