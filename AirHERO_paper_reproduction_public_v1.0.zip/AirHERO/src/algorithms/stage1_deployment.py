﻿from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np

from src.algorithms.heterogeneous_deployment import assign_station_type_indices, parse_station_types
from src.algorithms.init_strategies import ensure_non_building
from src.data.types import CityMap, Config
from src.propagation.low_fidelity import compute_point_snr
from src.propagation.sector_geometry import (
    DEFAULT_SECTOR_DIRECTIONS_DEG,
    inside_sector_mask,
    nearest_supported_sector_direction_deg,
    sector_geometry_config_from_mapping,
)

try:
    from sklearn.cluster import KMeans
except Exception:  # pragma: no cover
    KMeans = None


STAGE1_BLIND_FILLING_SOURCE = "stage1_blind_filling"
STAGE1_SECTOR_SCORE_COUNT = "count_based"
STAGE1_SECTOR_SCORE_DEMAND = "demand_weighted"
STAGE1_SECTOR_SCORE_QOS_DEFICIT = "qos_deficit_weighted"
STAGE1_SECTOR_TIE_SMALLER_INDEX = "smaller_index"
STAGE1_5GA_DIRECTION_STRATEGY_ENUMERATE_BEST = "enumerate_best"
STAGE1_5GA_DIRECTION_STRATEGY_DEMAND_WEIGHTED_BEST = "demand_weighted_best"
STAGE1_5GA_DIRECTION_STRATEGY_SCORE = "score"
STAGE1_5GA_DIRECTION_STRATEGY_RANDOM = "random"


@dataclass
class Stage1BlindSpotResult:
    """阶段一输出：新增站点、盲点集合与统计信息。

    `added_sites` is kept as a coordinate-only compatibility view. New code
    should prefer `added_station_records`, which also stores station type and
    5GA sector metadata.
    """

    added_sites: np.ndarray
    blind_spot_points: np.ndarray
    stats: Dict[str, float]
    added_station_records: Optional[List[Dict[str, Any]]] = None

    def __post_init__(self) -> None:
        if self.added_station_records is None:
            self.added_station_records = build_stage1_station_records_from_sites(
                added_sites=self.added_sites,
                blind_spot_points=self.blind_spot_points,
                config={},
            )
        validate_stage1_station_records(self.added_station_records)
        self.added_sites = stage1_station_records_to_array(self.added_station_records)


def deploy_stage1_blind_spots(
    test_points: np.ndarray,
    existing_stations: Optional[np.ndarray],
    config: Config,
    city_map: CityMap,
    channel_params: Config,
    rng: np.random.Generator,
) -> Stage1BlindSpotResult:
    """阶段一盲点补站流程。

    算法顺序：
    1. 先基于现有站点评估盲点；
    2. 若启用升级策略，先尝试升级现有设备缩减盲点；
    3. 仍存在盲点时，再用 KMeans/随机方式生成新增站点。
    """
    stage1_cfg = config.get("stage1", {})
    num_new = int(stage1_cfg.get("numNewStations", stage1_cfg.get("numAdditions", 0)))
    if num_new <= 0 or test_points.size == 0:
        return Stage1BlindSpotResult(
            added_sites=np.zeros((0, 3), dtype=float),
            blind_spot_points=np.zeros((0, 3), dtype=float),
            stats={
                "stage1_num_existing": 0.0,
                "stage1_num_blind_points": 0.0,
                "stage1_blind_ratio": 0.0,
                "stage1_num_added": 0.0,
                "stage1_upgrade_enabled": 0.0,
                "stage1_num_upgraded": 0.0,
                "stage1_blind_points_before_upgrade": 0.0,
                "stage1_blind_points_after_upgrade": 0.0,
                "stage1_upgrade_improvement_ratio": 0.0,
            },
        )

    existing = _normalize_existing_stations(existing_stations)
    snr_threshold = float(channel_params.get("snrThreshold", 0.0))

    if existing.size == 0:
        blind_points = test_points.copy()
        blind_ratio = 1.0
        upgrade_stats = _build_upgrade_stats(
            enabled=False,
            num_upgraded=0,
            blind_before=blind_points.shape[0],
            blind_after=blind_points.shape[0],
        )
    else:
        sector_params = _build_existing_station_sector_params(config=config, num_existing=existing.shape[0])
        snr_existing = compute_point_snr(
            best_position=existing,
            test_points=test_points,
            city_map=city_map,
            channel_params=channel_params,
            **sector_params,
        )
        blind_mask = snr_existing < snr_threshold
        blind_points = test_points[blind_mask]
        blind_ratio = float(np.mean(blind_mask.astype(float)))

        if blind_points.size == 0:
            weakest_idx = np.argsort(snr_existing)[: min(max(num_new * 3, 1), snr_existing.size)]
            blind_points = test_points[weakest_idx]

        blind_points, upgrade_stats = _apply_upgrade_first(
            test_points=test_points,
            blind_points=blind_points,
            existing_stations=existing,
            snr_threshold=snr_threshold,
            config=config,
            city_map=city_map,
            channel_params=channel_params,
        )

    added_sites = _select_added_sites_from_blind_points(
        blind_points=blind_points,
        num_new=num_new,
        city_map=city_map,
        config=config,
        rng=rng,
    )
    added_station_records = build_stage1_station_records_from_sites(
        added_sites=added_sites,
        blind_spot_points=blind_points,
        config=config,
        rng=rng,
    )

    stats = {
        "stage1_num_existing": float(existing.shape[0]),
        "stage1_num_blind_points": float(blind_points.shape[0]),
        "stage1_blind_ratio": float(blind_ratio),
        "stage1_num_added": float(added_sites.shape[0]),
    }
    stats.update(upgrade_stats)
    return Stage1BlindSpotResult(
        added_sites=added_sites,
        blind_spot_points=blind_points,
        stats=stats,
        added_station_records=added_station_records,
    )


def _normalize_existing_stations(existing_stations: Optional[np.ndarray]) -> np.ndarray:
    if existing_stations is None:
        return np.zeros((0, 3), dtype=float)
    arr = np.asarray(existing_stations, dtype=float)
    if arr.size == 0:
        return np.zeros((0, 3), dtype=float)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    if arr.shape[1] < 3:
        raise ValueError("existing_stations must have 3 columns [x,y,z]")
    return arr[:, :3]


def _select_added_sites_from_blind_points(
    blind_points: np.ndarray,
    num_new: int,
    city_map: CityMap,
    config: Config,
    rng: np.random.Generator,
) -> np.ndarray:
    if blind_points.size == 0:
        return np.zeros((0, 3), dtype=float)

    pso_cfg = config.get("pso", {})
    min_pos = np.asarray(pso_cfg.get("minPosition", [0.0, 0.0, 10.0]), dtype=float)
    max_pos = np.asarray(
        pso_cfg.get("maxPosition", [city_map.size_x, city_map.size_y, max(city_map.size_z, 45.0)]), dtype=float
    )
    stage1_cfg = config.get("stage1", {})
    use_kmeans = bool(stage1_cfg.get("useKMeansForBlindSpots", True))

    k = int(min(num_new, blind_points.shape[0]))
    if k <= 0:
        return np.zeros((0, 3), dtype=float)

    if use_kmeans and KMeans is not None and blind_points.shape[0] >= k:
        km = KMeans(n_clusters=k, n_init=10, max_iter=120, random_state=42)
        km.fit(blind_points)
        seeds = km.cluster_centers_
    else:
        idx = rng.choice(blind_points.shape[0], size=k, replace=False)
        seeds = blind_points[idx]

    # 统一约束：边界合法 + 非建筑内部 + 道路中心线禁放。
    out = np.zeros((k, 3), dtype=float)
    for i in range(k):
        x = float(np.clip(seeds[i, 0], 0.0, city_map.size_x))
        y = float(np.clip(seeds[i, 1], 0.0, city_map.size_y))
        z = float(np.clip(seeds[i, 2], min_pos[2], max_pos[2]))
        x, y, z = ensure_non_building(x, y, z, city_map, min_pos, max_pos, rng)
        x, y, z = _snap_point_off_road_centerline(x, y, z, city_map, min_pos, max_pos, stage1_cfg, rng)
        x, y, z = ensure_non_building(x, y, z, city_map, min_pos, max_pos, rng)
        out[i] = [x, y, z]
    return out


def build_stage1_station_records_from_sites(
    added_sites: np.ndarray,
    blind_spot_points: np.ndarray,
    config: Config,
    rng: Optional[np.random.Generator] = None,
) -> List[Dict[str, Any]]:
    """Build typed Stage-1 station records from coordinate-only added sites."""
    sites = _normalize_added_sites_array(added_sites)
    if sites.shape[0] == 0:
        return []

    type_indices, type_names = _assign_stage1_station_types(sites.shape[0], config)
    sector_cfg = sector_geometry_config_from_mapping(config)
    records: List[Dict[str, Any]] = []
    for i, site in enumerate(sites):
        station_type = str(type_names[i])
        is_5ga = station_type.strip().lower() == "5ga"
        sector_idx: Optional[int] = None
        sector_azimuth: Optional[float] = None
        sector_scores: Optional[List[Dict[str, float]]] = None
        sector_covered_count: Optional[int] = None
        sector_score_mode: Optional[str] = None
        if is_5ga:
            sector_choice = choose_stage1_5ga_sector_direction(
                site=site,
                blind_spot_points=blind_spot_points,
                sector_beamwidth_deg=sector_cfg.sector_beamwidth_deg,
                config=config,
                rng=rng,
            )
            sector_idx = int(sector_choice["sector_direction_index"])
            sector_azimuth = float(sector_choice["sector_azimuth_deg"])
            sector_scores = list(sector_choice["direction_scores"])
            sector_covered_count = int(sector_choice["covered_blind_points"])
            sector_score_mode = str(sector_choice["score_mode"])

        records.append(
            {
                "station_id": int(i + 1),
                "x": float(site[0]),
                "y": float(site[1]),
                "z": float(site[2]),
                "station_type": station_type,
                "station_type_index": int(type_indices[i]),
                "sector_direction_index": sector_idx,
                "sector_azimuth_deg": sector_azimuth,
                "stage1_sector_score_mode": sector_score_mode,
                "stage1_sector_scores": sector_scores,
                "stage1_selected_sector_score": (
                    None if sector_scores is None or sector_idx is None else float(sector_scores[sector_idx]["score"])
                ),
                "stage1_selected_sector_covered_blind_points": sector_covered_count,
                "source": STAGE1_BLIND_FILLING_SOURCE,
            }
        )

    validate_stage1_station_records(records)
    return records


def stage1_station_records_to_array(records: Sequence[Mapping[str, Any]]) -> np.ndarray:
    """Return the coordinate compatibility view for Stage-1 station records."""
    if not records:
        return np.zeros((0, 3), dtype=float)
    out = np.zeros((len(records), 3), dtype=float)
    for i, record in enumerate(records):
        out[i] = [float(record["x"]), float(record["y"]), float(record.get("z", record.get("height", 0.0)))]
    return out


def stage1_added_sites_array(stage1_output: object) -> np.ndarray:
    """Convert Stage-1 output, records, or legacy arrays to an Nx3 coordinate array."""
    if isinstance(stage1_output, Stage1BlindSpotResult):
        if stage1_output.added_station_records is not None:
            return stage1_station_records_to_array(stage1_output.added_station_records)
        return _normalize_added_sites_array(stage1_output.added_sites)
    if isinstance(stage1_output, Sequence) and not isinstance(stage1_output, np.ndarray):
        if not stage1_output:
            return np.zeros((0, 3), dtype=float)
        first = stage1_output[0]
        if isinstance(first, Mapping):
            return stage1_station_records_to_array(stage1_output)  # type: ignore[arg-type]
    return _normalize_added_sites_array(np.asarray(stage1_output, dtype=float))


def validate_stage1_station_records(records: Sequence[Mapping[str, Any]]) -> None:
    """Validate Stage-1 typed station records.

    A 5GA station is invalid unless both `sector_direction_index` and
    `sector_azimuth_deg` are present. A 5G station must keep
    `sector_azimuth_deg` empty/None.
    """
    for record in records:
        for key in ["station_id", "x", "y", "station_type", "source"]:
            if key not in record:
                raise ValueError(f"Stage-1 station record missing required field: {key}")
        z_value = record.get("z", record.get("height"))
        if z_value is None:
            raise ValueError("Stage-1 station record missing required field: z")
        coords = np.asarray([record["x"], record["y"], z_value], dtype=float)
        if not np.isfinite(coords).all():
            raise ValueError("Stage-1 station coordinates must be finite")
        station_type = str(record["station_type"]).strip()
        if station_type not in {"5G", "5GA"}:
            raise ValueError("Stage-1 station_type must be '5G' or '5GA'")
        if str(record["source"]) != STAGE1_BLIND_FILLING_SOURCE:
            raise ValueError(f"Stage-1 station source must be {STAGE1_BLIND_FILLING_SOURCE!r}")

        sector_idx = record.get("sector_direction_index")
        sector_azimuth = record.get("sector_azimuth_deg")
        if station_type == "5GA":
            if sector_idx is None or sector_idx == "":
                raise ValueError("Stage-1 5GA station requires sector_direction_index")
            if sector_azimuth is None or sector_azimuth == "":
                raise ValueError("Stage-1 5GA station requires sector_azimuth_deg")
            if not np.isfinite(float(sector_azimuth)):
                raise ValueError("Stage-1 5GA sector_azimuth_deg must be finite")
            if int(sector_idx) < 0 or int(sector_idx) >= DEFAULT_SECTOR_DIRECTIONS_DEG.size:
                raise ValueError("Stage-1 5GA sector_direction_index must reference the eight allowed directions")
            expected_az = float(DEFAULT_SECTOR_DIRECTIONS_DEG[int(sector_idx)])
            if not np.isclose(float(sector_azimuth), expected_az, atol=1e-9, rtol=0.0):
                raise ValueError("Stage-1 5GA sector_azimuth_deg must match sector_direction_index")
        elif sector_azimuth not in (None, ""):
            raise ValueError("Stage-1 5G station must have sector_azimuth_deg=None")


def save_stage1_added_stations_csv(records: Sequence[Mapping[str, Any]], output_path: str | Path) -> Path:
    """Save typed Stage-1 added-station records to CSV with sector fields."""
    validate_stage1_station_records(records)
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "station_id",
        "x",
        "y",
        "z",
        "station_type",
        "station_type_index",
        "sector_direction_index",
        "sector_azimuth_deg",
        "stage1_sector_score_mode",
        "stage1_selected_sector_score",
        "stage1_selected_sector_covered_blind_points",
        "stage1_sector_scores",
        "source",
    ]
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for record in records:
            row = {key: record.get(key, "") for key in fieldnames}
            for key in fieldnames:
                if row[key] is None:
                    row[key] = ""
            if isinstance(row.get("stage1_sector_scores"), list):
                row["stage1_sector_scores"] = json.dumps(row["stage1_sector_scores"], ensure_ascii=False)
            writer.writerow(row)
    return path


def save_stage1_result_csv(result: Stage1BlindSpotResult, output_path: str | Path) -> Path:
    """Save a Stage-1 result object's typed added-station records to CSV."""
    return save_stage1_added_stations_csv(result.added_station_records or [], output_path)


def save_stage1_sector_visualization(
    result: Stage1BlindSpotResult,
    output_path: str | Path,
    config: Optional[Config] = None,
    city_map: Optional[CityMap] = None,
) -> Path:
    """Save a Stage-1 blind-spot sector selection plot.

    The plot shows blind-spot points, added Stage-1 stations, and the selected
    5GA sector wedge for each typed 5GA addition.
    """
    import os

    mpl_cache = Path(".mplcache").resolve()
    mpl_cache.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(mpl_cache))

    import matplotlib.pyplot as plt
    from matplotlib.patches import Wedge

    cfg = config or {}
    channel_cfg = sector_geometry_config_from_mapping(cfg)
    vis_cfg = cfg.get("visualization", {}) if isinstance(cfg, Mapping) else {}
    radius = float(vis_cfg.get("stage1SectorDisplayRadiusM", vis_cfg.get("sectorDisplayRadiusM", 120.0)))
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(7.2, 5.8))
    blind = np.asarray(result.blind_spot_points, dtype=float)
    if blind.size > 0:
        if blind.ndim == 1:
            blind = blind.reshape(1, -1)
        ax.scatter(blind[:, 0], blind[:, 1], s=24, c="#D95F02", alpha=0.70, label="blind spots")

    records = result.added_station_records or []
    first_5g = True
    first_5ga = True
    first_wedge = True
    for record in records:
        x = float(record["x"])
        y = float(record["y"])
        station_type = str(record["station_type"])
        is_5ga = station_type == "5GA"
        if is_5ga:
            ax.scatter(
                [x],
                [y],
                marker="^",
                s=100,
                c="#1B9E77",
                edgecolors="black",
                label="Stage-1 5GA" if first_5ga else None,
                zorder=4,
            )
            first_5ga = False
            azimuth = float(record["sector_azimuth_deg"])
            half_width = float(channel_cfg.sector_beamwidth_deg) * 0.5
            center_math_deg = 90.0 - azimuth
            wedge = Wedge(
                center=(x, y),
                r=radius,
                theta1=center_math_deg - half_width,
                theta2=center_math_deg + half_width,
                facecolor="#1B9E77",
                edgecolor="#006D2C",
                alpha=0.22,
                linewidth=1.1,
                label="selected 5GA sector" if first_wedge else None,
                zorder=2,
            )
            ax.add_patch(wedge)
            first_wedge = False
        else:
            ax.scatter(
                [x],
                [y],
                marker="^",
                s=90,
                c="#2166AC",
                edgecolors="black",
                label="Stage-1 5G" if first_5g else None,
                zorder=4,
            )
            first_5g = False

    if city_map is not None:
        ax.set_xlim(0.0, float(city_map.size_x))
        ax.set_ylim(0.0, float(city_map.size_y))
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_title("Stage-1 5GA Sector Selection")
    ax.grid(alpha=0.22)
    ax.legend(frameon=False, loc="best")
    fig.tight_layout()
    fig.savefig(output, dpi=180)
    plt.close(fig)
    return output


def _normalize_added_sites_array(added_sites: np.ndarray) -> np.ndarray:
    arr = np.asarray(added_sites, dtype=float)
    if arr.size == 0:
        return np.zeros((0, 3), dtype=float)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    if arr.shape[1] < 3:
        raise ValueError("Stage-1 added_sites must contain [x,y,z]")
    return arr[:, :3].copy()


def _assign_stage1_station_types(num_added: int, config: Config) -> Tuple[np.ndarray, List[str]]:
    if num_added <= 0:
        return np.zeros((0,), dtype=int), []

    specs = parse_station_types(config)
    stage1_cfg = config.get("stage1", {})
    forced_type = stage1_cfg.get("newStationType", stage1_cfg.get("defaultNewStationType"))
    if forced_type is not None:
        forced_name = str(forced_type).strip()
        if forced_name not in {"5G", "5GA"}:
            raise ValueError("stage1.defaultNewStationType must be '5G' or '5GA'")
        names = [forced_name] * num_added
        if specs:
            lookup = {str(spec.name): i for i, spec in enumerate(specs)}
            forced_idx = int(lookup.get(forced_name, 0))
        else:
            forced_idx = 0
        return np.full((num_added,), forced_idx, dtype=int), names

    if not specs:
        return np.zeros((num_added,), dtype=int), ["5G"] * num_added

    indices = assign_station_type_indices(num_added, specs)
    names = [str(specs[int(i)].name) for i in indices.tolist()]
    return indices.astype(int), names


def choose_stage1_5ga_sector_direction(
    site: np.ndarray,
    blind_spot_points: np.ndarray,
    sector_beamwidth_deg: float,
    config: Config,
    rng: Optional[np.random.Generator] = None,
) -> Dict[str, Any]:
    """Select the Stage-1 5GA sector direction by scoring eight compass beams.

    Scoring modes:
    - count_based: sum 1 for covered blind points.
    - demand_weighted: sum demand weights for covered blind points.
    - qos_deficit_weighted: sum QoS deficit weights for covered blind points.
    """
    directions = DEFAULT_SECTOR_DIRECTIONS_DEG.astype(float)
    stage1_cfg = config.get("stage1", {})
    strategy = _normalize_stage1_5ga_direction_strategy(
        stage1_cfg.get(
            "stage1_5ga_direction_strategy",
            stage1_cfg.get("fivegaDirectionStrategy", STAGE1_5GA_DIRECTION_STRATEGY_ENUMERATE_BEST),
        )
    )
    score_mode = _stage1_sector_score_mode(config)
    if strategy == STAGE1_5GA_DIRECTION_STRATEGY_DEMAND_WEIGHTED_BEST:
        score_mode = STAGE1_SECTOR_SCORE_DEMAND

    points = np.asarray(blind_spot_points, dtype=float)
    if points.size == 0 and strategy != STAGE1_5GA_DIRECTION_STRATEGY_RANDOM:
        default_az = float(
            config.get("heterogeneousDeployment", {}).get(
                "defaultSectorAzimuthDeg",
                config.get("heterogeneousDeployment", {}).get("default_sector_azimuth_deg", directions[0]),
            )
        )
        snapped = float(nearest_supported_sector_direction_deg(default_az, directions))
        idx = _sector_direction_index(snapped, directions)
        return _build_stage1_sector_choice(
            site=site,
            direction_scores=_empty_direction_scores(directions),
            selected_idx=idx,
            score_mode=score_mode,
            strategy=strategy,
        )
    if points.ndim == 1:
        points = points.reshape(1, -1)

    if strategy == STAGE1_5GA_DIRECTION_STRATEGY_RANDOM:
        if rng is None:
            raise ValueError("stage1_5ga_direction_strategy=random requires a reproducible rng")
        selected_idx = int(rng.integers(0, directions.size))
        scores = _score_stage1_sector_directions(
            site=site,
            blind_spot_points=points,
            directions=directions,
            sector_beamwidth_deg=sector_beamwidth_deg,
            config=config,
            score_mode=score_mode,
        )
        return _build_stage1_sector_choice(
            site=site,
            direction_scores=scores,
            selected_idx=selected_idx,
            score_mode=score_mode,
            strategy=strategy,
        )

    if strategy not in {
        STAGE1_5GA_DIRECTION_STRATEGY_ENUMERATE_BEST,
        STAGE1_5GA_DIRECTION_STRATEGY_DEMAND_WEIGHTED_BEST,
    }:
        raise ValueError(
            "stage1_5ga_direction_strategy must be 'enumerate_best', "
            "'demand_weighted_best', or 'random'"
        )

    scores = _score_stage1_sector_directions(
        site=site,
        blind_spot_points=points,
        directions=directions,
        sector_beamwidth_deg=sector_beamwidth_deg,
        config=config,
        score_mode=score_mode,
    )
    selected_idx = _select_stage1_sector_index_from_scores(scores, config)
    return _build_stage1_sector_choice(
        site=site,
        direction_scores=scores,
        selected_idx=selected_idx,
        score_mode=score_mode,
        strategy=strategy,
    )


def _score_stage1_sector_directions(
    site: np.ndarray,
    blind_spot_points: np.ndarray,
    directions: np.ndarray,
    sector_beamwidth_deg: float,
    config: Config,
    score_mode: str,
) -> List[Dict[str, float]]:
    points = np.asarray(blind_spot_points, dtype=float)
    weights = _stage1_blind_point_weights(points, config, score_mode)
    direction_scores: List[Dict[str, float]] = []
    for idx, azimuth in enumerate(directions.tolist()):
        inside = inside_sector_mask(
            station_xy=np.asarray(site[:2], dtype=float),
            point_xy=points[:, :2],
            sector_azimuth_deg=float(azimuth),
            sector_beamwidth_deg=float(sector_beamwidth_deg),
        )
        inside_mask = np.asarray(inside, dtype=bool)
        covered_count = int(np.sum(inside_mask))
        score = float(np.sum(weights[inside_mask])) if weights.size > 0 else 0.0
        direction_scores.append(
            {
                "sector_direction_index": float(idx),
                "sector_azimuth_deg": float(azimuth),
                "score": score,
                "covered_blind_points": float(covered_count),
            }
        )
    return direction_scores


def _stage1_sector_score_mode(config: Config) -> str:
    stage1_cfg = config.get("stage1", {})
    mode = str(
        stage1_cfg.get(
            "sectorScoringMode",
            stage1_cfg.get("stage1_5ga_sector_score_mode", STAGE1_SECTOR_SCORE_COUNT),
        )
    ).strip().lower()
    valid = {STAGE1_SECTOR_SCORE_COUNT, STAGE1_SECTOR_SCORE_DEMAND, STAGE1_SECTOR_SCORE_QOS_DEFICIT}
    if mode not in valid:
        raise ValueError(f"Unsupported Stage-1 5GA sector scoring mode: {mode!r}")
    return mode


def _normalize_stage1_5ga_direction_strategy(raw_strategy: object) -> str:
    strategy = str(raw_strategy or "").strip().lower().replace("-", "_")
    if strategy == STAGE1_5GA_DIRECTION_STRATEGY_SCORE:
        return STAGE1_5GA_DIRECTION_STRATEGY_ENUMERATE_BEST
    return strategy


def _stage1_blind_point_weights(points: np.ndarray, config: Config, score_mode: str) -> np.ndarray:
    n = int(points.shape[0]) if points.ndim == 2 else 0
    if n <= 0:
        return np.zeros((0,), dtype=float)
    stage1_cfg = config.get("stage1", {})
    if score_mode == STAGE1_SECTOR_SCORE_COUNT:
        return np.ones((n,), dtype=float)

    if score_mode == STAGE1_SECTOR_SCORE_DEMAND:
        raw = stage1_cfg.get("blindSpotDemandWeights", stage1_cfg.get("blind_spot_demand_weights"))
        fallback_col = 3
    else:
        raw = stage1_cfg.get("blindSpotQosDeficits", stage1_cfg.get("blind_spot_qos_deficits"))
        fallback_col = 4 if points.shape[1] > 4 else 3

    if raw is not None:
        weights = np.asarray(raw, dtype=float).reshape(-1)
        if weights.size != n:
            raise ValueError("Configured Stage-1 blind-point weights must match blind_spot_points length")
    elif points.shape[1] > fallback_col:
        weights = np.asarray(points[:, fallback_col], dtype=float)
    else:
        weights = np.ones((n,), dtype=float)

    weights = np.where(np.isfinite(weights), weights, 0.0)
    return np.maximum(weights.astype(float), 0.0)


def _select_stage1_sector_index_from_scores(scores: Sequence[Mapping[str, float]], config: Config) -> int:
    if not scores:
        return 0
    stage1_cfg = config.get("stage1", {})
    tie_rule = str(
        stage1_cfg.get(
            "sectorTieBreak",
            stage1_cfg.get("stage1_5ga_sector_tie_break", STAGE1_SECTOR_TIE_SMALLER_INDEX),
        )
    ).strip().lower()
    score_arr = np.asarray([float(s["score"]) for s in scores], dtype=float)
    best_score = float(np.max(score_arr))
    tied = np.where(np.isclose(score_arr, best_score, atol=1e-12, rtol=0.0))[0]
    if tied.size == 0:
        return int(np.argmax(score_arr))
    if tie_rule == STAGE1_SECTOR_TIE_SMALLER_INDEX:
        return int(np.min(tied))
    if tie_rule == "larger_index":
        return int(np.max(tied))
    raise ValueError("Unsupported Stage-1 5GA sector tie-breaking rule")


def _build_stage1_sector_choice(
    site: np.ndarray,
    direction_scores: Sequence[Mapping[str, float]],
    selected_idx: int,
    score_mode: str,
    strategy: str,
) -> Dict[str, Any]:
    idx = int(selected_idx)
    scores = [dict(s) for s in direction_scores]
    if not scores:
        scores = _empty_direction_scores(DEFAULT_SECTOR_DIRECTIONS_DEG)
    selected = scores[idx]
    return {
        "candidate_location": {
            "x": float(site[0]),
            "y": float(site[1]),
            "z": float(site[2]) if np.asarray(site).size > 2 else 0.0,
        },
        "direction_scores": scores,
        "sector_direction_index": idx,
        "sector_azimuth_deg": float(selected["sector_azimuth_deg"]),
        "selected_score": float(selected["score"]),
        "covered_blind_points": int(selected["covered_blind_points"]),
        "score_mode": score_mode,
        "strategy": strategy,
    }


def _empty_direction_scores(directions: np.ndarray) -> List[Dict[str, float]]:
    return [
        {
            "sector_direction_index": float(i),
            "sector_azimuth_deg": float(azimuth),
            "score": 0.0,
            "covered_blind_points": 0.0,
        }
        for i, azimuth in enumerate(np.asarray(directions, dtype=float).reshape(-1).tolist())
    ]


def _sector_direction_index(azimuth_deg: float, directions_deg: np.ndarray) -> int:
    directions = np.asarray(directions_deg, dtype=float).reshape(-1)
    diff = np.abs((directions - float(azimuth_deg) + 180.0) % 360.0 - 180.0)
    return int(np.argmin(diff))


def _apply_upgrade_first(
    test_points: np.ndarray,
    blind_points: np.ndarray,
    existing_stations: np.ndarray,
    snr_threshold: float,
    config: Config,
    city_map: CityMap,
    channel_params: Config,
) -> Tuple[np.ndarray, Dict[str, float]]:
    """先尝试“升级现有站点”而不是立即新建站。"""
    stage1_cfg = config.get("stage1", {})
    enabled = bool(stage1_cfg.get("upgradeFirst", True))
    if not enabled or blind_points.size == 0 or existing_stations.size == 0:
        stats = _build_upgrade_stats(
            enabled=enabled,
            num_upgraded=0,
            blind_before=blind_points.shape[0],
            blind_after=blind_points.shape[0],
        )
        return blind_points, stats

    default_max_upgrade = int(max(1, stage1_cfg.get("numNewStations", 1)))
    max_upgrade = int(np.clip(stage1_cfg.get("maxUpgradeStations", default_max_upgrade), 0, existing_stations.shape[0]))
    tx_boost_db = float(stage1_cfg.get("upgradeTxPowerBoostDb", 6.0))
    if max_upgrade <= 0 or tx_boost_db <= 0.0:
        stats = _build_upgrade_stats(
            enabled=enabled,
            num_upgraded=0,
            blind_before=blind_points.shape[0],
            blind_after=blind_points.shape[0],
        )
        return blind_points, stats

    chosen_idx = _select_upgrade_station_indices(
        existing_stations=existing_stations,
        blind_points=blind_points,
        max_upgrade=max_upgrade,
    )
    if chosen_idx.size == 0:
        stats = _build_upgrade_stats(
            enabled=enabled,
            num_upgraded=0,
            blind_before=blind_points.shape[0],
            blind_after=blind_points.shape[0],
        )
        return blind_points, stats

    offsets = np.zeros((existing_stations.shape[0],), dtype=float)
    offsets[chosen_idx] = tx_boost_db
    sector_params = _build_existing_station_sector_params(config=config, num_existing=existing_stations.shape[0])

    snr_upgraded = compute_point_snr(
        best_position=existing_stations,
        test_points=test_points,
        city_map=city_map,
        channel_params=channel_params,
        tx_power_offsets_db=offsets,
        **sector_params,
    )
    blind_after_mask = snr_upgraded < snr_threshold
    blind_after = test_points[blind_after_mask]

    stats = _build_upgrade_stats(
        enabled=enabled,
        num_upgraded=int(chosen_idx.size),
        blind_before=blind_points.shape[0],
        blind_after=blind_after.shape[0],
    )
    return blind_after, stats


def _select_upgrade_station_indices(
    existing_stations: np.ndarray,
    blind_points: np.ndarray,
    max_upgrade: int,
) -> np.ndarray:
    """选择要升级的现有站点索引（优先覆盖更多盲点且距离更近）。"""
    if existing_stations.size == 0 or blind_points.size == 0 or max_upgrade <= 0:
        return np.zeros((0,), dtype=int)

    bs_xy = existing_stations[:, :2]
    blind_xy = blind_points[:, :2]
    diff = blind_xy[:, None, :] - bs_xy[None, :, :]
    d2 = np.sum(diff * diff, axis=2)

    nearest = np.argmin(d2, axis=1)
    counts = np.bincount(nearest, minlength=bs_xy.shape[0]).astype(float)

    mean_d2 = np.full((bs_xy.shape[0],), np.inf, dtype=float)
    for i in range(bs_xy.shape[0]):
        mask = nearest == i
        if np.any(mask):
            mean_d2[i] = float(np.mean(d2[mask, i]))

    # Larger influenced blind-point counts first, then smaller mean distance.
    order = np.lexsort((mean_d2, -counts))
    k = int(min(max_upgrade, bs_xy.shape[0]))
    selected = order[:k]
    selected.sort()
    return selected.astype(int)


def _build_upgrade_stats(enabled: bool, num_upgraded: int, blind_before: int, blind_after: int) -> Dict[str, float]:
    """组装阶段一升级统计字段。"""
    before = float(max(blind_before, 0))
    after = float(max(blind_after, 0))
    improve_ratio = 0.0 if before <= 0.0 else float((before - after) / before)
    return {
        "stage1_upgrade_enabled": 1.0 if enabled else 0.0,
        "stage1_num_upgraded": float(max(num_upgraded, 0)),
        "stage1_blind_points_before_upgrade": before,
        "stage1_blind_points_after_upgrade": after,
        "stage1_upgrade_improvement_ratio": improve_ratio,
    }


def _build_existing_station_sector_params(config: Config, num_existing: int) -> Dict[str, object]:
    """Parse optional sector metadata for existing 5GA stations used by Stage-1."""
    if num_existing <= 0:
        return {}
    h_cfg = config.get("heterogeneousDeployment", {})
    raw_types = h_cfg.get("existingStationTypes", [])
    if not raw_types:
        return {}
    if len(raw_types) != num_existing:
        raise ValueError("heterogeneousDeployment.existingStationTypes length must match existingStations")
    sector_mask = np.asarray([str(t).strip().lower() == "5ga" for t in raw_types], dtype=bool)
    if not np.any(sector_mask):
        return {}

    sector_cfg = sector_geometry_config_from_mapping(config)
    raw_az = h_cfg.get("existingStationSectorAzimuthsDeg", [])
    if raw_az:
        az = np.asarray(raw_az, dtype=float).reshape(-1)
        if az.size != num_existing:
            raise ValueError(
                "heterogeneousDeployment.existingStationSectorAzimuthsDeg length must match existingStations"
            )
    else:
        default_az = float(h_cfg.get("defaultSectorAzimuthDeg", h_cfg.get("default_sector_azimuth_deg", 0.0)))
        az = np.full((num_existing,), default_az, dtype=float)
    az = np.asarray(nearest_supported_sector_direction_deg(az, sector_cfg.sector_directions_deg), dtype=float)
    return {
        "sector_station_mask": sector_mask,
        "sector_azimuths_deg": az,
        "sector_beamwidth_deg": sector_cfg.sector_beamwidth_deg,
        "outside_sector_mode": sector_cfg.outside_sector_mode,
        "side_lobe_attenuation_db": sector_cfg.side_lobe_attenuation_db,
    }


def _snap_point_off_road_centerline(
    x: float,
    y: float,
    z: float,
    city_map: CityMap,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    stage1_cfg: Config,
    rng: np.random.Generator,
) -> Tuple[float, float, float]:
    """若站点落在道路中心线禁放区，移动到最近合法区域。"""
    if not bool(stage1_cfg.get("avoidRoadCenter", True)):
        return x, y, z

    clearance = float(stage1_cfg.get("roadCenterClearanceM", 12.0))
    if clearance <= 0.0:
        return x, y, z

    road_dist = _distance_to_nearest_road_centerline(x, y, city_map.road_segments)
    if not np.isfinite(road_dist) or road_dist > clearance:
        return x, y, z

    max_radius = float(stage1_cfg.get("roadSnapMaxRadiusM", max(80.0, clearance * 8.0)))
    step = float(stage1_cfg.get("roadSnapStepM", max(3.0, clearance * 0.5)))
    num_angles = int(max(8, stage1_cfg.get("roadSnapAngles", 24)))

    radii = np.arange(step, max_radius + 1e-9, step, dtype=float)
    for r in radii:
        best_candidate: Optional[Tuple[float, float]] = None
        best_clearance = -np.inf
        for a_idx in range(num_angles):
            theta = 2.0 * np.pi * float(a_idx) / float(num_angles)
            cx = float(np.clip(x + r * np.cos(theta), min_pos[0], max_pos[0]))
            cy = float(np.clip(y + r * np.sin(theta), min_pos[1], max_pos[1]))

            cdist = _distance_to_nearest_road_centerline(cx, cy, city_map.road_segments)
            if not np.isfinite(cdist) or cdist <= clearance:
                continue
            if cdist > best_clearance:
                best_clearance = cdist
                best_candidate = (cx, cy)

        if best_candidate is not None:
            return float(best_candidate[0]), float(best_candidate[1]), float(np.clip(z, min_pos[2], max_pos[2]))

    # 回退策略：随机局部搜索，尽量找到道路禁放区外的合法点。
    for _ in range(120):
        r = float(rng.uniform(step, max_radius))
        theta = float(rng.uniform(0.0, 2.0 * np.pi))
        cx = float(np.clip(x + r * np.cos(theta), min_pos[0], max_pos[0]))
        cy = float(np.clip(y + r * np.sin(theta), min_pos[1], max_pos[1]))
        cdist = _distance_to_nearest_road_centerline(cx, cy, city_map.road_segments)
        if np.isfinite(cdist) and cdist > clearance:
            return cx, cy, float(np.clip(z, min_pos[2], max_pos[2]))

    return x, y, z


def _distance_to_nearest_road_centerline(x: float, y: float, road_segments: Optional[np.ndarray]) -> float:
    """计算点到最近道路中心线段的最短距离。"""
    if road_segments is None:
        return float("inf")
    segs = np.asarray(road_segments, dtype=float)
    if segs.size == 0 or segs.ndim != 3 or segs.shape[1:] != (2, 2):
        return float("inf")

    p = np.array([x, y], dtype=float)
    p0 = segs[:, 0, :]
    p1 = segs[:, 1, :]
    v = p1 - p0
    vv = np.sum(v * v, axis=1)
    valid = vv > 1e-12
    if not np.any(valid):
        return float("inf")

    w = p[None, :] - p0
    t = np.zeros_like(vv)
    t[valid] = np.clip(np.sum(w[valid] * v[valid], axis=1) / vv[valid], 0.0, 1.0)
    proj = p0 + t[:, None] * v
    dist = np.linalg.norm(proj - p[None, :], axis=1)
    return float(np.min(dist))
