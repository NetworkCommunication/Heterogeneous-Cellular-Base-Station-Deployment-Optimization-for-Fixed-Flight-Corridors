from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np

from src.algorithms.heterogeneous_deployment import assign_station_type_indices, parse_station_types
from src.data.types import Config
from src.propagation.sector_geometry import normalize_sector_directions_deg, sector_geometry_config_from_mapping


SPATIAL_DIMS = 3
TYPE_INDEX_COL = 3
SECTOR_INDEX_COL = 4
EXTENDED_DIMS = 5


@dataclass(frozen=True)
class ParticleEncodingSpec:
    """Particle decision encoding for proposed heterogeneous deployment."""

    optimize_station_type: bool
    optimize_sector_direction: bool
    station_type_names: List[str]
    station_type_probabilities: np.ndarray
    fixed_station_type_indices: np.ndarray
    sector_directions_deg: np.ndarray
    default_sector_index: int

    @property
    def enabled(self) -> bool:
        return bool(self.optimize_station_type or self.optimize_sector_direction)

    @property
    def num_station_types(self) -> int:
        return int(len(self.station_type_names))

    @property
    def num_sector_directions(self) -> int:
        return int(self.sector_directions_deg.size)


def particle_encoding_spec(config: Config, num_base_stations: int) -> ParticleEncodingSpec:
    """Parse particle-encoding controls from config.

    Full proposed configs default `optimizeSectorDirection` to True in
    `get_default_config`, and proposed runtime guards reject disabling it.
    Minimal non-proposed unit configs that omit `particleEncoding` keep the
    legacy [x, y, z] shape.
    """
    raw = config.get("particleEncoding", {})
    optimize_type = bool(raw.get("optimizeStationType", raw.get("stationTypeDecision", False)))
    optimize_sector = bool(raw.get("optimizeSectorDirection", raw.get("sectorDirectionDecision", False)))

    specs = parse_station_types(config)
    names = [str(s.name) for s in specs] if specs else ["5G"]
    ratios = np.asarray([max(float(s.ratio), 0.0) for s in specs], dtype=float) if specs else np.ones((1,), dtype=float)
    if float(np.sum(ratios)) <= 0.0:
        ratios = np.ones_like(ratios)
    probs = ratios / float(np.sum(ratios))

    fixed = assign_station_type_indices(int(num_base_stations), specs)
    if fixed.size != int(num_base_stations):
        fixed = np.zeros((int(num_base_stations),), dtype=int)

    sector_cfg = sector_geometry_config_from_mapping(config)
    directions = normalize_sector_directions_deg(sector_cfg.sector_directions_deg)
    default_azimuth = float(
        config.get("heterogeneousDeployment", {}).get(
            "defaultSectorAzimuthDeg",
            config.get("heterogeneousDeployment", {}).get("default_sector_azimuth_deg", directions[0]),
        )
    )
    default_sector_index = _nearest_sector_index(default_azimuth, directions)

    return ParticleEncodingSpec(
        optimize_station_type=optimize_type,
        optimize_sector_direction=optimize_sector,
        station_type_names=names,
        station_type_probabilities=probs,
        fixed_station_type_indices=fixed.astype(int),
        sector_directions_deg=directions,
        default_sector_index=int(default_sector_index),
    )


def is_extended_particle_array(particles: np.ndarray) -> bool:
    """Return True when the array carries station type and sector index columns."""
    arr = np.asarray(particles)
    return bool(arr.ndim >= 1 and arr.shape[-1] >= EXTENDED_DIMS)


def spatial_view(particles: np.ndarray) -> np.ndarray:
    """Return the [x, y, z] part of a legacy or extended particle array."""
    arr = np.asarray(particles, dtype=float)
    if arr.shape[-1] < SPATIAL_DIMS:
        raise ValueError("particle array must contain at least x, y, z columns")
    return arr[..., :SPATIAL_DIMS]


def encoding_min_max(
    min_position: np.ndarray,
    max_position: np.ndarray,
    spec: ParticleEncodingSpec,
) -> tuple[np.ndarray, np.ndarray]:
    """Return min/max vectors matching the active particle encoding."""
    min_pos = np.asarray(min_position, dtype=float).reshape(-1)[:SPATIAL_DIMS]
    max_pos = np.asarray(max_position, dtype=float).reshape(-1)[:SPATIAL_DIMS]
    if not spec.enabled:
        return min_pos, max_pos
    min_ext = np.asarray([min_pos[0], min_pos[1], min_pos[2], 0.0, 0.0], dtype=float)
    max_ext = np.asarray(
        [
            max_pos[0],
            max_pos[1],
            max_pos[2],
            float(max(spec.num_station_types - 1, 0)),
            float(max(spec.num_sector_directions - 1, 0)),
        ],
        dtype=float,
    )
    return min_ext, max_ext


def extend_particles_with_decisions(
    spatial_particles: np.ndarray,
    config: Config,
    rng: np.random.Generator,
) -> np.ndarray:
    """Attach station type and sector-index decision columns when configured."""
    spatial = np.asarray(spatial_particles, dtype=float)
    if spatial.ndim != 3 or spatial.shape[2] < SPATIAL_DIMS:
        raise ValueError("spatial_particles must have shape [num_particles, num_base, >=3]")
    if is_extended_particle_array(spatial):
        return repair_particle_encoding(spatial, config)

    num_particles, num_base, _ = spatial.shape
    spec = particle_encoding_spec(config, num_base)
    if not spec.enabled:
        return spatial[..., :SPATIAL_DIMS].copy()

    out = np.zeros((num_particles, num_base, EXTENDED_DIMS), dtype=float)
    out[..., :SPATIAL_DIMS] = spatial[..., :SPATIAL_DIMS]

    for i in range(num_particles):
        if spec.optimize_station_type:
            type_idx = rng.choice(spec.num_station_types, size=num_base, replace=True, p=spec.station_type_probabilities)
        else:
            type_idx = spec.fixed_station_type_indices
        out[i, :, TYPE_INDEX_COL] = np.asarray(type_idx, dtype=float)

        if spec.optimize_sector_direction:
            out[i, :, SECTOR_INDEX_COL] = rng.integers(0, spec.num_sector_directions, size=num_base)
        else:
            out[i, :, SECTOR_INDEX_COL] = spec.default_sector_index

    return repair_particle_encoding(out, config)


def repair_particle_encoding(particles: np.ndarray, config: Config) -> np.ndarray:
    """Round and clip categorical station-type and sector-index decisions."""
    arr = np.asarray(particles, dtype=float).copy()
    if not is_extended_particle_array(arr):
        return arr

    spec = particle_encoding_spec(config, int(arr.shape[-2]))
    type_idx = np.rint(arr[..., TYPE_INDEX_COL]).astype(int)
    type_idx = np.clip(type_idx, 0, max(spec.num_station_types - 1, 0))
    sector_idx = np.rint(arr[..., SECTOR_INDEX_COL]).astype(int)
    sector_idx = np.clip(sector_idx, 0, max(spec.num_sector_directions - 1, 0))

    arr[..., TYPE_INDEX_COL] = type_idx.astype(float)
    arr[..., SECTOR_INDEX_COL] = sector_idx.astype(float)
    return arr


def decode_particle_solution(particle: np.ndarray, config: Config) -> List[Dict[str, object]]:
    """Decode one particle into station records for export and plotting."""
    arr = np.asarray(particle, dtype=float)
    if arr.ndim != 2 or arr.shape[1] < SPATIAL_DIMS:
        raise ValueError("particle must have shape [num_base, >=3]")

    num_base = int(arr.shape[0])
    type_indices, type_names, sector_indices, sector_azimuths = decode_particle_type_and_sector(arr, config)

    rows: List[Dict[str, object]] = []
    for b in range(num_base):
        station_type = str(type_names[b])
        is_5ga = station_type.strip().lower() == "5ga"
        rows.append(
            {
                "station_id": int(b + 1),
                "x": float(arr[b, 0]),
                "y": float(arr[b, 1]),
                "z": float(arr[b, 2]),
                "station_type": station_type,
                "station_type_index": int(type_indices[b]),
                "sector_direction_index": int(sector_indices[b]) if is_5ga else None,
                "sector_azimuth_deg": float(sector_azimuths[b]) if is_5ga else None,
            }
        )
    return rows


def decode_particle_type_and_sector(
    particle: np.ndarray,
    config: Config,
) -> tuple[np.ndarray, List[str], np.ndarray, np.ndarray]:
    """Return station type indices/names and sector indices/azimuths for one particle."""
    arr = np.asarray(particle, dtype=float)
    num_base = int(arr.shape[0])
    spec = particle_encoding_spec(config, num_base)

    if is_extended_particle_array(arr):
        repaired = repair_particle_encoding(arr[None, :, :], config)[0]
        type_indices = repaired[:, TYPE_INDEX_COL].astype(int)
        sector_indices = repaired[:, SECTOR_INDEX_COL].astype(int)
    else:
        type_indices = spec.fixed_station_type_indices.astype(int)
        sector_indices = np.full((num_base,), spec.default_sector_index, dtype=int)

        explicit = config.get("heterogeneousDeployment", {}).get(
            "sectorAzimuthsDeg",
            config.get("heterogeneousDeployment", {}).get("sector_azimuths_deg"),
        )
        if explicit is not None:
            explicit_arr = np.asarray(explicit, dtype=float).reshape(-1)
            if explicit_arr.size == num_base:
                sector_indices = np.asarray(
                    [_nearest_sector_index(float(v), spec.sector_directions_deg) for v in explicit_arr],
                    dtype=int,
                )

    type_indices = np.clip(type_indices, 0, max(spec.num_station_types - 1, 0)).astype(int)
    sector_indices = np.clip(sector_indices, 0, max(spec.num_sector_directions - 1, 0)).astype(int)
    type_names = [spec.station_type_names[int(i)] for i in type_indices.tolist()]
    sector_azimuths = spec.sector_directions_deg[sector_indices].astype(float)
    return type_indices, type_names, sector_indices, sector_azimuths


def station_sector_azimuth_list(particle: np.ndarray, config: Config) -> List[Optional[float]]:
    """Return per-station azimuths, using None for non-5GA stations."""
    return [row["sector_azimuth_deg"] for row in decode_particle_solution(particle, config)]  # type: ignore[list-item]


def _nearest_sector_index(azimuth_deg: float, directions_deg: np.ndarray) -> int:
    directions = normalize_sector_directions_deg(directions_deg)
    candidate = float(np.mod(float(azimuth_deg), 360.0))
    diff = np.abs((directions - candidate + 180.0) % 360.0 - 180.0)
    return int(np.argmin(diff))
