﻿from __future__ import annotations

from typing import Tuple

import numpy as np

from src.data.types import CityMap, Config

try:
    from sklearn.cluster import KMeans
except Exception:  # pragma: no cover
    KMeans = None


def kmeans_init(
    test_points: np.ndarray,
    num_particles: int,
    config: Config,
    city_map: CityMap,
    rng: np.random.Generator,
) -> np.ndarray:
    """使用 KMeans 聚类中心初始化粒子群。"""
    pso_cfg = config["pso"]
    kmeans_cfg = config["kmeans"]
    num_base = int(pso_cfg["numBaseStations"])
    min_pos = np.asarray(pso_cfg["minPosition"], dtype=float)
    max_pos = np.asarray(pso_cfg["maxPosition"], dtype=float)
    use_kmeans_init = bool(kmeans_cfg.get("useKMeansInit", True))
    kmeans_ratio = float(np.clip(kmeans_cfg.get("kmeansInitRatio", 1.0), 0.0, 1.0))

    n_points = test_points.shape[0]
    n_clusters = int(min(kmeans_cfg["numClusters"], max(1, n_points)))

    if n_points == 0:
        centers = np.column_stack(
            [
                rng.random(n_clusters) * city_map.size_x,
                rng.random(n_clusters) * city_map.size_y,
                min_pos[2] + rng.random(n_clusters) * (max_pos[2] - min_pos[2]),
            ]
        )
    elif not use_kmeans_init:
        idx = rng.choice(n_points, size=n_clusters, replace=n_points < n_clusters)
        centers = test_points[idx]
    elif KMeans is None:
        idx = rng.choice(n_points, size=n_clusters, replace=n_points < n_clusters)
        centers = test_points[idx]
    else:
        km = KMeans(
            n_clusters=n_clusters,
            max_iter=int(kmeans_cfg["maxIterations"]),
            n_init=10,
            random_state=42,
        )
        km.fit(test_points)
        centers = km.cluster_centers_

    positions = np.zeros((num_particles, num_base, 3), dtype=float)
    guided_particles = int(round(num_particles * kmeans_ratio))
    for i in range(num_particles):
        for b in range(num_base):
            if i < guided_particles and i < n_clusters:
                center = centers[(i + b) % n_clusters]
                x = center[0] + (rng.random() - 0.5) * 50.0
                y = center[1] + (rng.random() - 0.5) * 50.0
                z = center[2] + (rng.random() - 0.5) * 20.0
            else:
                x = rng.random() * city_map.size_x
                y = rng.random() * city_map.size_y
                z = min_pos[2] + rng.random() * (max_pos[2] - min_pos[2])

            x = float(np.clip(x, 0.0, city_map.size_x))
            y = float(np.clip(y, 0.0, city_map.size_y))
            z = float(np.clip(z, min_pos[2], max_pos[2]))
            x, y, z = ensure_non_building(x, y, z, city_map, min_pos, max_pos, rng)
            positions[i, b] = [x, y, z]

    return positions


def ensure_non_building(
    x: float,
    y: float,
    z: float,
    city_map: CityMap,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    rng: np.random.Generator,
) -> Tuple[float, float, float]:
    """若点位落在建筑内部，则进行扰动修正。"""
    z = float(np.clip(z, min_pos[2], max_pos[2]))
    if city_map.building_bounds.size == 0:
        return x, y, z

    for attempt in range(100):
        if not is_inside_building(x, y, z, city_map.building_bounds):
            return x, y, z

        offset = (attempt + 1) * 5.0
        angle = rng.random() * 2.0 * np.pi
        x = float(np.clip(x + np.cos(angle) * offset, min_pos[0], max_pos[0]))
        y = float(np.clip(y + np.sin(angle) * offset, min_pos[1], max_pos[1]))
        z = float(np.clip(z, min_pos[2], max_pos[2]))

    return (
        float(np.clip(x, min_pos[0], max_pos[0])),
        float(np.clip(y, min_pos[1], max_pos[1])),
        float(np.clip(z, min_pos[2], max_pos[2])),
    )


def is_inside_building(x: float, y: float, z: float, bounds: np.ndarray) -> bool:
    """判断三维点是否在任意建筑内部。"""
    if bounds.size == 0:
        return False

    in_xy = (x >= bounds[:, 0]) & (x <= bounds[:, 1]) & (y >= bounds[:, 2]) & (y <= bounds[:, 3])
    if not np.any(in_xy):
        return False

    return bool(np.any(z <= bounds[in_xy, 5]))


def enforce_non_building_constraint(
    positions: np.ndarray,
    city_map: CityMap,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    rng: np.random.Generator,
) -> np.ndarray:
    """对所有粒子位置批量执行建筑避障约束。"""
    corrected = positions.copy()
    spatial_min = np.asarray(min_pos, dtype=float).reshape(-1)[:3]
    spatial_max = np.asarray(max_pos, dtype=float).reshape(-1)[:3]
    for i in range(corrected.shape[0]):
        for b in range(corrected.shape[1]):
            x, y, z = corrected[i, b, :3]
            x, y, z = ensure_non_building(x, y, z, city_map, spatial_min, spatial_max, rng)
            corrected[i, b, :3] = [x, y, z]
    return corrected

