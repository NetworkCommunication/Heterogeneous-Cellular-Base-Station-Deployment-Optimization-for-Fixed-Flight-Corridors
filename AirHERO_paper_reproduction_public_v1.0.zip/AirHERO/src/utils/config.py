﻿from __future__ import annotations

import json
from typing import Optional

from src.data.types import Config


def get_default_config() -> Config:
    """Return default experiment configuration."""
    return {
        "experiment": {
            "method": "proposed",
            "name": "tevc_two_stage_heterogeneous_deployment",
        },
        "allowProxyFallback": False,
        "initialization": {
            # "random" | "kmeans" | "two_stage"
            "mode": "kmeans",
        },
        "map": {
            "sizeX": 3600.0,
            "sizeY": 2800.0,
            "sizeZ": 500.0,
            "numBuildings": 100,
            "minBuildingHeight": 20.0,
            "maxBuildingHeight": 200.0,
            "minBuildingSize": 30.0,
            "maxBuildingSize": 100.0,
            "useRealMap": False,
            "useGeoDistanceScale": True,
            "realMapPath": "liaoning_map.qgz",
            "realClipBbox": [122.35, 41.18, 123.92, 42.25],
            "realMaxBuildings": 3000,
            "realMaxRoadSegments": 12000,
            "realMinBuildingHeight": 12.0,
            "realMaxBuildingHeight": 120.0,
            "buildingSubclassFile": None,
            "landingSelection": {
                "enabled": True,
                "allowedSubclasses": ["transport", "public_service", "commercial", "industrial", "medical"],
                "excludedSubclasses": ["residential"],
                "minRoofArea": 1800.0,
                "minBuildingHeight": 15.0,
                "minSiteSeparation": 220.0,
                "maxSites": 12,
                "allowOsmIds": [],
            },
        },
        "airRoute": {                                                 #现有航线
            "numSegments": 12,
            "pointsPerSegment": 45,
            "minAltitude": 80.0,
            "maxAltitude": 260.0,
            "gridSize": 20.0,
            "lateralHalfWidthMeters": 1500.0,
            "lateralStepMeters": 100.0,
            "sampleKeepProb": 0.85,
            "maxPointsPerSegment": 1800,
            "routeMode": "geo_start_south_distance",
            "routeXRatio": 0.5,
            "geoStartLon": 123.40935537725748,
            "geoStartLat": 41.92376403327159,
            "geoSouthDistanceKm": 32.0,
        },
        "routeSource": {
            # existing_real_routes | generated_from_pois | proxy_generated_routes
            "source": "existing_real_routes",
            # Optional CSV of real route test points with x/y/z or x_m/y_m/z_m columns.
            # If omitted, existing_real_routes falls back to the legacy configured airRoute
            # generator and records that fallback explicitly in route_source_metadata.json.
            "realRouteTestPointFile": None,
            # Generated/proxy future-airway outputs are saved below each experiment artifact dir.
            "generatedOutputSubdir": "generated_future_airways",
        },
        "routeObjectives": {
            # How to split evaluation points into existing-route and future-route sets.
            # - index_ratio: first ratio points as existing, remaining as future.
            # - explicit_indices: use existingIndices / futureIndices.
            "splitMode": "index_ratio",
            "existingRatio": 0.5,
            "existingIndices": [],
            "futureIndices": [],
        },
        "futureAirway": {
            "enabled": False,
            "mode": "poi_dfs",
            "dataLabel": "GENERATED_FUTURE_AIRWAY",
            "poiSource": {
                # csv | map_buildings | proxy
                "mode": "proxy",
                "poiFile": None,
            },
            "poiClassification": {
                "logisticsKeywords": ["logistics", "warehouse", "distribution", "freight", "industrial"],
                "hospitalKeywords": ["hospital", "clinic", "medical"],
                "businessKeywords": ["commercial", "office", "business", "mall", "retail"],
            },
            "candidateFiltering": {
                "minRoofArea": 0.0,
                "minBuildingHeight": 0.0,
                "maxCandidatesPerType": 50,
            },
            "graph": {
                "max_edge_distance": 5000.0,
                "k_nearest_neighbors": None,
                "allowed_connection_types": [
                    ["logistics_center", "logistics_center"],
                    ["logistics_center", "hospital"],
                    ["logistics_center", "business_district"],
                ],
            },
            "routeGeneration": {
                "max_total_routes": 30,
                "max_routes_per_logistics_center": 20,
                "max_routes_per_target_type": 20,
                "random_seed": 42,
                "route_selection_strategy": "shortest_first",
                "max_depth": 2,
                "dfsCandidateRouteCap": 5000,
            },
            "discretization": {
                "numSegments": 8,
                "pointsPerSegment": 30,
                "minAltitude": 80.0,
                "maxAltitude": 180.0,
                "gridSize": 30.0,
            },
            "proxyPoi": {
                "bbox": [0.0, 0.0, 1000.0, 800.0],
                "counts": {
                    "logistics_center": 2,
                    "hospital": 3,
                    "business_district": 3,
                },
            },
            "visualization": {
                "enabled": True,
            },
            "output": {
                "saveCSV": True,
                "saveGeoJSON": True,
                "saveUnreachableReport": True,
            },
        },
        "channel": {
            "frequency": 2.4e9,
            "txPower": 14.0,
            "noisePower": -90.0,
            "antennaGain": 0.0,
            "losThreshold": 0.7,
            "penetrationLoss": 40.0,
            "snrThreshold": 6.0,
            # low-fidelity channel model: "a2g_probabilistic" (paper Eq.1/2/3) or "legacy"
            "lowFidelityModel": "a2g_probabilistic",
            # Default urban-like parameters from paper-related A2G probabilistic model.
            # Kept configurable to support environment replacement later.
            "a2gProbabilistic": {
                "a": 9.61,
                "b": 0.16,
                "etaLoS": 1.0,
                "etaNLoS": 20.0,
            },
            # Isolated 5GA single-sector geometry defaults.
            "sector_directions_deg": [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0],
            "sector_beamwidth_deg": 90.0,
            "outside_sector_mode": "no_coverage",
            "side_lobe_attenuation_db": 30.0,
        },
        "baselineObjectives": {
            "coverageWeight": 1.0,
            "signalQualityWeight": 0.2,
            "costWeight": 0.2,
            "costEffectivenessWeight": 0.0,
            "capacityWeight": 0.0,
            "costReference": 3.0,
            "capacityReference": 3.0,
        },
        "asu_preset": "legacy_composite",
        "airwayServiceUtility": {
            "enabled": True,
            "name": "Airway Service Utility",
            "asu_preset": "legacy_composite",
            # Materialized by experiment exporters from baselineObjectives so
            # run_config.json snapshots record the fixed weights used.
            "weights": {},
            "normalization": {
                "snr_min_db": 0.0,
                "snr_max_db": 30.0,
                "cost_reference": 3.0,
                "capacity_reference": 3.0,
                "cost_effectiveness_reference": 2.0,
                "handover_reference": 8.0,
                "constraint_penalty_reference": 100.0,
            },
        },
        "heterogeneousDeployment": {
            "enabled": False,
            # Placeholder abstractions; replace by engineering-calibrated formulas later.
            "assumptionNote": "Heterogeneous effects are parameterized placeholders.",
            "stationTypes": [
                {
                    "name": "5G",
                    "ratio": 0.5,
                    "txPowerOffsetDb": 0.0,
                    "deploymentCost": 1.0,
                    "coverageBoostDb": 0.0,
                    "pathLossOffsetDb": 0.0,
                    "nlosPenaltyFactor": 1.0,
                    "capacityUnits": 1.0,
                },
                {
                    "name": "5GA",
                    "ratio": 0.5,
                    "txPowerOffsetDb": 2.5,
                    "deploymentCost": 1.4,
                    "coverageBoostDb": 1.0,
                    "pathLossOffsetDb": -0.5,
                    "nlosPenaltyFactor": 0.95,
                    "capacityUnits": 1.6,
                },
            ],
            # Optional fixed azimuths for non-proposed/manual diagnostics.
            # Proposed runs optimize the 5GA sector direction as a decision
            # variable and validate the strict eight-compass direction set.
            "sectorAzimuthsDeg": None,
            "defaultSectorAzimuthDeg": 0.0,
            "existingStations": [],
            "existingStationTypes": [],
            "existingStationSectorAzimuthsDeg": [],
        },
        "particleEncoding": {
            # Proposed 5GA sector direction must be optimized by default.
            # Extended particles use [x,y,z,station_type_index,sector_direction_index].
            "optimizeStationType": False,
            "optimizeSectorDirection": True,
            "stationTypeColumn": 3,
            "sectorDirectionColumn": 4,
            "sectorDirectionEncoding": "discrete_index",
        },
        "sectorLogging": {
            # Post-optimization diagnostics only; these fields do not feed back
            # into objective values, dominance, archive maintenance, or updates.
            "enabled": False,
        },
        "heterogeneousConstraints": {
            "maxNum5GA": None,
            "totalBudget": None,
            "minCoverageRate": None,
            "penalties": {
                "max5gaPenalty": 50.0,
                "budgetPenalty": 50.0,
                "minCoveragePenalty": 80.0,
            },
        },
        "stage1": {
            "enabled": False,
            "numNewStations": 2,
            "useKMeansForBlindSpots": True,
            # Upgrade existing sites before adding new stations.
            "upgradeFirst": True,
            "maxUpgradeStations": 2,
            "upgradeTxPowerBoostDb": 6.0,
            # Road-centerline deployment restriction.
            "avoidRoadCenter": True,
            "roadCenterClearanceM": 12.0,
            "roadSnapMaxRadiusM": 90.0,
            "roadSnapStepM": 4.0,
            "roadSnapAngles": 24,
            # 5GA sector selection for blind-spot filling.
            # Proposed main experiments use enumerate_best or demand_weighted_best.
            # random is reserved for explicitly marked ablation/diagnostic runs with
            # experiment.allowRandomStage1SectorStrategy=True.
            "stage1_5ga_direction_strategy": "enumerate_best",
            "stage1_5ga_sector_score_mode": "count_based",
            "stage1_5ga_sector_tie_break": "smaller_index",
            "blindSpotDemandWeights": None,
            "blindSpotQosDeficits": None,
        },
        "stage2": {
            "enabled": False,
            # Ratio of station slots per particle initialized from stage-1 anchors.
            # Example: 0.4 with 5 stations -> 2 seeded slots + 3 random slots in every particle.
            "seededParticleRatio": 0.4,
            "perturbationXY": 35.0,
            "perturbationZ": 10.0,
            "useExistingAnchors": True,
            # How Stage-2 carries Stage-1 5GA sector directions into seeded slots:
            # preserve | neighbor | random. Proposed default is preserve.
            "stage1SectorDirectionMode": "preserve",
        },
        "mopso": {
            "enabled": True,
            "archiveSize": 80,
            "velocityLimitRatio": 0.2,
            "stagnation": {
                "enabled": True,
                # legacy_weighted_qe | qe_gate_fixed | qe_gate_adaptive
                "detectionMode": "qe_gate_adaptive",
                # Before the QE gate opens, use "none" or "mild".
                "beforeGatePolicy": "none",
                "minIterationsBeforeCheck": 5,
                "thresholds": {
                    "globalBestChangeRate": {
                        "mild": 0.020,
                        "severe": 0.004
                    },
                    "archiveImprovementRate": {
                        "mild": 0.25,
                        "severe": 0.08
                    },
                    # Backward-compatible alias for archiveImprovementRate.
                    "nonDominatedFrontChangeRate": {
                        "mild": 0.25,
                        "severe": 0.08
                    },
                    "pbestImprovementRate": {
                        "mild": 0.12,
                        "severe": 0.02
                    },
                    "populationRadius": {
                        "mild": 0.22,
                        "severe": 0.08
                    },
                    "velocityNorm": {
                        "mild": 0.035,
                        "severe": 0.008
                    },
                    "leaderArchiveDiversity": {
                        "mild": 0.20,
                        "severe": 0.05
                    },
                    "objectiveSpaceSpread": {
                        "mild": 0.20,
                        "severe": 0.05
                    }
                },
                # Legacy/fixed mode weights. In qe_gate_adaptive mode these are base weights.
                "weights": {
                    "globalBestChangeRate": 1.0,
                    "nonDominatedFrontChangeRate": 1.0,
                    "populationRadius": 1.0,
                    "globalBestStall": 1.0,
                    "archiveStall": 1.0,
                    "pbestStall": 1.0,
                    "swarmDiversityLoss": 1.0,
                    "velocityDecay": 1.0,
                    "leaderArchiveDiversityLoss": 1.0,
                    "objectiveSpaceSpreadLoss": 0.8
                },
                # 论文 III-C/III-E 的 QE 参数:
                # - beta: top-beta 粒子用于 QE 计算
                # - theta: QE 自适应触发阈值, Q_E^t <= theta * Q_E^0
                # - nonPositiveEps: selected pbest<=0 时的兼容替代值（仅工程兼容）
                "quasiEntropyAdaptive": {
                    "beta": 0.3333333333,
                    "theta": 0.7,
                    "nonPositiveEps": 1e-12
                },
                "scoreThresholds": {
                    "mild": 0.25,
                    "moderate": 0.40,
                    "severe": 0.60
                },
                "nonQeFactors": {
                    "enableObjectiveSpaceSpread": True
                },
                "adaptiveWeights": {
                    "minWeight": 0.4,
                    "maxWeight": 2.2,
                    "smoothingFactor": 0.35,
                    "updateInterval": 1,
                    "baseWeights": {
                        "globalBestStall": 1.0,
                        "archiveStall": 1.0,
                        "pbestStall": 1.0,
                        "swarmDiversityLoss": 1.0,
                        "velocityDecay": 1.0,
                        "leaderArchiveDiversityLoss": 1.0,
                        "objectiveSpaceSpreadLoss": 0.8
                    }
                },
                "responses": {
                    "lowLatency": {
                        "enabled": True,
                        "inertiaBoost": 1.03,
                        "c1Scale": 1.02,
                        "c2Scale": 0.99,
                        "wMax": 0.95,
                        "c1Max": 2.4,
                        "c2Min": 0.9,
                        "enableLocalMutation": True,
                        "localMutationRatio": 0.20,
                        "mutationSigmaRatio": 0.08
                    },
                    "highStagnation": {
                        "enabled": True,
                        "restartRatio": 0.45,
                        "archiveGuideProb": 0.7,
                        "noiseSigmaRatio": 0.12
                    }
                }
            }
        },
        "multiFidelity": {
            # all_low_fidelity | all_high_fidelity | elite_mixed_fidelity
            "mode": "all_low_fidelity",
            "eliteRatio": 0.2,
            "eliteCount": None,
            "minEliteCount": 1,
            "eliteSelection": {
                # Placeholder rule: coverage + normalized mean SNR on low-fidelity pass.
                "metric": "coverage_mean_snr",
                "coverageWeight": 1.0,
                "snrWeight": 0.2,
            },
            "highFidelityModel": {
                # Placeholder high-fidelity approximation settings; replace when real model is ready.
                "numPathSamples": 7,
                "clearanceMarginM": 4.0,
                "losObstructionThreshold": 0.15,
                "baseNlosExponent": 2.7,
                "obstructionLossDb": 18.0,
                "diffractionLossDb": 10.0,
            },
        },
        "pso": {
            "numParticles": 45,
            "maxIterations": 160,
            "numBaseStations": 2,
            "w": 0.729,
            "c1": 1.49445,
            "c2": 1.49445,
            "wdamp": 0.99,
            "autoSyncMapBounds": True,
            "minPosition": [0.0, 0.0, 10.0],
            "maxPosition": [3600.0, 2800.0, 45.0],
        },
        "kmeans": {
            "numClusters": 50,
            "maxIterations": 100,
            "useKMeansInit": False,
            "kmeansInitRatio": 0.2,
        },
        "visualization": {
            "show3D": True,
            "showHeatmap": True,
            "showConvergence": True,
            "figureSize": [1200, 800],
            "localViewKm": 3.0,
            "paperStyle": True,
            "paperDpi": 300,
            "paperFontFamily": "Times New Roman",
        },
        "multiObjectiveMetrics": {
            "enabled": True,
            # Objective vectors saved by MOPSO are already minimization values:
            # handover count, deployment cost, existing-route coverage loss,
            # future-route coverage loss.
            "objectiveNames": [
                "handover_count",
                "deployment_cost",
                "existing_route_continuity_loss",
                "future_route_continuity_loss",
            ],
            "objectiveDirections": ["min", "min", "min", "min"],
            "normalization": {
                "enabled": True,
                # Optional fixed ranges. If omitted, one shared range is estimated
                # from all compared methods and seeds in the same experiment suite.
                "min": None,
                "max": None,
            },
            "hypervolume": {
                # Optional fixed HV reference point in normalized minimization space.
                # If omitted, it is estimated as slightly worse than the worst value.
                "referencePoint": None,
                "autoReferenceMargin": 0.05,
                "maxExactPoints": 16,
                "numSamples": 120000,
                "seed": 2026,
            },
        },
        "proxyData": {
            "cityArea": {
                "name": "proxy_city_bbox",
                "bbox": [0.0, 0.0, 10000.0, 8000.0],
                "polygon": None,
            },
            "existingBaseStations": {
                "numStations": 30,
                "typeProbabilities": {"5G": 0.7, "5GA": 0.3},
                "txPowerDbm": {"5G": [34.0, 42.0], "5GA": [38.0, 46.0]},
                "antennaHeightM": {"5G": [25.0, 45.0], "5GA": [30.0, 60.0]},
            },
            "odPoints": {
                "numAirports": 3,
                "numWaypoints": 20,
                "airportTrafficWeight": [1.5, 3.0],
                "waypointTrafficWeight": [0.5, 1.5],
            },
            "routes": {
                "numRoutes": 60,
                "minCorridorWidthM": 300.0,
                "maxCorridorWidthM": 1200.0,
                "demandNoise": [0.8, 1.2],
            },
            "blindSpotDemand": {
                "gridSpacingM": 250.0,
                "minCoverageRadiusM": 700.0,
                "maxDemandPoints": 2000,
                "altitudeM": 120.0,
            },
            "output": {
                "saveCSV": True,
                "saveGeoJSON": True,
            },
        },
        "save": {
            "saveData": True,
            "saveFigures": True,
            "saveReport": True,
            "saveIntermediateMetrics": True,
        },
    }


def deep_update(base: Config, override: Config) -> Config:
    """Recursively update nested dict config."""
    for key, val in override.items():
        if isinstance(val, dict) and isinstance(base.get(key), dict):
            deep_update(base[key], val)
        else:
            base[key] = val
    return base


def load_and_merge_config(default_cfg: Config, config_path: Optional[str]) -> Config:
    """Load external JSON config and merge into defaults."""
    cfg = json.loads(json.dumps(default_cfg))
    if config_path is None:
        return cfg

    with open(config_path, "r", encoding="utf-8-sig") as f:
        user_cfg = json.load(f)
    deep_update(cfg, user_cfg)
    return cfg


def init_channel_params(config: Config) -> Config:
    """Initialize channel parameters and derive wavelength."""
    frequency = float(config["channel"]["frequency"])
    a2g_cfg = config["channel"].get("a2gProbabilistic", {})
    sector_directions = config["channel"].get(
        "sector_directions_deg",
        [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0],
    )
    return {
        "frequency": frequency,
        "wavelength": 3e8 / frequency,
        "txPower": float(config["channel"]["txPower"]),
        "noisePower": float(config["channel"]["noisePower"]),
        "antennaGain": float(config["channel"].get("antennaGain", 0.0)),
        "penetrationLoss": float(config["channel"].get("penetrationLoss", 20.0)),
        "snrThreshold": float(config["channel"].get("snrThreshold", 0.0)),
        "lowFidelityModel": str(config["channel"].get("lowFidelityModel", "a2g_probabilistic")),
        "a2gProbabilistic": {
            "a": float(a2g_cfg.get("a", 9.61)),
            "b": float(a2g_cfg.get("b", 0.16)),
            "etaLoS": float(a2g_cfg.get("etaLoS", 1.0)),
            "etaNLoS": float(a2g_cfg.get("etaNLoS", 20.0)),
        },
        "sector_directions_deg": [float(v) for v in sector_directions],
        "sector_beamwidth_deg": float(config["channel"].get("sector_beamwidth_deg", 90.0)),
        "outside_sector_mode": str(config["channel"].get("outside_sector_mode", "no_coverage")),
        "side_lobe_attenuation_db": float(config["channel"].get("side_lobe_attenuation_db", 30.0)),
    }
