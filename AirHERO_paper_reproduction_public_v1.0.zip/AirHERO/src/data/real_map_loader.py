﻿from __future__ import annotations

import csv
import json
import sqlite3
import struct
import zlib
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

from src.data.types import Building, CityMap, Config

# Shenyang-wide bbox in WGS84: [min_lon, min_lat, max_lon, max_lat]
DEFAULT_SHENYANG_BBOX = (122.35, 41.18, 123.92, 42.25)


def generate_city_map_from_real_map(config: Config, rng: np.random.Generator) -> CityMap:
    """Load real map, clip by bbox, build city model, and infer landing sites."""
    map_cfg = config["map"]
    size_z = float(map_cfg["sizeZ"])

    map_path = _resolve_map_path(str(map_cfg.get("realMapPath", "liaoning_map.qgz")))
    gpkg_path, qgs_bbox = _resolve_gpkg_and_extent(map_path)
    clip_bbox = _read_clip_bbox(map_cfg) or qgs_bbox or DEFAULT_SHENYANG_BBOX
    min_lon, min_lat, max_lon, max_lat = clip_bbox

    use_geo_distance_scale = bool(map_cfg.get("useGeoDistanceScale", True))
    if use_geo_distance_scale:
        center_lat = 0.5 * (min_lat + max_lat)
        m_per_deg_lon, m_per_deg_lat = _meters_per_degree(center_lat)
        size_x = max((max_lon - min_lon) * m_per_deg_lon, 1.0)
        size_y = max((max_lat - min_lat) * m_per_deg_lat, 1.0)
    else:
        size_x = float(map_cfg["sizeX"])
        size_y = float(map_cfg["sizeY"])
        center_lat = 0.5 * (min_lat + max_lat)
        m_per_deg_lon, m_per_deg_lat = _meters_per_degree(center_lat)

    max_buildings = int(map_cfg.get("realMaxBuildings", 3000))
    max_road_segments = int(map_cfg.get("realMaxRoadSegments", 12000))
    min_h = float(map_cfg.get("realMinBuildingHeight", 12.0))
    max_h = float(map_cfg.get("realMaxBuildingHeight", 120.0))
    subclass_table = _load_subclass_table(map_cfg.get("buildingSubclassFile"))

    buildings, road_segments = _extract_buildings_and_roads(
        gpkg_path=gpkg_path,
        clip_bbox=clip_bbox,
        meter_scale=(m_per_deg_lon, m_per_deg_lat),
        xy_origin=(min_lon, min_lat),
        target_size=(size_x, size_y),
        max_buildings=max_buildings,
        max_road_segments=max_road_segments,
        min_h=min_h,
        max_h=max_h,
        subclass_table=subclass_table,
        rng=rng,
    )
    if not buildings:
        raise RuntimeError(f"No buildings found in real map clip bbox: {clip_bbox}")

    landing_points, landing_labels = _select_landing_points(buildings, map_cfg)
    takeoff_point, touchdown_point = _pick_takeoff_touchdown(landing_points)

    building_bounds = _build_bounds(buildings)
    height_resolution = float(map_cfg.get("heightResolution", 10.0))
    height_matrix = _generate_height_matrix(size_x, size_y, buildings, height_resolution)

    return CityMap(
        size_x=size_x,
        size_y=size_y,
        size_z=size_z,
        buildings=buildings,
        building_bounds=building_bounds,
        height_matrix=height_matrix,
        height_resolution=height_resolution,
        road_segments=road_segments,
        geo_bbox=clip_bbox,
        geo_origin_lonlat=(min_lon, min_lat),
        geo_m_per_deg=(m_per_deg_lon, m_per_deg_lat),
        landing_points=landing_points,
        landing_labels=landing_labels,
        takeoff_point=takeoff_point,
        touchdown_point=touchdown_point,
    )


def _resolve_map_path(path_text: str) -> Path:
    p = Path(path_text).expanduser()
    if not p.is_absolute():
        p = (Path.cwd() / p).resolve()

    candidates = [p]
    if p.suffix == "":
        candidates.extend([p.with_suffix(".qgz"), p.with_suffix(".gpkg")])

    for c in candidates:
        if c.exists():
            return c
    raise FileNotFoundError(f"Real map not found: {path_text}")


def _resolve_gpkg_and_extent(map_path: Path) -> Tuple[Path, Optional[Tuple[float, float, float, float]]]:
    suffix = map_path.suffix.lower()
    if suffix == ".gpkg":
        return map_path, None
    if suffix != ".qgz":
        raise ValueError(f"Unsupported real map file: {map_path.name}")

    with zipfile.ZipFile(map_path, "r") as zf:
        qgs_files = [n for n in zf.namelist() if n.lower().endswith(".qgs")]
        if not qgs_files:
            raise RuntimeError(f"No .qgs found in qgz: {map_path}")
        qgs_data = zf.read(qgs_files[0])
    root = ET.fromstring(qgs_data)

    xmin = _safe_float(root.findtext(".//mapcanvas/extent/xmin")) or _safe_float(root.findtext(".//xmin"))
    ymin = _safe_float(root.findtext(".//mapcanvas/extent/ymin")) or _safe_float(root.findtext(".//ymin"))
    xmax = _safe_float(root.findtext(".//mapcanvas/extent/xmax")) or _safe_float(root.findtext(".//xmax"))
    ymax = _safe_float(root.findtext(".//mapcanvas/extent/ymax")) or _safe_float(root.findtext(".//ymax"))
    extent = (xmin, ymin, xmax, ymax) if None not in (xmin, ymin, xmax, ymax) else None

    gpkg_path = None
    for ds in root.findall(".//maplayer/datasource"):
        txt = ds.text or ""
        if ".gpkg" not in txt.lower():
            continue
        src = txt.split("|", 1)[0]
        candidate = (map_path.parent / src).resolve()
        if candidate.exists():
            gpkg_path = candidate
            break

    if gpkg_path is None:
        raise FileNotFoundError(f"Cannot locate gpkg datasource from qgz: {map_path}")
    return gpkg_path, extent


def _read_clip_bbox(map_cfg: Config) -> Optional[Tuple[float, float, float, float]]:
    raw = map_cfg.get("realClipBbox")
    if raw is None:
        return None
    if not isinstance(raw, (list, tuple)) or len(raw) != 4:
        raise ValueError("map.realClipBbox must be [min_lon, min_lat, max_lon, max_lat]")
    return float(raw[0]), float(raw[1]), float(raw[2]), float(raw[3])


def _load_subclass_table(path_value: Optional[str]) -> Dict[str, Dict[str, object]]:
    """Load optional building subclass labels keyed by osm_id."""
    if not path_value:
        return {}

    p = Path(str(path_value)).expanduser()
    if not p.is_absolute():
        p = (Path.cwd() / p).resolve()
    if not p.exists():
        return {}

    if p.suffix.lower() == ".json":
        with open(p, "r", encoding="utf-8-sig") as f:
            obj = json.load(f)
        if isinstance(obj, dict):
            out: Dict[str, Dict[str, object]] = {}
            for k, v in obj.items():
                if isinstance(v, dict):
                    out[str(k)] = v
            return out
        if isinstance(obj, list):
            out2: Dict[str, Dict[str, object]] = {}
            for item in obj:
                if isinstance(item, dict) and "osm_id" in item:
                    out2[str(item["osm_id"])] = item
            return out2
        return {}

    # default csv format:
    # osm_id,subclass,can_land,priority
    out3: Dict[str, Dict[str, object]] = {}
    with open(p, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            osm_id = str(row.get("osm_id", "")).strip()
            if not osm_id:
                continue
            out3[osm_id] = {
                "subclass": str(row.get("subclass", "")).strip().lower(),
                "can_land": _parse_bool(row.get("can_land")),
                "priority": _safe_float(str(row.get("priority", ""))) or 0.0,
            }
    return out3


def _extract_buildings_and_roads(
    gpkg_path: Path,
    clip_bbox: Tuple[float, float, float, float],
    meter_scale: Tuple[float, float],
    xy_origin: Tuple[float, float],
    target_size: Tuple[float, float],
    max_buildings: int,
    max_road_segments: int,
    min_h: float,
    max_h: float,
    subclass_table: Dict[str, Dict[str, object]],
    rng: np.random.Generator,
) -> Tuple[List[Building], Optional[np.ndarray]]:
    min_lon, min_lat, max_lon, max_lat = clip_bbox
    origin_lon, origin_lat = xy_origin
    m_per_deg_lon, m_per_deg_lat = meter_scale
    size_x, size_y = target_size

    def to_xy(lon: float, lat: float) -> Tuple[float, float]:
        x = (lon - origin_lon) * m_per_deg_lon
        y = (lat - origin_lat) * m_per_deg_lat
        return float(np.clip(x, 0.0, size_x)), float(np.clip(y, 0.0, size_y))

    buildings_with_area: List[Tuple[float, Building]] = []
    road_segments: List[np.ndarray] = []

    con = sqlite3.connect(str(gpkg_path))
    cur = con.cursor()
    try:
        # osm_id / fclass / type are used for building sub-class inference.
        for osm_id, fclass, btype, code, geom in cur.execute(
            "SELECT osm_id, fclass, type, code, geom FROM gis_osm_buildings_a_free"
        ):
            env = _extract_envelope_xy(geom)
            if env is None or not _bbox_intersects(env, clip_bbox):
                continue

            lon0 = max(env[0], min_lon)
            lon1 = min(env[1], max_lon)
            lat0 = max(env[2], min_lat)
            lat1 = min(env[3], max_lat)
            if lon1 <= lon0 or lat1 <= lat0:
                continue

            x0, y0 = to_xy(lon0, lat0)
            x1, y1 = to_xy(lon1, lat1)
            width = max(x1 - x0, 0.0)
            length = max(y1 - y0, 0.0)
            if width < 0.8 or length < 0.8:
                continue

            osm_id_text = str(osm_id or "")
            fclass_text = str(fclass or "").strip().lower()
            btype_text = str(btype or "").strip().lower()
            subclass, manual_priority = _infer_subclass(
                osm_id_text, fclass_text, btype_text, subclass_table
            )
            h = _estimate_height(
                osm_id=osm_id_text,
                fclass=fclass_text,
                btype=btype_text,
                code=code,
                min_h=min_h,
                max_h=max_h,
                rng=rng,
            )
            b = Building(
                x=x0,
                y=y0,
                width=width,
                length=length,
                height=h,
                osm_id=osm_id_text,
                fclass=fclass_text,
                btype=btype_text,
                subclass=subclass,
                landing_priority=float(manual_priority),
            )
            buildings_with_area.append((width * length, b))

        if buildings_with_area:
            buildings_with_area.sort(key=lambda t: t[0], reverse=True)
            buildings = [b for _, b in buildings_with_area[:max_buildings]]
        else:
            buildings = []

        if max_road_segments > 0:
            for geom, in cur.execute("SELECT geom FROM gis_osm_roads_free"):
                env = _extract_envelope_xy(geom)
                if env is None or not _bbox_intersects(env, clip_bbox):
                    continue

                lines = _extract_lines_xy(geom)
                for line in lines:
                    if line.shape[0] < 2:
                        continue
                    xy = np.array([to_xy(float(p[0]), float(p[1])) for p in line], dtype=float)
                    for i in range(xy.shape[0] - 1):
                        p0 = xy[i]
                        p1 = xy[i + 1]
                        if np.allclose(p0, p1):
                            continue
                        road_segments.append(np.vstack([p0, p1]))
                        if len(road_segments) >= max_road_segments:
                            break
                    if len(road_segments) >= max_road_segments:
                        break
                if len(road_segments) >= max_road_segments:
                    break
    finally:
        con.close()

    roads_arr = np.asarray(road_segments, dtype=float) if road_segments else None
    return buildings, roads_arr


def _infer_subclass(
    osm_id: str,
    fclass: str,
    btype: str,
    table: Dict[str, Dict[str, object]],
) -> Tuple[str, float]:
    """Infer building subclass from manual table first, then heuristics."""
    if osm_id in table:
        row = table[osm_id]
        can_land = bool(row.get("can_land", True))
        if not can_land:
            return "blocked", -1.0
        s = str(row.get("subclass", "") or "").strip().lower()
        if s:
            return s, float(row.get("priority", 0.0) or 0.0)

    text = f"{fclass} {btype}".lower()
    if any(k in text for k in ("hospital", "clinic", "medical")):
        return "medical", 1.0
    if any(k in text for k in ("school", "college", "university", "campus")):
        return "education", 0.8
    if any(k in text for k in ("office", "commercial", "retail", "mall", "bank")):
        return "commercial", 0.9
    if any(k in text for k in ("industrial", "warehouse", "factory")):
        return "industrial", 0.7
    if any(k in text for k in ("government", "public", "townhall", "civic")):
        return "public_service", 0.9
    if any(k in text for k in ("transport", "station", "terminal", "airport")):
        return "transport", 1.0
    if any(k in text for k in ("residential", "apartments", "house", "dormitory")):
        return "residential", 0.3
    return "other", 0.2


def _estimate_height(
    osm_id: str,
    fclass: str,
    btype: str,
    code: Optional[int],
    min_h: float,
    max_h: float,
    rng: np.random.Generator,
) -> float:
    """Estimate height when explicit level/height attributes are unavailable."""
    text = f"{fclass} {btype}".lower()
    if any(k in text for k in ("industrial", "commercial", "office", "retail")):
        base, span = 28.0, 52.0
    elif any(k in text for k in ("residential", "apartments", "house")):
        base, span = 12.0, 28.0
    elif any(k in text for k in ("hospital", "school", "public", "transport")):
        base, span = 20.0, 38.0
    else:
        base, span = 15.0, 35.0

    token = f"{osm_id}|{fclass}|{btype}|{code}".encode("utf-8", errors="ignore")
    seed = zlib.crc32(token) & 0xFFFFFFFF
    local = np.random.default_rng(seed)
    h = base + local.random() * span + (rng.random() - 0.5) * 4.0
    return float(np.clip(h, min_h, max_h))


def _select_landing_points(
    buildings: List[Building], map_cfg: Config
) -> Tuple[Optional[np.ndarray], Optional[List[str]]]:
    """Select rooftop landing candidates by subclass and geometry constraints."""
    landing_cfg = map_cfg.get("landingSelection", {})
    enabled = bool(landing_cfg.get("enabled", True))
    if not enabled or not buildings:
        return None, None

    allowed = landing_cfg.get(
        "allowedSubclasses",
        ["transport", "public_service", "commercial", "industrial", "medical"],
    )
    allowed_set = {str(x).strip().lower() for x in allowed}
    excluded = landing_cfg.get("excludedSubclasses", [])
    excluded_set = {str(x).strip().lower() for x in excluded}

    min_area = float(landing_cfg.get("minRoofArea", 1800.0))
    min_height = float(landing_cfg.get("minBuildingHeight", 15.0))
    max_sites = int(landing_cfg.get("maxSites", 12))
    min_sep = float(landing_cfg.get("minSiteSeparation", 220.0))

    # Optional manual whitelist by osm_id.
    allow_osm = landing_cfg.get("allowOsmIds", [])
    allow_osm_set = {str(x) for x in allow_osm}

    candidates: List[Tuple[float, np.ndarray, str]] = []
    for b in buildings:
        area = b.width * b.length
        if area < min_area or b.height < min_height:
            continue
        subclass = (b.subclass or "").lower()
        if allow_osm_set and b.osm_id not in allow_osm_set:
            continue
        if subclass in excluded_set:
            continue
        if allowed_set and subclass not in allowed_set:
            continue

        # Prefer large/high/public buildings.
        score = (
            0.45 * np.log1p(area)
            + 0.35 * b.height
            + 80.0 * float(b.landing_priority)
        )
        p = np.array([b.x + b.width * 0.5, b.y + b.length * 0.5, b.height + 5.0], dtype=float)
        label = f"{subclass}|osm:{b.osm_id}" if b.osm_id else subclass
        candidates.append((float(score), p, label))

    if not candidates:
        # Relaxed fallback: if subclass tags are sparse, use geometric quality only.
        for b in buildings:
            area = max(b.width * b.length, 1.0)
            score = 0.55 * np.log1p(area) + 0.45 * b.height
            p = np.array([b.x + b.width * 0.5, b.y + b.length * 0.5, b.height + 5.0], dtype=float)
            label = f"fallback|{b.subclass or 'unknown'}|osm:{b.osm_id}" if b.osm_id else "fallback"
            candidates.append((float(score), p, label))
        if not candidates:
            return None, None
    candidates.sort(key=lambda t: t[0], reverse=True)

    selected_points: List[np.ndarray] = []
    selected_labels: List[str] = []
    for _, p, label in candidates:
        if not selected_points:
            selected_points.append(p)
            selected_labels.append(label)
        else:
            dist = [np.linalg.norm(p[:2] - q[:2]) for q in selected_points]
            if min(dist) >= min_sep:
                selected_points.append(p)
                selected_labels.append(label)
        if len(selected_points) >= max_sites:
            break

    if not selected_points:
        return None, None
    return np.asarray(selected_points, dtype=float), selected_labels


def _pick_takeoff_touchdown(
    landing_points: Optional[np.ndarray],
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """Derive one takeoff and one touchdown point from candidate sites."""
    if landing_points is None or landing_points.size == 0:
        return None, None
    if landing_points.shape[0] == 1:
        p = landing_points[0].copy()
        return p, p.copy()

    # For south-to-north missions: lowest-y as takeoff, highest-y as touchdown.
    idx_takeoff = int(np.argmin(landing_points[:, 1]))
    idx_touch = int(np.argmax(landing_points[:, 1]))
    return landing_points[idx_takeoff].copy(), landing_points[idx_touch].copy()


def _extract_envelope_xy(blob: bytes) -> Optional[Tuple[float, float, float, float]]:
    if not blob or len(blob) < 8 or blob[0:2] != b"GP":
        return None

    flags = blob[3]
    envelope_code = (flags >> 1) & 0x07
    endian = "<" if (flags & 0x01) else ">"
    if envelope_code == 0:
        return None

    minx, maxx, miny, maxy = struct.unpack_from(endian + "4d", blob, 8)
    return float(minx), float(maxx), float(miny), float(maxy)


def _extract_lines_xy(blob: bytes) -> List[np.ndarray]:
    wkb = _extract_wkb(blob)
    lines, _ = _parse_wkb_lines(wkb, 0)
    return lines


def _extract_wkb(blob: bytes) -> bytes:
    flags = blob[3]
    envelope_code = (flags >> 1) & 0x07
    envelope_sizes = {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}
    header_len = 8 + envelope_sizes.get(envelope_code, 0)
    return blob[header_len:]


def _parse_wkb_lines(data: bytes, offset: int) -> Tuple[List[np.ndarray], int]:
    if offset >= len(data):
        return [], offset

    byte_order = data[offset]
    endian = "<" if byte_order == 1 else ">"
    geom_type = struct.unpack_from(endian + "I", data, offset + 1)[0]
    base_type, dims = _decode_wkb_type(geom_type)
    stride = 8 * dims

    if base_type == 2:  # LineString
        n = struct.unpack_from(endian + "I", data, offset + 5)[0]
        cursor = offset + 9
        pts = np.zeros((n, 2), dtype=float)
        for i in range(n):
            pts[i, 0] = struct.unpack_from(endian + "d", data, cursor)[0]
            pts[i, 1] = struct.unpack_from(endian + "d", data, cursor + 8)[0]
            cursor += stride
        return [pts], cursor

    if base_type == 5:  # MultiLineString
        n = struct.unpack_from(endian + "I", data, offset + 5)[0]
        cursor = offset + 9
        lines: List[np.ndarray] = []
        for _ in range(n):
            sub_lines, cursor = _parse_wkb_lines(data, cursor)
            lines.extend(sub_lines)
        return lines, cursor

    return [], len(data)


def _decode_wkb_type(geom_type: int) -> Tuple[int, int]:
    has_z = False
    has_m = False
    base = geom_type

    if geom_type >= 3000:
        base = geom_type - 3000
        has_z = True
        has_m = True
    elif geom_type >= 2000:
        base = geom_type - 2000
        has_m = True
    elif geom_type >= 1000:
        base = geom_type - 1000
        has_z = True
    elif geom_type & 0x80000000:
        base = geom_type & 0x000000FF
        has_z = True

    dims = 2 + int(has_z) + int(has_m)
    return int(base), int(dims)


def _bbox_intersects(
    env: Tuple[float, float, float, float], bbox: Tuple[float, float, float, float]
) -> bool:
    # env: minx, maxx, miny, maxy ; bbox: min_lon, min_lat, max_lon, max_lat
    return not (env[1] < bbox[0] or env[0] > bbox[2] or env[3] < bbox[1] or env[2] > bbox[3])


def _parse_bool(value: object) -> bool:
    txt = str(value or "").strip().lower()
    return txt in {"1", "true", "yes", "y", "t"}


def _safe_float(value: Optional[str]) -> Optional[float]:
    if value is None:
        return None
    try:
        return float(value)
    except Exception:
        return None


def _meters_per_degree(lat_deg: float) -> Tuple[float, float]:
    """Approximate meter-per-degree for WGS84 at given latitude."""
    lat = np.deg2rad(lat_deg)
    # More accurate than constant sphere for regional-scale distance rendering.
    m_per_deg_lat = (
        111132.92
        - 559.82 * np.cos(2.0 * lat)
        + 1.175 * np.cos(4.0 * lat)
        - 0.0023 * np.cos(6.0 * lat)
    )
    m_per_deg_lon = (
        111412.84 * np.cos(lat)
        - 93.5 * np.cos(3.0 * lat)
        + 0.118 * np.cos(5.0 * lat)
    )
    return float(m_per_deg_lon), float(m_per_deg_lat)


def _build_bounds(buildings: List[Building]) -> np.ndarray:
    if not buildings:
        return np.zeros((0, 6), dtype=float)

    arr = np.zeros((len(buildings), 6), dtype=float)
    for i, b in enumerate(buildings):
        arr[i] = [b.x, b.x + b.width, b.y, b.y + b.length, 0.0, b.height]
    return arr


def _generate_height_matrix(
    size_x: float, size_y: float, buildings: List[Building], resolution: float
) -> np.ndarray:
    nx = int(np.floor(size_x / resolution)) + 1
    ny = int(np.floor(size_y / resolution)) + 1
    h = np.zeros((ny, nx), dtype=float)

    for b in buildings:
        x0 = int(np.floor(b.x / resolution))
        x1 = int(np.ceil((b.x + b.width) / resolution))
        y0 = int(np.floor(b.y / resolution))
        y1 = int(np.ceil((b.y + b.length) / resolution))
        x0 = max(0, min(nx - 1, x0))
        x1 = max(0, min(nx - 1, x1))
        y0 = max(0, min(ny - 1, y0))
        y1 = max(0, min(ny - 1, y1))
        h[y0 : y1 + 1, x0 : x1 + 1] = np.maximum(h[y0 : y1 + 1, x0 : x1 + 1], b.height)

    return h

