from __future__ import annotations

import csv
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from src.data.types import AirRoute, CityMap, Config

GENERATED_FUTURE_AIRWAY_LABEL = "GENERATED_FUTURE_AIRWAY"
PROXY_POI_LABEL = "SIMULATED_PROXY_POI"
VALID_POI_TYPES = {"logistics_center", "hospital", "business_district"}
TARGET_POI_TYPES = {"hospital", "business_district"}


@dataclass(frozen=True)
class POIRecord:
    """Candidate takeoff/landing POI used for future-airway generation."""

    poi_id: str
    name: str
    poi_type: str
    x_m: float
    y_m: float
    lon: Optional[float] = None
    lat: Optional[float] = None
    source: str = "real"
    demand_weight: float = 1.0


@dataclass(frozen=True)
class FutureAirwayRoute:
    """Generated route from one logistics root to one target POI."""

    route_id: str
    root_logistics_id: str
    target_id: str
    target_type: str
    node_sequence: List[str]
    total_distance: float
    num_hops: int
    route_weight: float
    source: str


@dataclass
class FutureAirwayResult:
    """In-memory future-airway generation output."""

    pois: List[POIRecord]
    routes: List[FutureAirwayRoute]
    graph: Dict[str, List[str]]
    unreachable_targets: List[Dict[str, object]]
    unselected_reachable_targets: List[Dict[str, object]]
    output_paths: Dict[str, str]
    stats: Dict[str, float]


def generate_future_airways(
    config: Config,
    rng: Optional[np.random.Generator] = None,
    output_dir: Optional[Path] = None,
    city_map: Optional[CityMap] = None,
    poi_records: Optional[Sequence[POIRecord | Dict[str, object]]] = None,
) -> FutureAirwayResult:
    """Generate POI-based future airways without modifying optimizer behavior."""
    fwa_cfg = _merge_future_airway_defaults(config.get("futureAirway", {}))
    seed = int(fwa_cfg["routeGeneration"].get("random_seed", 42))
    local_rng = rng if rng is not None else np.random.default_rng(seed)
    out_dir = Path(output_dir) if output_dir is not None else Path("artifacts/future_airway_generation")
    out_dir.mkdir(parents=True, exist_ok=True)

    pois = load_or_extract_pois(
        config=fwa_cfg,
        rng=local_rng,
        city_map=city_map,
        poi_records=poi_records,
    )
    candidates = filter_candidate_pois(pois)
    graph = build_candidate_graph(candidates, fwa_cfg["graph"])
    routes_all = generate_routes_dfs(candidates, graph, fwa_cfg["routeGeneration"], local_rng)
    routes = select_routes(routes_all, candidates, fwa_cfg["routeGeneration"], local_rng)

    unreachable = find_unreachable_targets(candidates, graph)
    selected_targets = {r.target_id for r in routes}
    reachable_targets = {
        p.poi_id
        for p in candidates
        if p.poi_type in TARGET_POI_TYPES and p.poi_id not in {str(u["poi_id"]) for u in unreachable}
    }
    unselected = [
        {
            "poi_id": p.poi_id,
            "poi_type": p.poi_type,
            "name": p.name,
            "reason": "reachable_but_not_selected_due_to_route_limits",
        }
        for p in candidates
        if p.poi_id in reachable_targets and p.poi_id not in selected_targets
    ]

    output_paths = save_future_airway_outputs(
        pois=candidates,
        routes=routes,
        graph=graph,
        unreachable_targets=unreachable,
        output_dir=out_dir,
        output_cfg=fwa_cfg["output"],
    )
    if bool(fwa_cfg["visualization"].get("enabled", True)):
        output_paths["route_plot_png"] = str(
            plot_future_airways(
                pois=candidates,
                routes=routes,
                output_path=out_dir / "future_airway_routes.png",
            ).resolve()
        )

    stats = {
        "num_pois": float(len(candidates)),
        "num_logistics_centers": float(sum(p.poi_type == "logistics_center" for p in candidates)),
        "num_hospitals": float(sum(p.poi_type == "hospital" for p in candidates)),
        "num_business_districts": float(sum(p.poi_type == "business_district" for p in candidates)),
        "num_generated_candidate_routes": float(len(routes_all)),
        "num_selected_routes": float(len(routes)),
        "num_unreachable_targets": float(len(unreachable)),
        "num_unselected_reachable_targets": float(len(unselected)),
    }
    with open(out_dir / "future_airway_stats.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "data_label": GENERATED_FUTURE_AIRWAY_LABEL,
                "stats": stats,
                "unreachable_targets": unreachable,
                "unselected_reachable_targets": unselected,
            },
            f,
            ensure_ascii=False,
            indent=2,
        )
    output_paths["stats_json"] = str((out_dir / "future_airway_stats.json").resolve())

    return FutureAirwayResult(
        pois=candidates,
        routes=routes,
        graph=graph,
        unreachable_targets=unreachable,
        unselected_reachable_targets=unselected,
        output_paths=output_paths,
        stats=stats,
    )


def load_or_extract_pois(
    config: Config,
    rng: np.random.Generator,
    city_map: Optional[CityMap] = None,
    poi_records: Optional[Sequence[POIRecord | Dict[str, object]]] = None,
) -> List[POIRecord]:
    """Load real/provided POIs or explicitly generate proxy POIs."""
    if poi_records is not None:
        return [_coerce_poi_record(row) for row in poi_records]

    source_cfg = config.get("poiSource", {})
    mode = str(source_cfg.get("mode", "proxy")).strip().lower()
    if mode == "csv":
        path = source_cfg.get("poiFile", None)
        if not path:
            raise ValueError("futureAirway.poiSource.poiFile is required when mode='csv'")
        return load_pois_from_csv(Path(str(path)))

    if mode == "map_buildings":
        if city_map is None:
            raise ValueError("city_map is required for futureAirway.poiSource.mode='map_buildings'")
        return extract_pois_from_city_map(city_map=city_map, config=config)

    if mode == "proxy":
        proxy_cfg = config.get("proxyPoi", {})
        return generate_proxy_pois(proxy_cfg, rng)

    raise ValueError(f"Unsupported futureAirway.poiSource.mode: {mode}")


def load_pois_from_csv(path: Path) -> List[POIRecord]:
    """Load POIs from a CSV file with the standard POI schema."""
    rows: List[POIRecord] = []
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for raw in reader:
            rows.append(_coerce_poi_record(raw))
    return rows


def extract_pois_from_city_map(city_map: CityMap, config: Config) -> List[POIRecord]:
    """Extract POIs from CityMap buildings using configurable keyword rules."""
    cls_cfg = config.get("poiClassification", {})
    filt_cfg = config.get("candidateFiltering", {})
    min_area = float(filt_cfg.get("minRoofArea", 0.0))
    min_height = float(filt_cfg.get("minBuildingHeight", 0.0))
    max_per_type = int(filt_cfg.get("maxCandidatesPerType", 1000000))

    grouped: Dict[str, List[Tuple[float, POIRecord]]] = {k: [] for k in VALID_POI_TYPES}
    for idx, b in enumerate(city_map.buildings, start=1):
        area = float(b.width * b.length)
        if area < min_area or float(b.height) < min_height:
            continue
        poi_type = classify_poi_type(
            text=f"{b.subclass} {b.fclass} {b.btype}",
            classification_cfg=cls_cfg,
        )
        if poi_type is None:
            continue
        lon, lat = _xy_to_lonlat(
            x=float(b.x + b.width * 0.5),
            y=float(b.y + b.length * 0.5),
            city_map=city_map,
        )
        score = float(np.log1p(max(area, 1.0)) + 0.1 * float(b.height) + float(b.landing_priority))
        poi = POIRecord(
            poi_id=f"map_poi_{idx:05d}",
            name=f"{poi_type}_{b.osm_id or idx}",
            poi_type=poi_type,
            x_m=float(b.x + b.width * 0.5),
            y_m=float(b.y + b.length * 0.5),
            lon=lon,
            lat=lat,
            source="real",
            demand_weight=max(float(b.landing_priority), 1.0),
        )
        grouped[poi_type].append((score, poi))

    out: List[POIRecord] = []
    for poi_type, items in grouped.items():
        items.sort(key=lambda x: x[0], reverse=True)
        out.extend([p for _, p in items[:max_per_type]])
    return out


def generate_proxy_pois(proxy_cfg: Config, rng: np.random.Generator) -> List[POIRecord]:
    """Generate clearly labeled proxy POIs for tests/demos only."""
    bbox = proxy_cfg.get("bbox", [0.0, 0.0, 1000.0, 800.0])
    if not isinstance(bbox, list) or len(bbox) != 4:
        raise ValueError("futureAirway.proxyPoi.bbox must be [min_x,min_y,max_x,max_y]")
    min_x, min_y, max_x, max_y = [float(v) for v in bbox]
    counts = proxy_cfg.get("counts", {})
    count_map = {
        "logistics_center": int(counts.get("logistics_center", 2)),
        "hospital": int(counts.get("hospital", 3)),
        "business_district": int(counts.get("business_district", 3)),
    }

    pois: List[POIRecord] = []
    for poi_type, n in count_map.items():
        for i in range(1, n + 1):
            pois.append(
                POIRecord(
                    poi_id=f"{poi_type[:3]}_{i:03d}",
                    name=f"proxy_{poi_type}_{i}",
                    poi_type=poi_type,
                    x_m=float(rng.uniform(min_x, max_x)),
                    y_m=float(rng.uniform(min_y, max_y)),
                    lon=None,
                    lat=None,
                    source="proxy",
                    demand_weight=float(rng.uniform(0.5, 2.0)),
                )
            )
    return pois


def classify_poi_type(text: str, classification_cfg: Config) -> Optional[str]:
    """Classify raw POI/building text into one of the supported POI types."""
    s = str(text).strip().lower()
    keyword_map = {
        "logistics_center": classification_cfg.get(
            "logisticsKeywords",
            ["logistics", "warehouse", "distribution", "freight", "industrial"],
        ),
        "hospital": classification_cfg.get("hospitalKeywords", ["hospital", "clinic", "medical"]),
        "business_district": classification_cfg.get(
            "businessKeywords",
            ["commercial", "office", "business", "mall", "retail"],
        ),
    }
    for poi_type, keywords in keyword_map.items():
        if any(str(k).lower() in s for k in keywords):
            return poi_type
    return None


def filter_candidate_pois(pois: Sequence[POIRecord]) -> List[POIRecord]:
    """Keep valid POI types and validate roots/targets exist."""
    out = [p for p in pois if p.poi_type in VALID_POI_TYPES]
    if not any(p.poi_type == "logistics_center" for p in out):
        raise ValueError("Future-airway generation requires at least one logistics_center POI")
    if not any(p.poi_type in TARGET_POI_TYPES for p in out):
        raise ValueError("Future-airway generation requires at least one hospital or business_district POI")
    return out


def build_candidate_graph(pois: Sequence[POIRecord], graph_cfg: Config) -> Dict[str, List[str]]:
    """Build an undirected candidate graph with configurable distance/kNN filters."""
    max_edge_distance = float(graph_cfg.get("max_edge_distance", graph_cfg.get("maxEdgeDistanceM", 5000.0)))
    k_nearest = graph_cfg.get("k_nearest_neighbors", graph_cfg.get("kNearestNeighbors", None))
    k_nearest_int = None if k_nearest is None else int(k_nearest)
    allowed = _parse_allowed_connection_types(graph_cfg.get("allowed_connection_types", None))

    graph: Dict[str, List[str]] = {p.poi_id: [] for p in pois}
    by_id = {p.poi_id: p for p in pois}
    distances: Dict[str, List[Tuple[float, str]]] = {p.poi_id: [] for p in pois}

    for i in range(len(pois)):
        for j in range(i + 1, len(pois)):
            a = pois[i]
            b = pois[j]
            if not _is_connection_type_allowed(a.poi_type, b.poi_type, allowed):
                continue
            d = _distance_poi(a, b)
            if d <= max_edge_distance:
                distances[a.poi_id].append((d, b.poi_id))
                distances[b.poi_id].append((d, a.poi_id))

    for poi_id, neigh in distances.items():
        neigh.sort(key=lambda x: (x[0], x[1]))
        chosen = neigh if k_nearest_int is None or k_nearest_int <= 0 else neigh[:k_nearest_int]
        for _, nid in chosen:
            if nid not in graph[poi_id]:
                graph[poi_id].append(nid)
            if poi_id not in graph[nid]:
                graph[nid].append(poi_id)

    for nid in graph:
        graph[nid].sort(key=lambda x: (_distance_poi(by_id[nid], by_id[x]), x))
    return graph


def generate_routes_dfs(
    pois: Sequence[POIRecord],
    graph: Dict[str, List[str]],
    route_cfg: Config,
    rng: np.random.Generator,
) -> List[FutureAirwayRoute]:
    """Generate all capped DFS routes from logistics roots to target POIs."""
    max_depth = int(max(1, route_cfg.get("max_depth", route_cfg.get("maxDepth", 2))))
    hard_cap = int(max(1, route_cfg.get("dfsCandidateRouteCap", 5000)))
    by_id = {p.poi_id: p for p in pois}
    roots = [p for p in pois if p.poi_type == "logistics_center"]

    raw_routes: List[FutureAirwayRoute] = []
    seen_sequences: set[Tuple[str, ...]] = set()
    for root in roots:
        stack: List[Tuple[str, List[str], float]] = [(root.poi_id, [root.poi_id], 0.0)]
        while stack and len(raw_routes) < hard_cap:
            node_id, path, dist_so_far = stack.pop()
            if len(path) - 1 >= max_depth:
                continue
            neighbors = list(graph.get(node_id, []))
            # DFS ordering remains deterministic unless route strategy later randomizes selection.
            neighbors.sort(reverse=True)
            for next_id in neighbors:
                if next_id in path:
                    continue
                nxt = by_id[next_id]
                new_path = path + [next_id]
                new_dist = dist_so_far + _distance_poi(by_id[node_id], nxt)
                if nxt.poi_type in TARGET_POI_TYPES:
                    seq = tuple(new_path)
                    if seq not in seen_sequences:
                        seen_sequences.add(seq)
                        route_type = "logistics_to_hospital" if nxt.poi_type == "hospital" else "logistics_to_business"
                        raw_routes.append(
                            FutureAirwayRoute(
                                route_id=f"future_route_{len(raw_routes) + 1:05d}",
                                root_logistics_id=root.poi_id,
                                target_id=nxt.poi_id,
                                target_type=nxt.poi_type,
                                node_sequence=new_path,
                                total_distance=float(new_dist),
                                num_hops=int(len(new_path) - 1),
                                route_weight=float(max(nxt.demand_weight, 1e-9)),
                                source=_route_source([by_id[x] for x in new_path]),
                            )
                        )
                if nxt.poi_type == "logistics_center":
                    stack.append((next_id, new_path, new_dist))
    return raw_routes


def select_routes(
    routes: Sequence[FutureAirwayRoute],
    pois: Sequence[POIRecord],
    route_cfg: Config,
    rng: np.random.Generator,
) -> List[FutureAirwayRoute]:
    """Select routes with total/root/type caps and configured strategy."""
    max_total = int(max(0, route_cfg.get("max_total_routes", route_cfg.get("maxTotalRoutes", 30))))
    max_per_root = int(max(1, route_cfg.get("max_routes_per_logistics_center", route_cfg.get("maxRoutesPerLogisticsCenter", 1000000))))
    max_per_type = int(max(1, route_cfg.get("max_routes_per_target_type", route_cfg.get("maxRoutesPerTargetType", 1000000))))
    strategy = str(route_cfg.get("route_selection_strategy", route_cfg.get("routeSelectionStrategy", "shortest_first"))).lower()

    route_list = list(routes)
    if strategy == "shortest_first":
        ordered = sorted(route_list, key=lambda r: (r.total_distance, r.root_logistics_id, r.target_id, tuple(r.node_sequence)))
    elif strategy == "random":
        ordered = route_list.copy()
        rng.shuffle(ordered)
    elif strategy == "demand_weighted":
        ordered = _weighted_route_order(route_list, rng)
    else:
        raise ValueError(f"Unsupported route_selection_strategy: {strategy}")

    selected: List[FutureAirwayRoute] = []
    root_count: Dict[str, int] = {}
    type_count: Dict[str, int] = {}
    seen_seq: set[Tuple[str, ...]] = set()
    for route in ordered:
        if len(selected) >= max_total:
            break
        seq_key = tuple(route.node_sequence)
        if seq_key in seen_seq:
            continue
        if route.node_sequence[0] != route.root_logistics_id:
            continue
        root_count.setdefault(route.root_logistics_id, 0)
        type_count.setdefault(route.target_type, 0)
        if root_count[route.root_logistics_id] >= max_per_root:
            continue
        if type_count[route.target_type] >= max_per_type:
            continue
        selected.append(_renumber_route(route, len(selected) + 1))
        seen_seq.add(seq_key)
        root_count[route.root_logistics_id] += 1
        type_count[route.target_type] += 1
    return selected


def find_unreachable_targets(pois: Sequence[POIRecord], graph: Dict[str, List[str]]) -> List[Dict[str, object]]:
    """Report hospital/business targets that cannot be reached from any logistics root."""
    by_id = {p.poi_id: p for p in pois}
    roots = [p.poi_id for p in pois if p.poi_type == "logistics_center"]
    reachable: set[str] = set()
    for root in roots:
        stack = [root]
        seen = {root}
        while stack:
            curr = stack.pop()
            reachable.add(curr)
            for nxt in graph.get(curr, []):
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)

    out: List[Dict[str, object]] = []
    for poi in pois:
        if poi.poi_type not in TARGET_POI_TYPES or poi.poi_id in reachable:
            continue
        nearest_id, nearest_d = _nearest_logistics(poi, [by_id[r] for r in roots])
        out.append(
            {
                "poi_id": poi.poi_id,
                "name": poi.name,
                "poi_type": poi.poi_type,
                "x_m": float(poi.x_m),
                "y_m": float(poi.y_m),
                "nearest_logistics_id": nearest_id,
                "nearest_logistics_distance_m": float(nearest_d),
                "reason": "no_path_from_logistics_root",
                "data_label": GENERATED_FUTURE_AIRWAY_LABEL,
            }
        )
    return out


def save_future_airway_outputs(
    pois: Sequence[POIRecord],
    routes: Sequence[FutureAirwayRoute],
    graph: Dict[str, List[str]],
    unreachable_targets: Sequence[Dict[str, object]],
    output_dir: Path,
    output_cfg: Config,
) -> Dict[str, str]:
    """Save POIs/routes/reports as CSV and GeoJSON."""
    output_dir.mkdir(parents=True, exist_ok=True)
    paths: Dict[str, str] = {}
    if bool(output_cfg.get("saveCSV", True)):
        paths["pois_csv"] = _write_csv(output_dir / "future_airway_pois.csv", [_poi_to_row(p) for p in pois])
        paths["routes_csv"] = _write_csv(output_dir / "future_airway_routes.csv", [_route_to_row(r) for r in routes])
        paths["graph_csv"] = _write_csv(output_dir / "future_airway_graph_edges.csv", _graph_to_rows(graph, pois))
        if bool(output_cfg.get("saveUnreachableReport", True)):
            paths["unreachable_csv"] = _write_csv(
                output_dir / "future_airway_unreachable_targets.csv",
                list(unreachable_targets),
            )
    if bool(output_cfg.get("saveGeoJSON", True)):
        paths["pois_geojson"] = _write_pois_geojson(output_dir / "future_airway_pois.geojson", pois)
        paths["routes_geojson"] = _write_routes_geojson(output_dir / "future_airway_routes.geojson", routes, pois)
    return paths


def plot_future_airways(
    pois: Sequence[POIRecord],
    routes: Sequence[FutureAirwayRoute],
    output_path: Path,
) -> Path:
    """Plot POIs with distinct markers and generated routes."""
    mpl_cache = Path(".mplcache").resolve()
    mpl_cache.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(mpl_cache))
    import matplotlib.pyplot as plt

    output_path.parent.mkdir(parents=True, exist_ok=True)
    by_id = {p.poi_id: p for p in pois}
    fig, ax = plt.subplots(figsize=(8.0, 6.2))
    styles = {
        "logistics_center": ("s", "#1B9E77", "Logistics centers"),
        "hospital": ("^", "#D95F02", "Hospitals"),
        "business_district": ("o", "#7570B3", "Business districts"),
    }
    for route in routes:
        pts = [by_id[x] for x in route.node_sequence if x in by_id]
        if len(pts) >= 2:
            ax.plot([p.x_m for p in pts], [p.y_m for p in pts], color="#555555", alpha=0.45, linewidth=1.2)

    for poi_type, (marker, color, label) in styles.items():
        pts = [p for p in pois if p.poi_type == poi_type]
        if not pts:
            continue
        ax.scatter(
            [p.x_m for p in pts],
            [p.y_m for p in pts],
            marker=marker,
            s=62,
            color=color,
            edgecolors="black",
            linewidths=0.4,
            label=label,
            zorder=3,
        )
    ax.set_title("Generated Future Airways from POI Roots")
    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)
    return output_path


def discretize_future_airway_routes(
    result: FutureAirwayResult,
    config: Config,
    rng: np.random.Generator,
) -> AirRoute:
    """Convert generated future airway routes into an AirRoute object for later pipeline wiring."""
    disc_cfg = _merge_future_airway_defaults(config.get("futureAirway", {}))["discretization"]
    min_alt = float(disc_cfg.get("minAltitude", 80.0))
    max_alt = float(disc_cfg.get("maxAltitude", 180.0))
    points_per_segment = int(disc_cfg.get("pointsPerSegment", 30))
    num_segments = int(disc_cfg.get("numSegments", 8))
    grid_size = float(disc_cfg.get("gridSize", 30.0))
    mid_alt = 0.5 * (min_alt + max_alt)
    by_id = {p.poi_id: p for p in result.pois}

    route_pairs: List[Tuple[np.ndarray, np.ndarray]] = []
    pts: List[np.ndarray] = []
    for route in result.routes:
        seq = [by_id[n] for n in route.node_sequence if n in by_id]
        for a, b in zip(seq[:-1], seq[1:]):
            start = np.asarray([a.x_m, a.y_m, mid_alt], dtype=float)
            end = np.asarray([b.x_m, b.y_m, mid_alt], dtype=float)
            route_pairs.append((start, end))
            for k in range(max(points_per_segment, 1)):
                t = float(k) / float(max(points_per_segment - 1, 1))
                p = (1.0 - t) * start + t * end
                p[2] = float(rng.uniform(min_alt, max_alt))
                pts.append(p)

    test_points = np.asarray(pts, dtype=float) if pts else np.zeros((0, 3), dtype=float)
    return AirRoute(
        routes=route_pairs,
        num_segments=num_segments,
        points_per_segment=points_per_segment,
        min_altitude=min_alt,
        max_altitude=max_alt,
        grid_size=grid_size,
        test_points=test_points,
    )


def _merge_future_airway_defaults(user_cfg: Config) -> Config:
    cfg: Config = {
        "enabled": False,
        "mode": "poi_dfs",
        "dataLabel": GENERATED_FUTURE_AIRWAY_LABEL,
        "poiSource": {"mode": "proxy", "poiFile": None},
        "poiClassification": {
            "logisticsKeywords": ["logistics", "warehouse", "distribution", "freight", "industrial"],
            "hospitalKeywords": ["hospital", "clinic", "medical"],
            "businessKeywords": ["commercial", "office", "business", "mall", "retail"],
        },
        "candidateFiltering": {
            "minRoofArea": 0.0,
            "minBuildingHeight": 0.0,
            "maxCandidatesPerType": 50,
        },
        "graph": {
            "max_edge_distance": 5000.0,
            "k_nearest_neighbors": None,
            "allowed_connection_types": [
                ["logistics_center", "logistics_center"],
                ["logistics_center", "hospital"],
                ["logistics_center", "business_district"],
            ],
        },
        "routeGeneration": {
            "max_total_routes": 30,
            "max_routes_per_logistics_center": 20,
            "max_routes_per_target_type": 20,
            "random_seed": 42,
            "route_selection_strategy": "shortest_first",
            "max_depth": 2,
            "dfsCandidateRouteCap": 5000,
        },
        "discretization": {
            "numSegments": 8,
            "pointsPerSegment": 30,
            "minAltitude": 80.0,
            "maxAltitude": 180.0,
            "gridSize": 30.0,
        },
        "proxyPoi": {
            "bbox": [0.0, 0.0, 1000.0, 800.0],
            "counts": {"logistics_center": 2, "hospital": 3, "business_district": 3},
        },
        "visualization": {"enabled": True},
        "output": {"saveCSV": True, "saveGeoJSON": True, "saveUnreachableReport": True},
    }
    _deep_update(cfg, dict(user_cfg))
    return cfg


def _deep_update(base: Config, override: Config) -> None:
    for key, val in override.items():
        if isinstance(val, dict) and isinstance(base.get(key), dict):
            _deep_update(base[key], val)
        else:
            base[key] = val


def _coerce_poi_record(row: POIRecord | Dict[str, object]) -> POIRecord:
    if isinstance(row, POIRecord):
        return row
    poi_type = str(row.get("type", row.get("poi_type", ""))).strip().lower()
    return POIRecord(
        poi_id=str(row.get("poi_id", "")),
        name=str(row.get("name", row.get("poi_id", ""))),
        poi_type=poi_type,
        x_m=float(row.get("x_m", row.get("x", 0.0))),
        y_m=float(row.get("y_m", row.get("y", 0.0))),
        lon=_optional_float(row.get("lon", None)),
        lat=_optional_float(row.get("lat", None)),
        source=str(row.get("source", "real")),
        demand_weight=float(row.get("demand_weight", 1.0)),
    )


def _optional_float(value: object) -> Optional[float]:
    if value is None or str(value).strip() == "":
        return None
    return float(value)


def _parse_allowed_connection_types(raw: object) -> set[Tuple[str, str]]:
    if raw is None:
        raw = [
            ["logistics_center", "logistics_center"],
            ["logistics_center", "hospital"],
            ["logistics_center", "business_district"],
        ]
    out: set[Tuple[str, str]] = set()
    if isinstance(raw, list):
        for item in raw:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                a, b = str(item[0]).lower(), str(item[1]).lower()
                out.add(tuple(sorted((a, b))))
    return out


def _is_connection_type_allowed(a: str, b: str, allowed: set[Tuple[str, str]]) -> bool:
    return tuple(sorted((str(a).lower(), str(b).lower()))) in allowed


def _distance_poi(a: POIRecord, b: POIRecord) -> float:
    return float(np.hypot(float(a.x_m) - float(b.x_m), float(a.y_m) - float(b.y_m)))


def _weighted_route_order(routes: Sequence[FutureAirwayRoute], rng: np.random.Generator) -> List[FutureAirwayRoute]:
    remaining = list(routes)
    ordered: List[FutureAirwayRoute] = []
    while remaining:
        weights = np.asarray([max(r.route_weight, 1e-9) for r in remaining], dtype=float)
        weights = weights / max(float(np.sum(weights)), 1e-12)
        idx = int(rng.choice(len(remaining), p=weights))
        ordered.append(remaining.pop(idx))
    return ordered


def _renumber_route(route: FutureAirwayRoute, idx: int) -> FutureAirwayRoute:
    return FutureAirwayRoute(
        route_id=f"future_route_{idx:05d}",
        root_logistics_id=route.root_logistics_id,
        target_id=route.target_id,
        target_type=route.target_type,
        node_sequence=list(route.node_sequence),
        total_distance=float(route.total_distance),
        num_hops=int(route.num_hops),
        route_weight=float(route.route_weight),
        source=route.source,
    )


def _route_source(pois: Sequence[POIRecord]) -> str:
    sources = {p.source for p in pois}
    if sources == {"real"}:
        return "real"
    if sources == {"proxy"}:
        return "proxy"
    return "mixed"


def _nearest_logistics(target: POIRecord, roots: Sequence[POIRecord]) -> Tuple[str, float]:
    if not roots:
        return "", float("inf")
    vals = [(_distance_poi(target, r), r.poi_id) for r in roots]
    vals.sort(key=lambda x: (x[0], x[1]))
    return vals[0][1], float(vals[0][0])


def _xy_to_lonlat(x: float, y: float, city_map: CityMap) -> Tuple[Optional[float], Optional[float]]:
    if city_map.geo_origin_lonlat is None or city_map.geo_m_per_deg is None:
        return None, None
    lon0, lat0 = city_map.geo_origin_lonlat
    mx, my = city_map.geo_m_per_deg
    return float(lon0 + x / max(mx, 1e-12)), float(lat0 + y / max(my, 1e-12))


def _poi_to_row(p: POIRecord) -> Dict[str, object]:
    return {
        "poi_id": p.poi_id,
        "name": p.name,
        "type": p.poi_type,
        "x_m": float(p.x_m),
        "y_m": float(p.y_m),
        "lon": "" if p.lon is None else float(p.lon),
        "lat": "" if p.lat is None else float(p.lat),
        "source": p.source,
        "demand_weight": float(p.demand_weight),
        "data_label": GENERATED_FUTURE_AIRWAY_LABEL if p.source != "proxy" else PROXY_POI_LABEL,
    }


def _route_to_row(r: FutureAirwayRoute) -> Dict[str, object]:
    return {
        "route_id": r.route_id,
        "root_logistics_id": r.root_logistics_id,
        "target_id": r.target_id,
        "target_type": r.target_type,
        "node_sequence": "|".join(r.node_sequence),
        "total_distance": float(r.total_distance),
        "num_hops": int(r.num_hops),
        "route_weight": float(r.route_weight),
        "source": r.source,
        "data_label": GENERATED_FUTURE_AIRWAY_LABEL,
    }


def _graph_to_rows(graph: Dict[str, List[str]], pois: Sequence[POIRecord]) -> List[Dict[str, object]]:
    by_id = {p.poi_id: p for p in pois}
    rows: List[Dict[str, object]] = []
    seen: set[Tuple[str, str]] = set()
    for a, neighbors in graph.items():
        for b in neighbors:
            key = tuple(sorted((a, b)))
            if key in seen:
                continue
            seen.add(key)
            rows.append(
                {
                    "node_a": a,
                    "node_b": b,
                    "type_a": by_id[a].poi_type,
                    "type_b": by_id[b].poi_type,
                    "distance_m": _distance_poi(by_id[a], by_id[b]),
                    "data_label": GENERATED_FUTURE_AIRWAY_LABEL,
                }
            )
    return rows


def _write_csv(path: Path, rows: Sequence[Dict[str, object]]) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    keys: List[str] = []
    for row in rows:
        for key in row.keys():
            if key not in keys:
                keys.append(key)
    with open(path, "w", encoding="utf-8", newline="") as f:
        if not keys:
            f.write("")
        else:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
    return str(path.resolve())


def _write_pois_geojson(path: Path, pois: Sequence[POIRecord]) -> str:
    features = [
        {
            "type": "Feature",
            "properties": _poi_to_row(p),
            "geometry": {"type": "Point", "coordinates": [float(p.x_m), float(p.y_m)]},
        }
        for p in pois
    ]
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"type": "FeatureCollection", "features": features}, f, ensure_ascii=False, indent=2)
    return str(path.resolve())


def _write_routes_geojson(path: Path, routes: Sequence[FutureAirwayRoute], pois: Sequence[POIRecord]) -> str:
    by_id = {p.poi_id: p for p in pois}
    features = []
    for route in routes:
        coords = [[by_id[n].x_m, by_id[n].y_m] for n in route.node_sequence if n in by_id]
        features.append(
            {
                "type": "Feature",
                "properties": _route_to_row(route),
                "geometry": {"type": "LineString", "coordinates": coords},
            }
        )
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"type": "FeatureCollection", "features": features}, f, ensure_ascii=False, indent=2)
    return str(path.resolve())
