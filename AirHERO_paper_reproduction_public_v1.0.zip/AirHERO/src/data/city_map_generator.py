﻿from __future__ import annotations

from typing import List

import numpy as np

from src.data.types import Building, CityMap, Config
from src.data.real_map_loader import generate_city_map_from_real_map


def generate_city_map(config: Config, rng: np.random.Generator) -> CityMap:
    """生成带建筑簇分布特性的三维城市地图。"""
    if bool(config["map"].get("useRealMap", False)):
        return generate_city_map_from_real_map(config, rng)

    map_cfg = config["map"]
    size_x = float(map_cfg["sizeX"])
    size_y = float(map_cfg["sizeY"])
    size_z = float(map_cfg["sizeZ"])
    num_buildings = int(map_cfg["numBuildings"])

    # 通过若干簇中心控制建筑密度与高度，得到更接近城市形态的分布。
    cluster_centers = np.array(
        [
            [size_x * 0.25, size_y * 0.25],
            [size_x * 0.75, size_y * 0.25],
            [size_x * 0.50, size_y * 0.50],
            [size_x * 0.25, size_y * 0.75],
            [size_x * 0.75, size_y * 0.75],
        ],
        dtype=float,
    )
    cluster_radii = np.array([250.0, 250.0, 350.0, 200.0, 200.0], dtype=float)
    cluster_heights = np.array([80.0, 80.0, 120.0, 50.0, 50.0], dtype=float)

    buildings: List[Building] = []
    attempts = 0
    max_attempts = num_buildings * 20

    while len(buildings) < num_buildings and attempts < max_attempts:
        attempts += 1
        x = rng.random() * size_x
        y = rng.random() * size_y

        dists = np.linalg.norm(cluster_centers - np.array([x, y]), axis=1)
        cluster_idx = int(np.argmin(dists))
        min_dist = float(dists[cluster_idx])
        cluster_radius = float(cluster_radii[cluster_idx])

        if min_dist > cluster_radius:
            if rng.random() > 0.3:
                continue
            base_height = 20.0 + rng.random() * 30.0
        else:
            density_factor = 1.0 - (min_dist / cluster_radius)
            if rng.random() > 0.1 + 0.5 * density_factor:
                continue
            base_height = float(cluster_heights[cluster_idx] * (0.5 + rng.random()))

        width = 20.0 + rng.random() * 40.0
        length = 20.0 + rng.random() * 40.0
        if x + width > size_x or y + length > size_y:
            continue

        if _has_overlap(x, y, width, length, buildings, padding=5.0):
            continue

        height = _generate_realistic_height(base_height, rng)
        buildings.append(Building(x=x, y=y, width=width, length=length, height=height))

    building_bounds = _build_bounds(buildings)
    height_resolution = 10.0
    height_matrix = _generate_height_matrix(size_x, size_y, buildings, height_resolution)

    return CityMap(
        size_x=size_x,
        size_y=size_y,
        size_z=size_z,
        buildings=buildings,
        building_bounds=building_bounds,
        height_matrix=height_matrix,
        height_resolution=height_resolution,
    )


def _has_overlap(
    x: float, y: float, width: float, length: float, buildings: List[Building], padding: float
) -> bool:
    """检测新建筑是否与已有建筑重叠。"""
    for b in buildings:
        if (
            x < b.x + b.width + padding
            and x + width + padding > b.x
            and y < b.y + b.length + padding
            and y + length + padding > b.y
        ):
            return True
    return False


def _generate_realistic_height(base_height: float, rng: np.random.Generator) -> float:
    """按分段概率生成建筑高度，并与簇中心高度耦合。"""
    r = rng.random()
    if r < 0.8:
        h = 15.0 + rng.random() * 45.0
    elif r < 0.95:
        h = 50.0 + rng.random() * 50.0
    else:
        h = 80.0 + rng.random() * 70.0
    h = min(h, 150.0)
    h = h * (base_height / 70.0)
    return float(np.clip(h, 10.0, 150.0))


def _build_bounds(buildings: List[Building]) -> np.ndarray:
    """将建筑列表转成包围盒数组，便于后续矢量化判断。"""
    if not buildings:
        return np.zeros((0, 6), dtype=float)

    arr = np.zeros((len(buildings), 6), dtype=float)
    for i, b in enumerate(buildings):
        arr[i] = [b.x, b.x + b.width, b.y, b.y + b.length, 0.0, b.height]
    return arr


def _generate_height_matrix(
    size_x: float, size_y: float, buildings: List[Building], resolution: float
) -> np.ndarray:
    """把建筑高度投影到二维网格，供 LOS/NLOS 近似判断。"""
    nx = int(np.floor(size_x / resolution)) + 1
    ny = int(np.floor(size_y / resolution)) + 1
    h = np.zeros((ny, nx), dtype=float)

    for b in buildings:
        x0 = int(np.floor(b.x / resolution))
        x1 = int(np.ceil((b.x + b.width) / resolution))
        y0 = int(np.floor(b.y / resolution))
        y1 = int(np.ceil((b.y + b.length) / resolution))
        x0 = max(0, min(nx - 1, x0))
        x1 = max(0, min(nx - 1, x1))
        y0 = max(0, min(ny - 1, y0))
        y1 = max(0, min(ny - 1, y1))
        h[y0 : y1 + 1, x0 : x1 + 1] = np.maximum(h[y0 : y1 + 1, x0 : x1 + 1], b.height)

    return h

