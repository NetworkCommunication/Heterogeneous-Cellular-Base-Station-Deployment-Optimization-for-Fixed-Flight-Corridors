﻿from __future__ import annotations

from typing import List, Tuple

import numpy as np

from src.data.types import AirRoute, CityMap, Config


def discretize_air_route(config: Config, city_map: CityMap, rng: np.random.Generator) -> AirRoute:
    """将航路离散成候选测试点。"""
    air_cfg = config["airRoute"]
    num_segments = int(air_cfg["numSegments"])
    points_per_segment = int(air_cfg["pointsPerSegment"])
    min_altitude = float(air_cfg["minAltitude"])
    max_altitude = float(air_cfg["maxAltitude"])
    grid_size = float(air_cfg["gridSize"])
    lateral_half_width = float(air_cfg.get("lateralHalfWidthMeters", 1500.0))
    lateral_step = float(air_cfg.get("lateralStepMeters", max(grid_size, 1.0)))
    sample_keep_prob = float(np.clip(air_cfg.get("sampleKeepProb", 0.85), 0.01, 1.0))
    max_points_per_segment = int(air_cfg.get("maxPointsPerSegment", 1800))
    route_mode = str(air_cfg.get("routeMode", "single_south_north")).lower()
    route_x_ratio = float(air_cfg.get("routeXRatio", 0.5))
    route_x_ratio = float(np.clip(route_x_ratio, 0.0, 1.0))
    mid_alt = (min_altitude + max_altitude) / 2.0

    if route_mode == "geo_start_south_distance":
        start_lon = float(air_cfg.get("geoStartLon", 123.40935537725748))
        start_lat = float(air_cfg.get("geoStartLat", 41.92376403327159))
        south_distance_km = float(air_cfg.get("geoSouthDistanceKm", 32.0))
        start_xy, end_xy = _geo_start_south_distance_to_xy(
            start_lon=start_lon,
            start_lat=start_lat,
            south_distance_km=south_distance_km,
            city_map=city_map,
            config=config,
        )
        routes: List[Tuple[np.ndarray, np.ndarray]] = [
            (np.array([start_xy[0], start_xy[1], mid_alt]), np.array([end_xy[0], end_xy[1], mid_alt]))
        ]
    elif route_mode == "single_south_north":
        # 单条南北向航线：从南端(y=0)飞向北端(y=size_y)。
        x = city_map.size_x * route_x_ratio
        routes: List[Tuple[np.ndarray, np.ndarray]] = [
            (np.array([x, 0.0, mid_alt]), np.array([x, city_map.size_y, mid_alt]))
        ]
    else:
        routes = [
            (
                np.array([0.0, city_map.size_y * 0.3, mid_alt]),
                np.array([city_map.size_x, city_map.size_y * 0.3, mid_alt]),
            ),
            (
                np.array([0.0, city_map.size_y, mid_alt]),
                np.array([city_map.size_x, 0.0, mid_alt]),
            ),
            (
                np.array([city_map.size_x * 0.5, 0.0, mid_alt]),
                np.array([city_map.size_x * 0.5, city_map.size_y, mid_alt]),
            ),
            (np.array([0.0, 0.0, mid_alt]), np.array([city_map.size_x, city_map.size_y, mid_alt])),
        ]

    all_points: List[np.ndarray] = []
    for route_start, route_end in routes:
        route_vec = route_end - route_start
        route_len = float(np.linalg.norm(route_vec))
        route_dir = route_vec / max(route_len, 1e-9)
        segment_len = route_len / max(num_segments, 1)

        for seg in range(num_segments):
            seg_start = route_start + seg * segment_len * route_dir
            seg_end = route_start + (seg + 1) * segment_len * route_dir
            seg_points = _generate_segment_grid(
                seg_start,
                seg_end,
                points_per_segment,
                min_altitude,
                max_altitude,
                grid_size,
                lateral_half_width,
                lateral_step,
                sample_keep_prob,
                max_points_per_segment,
                city_map,
                rng,
            )
            if seg_points.size > 0:
                all_points.append(seg_points)

    test_points = np.vstack(all_points) if all_points else np.zeros((0, 3), dtype=float)
    return AirRoute(
        routes=routes,
        num_segments=num_segments,
        points_per_segment=points_per_segment,
        min_altitude=min_altitude,
        max_altitude=max_altitude,
        grid_size=grid_size,
        test_points=test_points,
    )


def _geo_start_south_distance_to_xy(
    start_lon: float,
    start_lat: float,
    south_distance_km: float,
    city_map: CityMap,
    config: Config,
) -> Tuple[np.ndarray, np.ndarray]:
    """Convert given geo start + south distance route into local XY coordinates."""
    map_cfg = config["map"]
    bbox = city_map.geo_bbox
    if bbox is None:
        bbox = map_cfg.get("realClipBbox", [0.0, 0.0, 1.0, 1.0])
    min_lon, min_lat, max_lon, max_lat = [float(v) for v in bbox]

    if city_map.geo_origin_lonlat is not None:
        origin_lon, origin_lat = city_map.geo_origin_lonlat
    else:
        origin_lon, origin_lat = min_lon, min_lat

    if city_map.geo_m_per_deg is not None:
        m_per_deg_lon, m_per_deg_lat = city_map.geo_m_per_deg
    else:
        center_lat = 0.5 * (min_lat + max_lat)
        m_per_deg_lon, m_per_deg_lat = _meters_per_degree(center_lat)

    end_lon = start_lon
    end_lat = start_lat - (south_distance_km * 1000.0) / max(m_per_deg_lat, 1e-9)

    x0 = (start_lon - origin_lon) * m_per_deg_lon
    y0 = (start_lat - origin_lat) * m_per_deg_lat
    x1 = (end_lon - origin_lon) * m_per_deg_lon
    y1 = (end_lat - origin_lat) * m_per_deg_lat

    start_xy = np.array([np.clip(x0, 0.0, city_map.size_x), np.clip(y0, 0.0, city_map.size_y)], dtype=float)
    end_xy = np.array([np.clip(x1, 0.0, city_map.size_x), np.clip(y1, 0.0, city_map.size_y)], dtype=float)
    return start_xy, end_xy


def _meters_per_degree(lat_deg: float) -> Tuple[float, float]:
    lat = np.deg2rad(lat_deg)
    m_per_deg_lat = (
        111132.92
        - 559.82 * np.cos(2.0 * lat)
        + 1.175 * np.cos(4.0 * lat)
        - 0.0023 * np.cos(6.0 * lat)
    )
    m_per_deg_lon = (
        111412.84 * np.cos(lat)
        - 93.5 * np.cos(3.0 * lat)
        + 0.118 * np.cos(5.0 * lat)
    )
    return float(m_per_deg_lon), float(m_per_deg_lat)


def _generate_segment_grid(
    seg_start: np.ndarray,
    seg_end: np.ndarray,
    points_per_segment: int,
    min_altitude: float,
    max_altitude: float,
    grid_size: float,
    lateral_half_width: float,
    lateral_step: float,
    sample_keep_prob: float,
    max_points_per_segment: int,
    city_map: CityMap,
    rng: np.random.Generator,
) -> np.ndarray:
    """在单段航路周围构造三维网格采样点。"""
    seg_vec = seg_end - seg_start
    seg_len = float(np.linalg.norm(seg_vec))
    seg_dir = seg_vec / max(seg_len, 1e-9)
    perp = np.cross(seg_dir, np.array([0.0, 0.0, 1.0]))
    perp_norm = float(np.linalg.norm(perp))
    if perp_norm < 1e-9:
        perp = np.array([1.0, 0.0, 0.0])
    else:
        perp = perp / perp_norm

    num_along = int(np.ceil(seg_len / max(grid_size, 1e-9)))
    num_perp = int(np.ceil(max(lateral_half_width, 0.0) / max(lateral_step, 1e-9)))
    num_vertical = int(np.ceil((max_altitude - min_altitude) / max(grid_size, 1e-9)))

    points: List[np.ndarray] = []
    for i in range(num_along + 1):
        along_pos = (i / max(num_along, 1)) * seg_len
        for j in range(-num_perp, num_perp + 1):
            perp_pos = j * grid_size
            for k in range(num_vertical + 1):
                vert_pos = min_altitude + (k / max(num_vertical, 1)) * (max_altitude - min_altitude)
                p = seg_start + along_pos * seg_dir + perp_pos * perp
                p[2] = vert_pos
                if (
                    0.0 <= p[0] <= city_map.size_x
                    and 0.0 <= p[1] <= city_map.size_y
                    and min_altitude <= p[2] <= max_altitude
                    and rng.random() < sample_keep_prob
                ):
                    points.append(p.copy())

    # 若规则网格点数量不足，则用随机补点保证每段最少采样数量。
    if len(points) < points_per_segment:
        need = points_per_segment - len(points)
        for _ in range(need):
            t = rng.random()
            along_pos = t * seg_len
            perp_offset = (rng.random() - 0.5) * 2.0 * lateral_step * max(num_perp, 1)
            vert_pos = min_altitude + rng.random() * (max_altitude - min_altitude)
            p = seg_start + along_pos * seg_dir + perp_offset * perp
            p[2] = vert_pos
            p[0] = np.clip(p[0], 0.0, city_map.size_x)
            p[1] = np.clip(p[1], 0.0, city_map.size_y)
            points.append(p)

    # 控制单段点数上限，避免宽航线下点数爆炸导致优化过慢。
    if max_points_per_segment > 0 and len(points) > max_points_per_segment:
        idx = rng.choice(len(points), size=max_points_per_segment, replace=False)
        pts = np.asarray(points, dtype=float)[idx]
        return pts

    if not points:
        return np.zeros((0, 3), dtype=float)
    return np.asarray(points, dtype=float)


