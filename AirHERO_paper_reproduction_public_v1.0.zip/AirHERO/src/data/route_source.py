from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np

from src.data.air_route_generator import discretize_air_route
from src.data.future_airway_generator import (
    FutureAirwayResult,
    discretize_future_airway_routes,
    generate_future_airways,
)
from src.data.types import AirRoute, CityMap, Config


ROUTE_SOURCE_CODES = {
    "existing_real_routes": 0.0,
    "generated_from_pois": 1.0,
    "proxy_generated_routes": 2.0,
}


@dataclass
class RouteSourceResult:
    """Resolved route source for one experiment scene."""

    air_route: AirRoute
    route_source: str
    metadata: Dict[str, Any]
    generated_future_airway: Optional[FutureAirwayResult] = None


def build_air_route_from_config(
    config: Config,
    city_map: CityMap,
    rng: np.random.Generator,
    output_dir: Optional[Path] = None,
) -> RouteSourceResult:
    """Resolve configured route source and return an AirRoute for evaluation.

    This is the only experiment-facing switch between existing route data and
    generated POI-DFS future airways. It keeps generated/proxy routes under the
    experiment artifacts directory so real route files are never overwritten.
    """
    route_cfg = config.get("routeSource", {})
    source = _normalize_route_source(route_cfg.get("source", route_cfg.get("mode", "existing_real_routes")))

    if source == "existing_real_routes":
        return _build_existing_real_routes(config=config, city_map=city_map, rng=rng, output_dir=output_dir)

    if source == "generated_from_pois":
        return _build_generated_from_pois(
            config=config,
            city_map=city_map,
            output_dir=output_dir,
            force_proxy=False,
        )

    if source == "proxy_generated_routes":
        return _build_generated_from_pois(
            config=config,
            city_map=city_map,
            output_dir=output_dir,
            force_proxy=True,
        )

    raise ValueError(f"Unsupported routeSource.source: {source}")


def _build_existing_real_routes(
    config: Config,
    city_map: CityMap,
    rng: np.random.Generator,
    output_dir: Optional[Path],
) -> RouteSourceResult:
    route_cfg = config.get("routeSource", {})
    real_file = route_cfg.get("realRouteTestPointFile", None)

    if real_file:
        air_route = _load_real_route_test_points(Path(str(real_file)), config)
        metadata: Dict[str, Any] = {
            "route_source": "existing_real_routes",
            "route_source_code": ROUTE_SOURCE_CODES["existing_real_routes"],
            "route_source_detail": "loaded_real_route_test_points_csv",
            "real_route_test_point_file": str(Path(str(real_file)).resolve()),
            "route_random_seed": None,
            "num_test_points": int(air_route.test_points.shape[0]),
            "generated_route_count": 0,
            "generated_poi_count": 0,
            "unreachable_target_count": 0,
            "output_dir": None,
            "warning": "",
        }
        _save_route_source_metadata(metadata, output_dir)
        return RouteSourceResult(air_route=air_route, route_source="existing_real_routes", metadata=metadata)

    air_route = discretize_air_route(config, city_map, rng)
    warning = (
        "No routeSource.realRouteTestPointFile was provided; using legacy configured airRoute "
        "discretization. This is not labeled as real measured route data."
    )
    metadata = {
        "route_source": "existing_real_routes",
        "route_source_code": ROUTE_SOURCE_CODES["existing_real_routes"],
        "route_source_detail": "configured_route_fallback",
        "real_route_test_point_file": None,
        "route_random_seed": None,
        "num_test_points": int(air_route.test_points.shape[0]),
        "generated_route_count": 0,
        "generated_poi_count": 0,
        "unreachable_target_count": 0,
        "output_dir": None,
        "warning": warning,
    }
    _save_route_source_metadata(metadata, output_dir)
    return RouteSourceResult(air_route=air_route, route_source="existing_real_routes", metadata=metadata)


def _build_generated_from_pois(
    config: Config,
    city_map: CityMap,
    output_dir: Optional[Path],
    force_proxy: bool,
) -> RouteSourceResult:
    cfg = _clone_config(config)
    cfg.setdefault("futureAirway", {})
    cfg["futureAirway"]["enabled"] = True
    cfg["futureAirway"].setdefault("poiSource", {})
    if force_proxy:
        cfg["futureAirway"]["poiSource"]["mode"] = "proxy"

    route_source = "proxy_generated_routes" if force_proxy else "generated_from_pois"
    route_seed = int(cfg["futureAirway"].get("routeGeneration", {}).get("random_seed", 42))
    route_rng = np.random.default_rng(route_seed)

    gen_subdir = str(cfg.get("routeSource", {}).get("generatedOutputSubdir", "generated_future_airways"))
    gen_dir = (Path(output_dir) / gen_subdir) if output_dir is not None else Path("artifacts") / gen_subdir

    generated = generate_future_airways(
        config=cfg,
        rng=route_rng,
        output_dir=gen_dir,
        city_map=city_map,
    )
    air_route = discretize_future_airway_routes(generated, cfg, route_rng)

    metadata: Dict[str, Any] = {
        "route_source": route_source,
        "route_source_code": ROUTE_SOURCE_CODES[route_source],
        "route_source_detail": "poi_dfs_generated_future_airways",
        "poi_source_mode": str(cfg["futureAirway"].get("poiSource", {}).get("mode", "")),
        "route_random_seed": route_seed,
        "num_test_points": int(air_route.test_points.shape[0]),
        "generated_route_count": int(len(generated.routes)),
        "generated_poi_count": int(len(generated.pois)),
        "unreachable_target_count": int(len(generated.unreachable_targets)),
        "output_dir": str(gen_dir.resolve()),
        "output_paths": dict(generated.output_paths),
        "warning": "",
    }
    metadata.update({f"future_airway_{k}": float(v) for k, v in generated.stats.items()})
    _save_route_source_metadata(metadata, output_dir)
    return RouteSourceResult(
        air_route=air_route,
        route_source=route_source,
        metadata=metadata,
        generated_future_airway=generated,
    )


def _normalize_route_source(value: object) -> str:
    raw = str(value).strip().lower()
    aliases = {
        "real": "existing_real_routes",
        "existing": "existing_real_routes",
        "existing_real_routes": "existing_real_routes",
        "generated": "generated_from_pois",
        "poi": "generated_from_pois",
        "poi_dfs": "generated_from_pois",
        "generated_from_pois": "generated_from_pois",
        "proxy": "proxy_generated_routes",
        "proxy_generated_routes": "proxy_generated_routes",
    }
    return aliases.get(raw, raw)


def _load_real_route_test_points(path: Path, config: Config) -> AirRoute:
    if not path.exists():
        raise FileNotFoundError(f"Real route test-point CSV does not exist: {path}")

    rows = []
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for raw in reader:
            rows.append(raw)
    if not rows:
        raise ValueError(f"Real route test-point CSV is empty: {path}")

    points = []
    for row in rows:
        x = _row_float(row, "x", "x_m", "X", "lon_x")
        y = _row_float(row, "y", "y_m", "Y", "lat_y")
        z = _row_float(row, "z", "z_m", "altitude", "altitude_m", default=config["airRoute"]["minAltitude"])
        points.append([x, y, z])

    test_points = np.asarray(points, dtype=float)
    air_cfg = config["airRoute"]
    start = test_points[0].copy()
    end = test_points[-1].copy()
    return AirRoute(
        routes=[(start, end)],
        num_segments=int(air_cfg.get("numSegments", 1)),
        points_per_segment=int(max(test_points.shape[0], 1)),
        min_altitude=float(np.min(test_points[:, 2])),
        max_altitude=float(np.max(test_points[:, 2])),
        grid_size=float(air_cfg.get("gridSize", 20.0)),
        test_points=test_points,
    )


def _row_float(row: Dict[str, str], *keys: str, default: object = None) -> float:
    for key in keys:
        if key in row and str(row[key]).strip() != "":
            return float(row[key])
    if default is not None:
        return float(default)
    raise ValueError(f"Missing required CSV column. Expected one of: {', '.join(keys)}")


def _save_route_source_metadata(metadata: Dict[str, Any], output_dir: Optional[Path]) -> None:
    if output_dir is None:
        return
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "route_source_metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)


def _clone_config(config: Config) -> Config:
    return json.loads(json.dumps(config))
