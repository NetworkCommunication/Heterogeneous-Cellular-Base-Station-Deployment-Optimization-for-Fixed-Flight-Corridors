﻿from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

Config = Dict[str, Any]


@dataclass
class Building:
    """Single building parameters."""

    x: float
    y: float
    width: float
    length: float
    height: float
    osm_id: str = ""
    fclass: str = ""
    btype: str = ""
    subclass: str = ""
    landing_priority: float = 0.0


@dataclass
class CityMap:
    """City map and discretized building-height model."""

    size_x: float
    size_y: float
    size_z: float
    buildings: List[Building]
    building_bounds: np.ndarray
    height_matrix: np.ndarray
    height_resolution: float
    road_segments: Optional[np.ndarray] = None
    geo_bbox: Optional[Tuple[float, float, float, float]] = None
    geo_origin_lonlat: Optional[Tuple[float, float]] = None
    geo_m_per_deg: Optional[Tuple[float, float]] = None
    landing_points: Optional[np.ndarray] = None
    landing_labels: Optional[List[str]] = None
    takeoff_point: Optional[np.ndarray] = None
    touchdown_point: Optional[np.ndarray] = None


@dataclass
class AirRoute:
    """Discretized airway test points."""

    routes: List[Tuple[np.ndarray, np.ndarray]]
    num_segments: int
    points_per_segment: int
    min_altitude: float
    max_altitude: float
    grid_size: float
    test_points: np.ndarray


@dataclass
class PSOResult:
    """PSO optimization result container."""

    best_position: np.ndarray
    best_fitness: float
    convergence_history: np.ndarray
    iteration: int
    convergence_iteration: int
    best_objectives: Optional[Dict[str, float]] = None
    objective_history: Optional[Dict[str, np.ndarray]] = None
    station_type_indices: Optional[np.ndarray] = None
    station_type_names: Optional[List[str]] = None
    station_sector_azimuths_deg: Optional[List[Optional[float]]] = None
    decoded_solution: Optional[List[Dict[str, Any]]] = None
    pareto_positions: Optional[np.ndarray] = None
    pareto_objectives: Optional[np.ndarray] = None
    pareto_composite_scores: Optional[np.ndarray] = None
    pareto_metrics: Optional[List[Dict[str, float]]] = None
    pareto_decoded_solutions: Optional[List[List[Dict[str, Any]]]] = None
    init_stats: Optional[Dict[str, float]] = None
    evaluation_stats: Optional[Dict[str, Any]] = None
