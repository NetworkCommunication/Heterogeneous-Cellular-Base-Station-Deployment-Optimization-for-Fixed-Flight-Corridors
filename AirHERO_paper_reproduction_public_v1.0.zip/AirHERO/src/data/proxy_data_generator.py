﻿from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np

from src.data.types import Config

SIMULATED_PROXY_LABEL = "SIMULATED_PROXY_DATA"


@dataclass
class CityArea:
    """City area geometry used for proxy data generation."""

    name: str
    polygon_xy: np.ndarray  # [N, 2], not closed
    bbox_xy: Tuple[float, float, float, float]


@dataclass
class ProxyDataset:
    """Container for generated proxy datasets and metadata."""

    label: str
    city_area: CityArea
    base_stations: List[Dict[str, object]]
    od_points: List[Dict[str, object]]
    routes: List[Dict[str, object]]
    demand_points: List[Dict[str, object]]
    output_paths: Dict[str, str]
    stats: Dict[str, float]


def generate_proxy_dataset(config: Config, rng: np.random.Generator, output_dir: Path) -> ProxyDataset:
    """Generate simulated city-level proxy data for early-stage experiments.

    The generated data is explicitly labeled as simulated/proxy and persisted as
    CSV + GeoJSON for easy replacement by real data later.
    """
    proxy_cfg = _merge_proxy_defaults(config.get("proxyData", {}))
    output_dir.mkdir(parents=True, exist_ok=True)

    city_area = _build_city_area(proxy_cfg["cityArea"])
    base_stations = _generate_base_stations(city_area, proxy_cfg["existingBaseStations"], rng)
    od_points = _generate_od_points(city_area, proxy_cfg["odPoints"], rng)
    routes = _generate_routes(od_points, proxy_cfg["routes"], rng)
    demand_points = _generate_blind_spot_demand(
        city_area=city_area,
        base_stations=base_stations,
        routes=routes,
        cfg=proxy_cfg["blindSpotDemand"],
    )

    output_paths = _save_proxy_outputs(
        label=SIMULATED_PROXY_LABEL,
        city_area=city_area,
        base_stations=base_stations,
        od_points=od_points,
        routes=routes,
        demand_points=demand_points,
        output_dir=output_dir,
        save_csv=bool(proxy_cfg["output"].get("saveCSV", True)),
        save_geojson=bool(proxy_cfg["output"].get("saveGeoJSON", True)),
    )

    stats = {
        "num_base_stations": float(len(base_stations)),
        "num_od_points": float(len(od_points)),
        "num_routes": float(len(routes)),
        "num_demand_points": float(len(demand_points)),
        "city_area_m2": float(_polygon_area(city_area.polygon_xy)),
        "mean_route_weight": float(np.mean([float(r["demand_weight"]) for r in routes])) if routes else 0.0,
        "mean_station_tx_power_dbm": float(
            np.mean([float(bs["tx_power_dbm"]) for bs in base_stations])
        )
        if base_stations
        else 0.0,
    }

    stats_path = output_dir / "proxy_dataset_stats.json"
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump({"label": SIMULATED_PROXY_LABEL, "stats": stats}, f, ensure_ascii=False, indent=2)
    output_paths["stats_json"] = str(stats_path.resolve())

    return ProxyDataset(
        label=SIMULATED_PROXY_LABEL,
        city_area=city_area,
        base_stations=base_stations,
        od_points=od_points,
        routes=routes,
        demand_points=demand_points,
        output_paths=output_paths,
        stats=stats,
    )


def _merge_proxy_defaults(user_cfg: Dict[str, object]) -> Dict[str, object]:
    cfg: Dict[str, object] = {
        "cityArea": {
            "name": "proxy_city_bbox",
            "bbox": [0.0, 0.0, 10000.0, 8000.0],
            "polygon": None,
        },
        "existingBaseStations": {
            "numStations": 30,
            "typeProbabilities": {"5G": 0.7, "5GA": 0.3},
            "txPowerDbm": {"5G": [34.0, 42.0], "5GA": [38.0, 46.0]},
            "antennaHeightM": {"5G": [25.0, 45.0], "5GA": [30.0, 60.0]},
        },
        "odPoints": {
            "numAirports": 3,
            "numWaypoints": 20,
            "airportTrafficWeight": [1.5, 3.0],
            "waypointTrafficWeight": [0.5, 1.5],
        },
        "routes": {
            "numRoutes": 60,
            "minCorridorWidthM": 300.0,
            "maxCorridorWidthM": 1200.0,
            "demandNoise": [0.8, 1.2],
        },
        "blindSpotDemand": {
            "gridSpacingM": 250.0,
            "minCoverageRadiusM": 700.0,
            "maxDemandPoints": 2000,
            "altitudeM": 120.0,
        },
        "output": {
            "saveCSV": True,
            "saveGeoJSON": True,
        },
    }
    _deep_update(cfg, user_cfg)
    return cfg


def _deep_update(base: Dict[str, object], override: Dict[str, object]) -> None:
    for key, val in override.items():
        if isinstance(val, dict) and isinstance(base.get(key), dict):
            _deep_update(base[key], val)
        else:
            base[key] = val


def _build_city_area(cfg: Dict[str, object]) -> CityArea:
    name = str(cfg.get("name", "proxy_city"))
    poly_cfg = cfg.get("polygon")
    if isinstance(poly_cfg, list) and len(poly_cfg) >= 3:
        polygon = np.asarray(poly_cfg, dtype=float)
    else:
        bbox = cfg.get("bbox", [0.0, 0.0, 10000.0, 8000.0])
        if not isinstance(bbox, list) or len(bbox) != 4:
            raise ValueError("proxyData.cityArea requires either polygon or bbox=[min_x,min_y,max_x,max_y]")
        min_x, min_y, max_x, max_y = [float(v) for v in bbox]
        polygon = np.asarray(
            [[min_x, min_y], [max_x, min_y], [max_x, max_y], [min_x, max_y]],
            dtype=float,
        )

    bbox_xy = (
        float(np.min(polygon[:, 0])),
        float(np.min(polygon[:, 1])),
        float(np.max(polygon[:, 0])),
        float(np.max(polygon[:, 1])),
    )
    return CityArea(name=name, polygon_xy=polygon, bbox_xy=bbox_xy)


def _generate_base_stations(
    city_area: CityArea,
    cfg: Dict[str, object],
    rng: np.random.Generator,
) -> List[Dict[str, object]]:
    n = int(cfg.get("numStations", 30))
    probs_cfg = cfg.get("typeProbabilities", {"5G": 0.7, "5GA": 0.3})
    p_5g = float(probs_cfg.get("5G", 0.7))
    p_5ga = float(probs_cfg.get("5GA", 0.3))
    prob_sum = max(p_5g + p_5ga, 1e-9)
    p_5g /= prob_sum

    tx_cfg = cfg.get("txPowerDbm", {})
    h_cfg = cfg.get("antennaHeightM", {})

    points = _sample_points_in_polygon(city_area.polygon_xy, n, rng)
    items: List[Dict[str, object]] = []
    for i, pt in enumerate(points, start=1):
        bs_type = "5G" if rng.random() < p_5g else "5GA"
        tx_range = tx_cfg.get(bs_type, [35.0, 45.0])
        h_range = h_cfg.get(bs_type, [25.0, 60.0])
        tx = float(rng.uniform(float(tx_range[0]), float(tx_range[1])))
        h = float(rng.uniform(float(h_range[0]), float(h_range[1])))
        items.append(
            {
                "station_id": f"bs_{i:04d}",
                "x_m": float(pt[0]),
                "y_m": float(pt[1]),
                "station_type": bs_type,
                "tx_power_dbm": tx,
                "antenna_height_m": h,
                "data_label": SIMULATED_PROXY_LABEL,
            }
        )
    return items


def _generate_od_points(city_area: CityArea, cfg: Dict[str, object], rng: np.random.Generator) -> List[Dict[str, object]]:
    n_airports = int(cfg.get("numAirports", 3))
    n_waypoints = int(cfg.get("numWaypoints", 20))

    airport_weights = cfg.get("airportTrafficWeight", [1.5, 3.0])
    waypoint_weights = cfg.get("waypointTrafficWeight", [0.5, 1.5])

    airport_pts = _sample_points_in_polygon(city_area.polygon_xy, n_airports, rng)
    waypoint_pts = _sample_points_in_polygon(city_area.polygon_xy, n_waypoints, rng)

    rows: List[Dict[str, object]] = []
    for i, pt in enumerate(airport_pts, start=1):
        rows.append(
            {
                "point_id": f"ap_{i:03d}",
                "point_type": "airport",
                "x_m": float(pt[0]),
                "y_m": float(pt[1]),
                "traffic_weight": float(rng.uniform(float(airport_weights[0]), float(airport_weights[1]))),
                "data_label": SIMULATED_PROXY_LABEL,
            }
        )

    for i, pt in enumerate(waypoint_pts, start=1):
        rows.append(
            {
                "point_id": f"wp_{i:03d}",
                "point_type": "waypoint",
                "x_m": float(pt[0]),
                "y_m": float(pt[1]),
                "traffic_weight": float(rng.uniform(float(waypoint_weights[0]), float(waypoint_weights[1]))),
                "data_label": SIMULATED_PROXY_LABEL,
            }
        )
    return rows


def _generate_routes(od_points: List[Dict[str, object]], cfg: Dict[str, object], rng: np.random.Generator) -> List[Dict[str, object]]:
    n_routes = int(cfg.get("numRoutes", 60))
    min_w = float(cfg.get("minCorridorWidthM", 300.0))
    max_w = float(cfg.get("maxCorridorWidthM", 1200.0))
    noise_range = cfg.get("demandNoise", [0.8, 1.2])

    if len(od_points) < 2:
        return []

    ids = [str(p["point_id"]) for p in od_points]
    coords = {str(p["point_id"]): np.array([float(p["x_m"]), float(p["y_m"])], dtype=float) for p in od_points}
    traffic = {str(p["point_id"]): float(p["traffic_weight"]) for p in od_points}

    probs = np.asarray([traffic[i] for i in ids], dtype=float)
    probs = probs / max(float(probs.sum()), 1e-9)

    routes: List[Dict[str, object]] = []
    for i in range(1, n_routes + 1):
        src_idx = int(rng.choice(len(ids), p=probs))
        dst_idx = int(rng.choice(len(ids), p=probs))
        if dst_idx == src_idx:
            dst_idx = (dst_idx + 1) % len(ids)

        src_id = ids[src_idx]
        dst_id = ids[dst_idx]
        src = coords[src_id]
        dst = coords[dst_id]
        width = float(rng.uniform(min_w, max_w))
        demand = float(traffic[src_id] * traffic[dst_id] * rng.uniform(float(noise_range[0]), float(noise_range[1])))

        routes.append(
            {
                "route_id": f"rt_{i:04d}",
                "origin_id": src_id,
                "destination_id": dst_id,
                "x0_m": float(src[0]),
                "y0_m": float(src[1]),
                "x1_m": float(dst[0]),
                "y1_m": float(dst[1]),
                "corridor_width_m": width,
                "demand_weight": demand,
                "data_label": SIMULATED_PROXY_LABEL,
            }
        )

    if routes:
        all_w = np.asarray([float(r["demand_weight"]) for r in routes], dtype=float)
        w_max = max(float(all_w.max()), 1e-9)
        for r in routes:
            r["demand_weight_norm"] = float(float(r["demand_weight"]) / w_max)

    return routes


def _generate_blind_spot_demand(
    city_area: CityArea,
    base_stations: List[Dict[str, object]],
    routes: List[Dict[str, object]],
    cfg: Dict[str, object],
) -> List[Dict[str, object]]:
    spacing = float(cfg.get("gridSpacingM", 250.0))
    coverage_radius = float(cfg.get("minCoverageRadiusM", 700.0))
    max_points = int(cfg.get("maxDemandPoints", 2000))
    altitude = float(cfg.get("altitudeM", 120.0))

    min_x, min_y, max_x, max_y = city_area.bbox_xy
    xs = np.arange(min_x, max_x + spacing * 0.5, spacing)
    ys = np.arange(min_y, max_y + spacing * 0.5, spacing)

    station_xy = np.asarray([[float(s["x_m"]), float(s["y_m"])] for s in base_stations], dtype=float)
    demand_rows: List[Dict[str, object]] = []

    route_segments: List[Tuple[np.ndarray, np.ndarray, float, float]] = []
    for r in routes:
        p0 = np.array([float(r["x0_m"]), float(r["y0_m"])], dtype=float)
        p1 = np.array([float(r["x1_m"]), float(r["y1_m"])], dtype=float)
        w = float(r.get("demand_weight_norm", r.get("demand_weight", 1.0)))
        c = float(r.get("corridor_width_m", 500.0))
        route_segments.append((p0, p1, w, c))

    idx = 0
    for x in xs:
        for y in ys:
            p = np.array([float(x), float(y)], dtype=float)
            if not _point_in_polygon(p[0], p[1], city_area.polygon_xy):
                continue

            if station_xy.size == 0:
                nearest_station = coverage_radius * 2.0
            else:
                nearest_station = float(np.min(np.linalg.norm(station_xy - p[None, :], axis=1)))

            route_influence = 0.0
            nearest_route_dist = 1e9
            for p0, p1, w, c in route_segments:
                d = _point_to_segment_distance(p, p0, p1)
                nearest_route_dist = min(nearest_route_dist, d)
                route_influence = max(route_influence, w * float(np.exp(-d / max(c, 1e-6))))

            blind_score = max(0.0, (nearest_station - coverage_radius) / max(coverage_radius, 1.0))
            demand_weight = blind_score * (1.0 + route_influence)
            if demand_weight <= 0.0:
                continue

            idx += 1
            demand_rows.append(
                {
                    "demand_id": f"dp_{idx:05d}",
                    "x_m": float(p[0]),
                    "y_m": float(p[1]),
                    "z_m": altitude,
                    "blind_spot_score": float(blind_score),
                    "demand_weight": float(demand_weight),
                    "nearest_station_distance_m": float(nearest_station),
                    "nearest_route_distance_m": float(nearest_route_dist if nearest_route_dist < 1e8 else -1.0),
                    "data_label": SIMULATED_PROXY_LABEL,
                }
            )

    demand_rows.sort(key=lambda r: float(r["demand_weight"]), reverse=True)
    if max_points > 0:
        demand_rows = demand_rows[:max_points]
    return demand_rows


def _save_proxy_outputs(
    label: str,
    city_area: CityArea,
    base_stations: List[Dict[str, object]],
    od_points: List[Dict[str, object]],
    routes: List[Dict[str, object]],
    demand_points: List[Dict[str, object]],
    output_dir: Path,
    save_csv: bool,
    save_geojson: bool,
) -> Dict[str, str]:
    paths: Dict[str, str] = {}

    if save_csv:
        paths["base_stations_csv"] = _write_csv(output_dir / "proxy_base_stations.csv", base_stations)
        paths["od_points_csv"] = _write_csv(output_dir / "proxy_od_points.csv", od_points)
        paths["routes_csv"] = _write_csv(output_dir / "proxy_routes.csv", routes)
        paths["demand_points_csv"] = _write_csv(output_dir / "proxy_blindspot_demand_points.csv", demand_points)

    if save_geojson:
        paths["city_area_geojson"] = _write_city_area_geojson(output_dir / "proxy_city_area.geojson", city_area, label)
        paths["base_stations_geojson"] = _write_points_geojson(
            output_dir / "proxy_base_stations.geojson",
            base_stations,
            x_key="x_m",
            y_key="y_m",
        )
        paths["od_points_geojson"] = _write_points_geojson(
            output_dir / "proxy_od_points.geojson",
            od_points,
            x_key="x_m",
            y_key="y_m",
        )
        paths["demand_points_geojson"] = _write_points_geojson(
            output_dir / "proxy_blindspot_demand_points.geojson",
            demand_points,
            x_key="x_m",
            y_key="y_m",
        )
        paths["routes_geojson"] = _write_routes_geojson(output_dir / "proxy_routes.geojson", routes)

    return paths


def _write_csv(path: Path, rows: List[Dict[str, object]]) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write("")
        return str(path.resolve())

    keys = list(rows[0].keys())
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)
    return str(path.resolve())


def _write_city_area_geojson(path: Path, city_area: CityArea, label: str) -> str:
    ring = city_area.polygon_xy.tolist()
    if ring and ring[0] != ring[-1]:
        ring.append(ring[0])

    fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {
                    "name": city_area.name,
                    "coordinate_system": "local_xy_meters",
                    "data_label": label,
                },
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [ring],
                },
            }
        ],
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(fc, f, ensure_ascii=False, indent=2)
    return str(path.resolve())


def _write_points_geojson(path: Path, rows: List[Dict[str, object]], x_key: str, y_key: str) -> str:
    features = []
    for r in rows:
        props = dict(r)
        x = float(props.pop(x_key))
        y = float(props.pop(y_key))
        features.append(
            {
                "type": "Feature",
                "properties": props,
                "geometry": {"type": "Point", "coordinates": [x, y]},
            }
        )

    fc = {"type": "FeatureCollection", "features": features}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(fc, f, ensure_ascii=False, indent=2)
    return str(path.resolve())


def _write_routes_geojson(path: Path, rows: List[Dict[str, object]]) -> str:
    features = []
    for r in rows:
        props = dict(r)
        x0 = float(props.pop("x0_m"))
        y0 = float(props.pop("y0_m"))
        x1 = float(props.pop("x1_m"))
        y1 = float(props.pop("y1_m"))
        features.append(
            {
                "type": "Feature",
                "properties": props,
                "geometry": {"type": "LineString", "coordinates": [[x0, y0], [x1, y1]]},
            }
        )

    fc = {"type": "FeatureCollection", "features": features}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(fc, f, ensure_ascii=False, indent=2)
    return str(path.resolve())


def _sample_points_in_polygon(polygon: np.ndarray, n: int, rng: np.random.Generator) -> np.ndarray:
    if n <= 0:
        return np.zeros((0, 2), dtype=float)

    min_x = float(np.min(polygon[:, 0]))
    max_x = float(np.max(polygon[:, 0]))
    min_y = float(np.min(polygon[:, 1]))
    max_y = float(np.max(polygon[:, 1]))

    points: List[Tuple[float, float]] = []
    attempts = 0
    max_attempts = max(1000, n * 200)
    while len(points) < n and attempts < max_attempts:
        attempts += 1
        x = float(rng.uniform(min_x, max_x))
        y = float(rng.uniform(min_y, max_y))
        if _point_in_polygon(x, y, polygon):
            points.append((x, y))

    if len(points) < n:
        raise RuntimeError("Failed to sample enough points in polygon. Check polygon geometry.")

    return np.asarray(points, dtype=float)


def _point_in_polygon(x: float, y: float, polygon: np.ndarray) -> bool:
    inside = False
    n = polygon.shape[0]
    j = n - 1
    for i in range(n):
        xi, yi = float(polygon[i, 0]), float(polygon[i, 1])
        xj, yj = float(polygon[j, 0]), float(polygon[j, 1])
        intersects = (yi > y) != (yj > y)
        if intersects:
            x_cross = (xj - xi) * (y - yi) / max(yj - yi, 1e-12) + xi
            if x < x_cross:
                inside = not inside
        j = i
    return inside


def _point_to_segment_distance(point: np.ndarray, a: np.ndarray, b: np.ndarray) -> float:
    ab = b - a
    denom = float(np.dot(ab, ab))
    if denom <= 1e-12:
        return float(np.linalg.norm(point - a))
    t = float(np.dot(point - a, ab) / denom)
    t = float(np.clip(t, 0.0, 1.0))
    proj = a + t * ab
    return float(np.linalg.norm(point - proj))


def _polygon_area(polygon: np.ndarray) -> float:
    x = polygon[:, 0]
    y = polygon[:, 1]
    return float(0.5 * np.abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))))
