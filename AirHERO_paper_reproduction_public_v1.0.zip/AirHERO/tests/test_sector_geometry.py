from __future__ import annotations

import numpy as np

from src.propagation.sector_geometry import (
    DEFAULT_SECTOR_DIRECTIONS_DEG,
    OUTSIDE_SECTOR_NO_COVERAGE,
    OUTSIDE_SECTOR_SIDE_LOBE,
    absolute_wrapped_angular_difference_deg,
    bearing_deg,
    compute_sector_gain_db,
    inside_sector_mask,
    is_supported_sector_direction_deg,
    nearest_supported_sector_direction_deg,
    sector_gain_linear,
    sector_geometry_config_from_mapping,
)
from src.utils.config import get_default_config, init_channel_params


def _point_from_compass_bearing(bearing_deg_value: float, radius: float = 100.0) -> np.ndarray:
    rad = np.radians(float(bearing_deg_value))
    return np.asarray([np.sin(rad) * radius, np.cos(rad) * radius], dtype=float)


def test_point_exactly_on_boresight_is_inside() -> None:
    station = np.asarray([0.0, 0.0], dtype=float)
    point = _point_from_compass_bearing(0.0)

    mask = inside_sector_mask(
        station_xy=station,
        point_xy=point,
        sector_azimuth_deg=0.0,
        sector_beamwidth_deg=60.0,
    )

    assert bool(mask)
    assert float(bearing_deg(station, point)) == 0.0


def test_point_at_beam_edge_is_inside() -> None:
    station = np.asarray([0.0, 0.0], dtype=float)
    point = _point_from_compass_bearing(30.0)

    mask = inside_sector_mask(
        station_xy=station,
        point_xy=point,
        sector_azimuth_deg=0.0,
        sector_beamwidth_deg=60.0,
    )

    assert bool(mask)


def test_point_outside_beam_is_outside() -> None:
    station = np.asarray([0.0, 0.0], dtype=float)
    point = _point_from_compass_bearing(31.0)

    mask = inside_sector_mask(
        station_xy=station,
        point_xy=point,
        sector_azimuth_deg=0.0,
        sector_beamwidth_deg=60.0,
    )

    assert not bool(mask)


def test_wrap_around_angular_difference_and_sector_mask() -> None:
    assert np.isclose(float(absolute_wrapped_angular_difference_deg(350.0, 10.0)), 20.0)
    assert np.isclose(float(absolute_wrapped_angular_difference_deg(10.0, 350.0)), 20.0)

    station = np.asarray([0.0, 0.0], dtype=float)
    point = _point_from_compass_bearing(350.0)
    mask = inside_sector_mask(
        station_xy=station,
        point_xy=point,
        sector_azimuth_deg=10.0,
        sector_beamwidth_deg=40.0,
    )
    assert bool(mask)


def test_all_eight_sector_directions_are_supported() -> None:
    station = np.asarray([0.0, 0.0], dtype=float)
    for azimuth in DEFAULT_SECTOR_DIRECTIONS_DEG:
        point = _point_from_compass_bearing(float(azimuth))
        assert is_supported_sector_direction_deg(float(azimuth))
        assert bool(
            inside_sector_mask(
                station_xy=station,
                point_xy=point,
                sector_azimuth_deg=float(azimuth),
                sector_beamwidth_deg=45.0,
            )
        )

    snapped = nearest_supported_sector_direction_deg(np.asarray([2.0, 47.0, 269.0]))
    assert np.allclose(snapped, np.asarray([0.0, 45.0, 270.0]))


def test_sector_gain_modes_are_configurable() -> None:
    station = np.asarray([0.0, 0.0], dtype=float)
    points = np.asarray(
        [
            _point_from_compass_bearing(0.0),
            _point_from_compass_bearing(90.0),
        ],
        dtype=float,
    )

    no_coverage_gain = np.asarray(
        compute_sector_gain_db(
            station_xy=station,
            point_xy=points,
            sector_azimuth_deg=0.0,
            sector_beamwidth_deg=60.0,
            outside_sector_mode=OUTSIDE_SECTOR_NO_COVERAGE,
            side_lobe_attenuation_db=25.0,
        )
    )
    side_lobe_gain = np.asarray(
        compute_sector_gain_db(
            station_xy=station,
            point_xy=points,
            sector_azimuth_deg=0.0,
            sector_beamwidth_deg=60.0,
            outside_sector_mode=OUTSIDE_SECTOR_SIDE_LOBE,
            side_lobe_attenuation_db=25.0,
        )
    )

    assert np.allclose(no_coverage_gain[0], 0.0)
    assert np.isneginf(no_coverage_gain[1])
    assert np.allclose(side_lobe_gain, np.asarray([0.0, -25.0]))
    assert np.allclose(
        sector_gain_linear([True, False], OUTSIDE_SECTOR_SIDE_LOBE, 30.0),
        np.asarray([1.0, 0.001]),
    )


def test_default_config_exposes_sector_geometry_fields() -> None:
    cfg = get_default_config()
    channel = init_channel_params(cfg)
    sector_cfg = sector_geometry_config_from_mapping(cfg)

    assert channel["sector_directions_deg"] == [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]
    assert np.allclose(sector_cfg.sector_directions_deg, DEFAULT_SECTOR_DIRECTIONS_DEG)
    assert float(channel["sector_beamwidth_deg"]) == float(cfg["channel"]["sector_beamwidth_deg"])
    assert channel["outside_sector_mode"] == cfg["channel"]["outside_sector_mode"]
    assert float(channel["side_lobe_attenuation_db"]) == float(cfg["channel"]["side_lobe_attenuation_db"])
