from __future__ import annotations

import math

import numpy as np

from src.baselines.registry import build_method_registry
from src.baselines.base import DeploymentProblem
from src.data.types import AirRoute, CityMap
from src.experiments.route_priority_two_stage_wrapper import run_route_priority_two_stage


def test_v2_asu_v2_method_key_registered_and_old_v2_available() -> None:
    registry = build_method_registry()
    assert "proposed_method_search_expansion_response_v2_asu_v2" in registry
    assert "proposed_method_search_expansion_response_v2" in registry
    assert registry["proposed_method_search_expansion_response_v2_asu_v2"].implemented is True


def test_v2_asu_v2_two_stage_wrapper_outputs_valid_solution() -> None:
    problem = _toy_problem(k=4)
    result = run_route_priority_two_stage(
        problem,
        problem.config,
        seed=2026,
        stage1_optimizer="proposed_method_search_expansion_response_v2_asu_v2",
        stage2_optimizer="proposed_method_search_expansion_response_v2_asu_v2",
        k1=2,
        k2=2,
    )

    assert result.final_deployment.shape == (4, 5)
    assert len(result.decoded_stations) == 4
    assert {row["station_source"] for row in result.decoded_stations} == {
        "stage1_current_priority",
        "stage2_future_priority",
    }
    assert all(
        row["station_type"] != "5GA"
        or float(row["sector_azimuth_deg"]) in {0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0}
        for row in result.decoded_stations
    )
    for stage in [result.stage1_result, result.stage2_result]:
        assert stage.logs["asu_preset"] == "asu_route_service_v2"
        assert stage.logs["uses_tmc_asu"] is False
        assert math.isfinite(float(stage.logs["best_ASU"]))
        for key in [
            "response_count",
            "mild_response_count",
            "moderate_response_count",
            "severe_response_count",
            "restart_count",
            "pbest_preservation_count",
        ]:
            assert key in stage.logs


def _toy_problem(k: int) -> DeploymentProblem:
    cfg = _toy_config(k)
    points = np.asarray(
        [
            [10.0, 10.0, 90.0],
            [30.0, 25.0, 95.0],
            [70.0, 55.0, 100.0],
            [95.0, 75.0, 100.0],
        ],
        dtype=float,
    )
    route = AirRoute(
        routes=[],
        num_segments=2,
        points_per_segment=2,
        min_altitude=90.0,
        max_altitude=100.0,
        grid_size=20.0,
        test_points=points,
    )
    city = CityMap(
        size_x=120.0,
        size_y=100.0,
        size_z=130.0,
        buildings=[],
        building_bounds=np.zeros((0, 4), dtype=float),
        height_matrix=np.zeros((1, 1), dtype=float),
        height_resolution=10.0,
    )
    return DeploymentProblem(config=cfg, city_map=city, air_route=route, channel_params=cfg["channel"])


def _toy_config(k: int) -> dict:
    return {
        "run_label": "v2_asu_v2_adapter_unit_test",
        "asu_preset": "asu_route_service_v2",
        "pso": {
            "numBaseStations": k,
            "numParticles": 4,
            "maxIterations": 2,
            "minPosition": [0.0, 0.0, 20.0],
            "maxPosition": [120.0, 100.0, 120.0],
        },
        "mopso": {"archiveSize": 4, "velocityLimitRatio": 0.2},
        "channel": {
            "frequency": 2.4e9,
            "txPower": 18.0,
            "noisePower": -90.0,
            "antennaGain": 0.0,
            "snrThreshold": 0.0,
            "lowFidelityModel": "a2g_probabilistic",
            "a2gProbabilistic": {"a": 9.61, "b": 0.16, "etaLoS": 1.0, "etaNLoS": 20.0},
            "sector_directions_deg": [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0],
            "sector_beamwidth_deg": 120.0,
            "outside_sector_mode": "no_coverage",
        },
        "heterogeneousDeployment": {
            "enabled": True,
            "stationTypes": [
                {
                    "name": "5G",
                    "ratio": 0.5,
                    "txPowerOffsetDb": 0.0,
                    "deploymentCost": 1.0,
                    "coverageBoostDb": 0.0,
                    "capacityUnits": 1.0,
                },
                {
                    "name": "5GA",
                    "ratio": 0.5,
                    "txPowerOffsetDb": 4.0,
                    "deploymentCost": 1.35,
                    "coverageBoostDb": 9.0,
                    "capacityUnits": 3.0,
                },
            ],
            "defaultSectorAzimuthDeg": 0.0,
        },
        "particleEncoding": {"optimizeStationType": True, "optimizeSectorDirection": True},
        "baselineObjectives": {"coverageWeight": 1.0, "signalQualityWeight": 0.2, "costWeight": 0.2, "costReference": 6.0},
        "nsga2": {"repair": {"enabled": True, "enforceNonBuilding": False}, "feasiblePenaltyTol": 1e9},
        "routeObjectives": {"splitMode": "index_ratio", "existingRatio": 0.5},
        "airwayServiceUtilityV2": {
            "signal_metric": "snr",
            "w_current": 0.5,
            "w_future": 0.5,
            "C_5G": 1.0,
            "C_5GA": 1.35,
            "kappa_H": 0.01,
            "C_0": 1.0,
        },
        "multiFidelity": {"mode": "all_low_fidelity"},
        "searchExpansionResponseV2": {
            "minIterationsBeforeResponse": 10,
            "responseCooldown": 10,
            "maxResponsesPerRun": 2,
        },
    }
