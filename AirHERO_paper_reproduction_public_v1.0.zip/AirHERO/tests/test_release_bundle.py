"""Sanity checks specific to preserving the fixed experimental input bundle."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]


def test_frozen_input_bytes() -> None:
    """Fixed paper inputs must retain audited bytes, not regenerated substitutes."""
    expected = {
        "artifacts/tmc_rebuild/station_generation_citywide_route_agnostic/generated_existing_stations_citywide_route_agnostic_low.csv": "6faa8a35392931ac4c0ba41a1fd0f9ccbc387dca1467be8ed25587327201532d",
        "artifacts/tmc_rebuild/route_resampling/shenyang_predicted_routes_resampled_points.csv": "54a7aa6f7480c5444d8b2ce71af5da141b81c0e6a7a1605d7771ce701a2ef732",
    }
    for path, digest in expected.items():
        assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest


def test_smoke_does_not_replace_paper_settings() -> None:
    """Smoke settings are explicit and keep the same complete fixed input data."""
    smoke = json.loads((ROOT / "configs/release/smoke.json").read_text())
    paper = json.loads((ROOT / "configs/release/paper_entry.json").read_text())
    assert smoke["validation_only"] is True and paper["validation_only"] is False
    assert (paper["population"], paper["iterations_per_stage"], paper["seeds"]) == (50, 150, [2026, 2027, 2028])
    assert smoke["station_path"] == paper["station_path"] and smoke["route_path"] == paper["route_path"]


def test_route60_supplement_payload_complete() -> None:
    """Keep all 15 real supplement units and their actual route split."""
    import csv
    base = ROOT / "artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_sensitivity/route60_extension"
    with (base / "route60_all_runs.csv").open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    with (base / "route60_selected_routes.csv").open(encoding="utf-8-sig", newline="") as f:
        routes = list(csv.DictReader(f))
    assert len(rows) == len({(r["method_key"], r["K"], r["seed"]) for r in rows}) == 15
    assert all(r["status"] == "completed" and r["seed"] == "2026" for r in rows)
    assert len({r["route_id"] for r in routes}) == 60
    assert sum(r["route_category"] == "current" for r in routes) == 25
    assert sum(r["route_category"] == "predicted" for r in routes) == 35
    assert (ROOT / "scripts/tmc_rebuild/run_route60_historical_multioptimizer_extension.py").is_file()
