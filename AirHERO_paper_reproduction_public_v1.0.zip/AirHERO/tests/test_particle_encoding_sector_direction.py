from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from src.algorithms.particle_encoding import (
    decode_particle_solution,
    extend_particles_with_decisions,
    repair_particle_encoding,
)
from src.experiments.runner import run_experiment


def _sector_config() -> dict:
    return {
        "channel": {
            "sector_directions_deg": [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0],
            "sector_beamwidth_deg": 90.0,
            "outside_sector_mode": "no_coverage",
        },
        "heterogeneousDeployment": {
            "enabled": True,
            "stationTypes": [
                {"name": "5G", "ratio": 0.5, "txPowerOffsetDb": 0.0, "deploymentCost": 1.0},
                {"name": "5GA", "ratio": 0.5, "txPowerOffsetDb": 2.0, "deploymentCost": 1.4},
            ],
            "defaultSectorAzimuthDeg": 0.0,
        },
        "particleEncoding": {
            "optimizeStationType": True,
            "optimizeSectorDirection": True,
        },
    }


def test_decode_mixed_5g_5ga_particle_has_optional_sector_azimuth() -> None:
    cfg = _sector_config()
    particle = np.asarray(
        [
            [10.0, 20.0, 30.0, 0.0, 3.0],
            [40.0, 50.0, 35.0, 1.0, 6.0],
        ],
        dtype=float,
    )

    decoded = decode_particle_solution(particle, cfg)

    assert decoded[0]["station_id"] == 1
    assert decoded[0]["station_type"] == "5G"
    assert decoded[0]["sector_azimuth_deg"] is None
    assert decoded[1]["station_type"] == "5GA"
    assert decoded[1]["sector_direction_index"] == 6
    assert decoded[1]["sector_azimuth_deg"] == 270.0


def test_repair_clips_invalid_sector_indices_to_allowed_range() -> None:
    cfg = _sector_config()
    particles = np.asarray(
        [
            [
                [10.0, 20.0, 30.0, -2.4, -9.2],
                [40.0, 50.0, 35.0, 8.1, 12.7],
            ]
        ],
        dtype=float,
    )

    repaired = repair_particle_encoding(particles, cfg)

    assert repaired[0, 0, 3] == 0.0
    assert repaired[0, 0, 4] == 0.0
    assert repaired[0, 1, 3] == 1.0
    assert repaired[0, 1, 4] == 7.0


def test_random_initialization_samples_only_eight_sector_directions() -> None:
    cfg = _sector_config()
    rng = np.random.default_rng(123)
    spatial = rng.uniform([0.0, 0.0, 10.0], [100.0, 100.0, 60.0], size=(24, 3, 3))

    particles = extend_particles_with_decisions(spatial, cfg, rng)
    decoded_azimuths = []
    for particle in particles:
        for station in decode_particle_solution(particle, cfg):
            if station["station_type"] == "5GA":
                decoded_azimuths.append(float(station["sector_azimuth_deg"]))

    assert decoded_azimuths
    assert set(decoded_azimuths).issubset({0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0})
    assert np.all((particles[:, :, 4] >= 0.0) & (particles[:, :, 4] <= 7.0))


def test_toy_optimization_exports_sector_azimuths(tmp_path: Path) -> None:
    cfg = {
        "experiment": {"method": "proposed", "name": "sector_encoding_toy"},
        "initialization": {"mode": "random"},
        "map": {"useRealMap": False, "sizeX": 280.0, "sizeY": 220.0, "sizeZ": 120.0, "numBuildings": 3},
        "airRoute": {
            "routeMode": "single_south_north",
            "numSegments": 1,
            "pointsPerSegment": 8,
            "minAltitude": 50.0,
            "maxAltitude": 70.0,
            "gridSize": 40.0,
            "lateralHalfWidthMeters": 40.0,
            "lateralStepMeters": 40.0,
            "sampleKeepProb": 1.0,
            "maxPointsPerSegment": 16,
        },
        "pso": {
            "numParticles": 4,
            "maxIterations": 3,
            "numBaseStations": 2,
            "minPosition": [0.0, 0.0, 10.0],
            "maxPosition": [280.0, 220.0, 45.0],
        },
        "heterogeneousDeployment": {
            "enabled": True,
            "stationTypes": [
                {"name": "5G", "ratio": 0.5, "txPowerOffsetDb": 0.0, "deploymentCost": 1.0},
                {"name": "5GA", "ratio": 0.5, "txPowerOffsetDb": 2.0, "deploymentCost": 1.4},
            ],
            "defaultSectorAzimuthDeg": 0.0,
        },
        "particleEncoding": {"optimizeStationType": False, "optimizeSectorDirection": True},
        "channel": {
            "sector_directions_deg": [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0],
            "sector_beamwidth_deg": 90.0,
            "outside_sector_mode": "side_lobe",
        },
        "multiFidelity": {"mode": "all_low_fidelity"},
        "mopso": {"archiveSize": 12, "stagnation": {"enabled": False}},
        "save": {"saveData": True, "saveFigures": False, "saveReport": True, "saveIntermediateMetrics": True},
    }
    cfg_path = tmp_path / "sector_toy.json"
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

    run_experiment(config_path=str(cfg_path), seed=7, results_dir=str(tmp_path / "out"), verbose=False)

    station_csv = tmp_path / "out" / "best_station_deployments.csv"
    assert station_csv.exists()
    with open(station_csv, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    assert "sector_azimuth_deg" in rows[0]
    fivega_rows = [r for r in rows if r["station_type"] == "5GA"]
    assert fivega_rows
    assert all(float(r["sector_azimuth_deg"]) in {0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0} for r in fivega_rows)
