from __future__ import annotations

import numpy as np

from src.experiments.multiobjective_metrics import (
    ObjectiveSetRecord,
    evaluate_multiobjective_metrics,
    generational_distance,
    hypervolume_minimization,
    inverted_generational_distance,
    nondominated_mask,
)


def test_hv_increases_when_approximation_improves() -> None:
    reference_point = np.asarray([1.2, 1.2], dtype=float)
    weak = np.asarray([[0.8, 0.8]], dtype=float)
    better = np.asarray([[0.2, 0.8], [0.8, 0.2]], dtype=float)

    hv_weak, weak_method = hypervolume_minimization(weak, reference_point)
    hv_better, better_method = hypervolume_minimization(better, reference_point)

    assert weak_method == "exact_2d"
    assert better_method == "exact_2d"
    assert hv_better > hv_weak


def test_gd_decreases_when_points_move_closer_to_reference() -> None:
    reference = np.asarray([[0.0, 1.0], [0.5, 0.5], [1.0, 0.0]], dtype=float)
    far = reference + 0.30
    close = reference + 0.08

    assert generational_distance(close, reference) < generational_distance(far, reference)


def test_igd_decreases_when_approximation_covers_reference_better() -> None:
    reference = np.asarray([[0.0, 1.0], [0.5, 0.5], [1.0, 0.0]], dtype=float)
    sparse = np.asarray([[0.0, 1.0]], dtype=float)
    covered = reference.copy()

    assert inverted_generational_distance(covered, reference) < inverted_generational_distance(sparse, reference)


def test_empirical_reference_front_merges_nondominated_points() -> None:
    records = [
        ObjectiveSetRecord(
            seed=1,
            method_name="method_a",
            group="main_group",
            objectives=np.asarray([[0.2, 0.8], [0.8, 0.2]], dtype=float),
        ),
        ObjectiveSetRecord(
            seed=1,
            method_name="method_b",
            group="main_group",
            objectives=np.asarray([[0.6, 0.6], [0.1, 0.9]], dtype=float),
        ),
    ]
    cfg = {
        "multiObjectiveMetrics": {
            "objectiveNames": ["obj1", "obj2"],
            "objectiveDirections": ["min", "min"],
            "normalization": {"enabled": True},
            "hypervolume": {"referencePoint": [1.2, 1.2]},
        }
    }

    result = evaluate_multiobjective_metrics(records, cfg)
    merged = np.vstack([records[0].objectives, records[1].objectives])

    assert result.metadata["reference_front_type"] == "empirical_merged_nondominated"
    assert result.metadata["reference_front_size"] == int(np.sum(nondominated_mask(merged)))
    assert len(result.per_run_rows) == 2
    assert {"hv", "gd", "igd"}.issubset(result.per_run_rows[0].keys())
