from __future__ import annotations

import math

import numpy as np

from src.baselines.base import DeploymentProblem
from src.data.types import AirRoute, CityMap
from src.experiments.asu_route_service_v2 import asu_route_service_v2_from_metrics
from src.experiments.asu_route_service_v2_sinr import (
    ASU_ROUTE_SERVICE_V2_SINR,
    evaluate_with_existing_context_sinr_asu_v2,
)


def _toy_problem(rho: float = 0.10) -> DeploymentProblem:
    points = np.asarray(
        [
            [0.0, 0.0, 100.0, 100.0],
            [200.0, 0.0, 100.0, 100.0],
            [400.0, 0.0, 100.0, 100.0],
            [600.0, 0.0, 100.0, 100.0],
        ],
        dtype=float,
    )
    cfg = {
        "pso": {"numBaseStations": 1, "minPosition": [-100.0, -100.0, 20.0], "maxPosition": [700.0, 100.0, 120.0]},
        "channel": {
            "frequency": 2.4e9,
            "txPower": 18.0,
            "noisePower": -90.0,
            "antennaGain": 0.0,
            "snrThreshold": 0.0,
            "lowFidelityModel": "a2g_probabilistic",
            "a2gProbabilistic": {"a": 9.61, "b": 0.16, "etaLoS": 1.0, "etaNLoS": 20.0},
            "sector_directions_deg": [0, 45, 90, 135, 180, 225, 270, 315],
            "sector_beamwidth_deg": 120.0,
            "outside_sector_mode": "no_coverage",
        },
        "evaluation": {
            "optimization_signal_metric": "sinr",
            "signal_metric": "sinr",
            "threshold_main_db": 0.0,
            "auxiliary_thresholds_db": [5.0, 10.0],
            "rho": float(rho),
            "power_mode": "station_file_preferred",
        },
        "heterogeneousDeployment": {
            "enabled": True,
            "existingStations": [[100.0, 0.0, 35.0, 35.0]],
            "existingStationTypes": ["5G"],
            "existingStationTxPowerDbm": [18.0],
            "existingStationSectorAzimuthsDeg": [0.0],
            "stationTypes": [
                {"name": "5G", "deploymentCost": 1.0, "cost": 1.0, "txPowerOffsetDb": 0.0, "coverageBoostDb": 0.0, "capacityUnits": 1.0},
                {"name": "5GA", "deploymentCost": 1.35, "cost": 1.35, "txPowerOffsetDb": 4.0, "coverageBoostDb": 9.0, "capacityUnits": 3.0},
            ],
        },
        "particleEncoding": {"optimizeStationType": True, "optimizeSectorDirection": True},
        "routeObjectives": {"splitMode": "explicit_indices", "existingIndices": [0, 1], "futureIndices": [2, 3]},
        "routePointMetadata": {"route_ids": ["r0", "r0", "r0", "r0"], "point_indices": [0, 1, 2, 3]},
        "airwayServiceUtilityV2": {
            "signal_metric": "sinr",
            "optimization_signal_metric": "sinr",
            "w_current": 0.5,
            "w_future": 0.5,
            "C_5G": 1.0,
            "C_5GA": 1.35,
            "kappa_H": 0.01,
            "C_0": 1.0,
        },
        "nsga2": {"feasiblePenaltyTol": 1e9},
    }
    city = CityMap(
        size_x=1000.0,
        size_y=1000.0,
        size_z=200.0,
        buildings=[],
        building_bounds=np.zeros((0, 4), dtype=float),
        height_matrix=np.zeros((1, 1), dtype=float),
        height_resolution=100.0,
    )
    return DeploymentProblem(
        config=cfg,
        city_map=city,
            air_route=AirRoute(
                routes=[],
                num_segments=1,
                points_per_segment=4,
                min_altitude=100.0,
                max_altitude=100.0,
                grid_size=100.0,
                test_points=points,
            ),
        channel_params=cfg["channel"],
    )


def test_sinr_evaluator_exists_and_old_snr_evaluator_remains_available() -> None:
    assert ASU_ROUTE_SERVICE_V2_SINR == "asu_route_service_v2_sinr"
    old = asu_route_service_v2_from_metrics(
        {
            "coverage_rate": 1.0,
            "mean_snr_db": 10.0,
            "handover_count": 0,
            "deployment_cost": 1.0,
            "N_5G": 1,
            "N_5GA": 0,
        },
        {"airwayServiceUtilityV2": {"signal_metric": "snr"}},
    )
    assert math.isfinite(old.ASU)


def test_sinr_evaluator_uses_rho_and_interference() -> None:
    decision = np.asarray([[[300.0, 0.0, 60.0, 0.0, 0.0]]], dtype=float)
    low_rho = evaluate_with_existing_context_sinr_asu_v2(
        decisions=decision,
        problem=_toy_problem(rho=0.0),
        config=_toy_problem(rho=0.0).config,
        method_name="toy",
    )
    high_rho_problem = _toy_problem(rho=1.0)
    high_rho = evaluate_with_existing_context_sinr_asu_v2(
        decisions=decision,
        problem=high_rho_problem,
        config=high_rho_problem.config,
        method_name="toy",
    )
    assert high_rho.metrics[0]["rho"] == 1.0
    assert high_rho.metrics[0]["mean_SINR_db"] < low_rho.metrics[0]["mean_SINR_db"]
    assert high_rho.asu_values[0] < low_rho.asu_values[0]


def test_sinr_evaluator_cost_threshold_gamma_and_no_nan() -> None:
    problem = _toy_problem(rho=0.1)
    decision = np.asarray([[[300.0, 0.0, 60.0, 1.0, 0.0]]], dtype=float)
    result = evaluate_with_existing_context_sinr_asu_v2(
        decisions=decision,
        problem=problem,
        config=problem.config,
        method_name="toy",
    )
    row = result.metrics[0]
    assert row["N_5G"] == 0
    assert row["N_5GA"] == 1
    assert row["C_dep"] == 1.35
    assert row["existing_stations_excluded_from_C_dep"] is True
    assert 0.0 <= row["Coverage@0dB"] <= 1.0
    assert row["coverage_rate"] == row["Coverage@0dB"]
    assert math.isfinite(row["ASU"])
    assert row["ASU"] >= 0.0
    numerator = 0.5 * row["Q_current"] + 0.5 * row["Q_future"]
    denominator = row["C_dep"] + row["kappa_H"] * row["handover_count"] + row["C_0"]
    assert abs(row["ASU"] - numerator / denominator) < 1e-12


def test_optimization_time_and_final_report_metrics_match_for_same_evaluator() -> None:
    problem = _toy_problem(rho=0.1)
    decision = np.asarray([[[300.0, 0.0, 60.0, 0.0, 0.0]]], dtype=float)
    a = evaluate_with_existing_context_sinr_asu_v2(decisions=decision, problem=problem, config=problem.config, method_name="toy")
    b = evaluate_with_existing_context_sinr_asu_v2(decisions=decision, problem=problem, config=problem.config, method_name="toy_final")
    keys = ["Q_current", "Q_future", "ASU_numerator", "ASU_denominator", "ASU", "Coverage@0dB", "Coverage@5dB", "Coverage@10dB", "C_dep", "handover_count", "mean_SINR_db"]
    for key in keys:
        assert abs(float(a.metrics[0][key]) - float(b.metrics[0][key])) < 1e-12
