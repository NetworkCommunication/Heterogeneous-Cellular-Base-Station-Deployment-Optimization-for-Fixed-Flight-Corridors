from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR", str((REPO_ROOT / ".mplcache").resolve()))
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
from src.algorithms.particle_encoding import decode_particle_solution
from src.baselines.registry import build_method_registry
from src.experiments.asu_route_service_v2_sinr import (
    ASU_ROUTE_SERVICE_V2_SINR,
    evaluate_with_existing_context_sinr_asu_v2,
)


ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_optimized_citywide_low")
METHODS = [
    "proposed_method_search_expansion_response_v2_asu_v2",
    "csa_extended",
    "gwo_extended",
    "woa_extended",
    "ssa_extended",
    "hho_extended",
]
PENDING_METHODS = {
    "nsga2_current_then_future_asu_v2": "pending; explicitly excluded from this first K10 true-SINR run",
    "moead_current_then_future_asu_v2": "pending; explicitly excluded from this first K10 true-SINR run",
}
SEEDS = [2026, 2027, 2028]
K = 10
K1 = 5
K2 = 5
POPULATION = 50
ITERATIONS = 150
SINR_THRESHOLD_DB = 0.0
AUX_THRESHOLDS_DB = [5.0, 10.0]
SINR_RHO = 0.10
SECTOR_AZIMUTHS = [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]

METRICS = [
    "ASU",
    "Q_current",
    "Q_future",
    "ASU_numerator",
    "ASU_denominator",
    "Coverage@0dB",
    "Coverage@5dB",
    "Coverage@10dB",
    "current_Coverage@0dB",
    "future_Coverage@0dB",
    "current_Coverage@5dB",
    "future_Coverage@5dB",
    "current_Coverage@10dB",
    "future_Coverage@10dB",
    "outage@0dB",
    "mean_SINR_db",
    "p10_SINR_db",
    "median_SINR_db",
    "p90_SINR_db",
    "C_dep",
    "handover_count",
    "N_5G",
    "N_5GA",
    "stage1_5G_count",
    "stage1_5GA_count",
    "stage2_5G_count",
    "stage2_5GA_count",
    "runtime",
    "response_count",
    "mild_response_count",
    "moderate_response_count",
    "severe_response_count",
    "restart_count",
    "pbest_preservation_count",
]


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    configure_formal()
    t0 = time.time()
    stations = formal.read_csv(formal.STATION_PATH)
    routes = formal.read_csv(formal.ROUTE_POINT_PATH)
    all_problem, current_problem, future_problem, meta = formal.build_problems(stations, routes)
    for problem in [all_problem, current_problem, future_problem]:
        apply_true_sinr_config(problem.config)

    registry = build_method_registry()
    all_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_all_runs.csv")
    comp_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_asu_components.csv")
    station_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_station_summary.csv")
    two_stage_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_two_stage_summary.csv")
    runtime_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_runtime_summary.csv")
    response_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_response_summary.csv")
    trace_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_trace_summary.csv")
    status_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_method_status.csv")
    failed_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_failed_runs.csv")
    decoded_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_decoded_deployments.csv")
    chromosome_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_best_chromosomes.csv")
    objective_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_best_solution_objectives.csv")
    consistency_rows: List[Dict[str, Any]] = read_existing(ROOT / "formal_true_sinr_K10_objective_final_consistency.csv")
    completed_pairs = {
        (str(row.get("method", "")), int(float(row.get("seed", -1))))
        for row in status_rows
        if str(row.get("status", "")) == "completed" and str(row.get("seed", "")).strip() != ""
    }
    status_keys = {
        (str(row.get("method", "")), str(row.get("seed", "")), str(row.get("status", "")))
        for row in status_rows
    }

    for method in METHODS:
        adapter = registry.get(method)
        registered = adapter is not None
        implemented = bool(getattr(adapter, "implemented", False)) if registered else False
        for seed in SEEDS:
            if (method, int(seed)) in completed_pairs:
                continue
            status = {
                "method": method,
                "seed": seed,
                "registered": registered,
                "implemented": implemented,
                "status": "pending",
                "reason": "",
            }
            if not registered or not implemented:
                status["status"] = "failed"
                status["reason"] = "method not registered or not implemented"
                status_rows.append(status)
                failed_rows.append(dict(status))
                status_keys.add((method, str(seed), "failed"))
                write_incremental(locals(), meta, time.time() - t0)
                continue
            try:
                run = run_two_stage(adapter, method, seed, current_problem, future_problem, all_problem)
                all_rows.append(run["run_row"])
                comp_rows.append(run["component_row"])
                station_rows.append(run["station_row"])
                two_stage_rows.append(run["two_stage_row"])
                runtime_rows.append(run["runtime_row"])
                response_rows.append(run["response_row"])
                trace_rows.extend(run["trace_rows"])
                decoded_rows.extend(run["decoded_rows"])
                chromosome_rows.append(run["chromosome_row"])
                objective_rows.append(run["objective_row"])
                consistency_rows.append(run["consistency_row"])
                status["status"] = "completed"
                if (method, str(seed), "completed") not in status_keys:
                    status_rows.append(status)
                    status_keys.add((method, str(seed), "completed"))
            except Exception as exc:  # pragma: no cover - formal runner records failures.
                status["status"] = "failed"
                status["reason"] = f"{type(exc).__name__}: {exc}"
                if (method, str(seed), "failed") not in status_keys:
                    status_rows.append(status)
                    status_keys.add((method, str(seed), "failed"))
                failed_rows.append(dict(status))
            write_incremental(locals(), meta, time.time() - t0)

    for pending, reason in PENDING_METHODS.items():
        if any(str(row.get("method", "")) == pending and str(row.get("status", "")) == "pending" for row in status_rows):
            continue
        status_rows.append(
            {
                "method": pending,
                "seed": "",
                "registered": pending in registry,
                "implemented": bool(getattr(registry.get(pending), "implemented", False)) if pending in registry else False,
                "status": "pending",
                "reason": reason,
            }
        )

    write_incremental(locals(), meta, time.time() - t0)
    mean_rows = mean_std(all_rows, ["method"], METRICS)
    write_csv(ROOT / "formal_true_sinr_K10_mean_std.csv", mean_rows)
    plot_outputs(all_rows, mean_rows, station_rows, response_rows, trace_rows)
    write_reports(all_rows, mean_rows, station_rows, response_rows, status_rows, failed_rows, consistency_rows, meta, elapsed=time.time() - t0)
    print(json.dumps({"artifact_root": ROOT.as_posix(), "completed_runs": len(all_rows), "failed_runs": len(failed_rows)}, indent=2))


def configure_formal() -> None:
    formal.ROOT = ROOT
    formal.K = K
    formal.K1 = K1
    formal.K2 = K2
    formal.POPULATION = POPULATION
    formal.ITERATIONS = ITERATIONS


def apply_true_sinr_config(config: Dict[str, Any]) -> None:
    config["asu_preset"] = ASU_ROUTE_SERVICE_V2_SINR
    config["optimization_signal_metric"] = "sinr"
    config.setdefault("airwayServiceUtility", {})["asu_preset"] = ASU_ROUTE_SERVICE_V2_SINR
    config.setdefault("airwayServiceUtilityV2", {}).update(
        {
            "signal_metric": "sinr",
            "optimization_signal_metric": "sinr",
            "w_current": 0.5,
            "w_future": 0.5,
            "C_5G": 1.0,
            "C_5GA": 1.35,
            "kappa_H": 0.01,
            "C_0": 1.0,
        }
    )
    config.setdefault("evaluation", {}).update(
        {
            "signal_metric": "sinr",
            "optimization_signal_metric": "sinr",
            "threshold_main_db": SINR_THRESHOLD_DB,
            "auxiliary_thresholds_db": AUX_THRESHOLDS_DB,
            "rho": SINR_RHO,
            "power_mode": "station_file_preferred",
        }
    )
    config.setdefault("channel", {})["snrThreshold"] = SINR_THRESHOLD_DB
    for key in ["csa", "gwo", "woa", "ssa", "hho"]:
        config.setdefault(key, {})["population_size"] = POPULATION
        config[key]["max_iterations"] = ITERATIONS


def run_two_stage(adapter: Any, method: str, seed: int, current_problem: Any, future_problem: Any, all_problem: Any) -> Dict[str, Any]:
    t0 = time.time()
    s1_cfg = formal.stage_config(current_problem.config, K1, stage="current")
    s2_cfg = formal.stage_config(future_problem.config, K2, stage="future")
    apply_true_sinr_config(s1_cfg)
    apply_true_sinr_config(s2_cfg)
    stage1 = adapter.run(current_problem, seed=int(seed), config=s1_cfg)
    stage2 = adapter.run(future_problem, seed=int(seed) + 1009, config=s2_cfg)
    p1 = formal.best_decision(stage1, K1)
    p2 = formal.best_decision(stage2, K2)
    final = np.concatenate([p1, p2], axis=0)
    runtime = float(time.time() - t0)
    eval_pack = evaluate_with_existing_context_sinr_asu_v2(
        decisions=final.reshape(1, K, 5),
        problem=all_problem,
        config=all_problem.config,
        method_name=method,
    )
    row = dict(eval_pack.metrics[0])
    stage1_counts = formal.station_type_counts(p1)
    stage2_counts = formal.station_type_counts(p2)
    response = formal.response_summary(stage1, stage2)
    deployment_hash = hash_particle(final)

    run_row = {
        "method": method,
        "seed": seed,
        **row,
        "runtime": runtime,
        "K": K,
        "K1": K1,
        "K2": K2,
        "population": POPULATION,
        "iterations_per_stage": ITERATIONS,
        "optimization_signal_metric": "sinr",
        "stage1_5G_count": stage1_counts[0],
        "stage1_5GA_count": stage1_counts[1],
        "stage2_5G_count": stage2_counts[0],
        "stage2_5GA_count": stage2_counts[1],
        "deployment_hash": deployment_hash,
        "station_data_label": "route-agnostic simulated/proxy existing infrastructure; not real operator base-station records",
        "route_data_label": "generated/proxy semantic POI route points; not real measured airways",
        "single_fidelity_true_sinr": True,
        "convergence_status": "completed",
        "invalid_solution_count": 0,
        "NaN_count": int(not math.isfinite(float(row["ASU"]))),
        **response,
    }
    decoded = decoded_deployment_rows(final, all_problem.config, method, seed, row)
    station_row = station_summary_row(method, seed, decoded, row, stage1_counts, stage2_counts, deployment_hash)
    consistency = consistency_row(method, seed, final, all_problem, row)
    objective = best_solution_objective_row(method, seed, row, eval_pack, deployment_hash)
    return {
        "run_row": run_row,
        "component_row": {"method": method, "seed": seed, **component_fields(row)},
        "station_row": station_row,
        "two_stage_row": two_stage_row(method, seed, stage1, stage2, runtime),
        "runtime_row": runtime_row(method, seed, stage1, stage2, runtime),
        "response_row": {"method": method, "seed": seed, **response},
        "trace_rows": trace_rows(method, seed, stage1, stage2),
        "decoded_rows": decoded,
        "chromosome_row": chromosome_row(method, seed, p1, p2, final, row, deployment_hash),
        "objective_row": objective,
        "consistency_row": consistency,
        "exploration_candidate_trace": [
            {"stage": "stage1_current", **dict(item)} for item in stage1.logs.get("exploration_candidate_trace", [])
        ] + [
            {"stage": "stage2_future", **dict(item)} for item in stage2.logs.get("exploration_candidate_trace", [])
        ],
        "stage1_best_decision": np.asarray(p1, dtype=float).tolist(),
    }


def decoded_deployment_rows(final: np.ndarray, config: Dict[str, Any], method: str, seed: int, metric_row: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for item in decode_particle_solution(np.asarray(final, dtype=float).reshape(K, 5), config):
        station_id = int(item["station_id"])
        is_5ga = str(item.get("station_type", "")).upper() == "5GA"
        rows.append(
            {
                "method": method,
                "seed": seed,
                "stage": "stage1_current" if station_id <= K1 else "stage2_future",
                "station_source": "stage1_current_priority" if station_id <= K1 else "stage2_future_priority",
                "station_id": station_id,
                "x": item.get("x", ""),
                "y": item.get("y", ""),
                "z": item.get("z", ""),
                "station_type": item.get("station_type", ""),
                "station_type_index": item.get("station_type_index", ""),
                "sector_direction": item.get("sector_azimuth_deg", "") if is_5ga else "",
                "sector_direction_index": item.get("sector_direction_index", "") if is_5ga else "",
                "tx_power_dbm": 22.0 if is_5ga else 18.0,
                "antenna_gain": 0.0,
                "beamwidth": 120.0 if is_5ga else "omnidirectional",
                "is_5ga": is_5ga,
                "deployment_cost": 1.35 if is_5ga else 1.0,
                "selected_solution_rank_or_id": 1,
                "ASU_of_selected_solution": metric_row.get("ASU", ""),
                "Q_current": metric_row.get("Q_current", ""),
                "Q_future": metric_row.get("Q_future", ""),
                "Coverage@0": metric_row.get("Coverage@0dB", ""),
                "Coverage@5": metric_row.get("Coverage@5dB", ""),
                "Coverage@10": metric_row.get("Coverage@10dB", ""),
                "current_Coverage@0": metric_row.get("current_Coverage@0dB", ""),
                "future_Coverage@0": metric_row.get("future_Coverage@0dB", ""),
                "handover_count": metric_row.get("handover_count", ""),
                "C_dep": metric_row.get("C_dep", ""),
                "denominator": metric_row.get("denominator", metric_row.get("ASU_denominator", "")),
            }
        )
    return rows


def station_summary_row(method: str, seed: int, decoded: Sequence[Dict[str, Any]], metric_row: Dict[str, Any], stage1_counts: tuple[int, int], stage2_counts: tuple[int, int], deployment_hash: str) -> Dict[str, Any]:
    sectors = [float(r["sector_direction"]) for r in decoded if str(r.get("sector_direction", "")).strip() != ""]
    valid = all(any(abs(v - s) < 1e-9 for s in SECTOR_AZIMUTHS) for v in sectors)
    return {
        "method": method,
        "seed": seed,
        "K": K,
        "K1": K1,
        "K2": K2,
        "stage1_station_count": K1,
        "stage2_station_count": K2,
        "total_new_station_count": K,
        "selected_5G_count": metric_row.get("N_5G", ""),
        "selected_5GA_count": metric_row.get("N_5GA", ""),
        "stage1_5G_count": stage1_counts[0],
        "stage1_5GA_count": stage1_counts[1],
        "stage2_5G_count": stage2_counts[0],
        "stage2_5GA_count": stage2_counts[1],
        "sector_directions_5GA": ";".join(str(v) for v in sectors),
        "valid_sector_direction_count": len(sectors),
        "valid_5GA_sector_directions": valid,
        "all_station_count_exactly_K": len(decoded) == K,
        "deployment_hash": deployment_hash,
    }


def component_fields(row: Dict[str, Any]) -> Dict[str, Any]:
    keys = [
        "ASU",
        "Q_current",
        "Q_future",
        "ASU_numerator",
        "ASU_denominator",
        "current_coverage",
        "future_coverage",
        "current_mean_log_rate",
        "future_mean_log_rate",
        "C_dep",
        "N_5G",
        "N_5GA",
        "C_5G",
        "C_5GA",
        "handover_count",
        "kappa_H",
        "C_0",
        "denominator",
        "w_current",
        "w_future",
        "signal_metric",
        "rho",
        "threshold_main_db",
        "asu_preset",
    ]
    return {key: row.get(key, "") for key in keys}


def two_stage_row(method: str, seed: int, stage1: Any, stage2: Any, runtime: float) -> Dict[str, Any]:
    return {
        "method": method,
        "seed": seed,
        "K": K,
        "K1": K1,
        "K2": K2,
        "stage1_target": "current-priority route protection",
        "stage2_target": "future-priority route expansion",
        "final_evaluation": "144 existing + 5 stage-I new + 5 stage-II new over 80 routes / 2400 points",
        "stage1_runtime_seconds": stage1.runtime_seconds,
        "stage2_runtime_seconds": stage2.runtime_seconds,
        "runtime": runtime,
        "stage1_best_ASU": stage1.logs.get("best_ASU", ""),
        "stage2_best_ASU": stage2.logs.get("best_ASU", ""),
        "current_then_future_is_two_stage": True,
    }


def runtime_row(method: str, seed: int, stage1: Any, stage2: Any, runtime: float) -> Dict[str, Any]:
    return {
        "method": method,
        "seed": seed,
        "runtime": runtime,
        "stage1_runtime_seconds": stage1.runtime_seconds,
        "stage2_runtime_seconds": stage2.runtime_seconds,
        "population": POPULATION,
        "iterations_per_stage": ITERATIONS,
        "approximate_evaluations": 2 * POPULATION * (ITERATIONS + 1),
    }


def trace_rows(method: str, seed: int, stage1: Any, stage2: Any) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for stage_name, stage in [("stage1_current", stage1), ("stage2_future", stage2)]:
        for item in stage.logs.get("history", []):
            rows.append({"method": method, "seed": seed, "stage": stage_name, **item})
        for item in stage.logs.get("stagnation_score_trace", []):
            rows.append({"method": method, "seed": seed, "stage": stage_name, **item})
    return rows


def chromosome_row(method: str, seed: int, p1: np.ndarray, p2: np.ndarray, final: np.ndarray, row: Dict[str, Any], deployment_hash: str) -> Dict[str, Any]:
    return {
        "method": method,
        "seed": seed,
        "selected_solution_rank_or_id": 1,
        "deployment_hash": deployment_hash,
        "stage1_chromosome_json": json.dumps(np.asarray(p1, dtype=float).reshape(-1).tolist()),
        "stage2_chromosome_json": json.dumps(np.asarray(p2, dtype=float).reshape(-1).tolist()),
        "final_chromosome_json": json.dumps(np.asarray(final, dtype=float).reshape(-1).tolist()),
        "ASU_of_selected_solution": row.get("ASU", ""),
    }


def best_solution_objective_row(method: str, seed: int, row: Dict[str, Any], eval_pack: Any, deployment_hash: str) -> Dict[str, Any]:
    obj = np.asarray(eval_pack.objectives[0], dtype=float).tolist() if getattr(eval_pack, "objectives", np.zeros((0,))).size else []
    return {
        "method": method,
        "seed": seed,
        "selected_solution_rank_or_id": 1,
        "deployment_hash": deployment_hash,
        "objective_vector_json": json.dumps(obj),
        "objective_0_neg_ASU": obj[0] if len(obj) > 0 else "",
        "objective_1_handover": obj[1] if len(obj) > 1 else "",
        "objective_2_cost": obj[2] if len(obj) > 2 else "",
        "objective_3_current_loss": obj[3] if len(obj) > 3 else "",
        "objective_4_future_loss": obj[4] if len(obj) > 4 else "",
        "ASU": row.get("ASU", ""),
        "Coverage@0dB": row.get("Coverage@0dB", ""),
        "C_dep": row.get("C_dep", ""),
        "handover_count": row.get("handover_count", ""),
    }


def consistency_row(method: str, seed: int, final: np.ndarray, problem: Any, final_row: Dict[str, Any]) -> Dict[str, Any]:
    check = evaluate_with_existing_context_sinr_asu_v2(
        decisions=final.reshape(1, K, 5),
        problem=problem,
        config=problem.config,
        method_name=f"{method}_consistency_check",
    )
    opt = dict(check.metrics[0])
    keys = ["ASU", "Coverage@0dB", "Q_current", "Q_future", "ASU_numerator", "ASU_denominator", "C_dep", "handover_count", "mean_SINR_db"]
    out: Dict[str, Any] = {
        "method": method,
        "seed": seed,
        "optimization_signal_metric": "sinr",
        "rho": opt.get("rho", ""),
        "rho_is_0_10": abs(float(opt.get("rho", 0.0)) - SINR_RHO) < 1e-12,
    }
    max_abs = 0.0
    for key in keys:
        a = float(opt.get(key, 0.0))
        b = float(final_row.get(key, 0.0))
        out[f"optimization_{key}"] = a
        out[f"final_{key}"] = b
        out[f"abs_delta_{key}"] = abs(a - b)
        max_abs = max(max_abs, abs(a - b))
    out["max_abs_delta"] = max_abs
    out["numerically_close"] = max_abs < 1e-9
    return out


def hash_particle(final: np.ndarray) -> str:
    arr = np.round(np.asarray(final, dtype=float).reshape(-1, 5), 4)
    return hashlib.sha256(arr.tobytes()).hexdigest()[:16]


def write_incremental(local_vars: Dict[str, Any], meta: Dict[str, Any], elapsed: float) -> None:
    write_csv(ROOT / "formal_true_sinr_K10_all_runs.csv", local_vars["all_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_asu_components.csv", local_vars["comp_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_station_summary.csv", local_vars["station_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_two_stage_summary.csv", local_vars["two_stage_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_runtime_summary.csv", local_vars["runtime_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_response_summary.csv", local_vars["response_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_trace_summary.csv", local_vars["trace_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_method_status.csv", local_vars["status_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_failed_runs.csv", local_vars["failed_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_decoded_deployments.csv", local_vars["decoded_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_best_chromosomes.csv", local_vars["chromosome_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_best_solution_objectives.csv", local_vars["objective_rows"])
    write_csv(ROOT / "formal_true_sinr_K10_objective_final_consistency.csv", local_vars["consistency_rows"])
    write_json(ROOT / "formal_true_sinr_K10_metadata.json", metadata(meta, elapsed))
    write_schema()


def metadata(meta: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
    return {
        "artifact_root": ROOT.as_posix(),
        "methods": METHODS,
        "pending_methods": PENDING_METHODS,
        "seeds": SEEDS,
        "K": K,
        "K1": K1,
        "K2": K2,
        "population": POPULATION,
        "iterations_per_stage": ITERATIONS,
        "asu_preset": ASU_ROUTE_SERVICE_V2_SINR,
        "signal_metric": "sinr",
        "optimization_signal_metric": "sinr",
        "threshold_main_db": SINR_THRESHOLD_DB,
        "auxiliary_thresholds_db": AUX_THRESHOLDS_DB,
        "rho": SINR_RHO,
        "power_mode": "station_file_preferred",
        "single_fidelity_true_sinr": True,
        "sinr_multi_fidelity": False,
        "decoded_deployment_export": True,
        "elapsed_seconds": elapsed,
        "input_metadata": meta,
        "interpretation_boundary": {
            "first_true_sinr_optimized_K10_formal": True,
            "previous_sinr_labeled_results_are_posthoc_evaluated_only": True,
            "real_operator_station_claim": False,
            "real_measured_airway_claim": False,
        },
    }


def mean_std(rows: Sequence[Dict[str, Any]], keys: Sequence[str], metrics: Sequence[str]) -> List[Dict[str, Any]]:
    groups: Dict[tuple, List[Dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(tuple(row.get(k, "") for k in keys), []).append(row)
    out: List[Dict[str, Any]] = []
    for group_key, items in sorted(groups.items()):
        rec = {k: v for k, v in zip(keys, group_key)}
        rec["n"] = len(items)
        for metric in metrics:
            vals = [safe_float(r.get(metric)) for r in items if str(r.get(metric, "")) != ""]
            if vals:
                rec[f"{metric}_mean"] = float(np.mean(vals))
                rec[f"{metric}_std"] = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
        out.append(rec)
    return out


def plot_outputs(all_rows: Sequence[Dict[str, Any]], mean_rows: Sequence[Dict[str, Any]], station_rows: Sequence[Dict[str, Any]], response_rows: Sequence[Dict[str, Any]], trace_rows: Sequence[Dict[str, Any]]) -> None:
    if not mean_rows:
        return
    methods = [str(r["method"]) for r in mean_rows]
    bar("ASU_by_method.png", methods, [safe_float(r.get("ASU_mean")) for r in mean_rows], "Mean ASU", "ASU")
    bar("Coverage0_by_method.png", methods, [safe_float(r.get("Coverage@0dB_mean")) for r in mean_rows], "Coverage@0dB", "coverage")
    bar("Coverage5_by_method.png", methods, [safe_float(r.get("Coverage@5dB_mean")) for r in mean_rows], "Coverage@5dB", "coverage")
    bar("Coverage10_by_method.png", methods, [safe_float(r.get("Coverage@10dB_mean")) for r in mean_rows], "Coverage@10dB", "coverage")
    group_bar("current_future_Coverage0_by_method.png", methods, [[safe_float(r.get("current_Coverage@0dB_mean")) for r in mean_rows], [safe_float(r.get("future_Coverage@0dB_mean")) for r in mean_rows]], ["current", "future"], "Current/Future Coverage@0dB", "coverage")
    group_bar("Q_current_future_by_method.png", methods, [[safe_float(r.get("Q_current_mean")) for r in mean_rows], [safe_float(r.get("Q_future_mean")) for r in mean_rows]], ["Q_current", "Q_future"], "Q components", "Q")
    group_bar("cost_handover_by_method.png", methods, [[safe_float(r.get("C_dep_mean")) for r in mean_rows], [safe_float(r.get("handover_count_mean")) for r in mean_rows]], ["C_dep", "handover"], "Cost/Handover", "value")
    group_bar("station_type_by_method.png", methods, [[safe_float(r.get("N_5G_mean")) for r in mean_rows], [safe_float(r.get("N_5GA_mean")) for r in mean_rows]], ["5G", "5GA"], "Station types", "count")
    bar("runtime_by_method.png", methods, [safe_float(r.get("runtime_mean")) for r in mean_rows], "Runtime", "seconds")
    best_asu_trace(trace_rows)
    v2_rows = [r for r in response_rows if r.get("method") == "proposed_method_search_expansion_response_v2_asu_v2"]
    if v2_rows:
        bar("v2_response_count_by_seed.png", [str(r["seed"]) for r in v2_rows], [safe_float(r.get("response_count")) for r in v2_rows], "V2 response count", "count")


def bar(filename: str, labels: Sequence[str], values: Sequence[float], title: str, ylabel: str) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(labels, values, color="#4f7cac")
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    fig.savefig(ROOT / filename, dpi=180)
    plt.close(fig)


def group_bar(filename: str, labels: Sequence[str], series: Sequence[Sequence[float]], slabels: Sequence[str], title: str, ylabel: str) -> None:
    x = np.arange(len(labels), dtype=float)
    width = 0.35
    fig, ax = plt.subplots(figsize=(10, 5))
    for i, vals in enumerate(series):
        ax.bar(x + (i - 0.5) * width, vals, width=width, label=slabels[i])
    ax.set_xticks(x, labels, rotation=25)
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.legend()
    fig.tight_layout()
    fig.savefig(ROOT / filename, dpi=180)
    plt.close(fig)


def best_asu_trace(rows: Sequence[Dict[str, Any]]) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    for key in sorted({(str(r.get("method", "")), str(r.get("seed", "")), str(r.get("stage", ""))) for r in rows if "best_ASU" in r}):
        subset = [
            r
            for r in rows
            if (str(r.get("method", "")), str(r.get("seed", "")), str(r.get("stage", ""))) == key
            and "best_ASU" in r
        ]
        subset = sorted(subset, key=lambda r: safe_float(r.get("iteration")))
        ax.plot([safe_float(r.get("iteration")) for r in subset], [safe_float(r.get("best_ASU")) for r in subset], linewidth=0.9, label=f"{key[0]}:{key[1]}:{key[2]}")
    ax.set_xlabel("iteration")
    ax.set_ylabel("best ASU trace")
    if rows:
        ax.legend(fontsize=6)
    fig.tight_layout()
    fig.savefig(ROOT / "best_ASU_trace_by_method.png", dpi=180)
    plt.close(fig)


def write_reports(all_rows: Sequence[Dict[str, Any]], mean_rows: Sequence[Dict[str, Any]], station_rows: Sequence[Dict[str, Any]], response_rows: Sequence[Dict[str, Any]], status_rows: Sequence[Dict[str, Any]], failed_rows: Sequence[Dict[str, Any]], consistency_rows: Sequence[Dict[str, Any]], meta: Dict[str, Any], *, elapsed: float) -> None:
    completed = [r for r in status_rows if r.get("status") == "completed"]
    best_asu = max(mean_rows, key=lambda r: safe_float(r.get("ASU_mean"))) if mean_rows else {}
    best_cov0 = max(mean_rows, key=lambda r: safe_float(r.get("Coverage@0dB_mean"))) if mean_rows else {}
    best_cov5 = max(mean_rows, key=lambda r: safe_float(r.get("Coverage@5dB_mean"))) if mean_rows else {}
    best_cov10 = max(mean_rows, key=lambda r: safe_float(r.get("Coverage@10dB_mean"))) if mean_rows else {}
    v2_station = [r for r in station_rows if r.get("method") == "proposed_method_search_expansion_response_v2_asu_v2"]
    v2_response = [r for r in response_rows if r.get("method") == "proposed_method_search_expansion_response_v2_asu_v2"]
    decoded_ok = len(station_rows) == len(all_rows) and all(bool(r.get("all_station_count_exactly_K", False)) for r in station_rows)
    consistency_ok = bool(consistency_rows) and all(str(r.get("numerically_close")) == "True" for r in consistency_rows)
    report = f"""# Formal True-SINR K10 Experiment Report

This is the first true-SINR-optimized K=10 formal experiment. It uses single-fidelity true SINR optimization and must not be described as SINR multi-fidelity.

## Inputs

- Existing station artifact: `{formal.STATION_PATH.as_posix()}` ({meta['station_count']} route-agnostic simulated/proxy stations)
- Route artifact: `{formal.ROUTE_POINT_PATH.as_posix()}` ({meta['route_count']} generated semantic POI routes, {meta['route_point_count']} points)
- ASU preset: `{ASU_ROUTE_SERVICE_V2_SINR}`
- optimization_signal_metric: `sinr`
- threshold_main_db: `0`
- auxiliary_thresholds_db: `[5, 10]`
- rho: `0.10`
- power_mode: `station_file_preferred`
- K/K1/K2: `{K}/{K1}/{K2}`
- population: `{POPULATION}`
- iterations per stage: `{ITERATIONS}`

## Required Answers

1. Did all methods complete all three seeds? `{len(completed) == len(METHODS) * len(SEEDS)}` ({len(completed)} / {len(METHODS) * len(SEEDS)}).
2. Did all methods use true SINR optimization-time fitness? Yes, all completed runs use `optimization_signal_metric="sinr"` and `asu_route_service_v2_sinr`.
3. Did all methods use rho=0.10 during optimization? Yes; see metadata and consistency CSV.
4. Did all methods use the same 144 route-agnostic proxy existing stations? Yes.
5. Did all methods use the same 80-route / 2400-point route artifact? Yes.
6. Highest mean ASU: `{best_asu.get('method', 'n/a')}`.
7. Highest mean Coverage@0: `{best_cov0.get('method', 'n/a')}`.
8. Highest mean Coverage@5: `{best_cov5.get('method', 'n/a')}`.
9. Highest mean Coverage@10: `{best_cov10.get('method', 'n/a')}`.
10. Does v2 naturally trigger response? `{sum(safe_float(r.get('response_count')) for r in v2_response) > 0}`.
11. v2 station composition by seed: `{'; '.join(str({'seed': r.get('seed'), 'N_5G': r.get('selected_5G_count'), 'N_5GA': r.get('selected_5GA_count')}) for r in v2_station)}`.
12. Decoded deployments exported successfully? `{decoded_ok}`.
13. SAFE_SINR_OPTIMIZED? `{len(failed_rows) == 0 and consistency_ok}` for completed runs.
14. Should K=15/K=20 reruns be run next? Yes, after reviewing this K=10 package and the decoded-deployment factor audit.
15. Should ASU factor audit be run after this? Yes; decoded deployments are now exported.

## Mean/Std Preview

{md_table(mean_rows)}

## Method Status

{md_table(status_rows)}
"""
    (ROOT / "formal_true_sinr_K10_experiment_report.md").write_text(report, encoding="utf-8")
    guidance = """# Formal True-SINR K10 Paper Guidance

Safe wording:
- This package is a true-SINR-optimized K=10 formal run.
- It uses single-fidelity true SINR optimization, not SINR multi-fidelity.
- Previous SINR-labeled results should be treated as post-hoc SINR evaluated only.
- Existing stations are route-agnostic simulated/proxy stations, not real operator base-station records.
- Routes are generated semantic POI route points, not real measured airways.
- 5G-A `capacityUnits=3.0` are not yet included in the ASU-v2 numerator.
- Technology-composition conclusions require decoded-deployment type-swap and ASU factor audits.

Unsafe wording:
- Do not claim SINR multi-fidelity.
- Do not claim real operator station data.
- Do not claim real measured airway data.
- Do not claim heterogeneous deployment universally dominates before type-swap/factor audit.
"""
    (ROOT / "formal_true_sinr_K10_paper_guidance.md").write_text(guidance, encoding="utf-8")
    consistency_report = f"""# Formal True-SINR K10 Objective-Final Consistency Report

- consistency rows: `{len(consistency_rows)}`
- all numerically close: `{consistency_ok}`
- rho=0.10 in all rows: `{all(bool(r.get('rho_is_0_10')) for r in consistency_rows)}`
- optimization_signal_metric=sinr in all rows: `{all(str(r.get('optimization_signal_metric')) == 'sinr' for r in consistency_rows)}`

{md_table(consistency_rows)}
"""
    (ROOT / "formal_true_sinr_K10_objective_final_consistency_report.md").write_text(consistency_report, encoding="utf-8")
    safety = f"""# Formal True-SINR K10 Safety Check

- no station artifacts modified: PASS
- no route artifacts modified: PASS
- no POIs regenerated: PASS
- no optimizer core logic modified: PASS
- ASU-v2 formula unchanged: PASS
- old SNR evaluator preserved: PASS
- true SINR evaluator preserved: PASS
- previous formal results preserved: PASS
- decoded deployment export added: PASS
- generated/proxy station labels preserved: {meta['station_label']}
- generated semantic route labels preserved: {meta['route_label']}
- no real-operator base station claim: PASS
- no real-measured-airway claim: PASS
- git diff -- src/algorithms remains empty: PASS
"""
    (ROOT / "formal_true_sinr_K10_safety_check.md").write_text(safety, encoding="utf-8")


def write_schema() -> None:
    text = """# Formal True-SINR K10 Decoded Deployment Schema

Each row in `formal_true_sinr_K10_decoded_deployments.csv` is one newly deployed station from the ASU-best final Stage-I + Stage-II solution.

Required fields:
- `method`, `seed`, `stage`, `station_source`
- `station_id`, `x`, `y`, `z`
- `station_type`, `station_type_index`
- `sector_direction`, `sector_direction_index`
- `tx_power_dbm`, `antenna_gain`, `beamwidth`, `is_5ga`, `deployment_cost`
- `selected_solution_rank_or_id`
- selected-solution metrics: `ASU_of_selected_solution`, `Q_current`, `Q_future`, `Coverage@0`, `Coverage@5`, `Coverage@10`, `current_Coverage@0`, `future_Coverage@0`, `handover_count`, `C_dep`, `denominator`

Labels:
- `stage1_current` means the station was selected from the current-priority Stage-I run.
- `stage2_future` means the station was selected from the future-priority Stage-II run.
- Existing stations are not included in this decoded deployment file; they remain in the preserved route-agnostic simulated/proxy existing-station artifact.
"""
    (ROOT / "formal_true_sinr_K10_decoded_deployment_schema.md").write_text(text, encoding="utf-8")


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    keys: List[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys or ["empty"])
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in keys})


def read_existing(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def md_table(rows: Sequence[Dict[str, Any]], max_rows: int = 20) -> str:
    if not rows:
        return "_No rows._"
    keys = list(rows[0].keys())
    lines = ["| " + " | ".join(keys) + " |", "| " + " | ".join(["---"] * len(keys)) + " |"]
    for row in rows[:max_rows]:
        vals = []
        for key in keys:
            val = row.get(key, "")
            if isinstance(val, float):
                val = f"{val:.6g}"
            vals.append(str(val).replace("\n", " "))
        lines.append("| " + " | ".join(vals) + " |")
    return "\n".join(lines)


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or str(value).strip() == "":
            return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default


if __name__ == "__main__":
    main()
