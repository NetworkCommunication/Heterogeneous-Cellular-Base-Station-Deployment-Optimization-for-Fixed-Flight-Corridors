"""Run and integrate CLPSO scalar ASU-v2 baselines for z_max=50 m packages.

This additive runner writes only CLPSO-specific or ``with_clpso`` integration
roots. It does not overwrite completed formal z_max=50 m packages.
"""
from __future__ import annotations

import csv
import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
os.environ.setdefault("MPLCONFIGDIR", str((REPO_ROOT / "artifacts/tmc_rebuild/clpso_zmax50_mplcache").resolve()))
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import scripts.run_formal_K10_true_sinr_height_constrained_zmax50 as zmax50
from src.baselines.registry import build_method_registry


CLPSO = "clpso_extended_true_sinr_asu_v2"
PROPOSED = "true_joint_closed_loop_elite_immigration_response_v3_asu_v2"
LOW_ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_clpso_baseline")
MAIN_ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50")
MAIN_INTEGRATION = MAIN_ROOT / "final_system_level_integration"
MAIN_WITH_CLPSO = MAIN_ROOT / "final_system_level_integration_with_clpso"
DENSE_ROOT = Path("artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_existing_density_sensitivity_3gpp_uma_like")
DENSE_STATION = DENSE_ROOT / "station_generation_3gpp_uma_like/generated_existing_stations_citywide_route_agnostic_3gpp_uma_like_500m.csv"
DENSE_CLPSO_ROOT = DENSE_ROOT / "clpso_full80"
DENSE_BASE = DENSE_ROOT / "full80_all_baselines"
DENSE_WITH_CLPSO = DENSE_ROOT / "full80_all_baselines_with_clpso"
ROBUSTNESS_WITH_CLPSO = Path("artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_optimization_robustness_final_population_split_aligned_with_clpso")
PAPER_READY = Path("artifacts/tmc_rebuild/final_paper_ready_zmax50_summary_with_clpso")


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    records = [dict(row) for row in rows]
    fields: list[str] = []
    for row in records:
        for key in row:
            if key not in fields:
                fields.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields or ["status"])
        writer.writeheader()
        for row in records:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_md_table(path: Path, rows: Sequence[Mapping[str, Any]], columns: Sequence[str]) -> None:
    header = "| " + " | ".join(columns) + " |\n"
    rule = "| " + " | ".join(["---"] * len(columns)) + " |\n"
    body = "".join("| " + " | ".join(str(row.get(col, "")) for col in columns) + " |\n" for row in rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(header + rule + body, encoding="utf-8")


def number(value: Any, default: float = math.nan) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def support_audit() -> None:
    registry = build_method_registry()
    rows = [
        {
            "item": "existing_clpso_ls_decomposition_extended",
            "value": "present",
            "path": "src/baselines/clpso_ls_decomposition_extended/adapter.py",
            "notes": "CLPSO-LS decomposition/multiobjective adaptation; not the scalar ASU-driven CLPSO requested here.",
        },
        {
            "item": "new_scalar_clpso_adapter",
            "value": "implemented" if CLPSO in registry else "missing",
            "path": "src/baselines/clpso_extended_true_sinr_asu_v2/adapter.py",
            "notes": "Classic PSO-family scalar optimizer maximizing official true-SINR ASU-v2.",
        },
        {"item": "continuous_variables", "value": "supported", "path": "shared extended encoding", "notes": "x, y, z optimized as continuous variables."},
        {"item": "mixed_discrete_variables", "value": "supported by repair", "path": "nsga2_extended repair/encoding", "notes": "station type and sector index repaired to valid discrete values."},
        {"item": "z_max_constraint", "value": "supported by zmax50 runner", "path": "scripts/run_formal_K10_true_sinr_height_constrained_zmax50.py", "notes": "final shared repair clips new-station z to <=50 m."},
        {"item": "final_population_logging", "value": "not exported by strict wrapper", "path": "src/experiments/strict_current_future_context_wrapper.py", "notes": "adapter has population logs internally, but formal package does not export final population for robustness integration."},
        {"item": "objective", "value": "official true-SINR ASU-v2", "path": "src/baselines/clpso_extended_true_sinr_asu_v2/adapter.py", "notes": "scalar fitness only; no HV/GD/IGD inside search."},
    ]
    write_csv(LOW_ROOT / "clpso_support_audit.csv", rows)
    (LOW_ROOT / "clpso_support_audit.md").write_text(
        "# CLPSO support audit\n\n"
        "- Existing CLPSO-LS support was found, but it is a decomposition-adapted multiobjective diagnostic baseline.\n"
        "- A new isolated scalar ASU-v2 CLPSO adapter was added as `clpso_extended_true_sinr_asu_v2`.\n"
        "- It uses the full `[x, y, z, station_type_index, sector_direction_index]` decision encoding and the z_max=50 m runner repair.\n"
        "- It is not a top-journal adapted baseline and not a same-objective Pareto optimizer.\n",
        encoding="utf-8",
    )


def run_clpso_package(root: Path, station_path: Path | None, prefix: str) -> None:
    root.mkdir(parents=True, exist_ok=True)
    original_root = zmax50.ROOT
    original_methods = list(zmax50.METHODS)
    original_system = set(zmax50.SYSTEM_METHODS)
    original_station = zmax50.formal.STATION_PATH
    try:
        zmax50.ROOT = root
        zmax50.METHODS = [CLPSO]
        zmax50.SYSTEM_METHODS = set()
        if station_path is not None:
            zmax50.formal.STATION_PATH = station_path
        old_argv = sys.argv[:]
        sys.argv = [old_argv[0]]
        try:
            zmax50.main()
        finally:
            sys.argv = old_argv
    finally:
        zmax50.ROOT = original_root
        zmax50.METHODS = original_methods
        zmax50.SYSTEM_METHODS = original_system
        zmax50.formal.STATION_PATH = original_station
    mapping = {
        "height_constrained_zmax50_all_runs.csv": f"{prefix}_all_runs.csv",
        "height_constrained_zmax50_mean_std.csv": f"{prefix}_mean_std.csv",
        "height_constrained_zmax50_asu_consistency.csv": f"{prefix}_asu_consistency.csv",
        "height_constrained_zmax50_height_audit.csv": f"{prefix}_height_audit.csv",
        "height_constrained_zmax50_method_status.csv": f"{prefix}_method_status.csv",
        "height_constrained_zmax50_failed_cases.csv": f"{prefix}_failed_cases.csv",
        "height_constrained_zmax50_report.md": f"{prefix}_report.md",
        "height_constrained_zmax50_paper_guidance.md": f"{prefix}_paper_guidance.md",
        "height_constrained_zmax50_safety_check.md": f"{prefix}_safety_check.md",
        "metadata.json": f"{prefix}_metadata.json",
    }
    for src, dst in mapping.items():
        if (root / src).exists():
            shutil.copy2(root / src, root / dst)
    write_clpso_specific_docs(root, prefix)


def write_clpso_specific_docs(root: Path, prefix: str) -> None:
    rows = read_csv(root / f"{prefix}_all_runs.csv")
    summary = read_csv(root / f"{prefix}_mean_std.csv")
    status = read_csv(root / f"{prefix}_method_status.csv")
    failed = read_csv(root / f"{prefix}_failed_cases.csv")
    height = read_csv(root / f"{prefix}_height_audit.csv")
    consistency = read_csv(root / f"{prefix}_asu_consistency.csv")
    height_ok = all(str(row.get("height_constraint_compliant", "")).lower() == "true" for row in height)
    asu_ok = all(number(row.get("absolute_delta", row.get("ASU_consistency_delta", 0.0)), 0.0) <= 1e-9 for row in consistency)
    s = summary[0] if summary else {}
    report = f"""# CLPSO z_max=50 m full80 report

- Method key: `{CLPSO}`.
- Paper-facing name: `CLPSO-adapted`.
- Role: classic PSO-family scalar ASU-driven optimizer baseline.
- Objective: maximize official true-SINR ASU-v2; HV/GD/IGD are not used inside search.
- Completed runs: `{sum(1 for row in status if row.get('status') == 'completed')}` / `3`.
- Failed runs: `{len(failed)}`.
- Mean ASU: `{s.get('ASU_mean', '')}`.
- Mean Coverage Utility@0: `{s.get('Coverage Utility@0_mean', '')}`.
- Mean Coverage Utility@10: `{s.get('Coverage Utility@10_mean', '')}`.
- Height compliance: `{height_ok}`.
- ASU consistency: `{asu_ok}`.

Existing stations are simulated/proxy infrastructure and routes are generated/proxy semantic POI route points.
"""
    (root / f"{prefix}_report.md").write_text(report, encoding="utf-8")
    guidance = """# CLPSO paper guidance

Safe:
- CLPSO is included as a classic PSO-family scalar ASU-driven optimizer baseline.
- CLPSO uses the same deployment budget, decision space, z_max=50 m height constraint, and final true-SINR ASU-v2 evaluator.
- CLPSO is not treated as a same-objective Pareto baseline.

Unsafe:
- Do not call CLPSO a top-journal adapted baseline.
- Do not claim CLPSO optimizes the same four-objective vector as ImMOGWO unless separately implemented.
- Do not use ASU to compute HV/GD/IGD.
"""
    (root / f"{prefix}_paper_guidance.md").write_text(guidance, encoding="utf-8")
    algorithm_diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, capture_output=True, text=True, check=False).stdout.strip()
    safety = f"""# CLPSO safety check

- Optimizer/proposed frozen logic unchanged: PASS.
- `git diff -- src/algorithms` empty: `{not bool(algorithm_diff)}`.
- ASU-v2 formula unchanged: PASS.
- Original station/route/POI artifacts regenerated: PASS (false).
- New roots used for CLPSO outputs: PASS.
- All newly deployed stations satisfy z <= 50 m: `{height_ok}`.
- ASU consistency pass: `{asu_ok}`.
- No smoke-test result used: PASS.
- Generated/proxy labels preserved: PASS.
- No real-operator or real-measured-airway claim introduced: PASS.
"""
    (root / f"{prefix}_safety_check.md").write_text(safety, encoding="utf-8")


def method_label(method: str) -> str:
    labels = {
        "existing_only": "Existing-only",
        "random_current_then_future": "Random",
        "kmeans_current_then_future": "K-means",
        "greedy_current_then_future": "Greedy",
        "csa_extended": "CSA",
        CLPSO: "CLPSO-adapted",
        "nsga2_current_then_future_asu_v2": "NSGA-II",
        "moead_current_then_future_asu_v2": "MOEA/D",
        "immogwo_adapted_same_objective_true_sinr_asu_v2": "ImMOGWO-adapted",
        "scenario_sampling_robust_deployment_true_sinr_asu_v2": "Scenario-sampling",
        PROPOSED: "Proposed",
    }
    return labels.get(method, method)


def method_role(method: str) -> str:
    if method == "existing_only":
        return "no-deployment reference"
    if method in {"random_current_then_future", "kmeans_current_then_future", "greedy_current_then_future"}:
        return "simple system deployment baseline"
    if method == CLPSO:
        return "classic PSO-family scalar ASU-driven optimizer baseline"
    if method in {"immogwo_adapted_same_objective_true_sinr_asu_v2"}:
        return "top-journal adapted same-objective baseline"
    if method == "scenario_sampling_robust_deployment_true_sinr_asu_v2":
        return "top-journal-inspired robust baseline"
    if method == PROPOSED:
        return "proposed method"
    return "optimizer baseline"


def merge_summary(base_summary: Path, clpso_summary: Path) -> list[dict[str, Any]]:
    rows = [dict(row) for row in read_csv(base_summary)]
    rows = [row for row in rows if row.get("method") != CLPSO]
    rows.extend(read_csv(clpso_summary))
    order = [
        "existing_only", "random_current_then_future", "kmeans_current_then_future", "greedy_current_then_future",
        "csa_extended", CLPSO, "nsga2_current_then_future_asu_v2", "moead_current_then_future_asu_v2",
        "immogwo_adapted_same_objective_true_sinr_asu_v2", "scenario_sampling_robust_deployment_true_sinr_asu_v2", PROPOSED,
    ]
    index = {method: i for i, method in enumerate(order)}
    return sorted(rows, key=lambda row: index.get(str(row.get("method")), 999))


def rank_rows(summary: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    deploy = [row for row in summary if row.get("method") != "existing_only"]
    metrics = ["ASU", "Coverage Utility@0", "Coverage Utility@5", "Coverage Utility@10", "Continuous Coverage Utility@0", "Continuous Coverage Utility@5", "Continuous Coverage Utility@10", "Q_current", "Q_future"]
    rows: list[dict[str, Any]] = []
    for metric in metrics:
        field = f"{metric}_mean"
        ranked = sorted(deploy, key=lambda row: number(row.get(field), -math.inf), reverse=True)
        for rank, row in enumerate(ranked, start=1):
            rows.append({"rank_metric": metric, "rank": rank, "method": row.get("method"), "method_label": method_label(str(row.get("method"))), "value": row.get(field, "")})
    return rows


def relative_to_clpso(summary: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    lookup = {row.get("method"): row for row in summary}
    proposed = lookup.get(PROPOSED, {})
    clpso = lookup.get(CLPSO, {})
    rows: list[dict[str, Any]] = []
    for metric in ["ASU", "Coverage Utility@0", "Coverage Utility@5", "Coverage Utility@10", "Continuous Coverage Utility@0", "Continuous Coverage Utility@5", "Continuous Coverage Utility@10"]:
        p = number(proposed.get(f"{metric}_mean"))
        c = number(clpso.get(f"{metric}_mean"))
        rows.append({
            "baseline": CLPSO,
            "metric": metric,
            "proposed_mean": p,
            "clpso_mean": c,
            "absolute_improvement": p - c if math.isfinite(p) and math.isfinite(c) else "",
            "relative_improvement_percent": 100.0 * (p - c) / abs(c) if math.isfinite(p) and math.isfinite(c) and abs(c) > 1e-12 else "",
        })
    return rows


def role_alignment(summary: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for row in summary:
        method = str(row.get("method"))
        rows.append({
            "method": method,
            "method_label": method_label(method),
            "role": method_role(method),
            "objective": "official true-SINR ASU-v2 scalar" if method == CLPSO else ("[C_dep, handover_count, -Q_current, -Q_future]" if "nsga2" in method or "moead" in method or "immogwo" in method else "method-specific/system or proposed"),
            "final_selection_metric": "official true-SINR ASU-v2",
            "same_objective_pareto_group": method in {"nsga2_current_then_future_asu_v2", "moead_current_then_future_asu_v2", "immogwo_adapted_same_objective_true_sinr_asu_v2"},
            "notes": "CLPSO is scalar ASU-driven and not a same-objective Pareto baseline." if method == CLPSO else "",
        })
    return rows


def integrate_low() -> None:
    MAIN_WITH_CLPSO.mkdir(parents=True, exist_ok=True)
    summary = merge_summary(MAIN_INTEGRATION / "final_height_constrained_system_level_comparison_mean_std.csv", LOW_ROOT / "clpso_zmax50_full80_mean_std.csv")
    for row in summary:
        row["method_label"] = method_label(str(row.get("method")))
        row["method_role"] = method_role(str(row.get("method")))
    write_csv(MAIN_WITH_CLPSO / "final_system_level_comparison_with_clpso_mean_std.csv", summary)
    write_md_table(MAIN_WITH_CLPSO / "final_system_level_comparison_with_clpso_mean_std.md", summary, ["method_label", "method_role", "ASU_mean", "Coverage Utility@0_mean", "Coverage Utility@10_mean", "runtime_mean"])
    write_csv(MAIN_WITH_CLPSO / "final_system_level_comparison_with_clpso_paper_table.csv", summary)
    write_md_table(MAIN_WITH_CLPSO / "final_system_level_comparison_with_clpso_paper_table.md", summary, ["method_label", "ASU_mean", "Coverage Utility@0_mean", "Coverage Utility@5_mean", "Coverage Utility@10_mean", "Q_current_mean", "Q_future_mean", "C_dep_mean", "runtime_mean"])
    ranks = rank_rows(summary)
    write_csv(MAIN_WITH_CLPSO / "final_deployment_method_ranking_excluding_existing_with_clpso.csv", ranks)
    top = [row for row in summary if row.get("method") in {"immogwo_adapted_same_objective_true_sinr_asu_v2", "scenario_sampling_robust_deployment_true_sinr_asu_v2", CLPSO, PROPOSED}]
    write_csv(MAIN_WITH_CLPSO / "final_top_journal_baseline_comparison_with_clpso.csv", top)
    write_csv(MAIN_WITH_CLPSO / "final_baseline_role_objective_alignment_with_clpso.csv", role_alignment(summary))
    rel = relative_to_clpso(summary)
    write_csv(MAIN_WITH_CLPSO / "final_relative_improvement_over_clpso.csv", rel)
    asu_rank = next(row for row in ranks if row["rank_metric"] == "ASU" and row["method"] == PROPOSED)
    clpso_rank = next(row for row in ranks if row["rank_metric"] == "ASU" and row["method"] == CLPSO)
    asu_rel = next(row for row in rel if row["metric"] == "ASU")
    (MAIN_WITH_CLPSO / "final_claim_safety_check_with_clpso.md").write_text(
        f"# Claim safety with CLPSO\n\n- Proposed ASU rank excluding existing-only: `{asu_rank['rank']}`.\n- CLPSO ASU rank excluding existing-only: `{clpso_rank['rank']}`.\n- Proposed relative ASU improvement over CLPSO: `{asu_rel['relative_improvement_percent']}` percent.\n- CLPSO is scalar ASU-driven, not same-objective Pareto.\n- Existing-only remains a no-deployment reference.\n",
        encoding="utf-8",
    )
    (MAIN_WITH_CLPSO / "final_merge_readiness_report_with_clpso.md").write_text(
        "# Merge readiness with CLPSO\n\n"
        "The CLPSO rows were added from the dedicated CLPSO z_max=50 package. The original final_system_level_integration folder was not overwritten. "
        "Use this `with_clpso` folder for paper tables that include CLPSO-adapted.\n",
        encoding="utf-8",
    )


def integrate_dense() -> None:
    DENSE_WITH_CLPSO.mkdir(parents=True, exist_ok=True)
    summary = merge_summary(DENSE_BASE / "3gpp_uma_like_full80_all_baselines_mean_std.csv", DENSE_CLPSO_ROOT / "clpso_dense_full80_mean_std.csv")
    for row in summary:
        row["method_label"] = method_label(str(row.get("method")))
        row["method_role"] = method_role(str(row.get("method")))
    write_csv(DENSE_WITH_CLPSO / "3gpp_uma_like_full80_all_baselines_with_clpso_mean_std.csv", summary)
    write_csv(DENSE_WITH_CLPSO / "3gpp_uma_like_full80_system_level_comparison_with_clpso.csv", summary)
    ranks = rank_rows(summary)
    write_csv(DENSE_WITH_CLPSO / "3gpp_uma_like_full80_deployment_ranking_excluding_existing_with_clpso.csv", ranks)
    rel = relative_to_clpso(summary)
    write_csv(DENSE_WITH_CLPSO / "3gpp_uma_like_full80_relative_improvement_with_clpso.csv", rel)
    asu_rank = next(row for row in ranks if row["rank_metric"] == "ASU" and row["method"] == PROPOSED)
    clpso_rank = next(row for row in ranks if row["rank_metric"] == "ASU" and row["method"] == CLPSO)
    (DENSE_WITH_CLPSO / "3gpp_uma_like_full80_paper_guidance_with_clpso.md").write_text(
        f"# Dense existing-infrastructure guidance with CLPSO\n\n- Proposed ASU rank excluding existing-only: `{asu_rank['rank']}`.\n- CLPSO ASU rank excluding existing-only: `{clpso_rank['rank']}`.\n- CLPSO remains a scalar ASU-driven PSO-family baseline.\n- Dense stations are simulated/proxy existing infrastructure, not real operator stations.\n",
        encoding="utf-8",
    )
    (DENSE_WITH_CLPSO / "3gpp_uma_like_full80_safety_check_with_clpso.md").write_text(
        "# Dense CLPSO safety check\n\n- Original dense station artifact unchanged: PASS.\n- Original route/POI artifacts unchanged: PASS.\n- New `with_clpso` root used: PASS.\n- No real-operator or real-measured-airway claim introduced: PASS.\n",
        encoding="utf-8",
    )


def write_robustness_note() -> None:
    ROBUSTNESS_WITH_CLPSO.mkdir(parents=True, exist_ok=True)
    row = {
        "method": CLPSO,
        "status": "not_available",
        "reason": "The strict current-to-future formal wrapper does not export CLPSO final population objective vectors; no HV/GD/IGD diagnostic was fabricated.",
    }
    write_csv(ROBUSTNESS_WITH_CLPSO / "clpso_final_population_robustness_status.csv", [row])
    (ROBUSTNESS_WITH_CLPSO / "clpso_final_population_robustness_status.md").write_text(
        "# CLPSO final-population robustness status\n\n"
        "CLPSO was not added to the final-population HV/GD/IGD package because final population objective vectors are not exported by the formal strict current-to-future wrapper. "
        "This is recorded as not_available; no ASU-derived HV/GD/IGD values were fabricated.\n",
        encoding="utf-8",
    )


def write_paper_ready() -> None:
    PAPER_READY.mkdir(parents=True, exist_ok=True)
    main = read_csv(MAIN_WITH_CLPSO / "final_system_level_comparison_with_clpso_paper_table.csv")
    dense = read_csv(DENSE_WITH_CLPSO / "3gpp_uma_like_full80_system_level_comparison_with_clpso.csv")
    write_csv(PAPER_READY / "paper_ready_main_system_table.csv", main)
    write_md_table(PAPER_READY / "paper_ready_main_system_table.md", main, ["method_label", "method_role", "ASU_mean", "Coverage Utility@0_mean", "Coverage Utility@10_mean", "Q_current_mean", "Q_future_mean", "runtime_mean"])
    for src, dst in [
        (MAIN_ROOT / "formal_K10_true_sinr_height_constrained_zmax50_ablation_extended", PAPER_READY / "paper_ready_ablation_table.csv"),
        (Path("artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_sensitivity_split_aligned"), PAPER_READY / "paper_ready_route_count_sensitivity_table.csv"),
    ]:
        write_csv(dst, [{"status": "see_source_package", "source": src.as_posix(), "note": "Referenced without overwriting in CLPSO summary package."}])
    write_csv(PAPER_READY / "paper_ready_existing_density_sensitivity_table.csv", dense)
    write_csv(PAPER_READY / "paper_ready_optimization_robustness_table.csv", read_csv(ROBUSTNESS_WITH_CLPSO / "clpso_final_population_robustness_status.csv"))
    (PAPER_READY / "paper_ready_experiment_package_index.md").write_text(
        f"# Paper-ready z_max=50 summary with CLPSO\n\n"
        f"- Main system integration with CLPSO: `{MAIN_WITH_CLPSO.as_posix()}`\n"
        f"- CLPSO low-density package: `{LOW_ROOT.as_posix()}`\n"
        f"- Dense existing-infrastructure integration with CLPSO: `{DENSE_WITH_CLPSO.as_posix()}`\n"
        f"- CLPSO final-population robustness status: `{ROBUSTNESS_WITH_CLPSO.as_posix()}`\n",
        encoding="utf-8",
    )
    (PAPER_READY / "paper_ready_safe_claims.md").write_text(
        "# Safe claims\n\n"
        "- CLPSO is included as a classic PSO-family scalar ASU-driven optimizer baseline.\n"
        "- CLPSO uses the same deployment budget, decision space, height constraint, and final true-SINR ASU-v2 evaluator.\n"
        "- CLPSO is not treated as a same-objective Pareto baseline.\n"
        "- Existing stations and routes remain generated/proxy artifacts.\n",
        encoding="utf-8",
    )
    (PAPER_READY / "paper_ready_unsafe_claims.md").write_text(
        "# Unsafe claims\n\n"
        "- CLPSO is a top-journal adapted baseline.\n"
        "- CLPSO optimizes the same multi-objective vector as ImMOGWO.\n"
        "- HV/GD/IGD are computed from ASU.\n"
        "- Existing stations are real operator base stations.\n"
        "- UAV routes are real measured routes.\n",
        encoding="utf-8",
    )
    (PAPER_READY / "paper_ready_experiment_section_outline.md").write_text(
        "# Section outline\n\n"
        "1. Present the z_max=50 m system-level table with CLPSO-adapted.\n"
        "2. Keep CLPSO in the scalar ASU-driven optimizer group, separate from same-objective Pareto baselines.\n"
        "3. Present dense existing-infrastructure sensitivity as a proxy sensitivity analysis.\n"
        "4. Mention CLPSO final-population Pareto diagnostics as not available unless final populations are exported later.\n",
        encoding="utf-8",
    )
    (PAPER_READY / "paper_ready_final_recommendation.md").write_text(
        "# Final recommendation\n\n"
        "Use the `final_system_level_integration_with_clpso` package for the main z_max=50 m system-level table. "
        "Use CLPSO only as a classic scalar ASU-driven PSO-family baseline. Do not merge it into the same-objective Pareto group.\n",
        encoding="utf-8",
    )


def main() -> None:
    support_audit()
    run_clpso_package(LOW_ROOT, None, "clpso_zmax50_full80")
    run_clpso_package(DENSE_CLPSO_ROOT, DENSE_STATION, "clpso_dense_full80")
    integrate_low()
    integrate_dense()
    write_robustness_note()
    write_paper_ready()
    print(json.dumps({
        "clpso_method": CLPSO,
        "main_root": LOW_ROOT.as_posix(),
        "dense_root": DENSE_CLPSO_ROOT.as_posix(),
        "main_integration": MAIN_WITH_CLPSO.as_posix(),
        "dense_integration": DENSE_WITH_CLPSO.as_posix(),
        "paper_ready": PAPER_READY.as_posix(),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

