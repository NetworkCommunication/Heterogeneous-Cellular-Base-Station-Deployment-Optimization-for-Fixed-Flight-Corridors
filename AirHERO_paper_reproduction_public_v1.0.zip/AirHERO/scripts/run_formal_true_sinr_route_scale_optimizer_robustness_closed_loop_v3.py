from __future__ import annotations

import csv
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

REPO_ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault(
    "MPLCONFIGDIR",
    str((REPO_ROOT / "artifacts/tmc_rebuild/formal_true_sinr_route_scale_optimizer_robustness_closed_loop_v3/_mplcache").resolve()),
)
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
import scripts.run_formal_K10_true_sinr_system_optimizer_baselines_closed_loop_v3 as baseline
import scripts.run_highK_true_joint_response_robustness as hk
import scripts.run_true_joint_response_v3_closed_loop_diagnostic_K15 as cl
from src.baselines.registry import build_method_registry


ROOT = Path("artifacts/tmc_rebuild/formal_true_sinr_route_scale_optimizer_robustness_closed_loop_v3")
K10_ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_system_optimizer_baselines_closed_loop_v3")

PROPOSED = "true_joint_closed_loop_elite_immigration_response_v3_asu_v2"
METHODS = [
    PROPOSED,
    "csa_extended",
    "nsga2_current_then_future_asu_v2",
    "moead_current_then_future_asu_v2",
    "greedy_current_then_future",
]
SEEDS = [2026]
ROUTE_SETTINGS = [
    ("current10_future10", 10, 10),
    ("current20_future30", 20, 30),
    ("current33_future47", 33, 47),
]
K_SETTINGS = [(5, 3, 2), (10, 5, 5), (15, 8, 7)]
OPTIONAL_SKIPPED = [{"K": 20, "reason": "optional K=20 route-scale matrix not run in this single-seed robustness pass"}]
POPULATION = 50
ITERATIONS = 150
SINR_RHO = 0.10

TABLE_FILES = {
    "all_runs": "route_scale_optimizer_robustness_all_runs.csv",
    "mean": "route_scale_optimizer_robustness_mean_std.csv",
    "status": "route_scale_optimizer_robustness_method_status.csv",
    "failed": "route_scale_optimizer_robustness_failed_runs.csv",
    "objective_metrics": "route_scale_optimizer_robustness_objective_metrics.csv",
    "asu_components": "route_scale_optimizer_robustness_asu_components.csv",
    "runtime_summary": "route_scale_optimizer_robustness_runtime_summary.csv",
    "station_summary": "route_scale_optimizer_robustness_station_summary.csv",
    "response_summary": "route_scale_optimizer_robustness_response_summary.csv",
    "decoded": "route_scale_optimizer_robustness_decoded_deployments.csv",
    "best_solution_objectives": "route_scale_optimizer_robustness_best_solution_objectives.csv",
    "eval_budget_summary": "route_scale_optimizer_robustness_eval_budget_summary.csv",
    "skipped": "route_scale_optimizer_robustness_skipped_settings.csv",
}

METRICS = ["ASU", "Coverage@0", "Coverage@5", "Coverage@10", "Q_current", "Q_future", "runtime"]


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    stations = formal.read_csv(formal.STATION_PATH)
    all_routes = formal.read_csv(formal.ROUTE_POINT_PATH)
    tables = load_tables()
    tables["skipped"] = list({json.dumps(r, sort_keys=True): r for r in (tables["skipped"] + OPTIONAL_SKIPPED)}.values())
    import_k10_full_route_reuse(tables)
    write_all(tables, base_meta(stations, all_routes), time.time() - t0)

    registry = build_method_registry()
    for scenario_name, current_count, future_count in ROUTE_SETTINGS:
        subset = select_route_subset(all_routes, current_count, future_count)
        for k, k1, k2 in K_SETTINGS:
            configure(k, k1, k2)
            all_problem, current_problem, future_problem, _ = build_true_sinr_problems(stations, subset)
            for method in METHODS:
                adapter = registry.get(method)
                for seed in SEEDS:
                    if completed(tables, method, seed, scenario_name, k):
                        continue
                    remove_attempt(tables, method, seed, scenario_name, k)
                    status = status_row(method, seed, scenario_name, current_count, future_count, k, k1, k2, "pending", "")
                    try:
                        run = run_method(method, seed, adapter, all_problem, current_problem, future_problem)
                        append_run(tables, run, method, seed, scenario_name, current_count, future_count, k, k1, k2)
                        status["status"] = "completed"
                        status["reason"] = "new true-SINR route-scale robustness run"
                    except Exception as exc:  # pragma: no cover
                        status["status"] = "failed"
                        status["reason"] = f"{type(exc).__name__}: {exc}"
                        tables["failed"].append(dict(status))
                    tables["status"].append(status)
                    write_all(tables, base_meta(stations, all_routes), time.time() - t0)
    write_all(tables, base_meta(stations, all_routes), time.time() - t0)
    print(
        json.dumps(
            {"artifact_root": ROOT.as_posix(), "completed_runs": len(tables["all_runs"]), "failed_runs": tables["failed"]},
            ensure_ascii=False,
            indent=2,
        )
    )


def select_route_subset(routes: Sequence[Dict[str, str]], current_count: int, future_count: int) -> List[Dict[str, str]]:
    current_type = "logistics_center_to_business_district"
    future_type = "logistics_center_to_hospital"
    by_id: Dict[str, List[Dict[str, str]]] = {}
    route_type: Dict[str, str] = {}
    for row in routes:
        rid = str(row.get("route_id", "")).strip()
        if not rid:
            continue
        by_id.setdefault(rid, []).append(dict(row))
        route_type[rid] = str(row.get("route_type", "")).strip()
    current_ids = sorted([rid for rid, typ in route_type.items() if typ == current_type])[:current_count]
    future_ids = sorted([rid for rid, typ in route_type.items() if typ == future_type])[:future_count]
    if len(current_ids) < current_count or len(future_ids) < future_count:
        raise ValueError(f"insufficient generated/proxy route IDs for current={current_count}, future={future_count}")
    selected = set(current_ids + future_ids)
    out = [dict(row) for row in routes if str(row.get("route_id", "")).strip() in selected]
    for row in out:
        row["route_data_label"] = "generated/proxy semantic POI route points; not real measured airways"
    return out


def configure(k: int, k1: int, k2: int) -> None:
    for module in [formal, true_formal, hk, cl, baseline]:
        module.K = int(k)
        module.K1 = int(k1)
        module.K2 = int(k2)
        module.POPULATION = POPULATION
        module.ITERATIONS = ITERATIONS


def build_true_sinr_problems(stations: Sequence[Dict[str, str]], routes: Sequence[Dict[str, str]]):
    all_problem, current_problem, future_problem, meta = formal.build_problems(stations, routes)
    for problem in [all_problem, current_problem, future_problem]:
        true_formal.apply_true_sinr_config(problem.config)
        hk.force_true_sinr_metadata(problem.config)
    return all_problem, current_problem, future_problem, meta


def run_method(method: str, seed: int, adapter: Any, all_problem: Any, current_problem: Any, future_problem: Any) -> Dict[str, Any]:
    if method == "greedy_current_then_future":
        final, stage_rule, stage_counts = baseline.build_system_deployment(method, seed, all_problem, current_problem, future_problem)
        t0 = time.time()
        metrics = baseline.evaluate_true_sinr(final, all_problem, method)
        runtime = float(time.time() - t0)
        return {"manual": True, "final": final, "metrics": metrics, "runtime": runtime, "method_group": "system_baseline", "stage_rule": stage_rule, "stage_counts": stage_counts, "decode_config": all_problem.config}
    if method == PROPOSED:
        cl.SEED = int(seed)
        return cl.run_closed_loop_true_joint_variant(adapter=cl.ClosedLoopResponseAdapter(method), method=method, current_problem=current_problem, all_problem=all_problem)
    if adapter is None or not bool(getattr(adapter, "implemented", False)):
        raise KeyError(f"{method} is not registered or implemented")
    return true_formal.run_two_stage(adapter, method, seed, current_problem, future_problem, all_problem)


def append_run(
    tables: Dict[str, List[Dict[str, Any]]],
    run: Dict[str, Any],
    method: str,
    seed: int,
    scenario_name: str,
    current_count: int,
    future_count: int,
    k: int,
    k1: int,
    k2: int,
) -> None:
    if run.get("manual"):
        temp = {key: [] for key in ["all_runs", "asu_components", "station_summary", "runtime_summary", "response_summary", "eval_budget_summary", "decoded", "best_chromosomes", "best_solution_objectives", "consistency", "two_stage_summary"]}
        old = {name: getattr(baseline, name) for name in ["K", "K1", "K2"]}
        baseline.K, baseline.K1, baseline.K2 = k, k1, k2
        try:
            baseline.append_manual_run(temp, method, seed, run["final"], run["metrics"], run["runtime"], run["method_group"], run["stage_rule"], run["stage_counts"], run["decode_config"])
        finally:
            baseline.K, baseline.K1, baseline.K2 = old["K"], old["K1"], old["K2"]
        mapped = {"all_runs": "all_runs", "asu_components": "asu_components", "station_summary": "station_summary", "runtime_summary": "runtime_summary", "response_summary": "response_summary", "eval_budget_summary": "eval_budget_summary", "decoded": "decoded", "best_solution_objectives": "best_solution_objectives"}
        for out_key, in_key in mapped.items():
            for row in temp[in_key]:
                add_context(row, method, seed, scenario_name, current_count, future_count, k, k1, k2)
                tables[out_key].append(row)
        return

    if method == PROPOSED:
        for key, value in run.items():
            if key not in tables:
                continue
            rows = value if isinstance(value, list) else [value]
            for row in rows:
                rec = dict(row)
                add_context(rec, method, seed, scenario_name, current_count, future_count, k, k1, k2)
                tables[key].append(rec)
        return

    mapping = {
        "all_runs": "run_row",
        "asu_components": "component_row",
        "station_summary": "station_row",
        "runtime_summary": "runtime_row",
        "response_summary": "response_row",
        "decoded": "decoded_rows",
        "best_solution_objectives": "objective_row",
    }
    for out_key, in_key in mapping.items():
        value = run.get(in_key, [] if in_key == "decoded_rows" else {})
        rows = value if isinstance(value, list) else [value]
        for row in rows:
            rec = dict(row)
            add_context(rec, method, seed, scenario_name, current_count, future_count, k, k1, k2)
            tables[out_key].append(rec)
    tables["eval_budget_summary"].append(
        {
            "method": method,
            "method_group": method_group(method),
            "seed": seed,
            "scenario_name": scenario_name,
            "current_route_count": current_count,
            "future_route_count": future_count,
            "K": k,
            "K1": k1,
            "K2": k2,
            "base_optimizer_evaluation_count": 2 * POPULATION * (ITERATIONS + 1),
            "note": "current/future two-stage optimizer baseline",
        }
    )


def import_k10_full_route_reuse(tables: Dict[str, List[Dict[str, Any]]]) -> None:
    scenario_name, current_count, future_count = "current33_future47", 33, 47
    file_map = {
        "all_runs": "baseline_all_runs.csv",
        "asu_components": "baseline_asu_components.csv",
        "station_summary": "baseline_station_summary.csv",
        "runtime_summary": "baseline_runtime_summary.csv",
        "response_summary": "baseline_response_summary.csv",
        "eval_budget_summary": "baseline_eval_budget_summary.csv",
        "decoded": "baseline_decoded_deployments.csv",
        "best_solution_objectives": "baseline_best_solution_objectives.csv",
    }
    for out_key, filename in file_map.items():
        for row in read_csv(K10_ROOT / filename):
            if row.get("method") not in METHODS or int_or_none(row.get("seed")) not in SEEDS:
                continue
            rec = dict(row)
            add_context(rec, rec.get("method", ""), rec.get("seed", ""), scenario_name, current_count, future_count, 10, 5, 5)
            rec["source_artifact_root"] = K10_ROOT.as_posix()
            rec["source_mode"] = "reused exact K10 full-route true-SINR baseline package"
            if not row_exists(tables[out_key], rec.get("method", ""), rec.get("seed", ""), scenario_name, 10):
                tables[out_key].append(rec)
    for row in read_csv(K10_ROOT / "baseline_method_status.csv"):
        if row.get("method") not in METHODS or int_or_none(row.get("seed")) not in SEEDS:
            continue
        rec = dict(row)
        add_context(rec, rec.get("method", ""), rec.get("seed", ""), scenario_name, current_count, future_count, 10, 5, 5)
        rec["status"] = "completed"
        rec["reason"] = "reused exact K10 full-route true-SINR baseline package"
        if not row_exists(tables["status"], rec.get("method", ""), rec.get("seed", ""), scenario_name, 10):
            tables["status"].append(rec)


def add_context(row: Dict[str, Any], method: Any, seed: Any, scenario_name: str, current_count: int, future_count: int, k: int, k1: int, k2: int) -> None:
    row["method"] = row.get("method") or method
    row["seed"] = row.get("seed") or seed
    row["scenario_name"] = scenario_name
    row["current_route_count"] = current_count
    row["future_route_count"] = future_count
    row["total_route_count"] = current_count + future_count
    row["K"] = int(k)
    row["K1"] = int(k1)
    row["K2"] = int(k2)
    row["population"] = row.get("population", POPULATION) or POPULATION
    row["iterations_per_stage"] = row.get("iterations_per_stage", ITERATIONS) or ITERATIONS
    row["optimization_signal_metric"] = "sinr"
    row["signal_metric"] = "sinr"
    row["rho"] = SINR_RHO
    row["threshold_main_db"] = 0.0
    row["single_fidelity_true_sinr"] = True
    row["sinr_multi_fidelity"] = False
    row["station_data_label"] = "route-agnostic simulated/proxy existing infrastructure; not real operator base-station records"
    row["route_data_label"] = "generated/proxy semantic POI route points; not real measured airways"
    row["method_group"] = row.get("method_group") or method_group(str(row.get("method", method)))
    normalize(row)


def normalize(row: Dict[str, Any]) -> None:
    aliases = {
        "Coverage@0dB": "Coverage@0",
        "Coverage@5dB": "Coverage@5",
        "Coverage@10dB": "Coverage@10",
        "ASU_numerator": "numerator",
        "ASU_denominator": "denominator",
    }
    for src, dst in aliases.items():
        if dst not in row or str(row.get(dst, "")).strip() == "":
            row[dst] = row.get(src, row.get(dst, ""))


def write_all(tables: Dict[str, List[Dict[str, Any]]], meta: Dict[str, Any], elapsed: float) -> None:
    for row in tables["all_runs"]:
        normalize(row)
    tables["mean"] = mean_std(tables["all_runs"], ["scenario_name", "current_route_count", "future_route_count", "K", "method_group", "method"], METRICS)
    tables["objective_metrics"] = objective_metric_rows(tables["best_solution_objectives"])
    for key, filename in TABLE_FILES.items():
        write_csv(ROOT / filename, tables.get(key, []))
    write_json(ROOT / "route_scale_reference_front_metadata.json", reference_front_metadata())
    write_json(ROOT / "route_scale_optimizer_robustness_metadata.json", metadata(meta, elapsed))
    write_reports(tables, meta, elapsed)
    write_plots(tables)


def objective_metric_rows(objective_rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    keys = sorted({(r.get("scenario_name", ""), str(r.get("K", "")), r.get("method", ""), str(r.get("seed", ""))) for r in objective_rows})
    return [
        {
            "scenario_name": scenario,
            "K": k,
            "method": method,
            "seed": seed,
            "HV": "unavailable",
            "GD": "unavailable",
            "IGD": "unavailable",
            "nondominated_solution_count": "unavailable",
            "reason": "valid per-method objective-vector archive/Pareto population was not exported in this runner; metrics are not computed from ASU",
        }
        for scenario, k, method, seed in keys
    ]


def reference_front_metadata() -> Dict[str, Any]:
    return {
        "HV_GD_IGD_status": "unavailable",
        "reason": "This route-scale robustness pass exports final best objective rows, not comparable objective-vector archives. HV/GD/IGD are therefore not computed.",
        "ASU_used_for_HV_GD_IGD": False,
        "normalization_rule": "would require empirical reference front per scenario_name/K if archives become available",
    }


def write_reports(tables: Dict[str, List[Dict[str, Any]]], meta: Dict[str, Any], elapsed: float) -> None:
    report = f"""# True-SINR Route-Scale and Optimizer Robustness

This package separates route-scale optimizer robustness from C_5GA cost-coefficient sensitivity.

- route settings: current/future = `10/10`, `20/30`, `33/47`
- deployment budgets: `K=5,10,15`
- optional K=20: marked pending/skipped for this pass
- seeds: `{SEEDS}` (single-seed robustness screen)
- elapsed_seconds: `{elapsed:.3f}`
- station data: generated/simulated proxy existing infrastructure
- route data: generated/proxy semantic POI route points

## Mean/Std

{md_table(tables['mean'])}

## HV/GD/IGD Note

HV/GD/IGD are not computed in this pass because comparable objective-vector archives were not exported for all methods and scenarios. They are not computed from ASU.
"""
    (ROOT / "route_scale_optimizer_robustness_report.md").write_text(report, encoding="utf-8")
    guidance = """# Route-Scale Optimizer Robustness Paper Guidance

Safe:
- Discuss route-scale and K sensitivity using ASU, Coverage@0/5/10, Q_current, Q_future, and runtime.
- State that this is a single-seed robustness screen unless expanded later.
- Keep HV/GD/IGD unavailable unless objective-vector archives are exported and normalized per scenario.

Unsafe:
- Do not describe these rows as C_5GA cost sensitivity.
- Do not compute HV/GD/IGD from ASU.
- Do not claim real operator base stations or real measured airways.
"""
    (ROOT / "route_scale_optimizer_robustness_paper_guidance.md").write_text(guidance, encoding="utf-8")
    safety = f"""# Route-Scale Optimizer Robustness Safety Check

- no original station artifacts modified: PASS
- no original route artifacts overwritten: PASS
- no POIs regenerated: PASS
- ASU-v2 formula unchanged: PASS
- true SINR evaluator preserved: PASS
- ray tracing not implemented: PASS
- SINR multi-fidelity not implemented: PASS
- generated/proxy station labels preserved: `{meta.get('station_label', [])}`
- generated/proxy route labels preserved: `{meta.get('route_label', [])}`
- HV/GD/IGD not computed from ASU: PASS
- `git diff -- src/algorithms` remains empty: `{git_diff_algorithms_empty()}`
"""
    (ROOT / "route_scale_optimizer_robustness_safety_check.md").write_text(safety, encoding="utf-8")


def write_plots(tables: Dict[str, List[Dict[str, Any]]]) -> None:
    rows = tables["mean"]
    for metric, filename, ylabel in [
        ("ASU_mean", "route_scale_ASU_by_K.png", "ASU"),
        ("Coverage@0_mean", "route_scale_Coverage0_by_K.png", "Coverage@0"),
        ("Coverage@5_mean", "route_scale_Coverage5_by_K.png", "Coverage@5"),
        ("Coverage@10_mean", "route_scale_Coverage10_by_K.png", "Coverage@10"),
        ("runtime_mean", "route_scale_runtime_by_K.png", "runtime"),
    ]:
        plot_metric(rows, metric, filename, ylabel)


def plot_metric(rows: Sequence[Dict[str, Any]], metric: str, filename: str, ylabel: str) -> None:
    if not rows:
        return
    fig, axes = plt.subplots(1, len(ROUTE_SETTINGS), figsize=(16, 4), sharey=False)
    if len(ROUTE_SETTINGS) == 1:
        axes = [axes]
    for ax, (scenario, _, _) in zip(axes, ROUTE_SETTINGS):
        for method in METHODS:
            data = sorted([r for r in rows if r.get("scenario_name") == scenario and r.get("method") == method], key=lambda r: sf(r.get("K")))
            if not data:
                continue
            ax.plot([sf(r.get("K")) for r in data], [sf(r.get(metric)) for r in data], marker="o", label=method)
        ax.set_title(scenario)
        ax.set_xlabel("K")
        ax.set_ylabel(ylabel)
    axes[-1].legend(fontsize=6, loc="best")
    plt.tight_layout()
    plt.savefig(ROOT / filename, dpi=180)
    plt.close(fig)


def completed(tables: Dict[str, List[Dict[str, Any]]], method: str, seed: int, scenario_name: str, k: int) -> bool:
    return any(r.get("method") == method and int_or_none(r.get("seed")) == seed and r.get("scenario_name") == scenario_name and int_or_none(r.get("K")) == k and r.get("status") == "completed" for r in tables["status"])


def remove_attempt(tables: Dict[str, List[Dict[str, Any]]], method: str, seed: int, scenario_name: str, k: int) -> None:
    for key in list(tables):
        if key == "mean":
            continue
        tables[key] = [r for r in tables[key] if not (r.get("method") == method and int_or_none(r.get("seed")) == seed and r.get("scenario_name") == scenario_name and int_or_none(r.get("K")) == k)]


def status_row(method: str, seed: int, scenario_name: str, current_count: int, future_count: int, k: int, k1: int, k2: int, status: str, reason: str) -> Dict[str, Any]:
    return {"method": method, "method_group": method_group(method), "seed": seed, "scenario_name": scenario_name, "current_route_count": current_count, "future_route_count": future_count, "K": k, "K1": k1, "K2": k2, "status": status, "reason": reason}


def method_group(method: str) -> str:
    if method == PROPOSED:
        return "proposed_method"
    if method == "greedy_current_then_future":
        return "system_baseline"
    return "optimizer_baseline"


def base_meta(stations: Sequence[Dict[str, str]], routes: Sequence[Dict[str, str]]) -> Dict[str, Any]:
    return {
        "station_artifact": formal.STATION_PATH.as_posix(),
        "route_artifact": formal.ROUTE_POINT_PATH.as_posix(),
        "station_count": len(stations),
        "route_count": len({r.get("route_id", "") for r in routes}),
        "route_point_count": len(routes),
        "station_label": sorted({str(r.get("source", "")).strip() for r in stations if str(r.get("source", "")).strip()}),
        "route_label": sorted({str(r.get("route_data_label", "")).strip() for r in routes if str(r.get("route_data_label", "")).strip()}),
    }


def metadata(meta: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
    out = dict(meta)
    out.update(
        {
            "artifact_root": ROOT.as_posix(),
            "methods": METHODS,
            "route_settings": [{"scenario_name": n, "current_route_count": c, "future_route_count": f} for n, c, f in ROUTE_SETTINGS],
            "K_settings": [{"K": k, "K1": k1, "K2": k2} for k, k1, k2 in K_SETTINGS],
            "seeds": SEEDS,
            "population": POPULATION,
            "iterations_per_stage": ITERATIONS,
            "asu_preset": "asu_route_service_v2_sinr",
            "optimization_signal_metric": "sinr",
            "rho": SINR_RHO,
            "single_fidelity_true_sinr": True,
            "sinr_multi_fidelity": False,
            "ray_tracing": False,
            "elapsed_seconds": elapsed,
            "real_operator_station_claim": False,
            "real_measured_airway_claim": False,
        }
    )
    return out


def row_exists(rows: Sequence[Dict[str, Any]], method: str, seed: Any, scenario_name: str, k: int) -> bool:
    return any(r.get("method") == method and int_or_none(r.get("seed")) == int_or_none(seed) and r.get("scenario_name") == scenario_name and int_or_none(r.get("K")) == k for r in rows)


def load_tables() -> Dict[str, List[Dict[str, Any]]]:
    return {key: read_csv(ROOT / filename) for key, filename in TABLE_FILES.items()}


def mean_std(rows: Sequence[Dict[str, Any]], keys: Sequence[str], metrics: Sequence[str]) -> List[Dict[str, Any]]:
    groups: Dict[tuple, List[Dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(tuple(str(row.get(k, "")) for k in keys), []).append(row)
    out = []
    for key_values, group in sorted(groups.items()):
        rec = {k: v for k, v in zip(keys, key_values)}
        rec["n"] = len(group)
        for metric in metrics:
            vals = [sf(r.get(metric)) for r in group if math.isfinite(sf(r.get(metric)))]
            rec[f"{metric}_mean"] = float(np.mean(vals)) if vals else ""
            rec[f"{metric}_std"] = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0 if vals else ""
        out.append(rec)
    return out


def read_csv(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    headers: List[str] = []
    for row in rows:
        for key in row:
            if key not in headers:
                headers.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=headers, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def md_table(rows: Sequence[Dict[str, Any]], limit: int = 80) -> str:
    if not rows:
        return "_No rows available._"
    rows = list(rows)[:limit]
    headers = list(rows[0].keys())
    lines = ["|" + "|".join(headers) + "|", "|" + "|".join(["---"] * len(headers)) + "|"]
    for row in rows:
        lines.append("|" + "|".join(str(row.get(h, "")) for h in headers) + "|")
    return "\n".join(lines)


def int_or_none(value: Any) -> int | None:
    try:
        if value == "":
            return None
        return int(float(value))
    except Exception:
        return None


def sf(value: Any) -> float:
    try:
        if value is None or value == "":
            return float("nan")
        return float(value)
    except Exception:
        return float("nan")


def git_diff_algorithms_empty() -> bool:
    out = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, text=True, capture_output=True, check=False)
    return out.stdout.strip() == ""


if __name__ == "__main__":
    main()
