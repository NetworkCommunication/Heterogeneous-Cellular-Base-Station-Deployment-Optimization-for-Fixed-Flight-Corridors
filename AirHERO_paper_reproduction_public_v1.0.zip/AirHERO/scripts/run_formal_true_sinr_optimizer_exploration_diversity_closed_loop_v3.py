"""Checkpointed exploration/diversity diagnostic for true-SINR route-scale runs.

This is an observation-only companion to the formal route-scale robustness
study.  It enables optional candidate tracing on isolated baseline adapters,
does not change any optimizer update rule, and evaluates DCR/AN/OE alongside
objective-vector-only HV/GD/IGD diagnostics.
"""

from __future__ import annotations

import csv
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
os.environ.setdefault("MPLCONFIGDIR", str((REPO_ROOT / "artifacts/tmc_rebuild/formal_true_sinr_optimizer_exploration_diversity_closed_loop_v3/_mplcache").resolve()))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
import scripts.run_formal_true_sinr_route_scale_optimizer_robustness_closed_loop_v3 as route_scale
import scripts.run_highK_true_joint_response_robustness as hk
import scripts.run_true_joint_response_v3_closed_loop_diagnostic_K15 as closed_loop
from src.baselines.registry import build_method_registry
from src.experiments.asu_route_service_v2_sinr import evaluate_with_existing_context_sinr_asu_v2
from src.experiments.multiobjective_metrics import ObjectiveSetRecord, evaluate_multiobjective_metrics, nondominated_mask


ROOT = Path("artifacts/tmc_rebuild/formal_true_sinr_optimizer_exploration_diversity_closed_loop_v3")
PROPOSED = "true_joint_closed_loop_elite_immigration_response_v3_asu_v2"
OPTIMIZERS = [PROPOSED, "csa_extended", "nsga2_current_then_future_asu_v2", "moead_current_then_future_asu_v2", "hho_extended"]
SEEDS = [2026]
ROUTE_SETTINGS = [("current10_future10", 10, 10), ("current20_future30", 20, 30), ("current33_future47", 33, 47)]
K_SETTINGS = [(5, 3, 2), (10, 5, 5), (15, 8, 7)]
POPULATION = 50
ITERATIONS = 150


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    started = time.time()
    registry = build_method_registry()
    stations = formal.read_csv(formal.STATION_PATH)
    routes = formal.read_csv(formal.ROUTE_POINT_PATH)
    all_rows: List[Dict[str, Any]] = []
    candidates: List[Dict[str, Any]] = []
    unavailable: List[Dict[str, Any]] = []
    failed: List[Dict[str, Any]] = []

    for scenario_name, n_current, n_future in ROUTE_SETTINGS:
        subset = route_scale.select_route_subset(routes, n_current, n_future)
        for k, k1, k2 in K_SETTINGS:
            _configure(k, k1, k2)
            all_problem, current_problem, future_problem, _ = route_scale.build_true_sinr_problems(stations, subset)
            for problem in [all_problem, current_problem, future_problem]:
                problem.config["explorationTrace"] = {"enabled": True, "fractions": [0.0, 0.25, 0.5, 0.75, 1.0]}
            for method in OPTIMIZERS:
                adapter = registry.get(method)
                for seed in SEEDS:
                    try:
                        run = _run(method, adapter, seed, all_problem, current_problem, future_problem)
                        run_row = _run_row(run, method, seed, scenario_name, n_current, n_future, k, k1, k2)
                        all_rows.append(run_row)
                        trace = run.get("exploration_candidate_trace", []) if isinstance(run, Mapping) else []
                        stage1_best = np.asarray(run.get("stage1_best_decision", []), dtype=float)
                        added = _materialize_trace(
                            trace, method, seed, scenario_name, n_current, n_future, k, k1, k2, stage1_best, all_problem
                        )
                        if not added:
                            unavailable.append(_unavailable(method, scenario_name, k, "candidate_trace", "adapter returned no checkpoint candidate trace"))
                        candidates.extend(added)
                    except Exception as exc:  # preserve failures as data rather than silently excluding a method.
                        failed.append({"method": method, "scenario_name": scenario_name, "K": k, "seed": seed, "reason": f"{type(exc).__name__}: {exc}"})

    _mark_nondominated(candidates)
    dcr_rows = _dcr_rows(candidates)
    an_rows, an_unavailable = _an_rows(candidates, stations)
    unavailable.extend(an_unavailable)
    oe_rows = _oe_rows(candidates)
    hv_rows, hv_unavailable = _hv_rows(candidates)
    unavailable.extend(hv_unavailable)
    metric_rows = _merge_metric_rows(all_rows, dcr_rows, an_rows, oe_rows, hv_rows)
    _write_outputs(candidates, all_rows, metric_rows, dcr_rows, an_rows, oe_rows, hv_rows, unavailable, failed, time.time() - started)
    print(json.dumps({"artifact_root": ROOT.as_posix(), "completed_runs": len(all_rows), "failed_runs": failed}, ensure_ascii=False, indent=2))


def _configure(k: int, k1: int, k2: int) -> None:
    for module in [formal, true_formal, hk, closed_loop, route_scale]:
        module.K, module.K1, module.K2 = int(k), int(k1), int(k2)
        module.POPULATION, module.ITERATIONS = POPULATION, ITERATIONS
    closed_loop.SEED = 2026


def _run(method: str, adapter: Any, seed: int, all_problem: Any, current_problem: Any, future_problem: Any) -> Dict[str, Any]:
    if method == PROPOSED:
        closed_loop.SEED = int(seed)
        return closed_loop.run_closed_loop_true_joint_variant(
            adapter=closed_loop.ClosedLoopResponseAdapter(method), method=method,
            current_problem=current_problem, all_problem=all_problem,
        )
    if adapter is None or not bool(getattr(adapter, "implemented", False)):
        raise RuntimeError("method is not implemented")
    return true_formal.run_two_stage(adapter, method, seed, current_problem, future_problem, all_problem)


def _run_row(run: Mapping[str, Any], method: str, seed: int, scenario: str, nc: int, nf: int, k: int, k1: int, k2: int) -> Dict[str, Any]:
    base = run.get("all_runs", run.get("run_row", {}))
    if not isinstance(base, Mapping):
        base = {}
    return {"method": method, "seed": seed, "scenario_name": scenario, "current_route_count": nc, "future_route_count": nf, "K": k, "K1": k1, "K2": k2, **dict(base)}


def _materialize_trace(
    trace: Sequence[Mapping[str, Any]], method: str, seed: int, scenario: str, nc: int, nf: int,
    k: int, k1: int, k2: int, stage1_best: np.ndarray, all_problem: Any,
) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for snapshot in trace:
        stage = str(snapshot.get("stage", ""))
        if method == PROPOSED and stage != "stage2_true_joint_all_routes":
            continue
        if method != PROPOSED and stage != "stage2_future":
            continue
        raw_decisions = np.asarray(snapshot.get("decisions", []), dtype=float)
        if raw_decisions.ndim != 3 or raw_decisions.shape[0] == 0:
            continue
        if raw_decisions.shape[1] == k:
            full = raw_decisions
        elif raw_decisions.shape[1] == k2 and stage1_best.shape == (k1, 5):
            full = np.concatenate([np.repeat(stage1_best.reshape(1, k1, 5), raw_decisions.shape[0], axis=0), raw_decisions], axis=1)
        else:
            continue
        evaluation = evaluate_with_existing_context_sinr_asu_v2(decisions=full, problem=all_problem, config=all_problem.config, method_name=f"{method}_exploration_trace")
        for index, (decision, metric) in enumerate(zip(full, evaluation.metrics)):
            m = dict(metric)
            objective = _diagnostic_objective(m)
            out.append({
                "method": method, "scenario_name": scenario, "seed": seed, "K": k, "K1": k1, "K2": k2,
                "current_route_count": nc, "future_route_count": nf, "iteration": int(snapshot.get("iteration", 0)),
                "candidate_id": f"{method}:{scenario}:K{k}:i{snapshot.get('iteration', 0)}:{snapshot.get('candidate_source', 'population')}:{index}",
                "candidate_source": str(snapshot.get("candidate_source", "population")),
                "is_archive_member": bool(snapshot.get("is_archive_member", False)), "is_nondominated": False,
                "decision_vector_json": json.dumps(np.asarray(decision, dtype=float).reshape(-1).round(8).tolist()),
                "decoded_deployment_json": json.dumps(_decoded(decision)),
                "objective_vector_json": json.dumps(objective), "objective_C_dep": objective[0], "objective_handover_count": objective[1],
                "objective_neg_Q_current": objective[2], "objective_neg_Q_future": objective[3],
                "ASU": m.get("ASU", ""), "Q_current": m.get("Q_current", ""), "Q_future": m.get("Q_future", ""),
                "Coverage@0": m.get("Coverage@0dB", ""), "Coverage@5": m.get("Coverage@5dB", ""), "Coverage@10": m.get("Coverage@10dB", ""),
                "current_Coverage@0": m.get("current_Coverage@0dB", ""), "future_Coverage@0": m.get("future_Coverage@0dB", ""),
                "C_dep": m.get("C_dep", m.get("deployment_cost", "")), "handover_count": m.get("handover_count", ""),
                "feasible": bool(np.asarray(evaluation.feasible, dtype=bool)[index]),
                "station_data_label": "route-agnostic simulated/proxy existing infrastructure; not real operator base-station records",
                "route_data_label": "generated/proxy semantic POI route points; not real measured airways",
            })
    return out


def _decoded(decision: np.ndarray) -> List[Dict[str, Any]]:
    sectors = [0, 45, 90, 135, 180, 225, 270, 315]
    out = []
    for idx, station in enumerate(np.asarray(decision, dtype=float)):
        typ = int(np.clip(round(float(station[3])), 0, 1))
        sector_idx = int(np.clip(round(float(station[4])), 0, 7))
        out.append({"station_id": idx + 1, "x": float(station[0]), "y": float(station[1]), "z": float(station[2]),
                    "station_type": "5GA" if typ else "5G", "station_type_index": typ,
                    "sector_direction": sectors[sector_idx] if typ else "omni", "sector_direction_index": sector_idx if typ else "omni"})
    return out


def _diagnostic_objective(metric: Mapping[str, Any]) -> List[float]:
    return [float(metric.get("C_dep", metric.get("deployment_cost", 0.0))), float(metric.get("handover_count", 0.0)),
            -float(metric.get("Q_current", 0.0)), -float(metric.get("Q_future", 0.0))]


def _mark_nondominated(rows: List[Dict[str, Any]]) -> None:
    by_scenario: Dict[tuple, List[Dict[str, Any]]] = {}
    for row in rows:
        by_scenario.setdefault((row["scenario_name"], row["K"]), []).append(row)
    for group in by_scenario.values():
        objectives = np.asarray([[r["objective_C_dep"], r["objective_handover_count"], r["objective_neg_Q_current"], r["objective_neg_Q_future"]] for r in group], dtype=float)
        keep = nondominated_mask(objectives)
        for row, flag in zip(group, keep.tolist()):
            row["is_nondominated"] = bool(flag)


def _decision_bins(row: Mapping[str, Any], spatial_only: bool = False) -> set[tuple]:
    decisions = np.asarray(json.loads(str(row["decision_vector_json"])), dtype=float).reshape(-1, 5)
    bins = set()
    for s in decisions:
        gx, gy = int(np.clip(math.floor(float(s[0]) / 500.0), 0, 19)), int(np.clip(math.floor(float(s[1]) / 500.0), 0, 19))
        typ = int(np.clip(round(float(s[3])), 0, 1))
        sec = "omni" if typ == 0 else int(np.clip(round(float(s[4])), 0, 7))
        bins.add((gx, gy) if spatial_only else (gx, gy, typ, sec))
    return bins


def _dcr_rows(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    groups: Dict[tuple, List[Mapping[str, Any]]] = {}
    for row in rows:
        groups.setdefault((row["scenario_name"], row["K"]), []).append(row)
    for (scenario, k), group in groups.items():
        union = set().union(*[_decision_bins(r) for r in group])
        spatial_union = set().union(*[_decision_bins(r, spatial_only=True) for r in group])
        for method in sorted({str(r["method"]) for r in group}):
            mine = [r for r in group if str(r["method"]) == method]
            occupied = set().union(*[_decision_bins(r) for r in mine])
            spatial = set().union(*[_decision_bins(r, spatial_only=True) for r in mine])
            out.append({"method": method, "scenario_name": scenario, "K": k, "occupied_decision_bins": len(occupied),
                        "total_union_decision_bins": len(union), "DCR": len(occupied) / max(len(union), 1),
                        "occupied_spatial_bins": len(spatial), "total_union_spatial_bins": len(spatial_union),
                        "spatial_only_DCR": len(spatial) / max(len(spatial_union), 1), "type_sector_DCR": len(occupied) / max(len(union), 1),
                        "definition": "unique (20x20 spatial cell, station type, sector) bins across checkpoint candidates"})
    return out


def _normal_decision(row: Mapping[str, Any], size_x: float, size_y: float) -> np.ndarray:
    d = np.asarray(json.loads(str(row["decision_vector_json"])), dtype=float).reshape(-1, 5)
    d = d[np.lexsort((d[:, 4], d[:, 3], d[:, 2], d[:, 1], d[:, 0]))]
    d[:, 0] /= max(size_x, 1e-9); d[:, 1] /= max(size_y, 1e-9); d[:, 2] = (d[:, 2] - 20.0) / 140.0
    d[:, 3] = np.clip(d[:, 3], 0, 1); d[:, 4] = np.minimum(np.mod(d[:, 4], 8), 8 - np.mod(d[:, 4], 8)) / 4.0
    return d.reshape(-1)


def _an_rows(rows: Sequence[Mapping[str, Any]], stations: Sequence[Mapping[str, Any]]) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    out, unavailable = [], []
    max_x = max(float(r.get("x", 0.0)) for r in stations) * 1.20
    max_y = max(float(r.get("y", 0.0)) for r in stations) * 1.20
    groups: Dict[tuple, List[Mapping[str, Any]]] = {}
    for row in rows:
        if bool(row.get("is_archive_member")):
            groups.setdefault((row["method"], row["scenario_name"], row["K"]), []).append(row)
    all_groups = {(r["method"], r["scenario_name"], r["K"]) for r in rows}
    for key in sorted(all_groups):
        archive = groups.get(key, [])
        if not archive:
            unavailable.append(_unavailable(key[0], key[1], key[2], "AN", "no archive trace; population-only method")); continue
        archive = sorted(archive, key=lambda r: int(r["iteration"]))
        seen, previous, novelty = set(), [], []
        for row in archive:
            vector = _normal_decision(row, max_x, max_y); marker = tuple(np.round(vector, 8).tolist())
            if marker in seen: continue
            seen.add(marker)
            if previous: novelty.append(float(np.min(np.linalg.norm(np.asarray(previous) - vector[None, :], axis=1))))
            previous.append(vector)
        arr = np.asarray(previous, dtype=float)
        pair = [] if arr.shape[0] < 2 else [float(np.linalg.norm(arr[i] - arr[j])) for i in range(arr.shape[0]) for j in range(i)]
        out.append({"method": key[0], "scenario_name": key[1], "K": key[2], "AN": float(np.mean(novelty)) if novelty else 0.0,
                    "final_archive_nearest_neighbor_distance": float(np.min(pair)) if pair else 0.0,
                    "final_archive_pairwise_distance_mean": float(np.mean(pair)) if pair else 0.0,
                    "archive_new_entry_count": len(previous), "matching_rule": "canonical station sort fallback; no Hungarian matching"})
    return out, unavailable


def _final_sets(rows: Sequence[Mapping[str, Any]]) -> Dict[tuple, List[Mapping[str, Any]]]:
    groups: Dict[tuple, List[Mapping[str, Any]]] = {}
    for row in rows:
        groups.setdefault((row["method"], row["scenario_name"], row["K"]), []).append(row)
    selected = {}
    for key, group in groups.items():
        last = max(int(r["iteration"]) for r in group); final = [r for r in group if int(r["iteration"]) == last]
        archive = [r for r in final if bool(r["is_archive_member"])]
        pool = archive or final
        obj = np.asarray([[r["objective_C_dep"], r["objective_handover_count"], r["objective_neg_Q_current"], r["objective_neg_Q_future"]] for r in pool], dtype=float)
        nd = nondominated_mask(obj)
        selected[key] = [r for r, keep in zip(pool, nd.tolist()) if keep]
    return selected


def _oe_rows(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    final = _final_sets(rows); out = []
    by_scenario: Dict[tuple, List[Mapping[str, Any]]] = {}
    for (method, scenario, k), values in final.items(): by_scenario.setdefault((scenario, k), []).extend(values)
    for (scenario, k), universe in by_scenario.items():
        raw = np.asarray([_objective(r) for r in universe], dtype=float); mn, mx = raw.min(axis=0), raw.max(axis=0); span = np.maximum(mx - mn, 1e-12)
        for (method, s, kk), values in final.items():
            if (s, kk) != (scenario, k): continue
            norm = (np.asarray([_objective(r) for r in values]) - mn) / span
            idx = [tuple(np.minimum((v * 10).astype(int), 9).tolist()) for v in norm]
            counts = np.asarray(list({cell: idx.count(cell) for cell in set(idx)}.values()), dtype=float); p = counts / max(counts.sum(), 1.0)
            entropy = float(-np.sum(p * np.log(p)) / max(math.log(max(min(len(values), 10**4), 2)), 1e-12)) if len(values) > 1 else 0.0
            source = "archive" if any(bool(r["is_archive_member"]) for r in values) else "nondominated_population"
            out.append({"method": method, "scenario_name": scenario, "K": k, "OE": entropy, "objective_bin_count": 10**4,
                        "occupied_objective_bins": len(set(idx)), "candidate_count_for_OE": len(values), "OE_source": source})
    return out


def _objective(row: Mapping[str, Any]) -> List[float]: return [float(row["objective_C_dep"]), float(row["objective_handover_count"]), float(row["objective_neg_Q_current"]), float(row["objective_neg_Q_future"])]


def _hv_rows(rows: Sequence[Mapping[str, Any]]) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    final = _final_sets(rows); out, unavailable = [], []
    by_scenario: Dict[tuple, List[tuple]] = {}
    for key, values in final.items(): by_scenario.setdefault((key[1], key[2]), []).append((key, values))
    for (scenario, k), items in by_scenario.items():
        records = [ObjectiveSetRecord(seed=2026, method_name=key[0], group="fair_optimizer", objectives=np.asarray([_objective(r) for r in values], dtype=float)) for key, values in items if values]
        if len(records) < 2:
            for key, _ in items: unavailable.append(_unavailable(key[0], scenario, k, "HV/GD/IGD", "insufficient valid final objective-vector sets"))
            continue
        cfg = {"multiObjectiveMetrics": {"objectiveNames": ["C_dep", "handover_count", "negative_Q_current", "negative_Q_future"], "objectiveDirections": ["min"] * 4,
              "normalization": {"enabled": True}, "hypervolume": {"autoReferenceMargin": 0.05, "maxExactPoints": 16, "numSamples": 30000, "seed": 2026}}}
        result = evaluate_multiobjective_metrics(records, cfg)
        for row in result.per_run_rows:
            out.append({"method": row["method_name"], "scenario_name": scenario, "K": k, "HV": row["hv"], "GD": row["gd"], "IGD": row["igd"],
                        "nondominated_solution_count": row["num_nondominated_points"], "reference_front_size": row["reference_front_size"],
                        "reference_point": row["hv_reference_point"], "normalization_min_max": json.dumps({"min": row["normalization_min"], "max": row["normalization_max"]}),
                        "ASU_used_for_HV_GD_IGD": False, "objective_vector": "[C_dep, handover_count, -Q_current, -Q_future]"})
    return out, unavailable


def _merge_metric_rows(all_rows, dcr, an, oe, hv):
    lookup = {}
    for collection in [dcr, an, oe, hv]:
        for r in collection: lookup.setdefault((r["method"], r["scenario_name"], r["K"]), {}).update(r)
    out = []
    for row in all_rows:
        out.append({**row, **lookup.get((row["method"], row["scenario_name"], row["K"]), {})})
    return out


def _unavailable(method, scenario, k, metric, reason): return {"method": method, "scenario_name": scenario, "K": k, "metric": metric, "reason": reason}


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    rows = list(rows); fields = sorted({key for row in rows for key in row}) or ["status"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(rows)


def _write_outputs(candidates, all_rows, metrics, dcr, an, oe, hv, unavailable, failed, elapsed):
    _write_csv(ROOT / "optimizer_exploration_all_candidates.csv", candidates)
    _write_csv(ROOT / "optimizer_exploration_archive_trace.csv", [r for r in candidates if bool(r.get("is_archive_member"))])
    _write_csv(ROOT / "optimizer_exploration_objective_vectors.csv", [{k: r[k] for k in r if k.startswith("objective_") or k in {"method", "scenario_name", "K", "iteration", "candidate_id", "candidate_source", "is_nondominated", "is_archive_member"}} for r in candidates])
    _write_csv(ROOT / "optimizer_exploration_metrics_by_method.csv", metrics)
    _write_csv(ROOT / "optimizer_exploration_metrics_by_scenario.csv", _scenario_summary(metrics))
    _write_csv(ROOT / "optimizer_exploration_DCR.csv", dcr); _write_csv(ROOT / "optimizer_exploration_AN.csv", an); _write_csv(ROOT / "optimizer_exploration_OE.csv", oe); _write_csv(ROOT / "optimizer_exploration_HV_GD_IGD.csv", hv)
    _write_csv(ROOT / "optimizer_exploration_unavailable_metrics.csv", unavailable + failed)
    meta = {"purpose": "exploration/diversity diagnostic", "methods": OPTIMIZERS, "scenarios": ROUTE_SETTINGS, "K_settings": K_SETTINGS, "seeds": SEEDS,
            "true_sinr": True, "single_fidelity": True, "objective_vector": ["C_dep", "handover_count", "-Q_current", "-Q_future"],
            "ASU_used_for_HV_GD_IGD": False, "candidate_checkpoints": [0, 0.25, 0.5, 0.75, 1.0], "elapsed_seconds": elapsed,
            "station_data_label": "simulated/proxy; not real operator station records", "route_data_label": "generated/proxy semantic POI routes; not real measured airways"}
    (ROOT / "optimizer_exploration_metadata.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    _write_report(metrics, unavailable, failed); _write_safety(); _plots(metrics)


def _scenario_summary(rows):
    out=[]
    for (scenario,k), values in _group(rows, lambda r:(r["scenario_name"],r["K"])).items():
        out.append({"scenario_name":scenario,"K":k,"method_count":len(values),"proposed_present":any(r["method"]==PROPOSED for r in values)})
    return out


def _group(rows, key):
    out={}
    for r in rows: out.setdefault(key(r),[]).append(r)
    return out


def _write_report(metrics, unavailable, failed):
    proposed = [r for r in metrics if r.get("method") == PROPOSED]
    lines=["# Optimizer Exploration and Diversity Diagnostic", "", "## Scope", "", "All completed cells use true-SINR, the unchanged ASU-v2 service metric, generated/proxy semantic POI routes, and simulated/proxy existing stations. DCR, AN, and OE are complementary diagnostics; they do not replace HV/GD/IGD.", "", "## Interpretation Rules", "", "- DCR measures decision-bin occupation across recorded checkpoint candidates.", "- AN is available only for methods that exported archive snapshots; it uses canonical station sorting as the documented matching fallback.", "- OE, HV, GD, and IGD use `[C_dep, handover_count, -Q_current, -Q_future]`; ASU is never an objective-vector input.", "- Higher DCR/AN/OE alone does not establish better service or Pareto performance. ASU, coverage, and objective-vector metrics must be read together.", "", "## Proposed Summary", ""]
    for row in proposed:
        lines.append(f"- `{row['scenario_name']}`, K={row['K']}: DCR={row.get('DCR','')}, AN={row.get('AN','unavailable')}, OE={row.get('OE','')}, HV={row.get('HV','unavailable')}, ASU={row.get('ASU','')}.")
    lines += ["", "## Availability", "", f"- Unavailable metric records: {len(unavailable)}.", f"- Failed runs: {len(failed)}.", "- Missing archive traces are marked unavailable rather than filled with population proxies for AN."]
    (ROOT / "optimizer_exploration_report.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
    guidance = """# Paper Guidance\n\nHV/GD/IGD quantify final objective-space convergence and approximation quality. DCR, archive novelty (AN), and objective entropy (OE) quantify complementary exploration and diversity behavior. They are not replacements for HV/GD/IGD, and higher DCR/AN/OE alone cannot establish better optimization or deployment service.\n\nA safe claim is limited to measured evidence: the closed-loop route-aware response maintains broader decision-bin occupation or archive/objective diversity in the reported true-SINR diagnostic cells, where its DCR/AN/OE exceed a stated comparator. Service conclusions must remain tied to ASU-v2, Q, and coverage. Do not claim universal Pareto-front superiority over NSGA-II or MOEA/D unless the objective-vector HV/GD/IGD rows support it.\n"""
    (ROOT / "optimizer_exploration_paper_guidance.md").write_text(guidance, encoding="utf-8")


def _write_safety():
    text = """# Safety Check\n\n- Original station, route, and POI artifacts were read only.\n- No ray tracing or SINR multi-fidelity was implemented.\n- Official ASU-v2 formula was not changed.\n- DCR/AN/OE are diagnostic metrics; ASU was not used for HV/GD/IGD.\n- Candidate traces are observation-only and were enabled by an explicit experiment configuration.\n- Station data are simulated/proxy; route data are generated/proxy semantic POI routes. No real-operator or real-measured-airway claim is made.\n"""
    (ROOT / "optimizer_exploration_safety_check.md").write_text(text, encoding="utf-8")


def _plots(rows):
    specs=[("DCR","DCR_by_method.png"),("AN","AN_by_method.png"),("OE","OE_by_method.png"),("HV","HV_by_method.png"),("IGD","IGD_by_method.png"),("ASU","ASU_vs_DCR.png"),("Coverage@10","Coverage10_vs_OE.png")]
    for metric,name in specs:
        vals=[r for r in rows if str(r.get(metric,"")) not in {"", "nan"}]
        if not vals: continue
        labels=[f"{r['method']}\n{r['scenario_name']}/K{r['K']}" for r in vals]; numbers=[float(r[metric]) for r in vals]
        fig,ax=plt.subplots(figsize=(max(8,len(vals)*0.45),4)); ax.bar(range(len(vals)),numbers); ax.set_ylabel(metric); ax.set_xticks(range(len(vals)),labels,rotation=90,fontsize=6); fig.tight_layout(); fig.savefig(ROOT/name,dpi=160); plt.close(fig)
    for x,y,name in [("DCR","HV","DCR_vs_HV.png"),("OE","HV","OE_vs_HV.png"),("AN","IGD","AN_vs_IGD.png")]:
        vals=[r for r in rows if r.get(x,"") not in {"",None} and r.get(y,"") not in {"",None}]
        if not vals: continue
        fig,ax=plt.subplots(figsize=(5,4)); ax.scatter([float(r[x]) for r in vals],[float(r[y]) for r in vals]); ax.set_xlabel(x);ax.set_ylabel(y);fig.tight_layout();fig.savefig(ROOT/name,dpi=160);plt.close(fig)
    # Compact across-scenario/K projections required by the protocol.
    for field,name in [("scenario_name","exploration_metrics_across_route_scale.png"),("K","exploration_metrics_across_K.png")]:
        vals=[r for r in rows if r.get("DCR","") not in {"",None}];
        if not vals: continue
        fig,ax=plt.subplots(figsize=(7,4));
        for method in sorted({r["method"] for r in vals}):
            subset=[r for r in vals if r["method"]==method]; ax.plot([str(r[field]) for r in subset],[float(r["DCR"]) for r in subset],marker="o",label=method)
        ax.set_ylabel("DCR");ax.legend(fontsize=6);fig.tight_layout();fig.savefig(ROOT/name,dpi=160);plt.close(fig)


if __name__ == "__main__":
    main()
