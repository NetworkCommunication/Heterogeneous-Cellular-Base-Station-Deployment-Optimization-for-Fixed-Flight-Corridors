from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
os.environ.setdefault("MPLCONFIGDIR", str((REPO_ROOT / ".mplcache").resolve()))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from src.algorithms.particle_encoding import decode_particle_solution
from src.baselines.base import DeploymentProblem
from src.baselines.registry import build_method_registry
from src.data.types import AirRoute, CityMap
from src.experiments.evaluation_consistency import _station_file_preferred_plan, existing_station_particle
from src.propagation.a2g_probabilistic import compute_population_per_bs_rx_power_a2g_dbm


ROOT = Path("artifacts/tmc_rebuild/formal_K10_balanced_sinr0_citywide_low")
CONFIG_ROOT = Path("artifacts/tmc_rebuild/formal_config_candidates_sinr_density_calibrated")
STATION_PATH = Path("artifacts/tmc_rebuild/station_generation_citywide_route_agnostic/generated_existing_stations_citywide_route_agnostic_low.csv")
ROUTE_POINT_PATH = Path("artifacts/tmc_rebuild/route_resampling/shenyang_predicted_routes_resampled_points.csv")
ROUTE_META_PATH = Path("data/real/shenyang/shenyang_predicted_routes.csv")
POI_PATH = Path("data/real/shenyang/shenyang_pois.csv")
BOUNDARY_PATH = Path("data/real/shenyang/shenyang_study_area_boundary.geojson")

METHODS = [
    "proposed_method_search_expansion_response_v2_asu_v2",
    "csa_extended",
    "gwo_extended",
    "woa_extended",
    "ssa_extended",
    "hho_extended",
]
PENDING_METHODS = {
    "nsga2_extended": "pending; not included in this first SINR K10 run",
    "moead_extended": "pending; not included in this first SINR K10 run",
}
SEEDS = [2026, 2027, 2028]
K = 10
K1 = 5
K2 = 5
POPULATION = 50
ITERATIONS = 150
SINR_THRESHOLD_DB = 0.0
AUX_THRESHOLDS_DB = [5.0, 10.0]
SINR_RHO = 0.10
NOISE_POWER_DBM = -90.0
SECTOR_AZIMUTHS = [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]


FORMAL_METRICS = [
    "ASU",
    "Q_current",
    "Q_future",
    "ASU_numerator",
    "ASU_denominator",
    "C_dep",
    "handover_count",
    "Coverage@0dB",
    "Coverage@5dB",
    "Coverage@10dB",
    "current_Coverage@0dB",
    "future_Coverage@0dB",
    "outage@0dB",
    "mean_SINR_db",
    "median_SINR_db",
    "runtime",
    "N_5G",
    "N_5GA",
    "response_count",
]


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    stations = read_csv(STATION_PATH)
    routes = read_csv(ROUTE_POINT_PATH)
    registry = build_method_registry()
    all_problem, current_problem, future_problem, meta = build_problems(stations, routes)

    all_rows: List[Dict[str, Any]] = []
    comp_rows: List[Dict[str, Any]] = []
    station_rows: List[Dict[str, Any]] = []
    two_stage_rows: List[Dict[str, Any]] = []
    runtime_rows: List[Dict[str, Any]] = []
    response_rows: List[Dict[str, Any]] = []
    trace_rows: List[Dict[str, Any]] = []
    status_rows: List[Dict[str, Any]] = []
    failed_rows: List[Dict[str, Any]] = []

    for method in METHODS:
        adapter = registry.get(method)
        registered = adapter is not None
        implemented = bool(getattr(adapter, "implemented", False)) if registered else False
        for seed in SEEDS:
            status = {
                "method": method,
                "seed": seed,
                "registered": registered,
                "implemented": implemented,
                "status": "pending",
                "reason": "",
            }
            if not registered or not implemented:
                status["status"] = "failed"
                status["reason"] = "method not registered or not implemented"
                status_rows.append(status)
                failed_rows.append(dict(status))
                continue
            try:
                run = run_two_stage(adapter, method, seed, current_problem, future_problem, all_problem)
                all_rows.append(run["run_row"])
                comp_rows.append(run["component_row"])
                station_rows.append(run["station_row"])
                two_stage_rows.append(run["two_stage_row"])
                runtime_rows.append(run["runtime_row"])
                response_rows.append(run["response_row"])
                trace_rows.extend(run["trace_rows"])
                status["status"] = "completed"
                status_rows.append(status)
                write_incremental(all_rows, comp_rows, station_rows, two_stage_rows, runtime_rows, response_rows, trace_rows, status_rows, failed_rows, meta, time.time() - t0)
            except Exception as exc:  # pragma: no cover - formal runner records failures.
                status["status"] = "failed"
                status["reason"] = f"{type(exc).__name__}: {exc}"
                status_rows.append(status)
                failed_rows.append(dict(status))
                write_incremental(all_rows, comp_rows, station_rows, two_stage_rows, runtime_rows, response_rows, trace_rows, status_rows, failed_rows, meta, time.time() - t0)

    for pending, reason in PENDING_METHODS.items():
        status_rows.append(
            {
                "method": pending,
                "seed": "",
                "registered": pending in registry,
                "implemented": bool(getattr(registry.get(pending), "implemented", False)) if pending in registry else False,
                "status": "pending",
                "reason": reason,
            }
        )

    write_incremental(all_rows, comp_rows, station_rows, two_stage_rows, runtime_rows, response_rows, trace_rows, status_rows, failed_rows, meta, time.time() - t0)
    mean_rows = mean_std(all_rows, ["method"], FORMAL_METRICS)
    write_csv(ROOT / "formal_sinr_K10_mean_std.csv", mean_rows)
    plot_outputs(all_rows, mean_rows, station_rows, response_rows, trace_rows)
    write_reports(all_rows, mean_rows, station_rows, response_rows, status_rows, failed_rows, meta, elapsed=time.time() - t0)
    print(
        json.dumps(
            {
                "artifact_root": ROOT.as_posix(),
                "completed_runs": len(all_rows),
                "failed_runs": len(failed_rows),
                "completed_methods": sorted({r["method"] for r in all_rows}),
            },
            indent=2,
        )
    )


def write_incremental(
    all_rows: Sequence[Dict[str, Any]],
    comp_rows: Sequence[Dict[str, Any]],
    station_rows: Sequence[Dict[str, Any]],
    two_stage_rows: Sequence[Dict[str, Any]],
    runtime_rows: Sequence[Dict[str, Any]],
    response_rows: Sequence[Dict[str, Any]],
    trace_rows: Sequence[Dict[str, Any]],
    status_rows: Sequence[Dict[str, Any]],
    failed_rows: Sequence[Dict[str, Any]],
    meta: Dict[str, Any],
    elapsed: float,
) -> None:
    write_csv(ROOT / "formal_sinr_K10_all_runs.csv", all_rows)
    write_csv(ROOT / "formal_sinr_K10_asu_components.csv", comp_rows)
    write_csv(ROOT / "formal_sinr_K10_station_summary.csv", station_rows)
    write_csv(ROOT / "formal_sinr_K10_two_stage_summary.csv", two_stage_rows)
    write_csv(ROOT / "formal_sinr_K10_runtime_summary.csv", runtime_rows)
    write_csv(ROOT / "formal_sinr_K10_response_summary.csv", response_rows)
    write_csv(ROOT / "formal_sinr_K10_trace_summary.csv", trace_rows)
    write_csv(ROOT / "formal_sinr_K10_method_status.csv", status_rows)
    write_csv(ROOT / "formal_sinr_K10_failed_runs.csv", failed_rows)
    write_json(ROOT / "formal_sinr_K10_metadata.json", metadata(meta, elapsed=elapsed))


def run_two_stage(adapter: Any, method: str, seed: int, current_problem: DeploymentProblem, future_problem: DeploymentProblem, all_problem: DeploymentProblem) -> Dict[str, Any]:
    t0 = time.time()
    stage1 = adapter.run(current_problem, seed=int(seed), config=stage_config(current_problem.config, K1, stage="current"))
    stage2 = adapter.run(future_problem, seed=int(seed) + 1009, config=stage_config(future_problem.config, K2, stage="future"))
    p1 = best_decision(stage1, K1)
    p2 = best_decision(stage2, K2)
    final = np.concatenate([p1, p2], axis=0)
    runtime = float(time.time() - t0)
    evaluation = final_evaluate_sinr(final, all_problem, method, seed, runtime)
    stage1_counts = station_type_counts(p1)
    stage2_counts = station_type_counts(p2)
    response = response_summary(stage1, stage2)
    trace = trace_summary(method, seed, stage1, stage2)
    decoded = decoded_deployment(final, all_problem.config, method, seed)
    sectors = [float(r.get("sector_azimuth_deg", 0.0)) for r in decoded if str(r.get("station_type", "")).upper() == "5GA"]
    valid_sectors = all(any(abs(v - s) < 1e-9 for s in SECTOR_AZIMUTHS) for v in sectors)

    run_row = {
        **evaluation["run_row"],
        "stage1_5G_count": stage1_counts[0],
        "stage1_5GA_count": stage1_counts[1],
        "stage2_5G_count": stage2_counts[0],
        "stage2_5GA_count": stage2_counts[1],
        "convergence_status": "completed",
        "invalid_solution_count": 0,
        "NaN_count": int(not math.isfinite(float(evaluation["run_row"]["ASU"]))),
        **response,
    }
    station_row = {
        "method": method,
        "seed": seed,
        "K": K,
        "K1": K1,
        "K2": K2,
        "stage1_station_count": K1,
        "stage2_station_count": K2,
        "total_new_station_count": K,
        "selected_5G_count": evaluation["run_row"]["N_5G"],
        "selected_5GA_count": evaluation["run_row"]["N_5GA"],
        "stage1_5G_count": stage1_counts[0],
        "stage1_5GA_count": stage1_counts[1],
        "stage2_5G_count": stage2_counts[0],
        "stage2_5GA_count": stage2_counts[1],
        "sector_directions_5GA": ";".join(str(v) for v in sectors),
        "valid_5GA_sector_directions": valid_sectors,
        "all_station_count_exactly_K": len(decoded) == K,
        "deployment_hash": evaluation["run_row"]["deployment_hash"],
    }
    return {
        "run_row": run_row,
        "component_row": {"method": method, "seed": seed, **evaluation["component_row"]},
        "station_row": station_row,
        "two_stage_row": {
            "method": method,
            "seed": seed,
            "K": K,
            "K1": K1,
            "K2": K2,
            "stage1_target": "current-priority route protection",
            "stage2_target": "future-priority route expansion",
            "final_evaluation": "144 existing + 5 stage-I new + 5 stage-II new over 80 routes / 2400 points",
            "stage1_runtime_seconds": stage1.runtime_seconds,
            "stage2_runtime_seconds": stage2.runtime_seconds,
            "runtime": runtime,
            "stage1_best_ASU": stage1.logs.get("best_ASU", ""),
            "stage2_best_ASU": stage2.logs.get("best_ASU", ""),
        },
        "runtime_row": {
            "method": method,
            "seed": seed,
            "runtime": runtime,
            "stage1_runtime_seconds": stage1.runtime_seconds,
            "stage2_runtime_seconds": stage2.runtime_seconds,
            "population": POPULATION,
            "iterations_per_stage": ITERATIONS,
            "approximate_evaluations": 2 * POPULATION * (ITERATIONS + 1),
        },
        "response_row": {"method": method, "seed": seed, **response},
        "trace_rows": trace,
    }


def final_evaluate_sinr(final: np.ndarray, problem: DeploymentProblem, method: str, seed: int, runtime: float) -> Dict[str, Dict[str, Any]]:
    new = np.asarray(final, dtype=float).reshape(1, K, 5)
    existing = existing_station_particle(problem.config, target_dims=5)
    combined = np.concatenate([existing[None, :, :], new], axis=1)
    plan = _station_file_preferred_plan(problem.config, combined[0], existing_count=existing.shape[0])
    rx_dbm, _ = compute_population_per_bs_rx_power_a2g_dbm(
        positions=combined[:, :, :3],
        test_points=problem.test_points,
        channel_params=problem.channel_params,
        tx_power_offsets_db=plan.tx_power_offsets_db,
        coverage_boost_db=plan.coverage_boost_db,
        path_loss_offsets_db=plan.path_loss_offsets_db,
        sector_station_mask=plan.sector_station_mask,
        sector_azimuths_deg=plan.sector_azimuths_deg,
        sector_beamwidth_deg=plan.sector_beamwidth_deg,
        outside_sector_mode=plan.outside_sector_mode,
        side_lobe_attenuation_db=plan.side_lobe_attenuation_db,
    )
    rx_dbm = np.asarray(rx_dbm[0], dtype=float)
    rx_mw = np.power(10.0, rx_dbm / 10.0)
    serving_idx = np.argmax(rx_dbm, axis=0)
    point_idx = np.arange(rx_dbm.shape[1])
    serving_power_mw = rx_mw[serving_idx, point_idx]
    total_power_mw = np.sum(rx_mw, axis=0)
    non_serving_mw = np.maximum(total_power_mw - serving_power_mw, 0.0)
    noise_mw = 10.0 ** (NOISE_POWER_DBM / 10.0)
    sinr_linear = serving_power_mw / (noise_mw + SINR_RHO * non_serving_mw)
    sinr_db = 10.0 * np.log10(np.maximum(sinr_linear, 1e-30))

    route_cfg = problem.config["routeObjectives"]
    current_idx = np.asarray(route_cfg["existingIndices"], dtype=int)
    future_idx = np.asarray(route_cfg["futureIndices"], dtype=int)
    route_ids = np.asarray(problem.config.get("routePointMetadata", {}).get("route_ids", [""] * sinr_db.size), dtype=object)
    route_point_indices = np.asarray(problem.config.get("routePointMetadata", {}).get("point_indices", list(range(sinr_db.size))), dtype=int)
    handover = count_serving_changes(route_ids, route_point_indices, serving_idx)
    n5g, n5ga = station_type_counts(final)
    c_dep = n5g * 1.0 + n5ga * 1.35
    denominator = c_dep + 0.01 * float(handover) + 1.0

    q_current, current_log = q_component(sinr_linear, sinr_db >= SINR_THRESHOLD_DB, current_idx)
    q_future, future_log = q_component(sinr_linear, sinr_db >= SINR_THRESHOLD_DB, future_idx)
    numerator = 0.5 * q_current + 0.5 * q_future
    asu = numerator / max(denominator, 1e-12)
    cover0 = coverage(sinr_db, 0.0)
    cover5 = coverage(sinr_db, 5.0)
    cover10 = coverage(sinr_db, 10.0)
    row = {
        "method": method,
        "seed": seed,
        "ASU": asu,
        "Q_current": q_current,
        "Q_future": q_future,
        "ASU_numerator": numerator,
        "ASU_denominator": denominator,
        "denominator": denominator,
        "C_dep": c_dep,
        "deployment_cost": c_dep,
        "handover_count": float(handover),
        "kappa_H": 0.01,
        "C_0": 1.0,
        "Coverage@0dB": cover0,
        "Coverage@5dB": cover5,
        "Coverage@10dB": cover10,
        "current_Coverage@0dB": coverage(sinr_db[current_idx], 0.0),
        "future_Coverage@0dB": coverage(sinr_db[future_idx], 0.0),
        "current_Coverage@5dB": coverage(sinr_db[current_idx], 5.0),
        "future_Coverage@5dB": coverage(sinr_db[future_idx], 5.0),
        "current_Coverage@10dB": coverage(sinr_db[current_idx], 10.0),
        "future_Coverage@10dB": coverage(sinr_db[future_idx], 10.0),
        "outage@0dB": 1.0 - cover0,
        "mean_SINR_db": float(np.mean(sinr_db)),
        "p10_SINR_db": float(np.percentile(sinr_db, 10)),
        "median_SINR_db": float(np.percentile(sinr_db, 50)),
        "p90_SINR_db": float(np.percentile(sinr_db, 90)),
        "current_mean_log_rate": current_log,
        "future_mean_log_rate": future_log,
        "N_5G": n5g,
        "N_5GA": n5ga,
        "K": K,
        "K1": K1,
        "K2": K2,
        "total_new_station_count": K,
        "runtime": runtime,
        "population": POPULATION,
        "iterations_per_stage": ITERATIONS,
        "signal_metric": "sinr",
        "threshold_main_db": SINR_THRESHOLD_DB,
        "auxiliary_thresholds_db": "5;10",
        "rho": SINR_RHO,
        "power_mode": "station_file_preferred",
        "existing_station_count": int(existing.shape[0]),
        "evaluation_station_count": int(combined.shape[1]),
        "existing_stations_excluded_from_C_dep": True,
        "deployment_hash": deployment_hash(final),
        "station_data_label": "route-agnostic simulated/proxy existing infrastructure; not real operator base-station records",
        "route_data_label": "generated/proxy semantic POI route points; not real measured airways",
    }
    comp = {
        "ASU": asu,
        "Q_current": q_current,
        "Q_future": q_future,
        "current_coverage": row["current_Coverage@0dB"],
        "future_coverage": row["future_Coverage@0dB"],
        "current_mean_log_rate": current_log,
        "future_mean_log_rate": future_log,
        "C_dep": c_dep,
        "N_5G": n5g,
        "N_5GA": n5ga,
        "C_5G": 1.0,
        "C_5GA": 1.35,
        "handover_count": float(handover),
        "kappa_H": 0.01,
        "C_0": 1.0,
        "denominator": denominator,
        "w_current": 0.5,
        "w_future": 0.5,
        "signal_metric": "sinr",
        "rho": SINR_RHO,
        "threshold_main_db": SINR_THRESHOLD_DB,
        "asu_preset": "asu_route_service_v2",
        "ASU_formula_unchanged": True,
    }
    return {"run_row": row, "component_row": comp}


def build_problems(stations: Sequence[Dict[str, str]], routes: Sequence[Dict[str, str]]) -> tuple[DeploymentProblem, DeploymentProblem, DeploymentProblem, Dict[str, Any]]:
    points = np.asarray([[num(r["x"]), num(r["y"]), num(r.get("z", r.get("altitude_m", 100.0)), 100.0)] for r in routes], dtype=float)
    priority = np.asarray([str(r.get("route_priority_label", "")).strip().lower() for r in routes], dtype=object)
    current_idx = np.where(priority == "current")[0]
    future_idx = np.where(priority == "future")[0]
    if current_idx.size == 0 or future_idx.size == 0:
        cut = points.shape[0] // 2
        current_idx = np.arange(0, cut)
        future_idx = np.arange(cut, points.shape[0])
    xs = [num(r["x"]) for r in stations] + points[:, 0].tolist()
    ys = [num(r["y"]) for r in stations] + points[:, 1].tolist()
    min_x, max_x = max(min(xs) - 500.0, 0.0), max(xs) + 500.0
    min_y, max_y = max(min(ys) - 500.0, 0.0), max(ys) + 500.0
    cfg = config(k=K, min_position=[min_x, min_y, 20.0], max_position=[max_x, max_y, 120.0])
    h = cfg["heterogeneousDeployment"]
    h["existingStations"] = [[num(r["x"]), num(r["y"]), num(r.get("z", r.get("height", 35.0)), 35.0)] for r in stations]
    h["existingStationTypes"] = [str(r.get("station_type", "5G") or "5G") for r in stations]
    h["existingStationTiers"] = [str(r.get("station_tier", "") or "") for r in stations]
    h["existingStationTxPowerDbm"] = [num(r.get("tx_power_dbm"), 18.0) for r in stations]
    h["existingStationSectorAzimuthsDeg"] = [num(r.get("sector_azimuth_deg"), 0.0) for r in stations]
    cfg["routePointMetadata"] = {
        "route_ids": [str(r.get("route_id", "")) for r in routes],
        "point_indices": [int(num(r.get("point_index", i), i)) for i, r in enumerate(routes)],
        "priority_labels": [str(r.get("route_priority_label", "")).strip().lower() for r in routes],
    }
    cfg["routeObjectives"] = {
        "splitMode": "explicit_indices",
        "existingIndices": current_idx.astype(int).tolist(),
        "futureIndices": future_idx.astype(int).tolist(),
    }
    city = CityMap(
        size_x=float(max_x + 500.0),
        size_y=float(max_y + 500.0),
        size_z=180.0,
        buildings=[],
        building_bounds=np.zeros((0, 4), dtype=float),
        height_matrix=np.zeros((1, 1), dtype=float),
        height_resolution=100.0,
    )
    all_problem = make_problem(cfg, city, points, current_idx, future_idx)
    current_problem = make_problem(cfg, city, points[current_idx], np.arange(current_idx.size), np.zeros((0,), dtype=int))
    future_problem = make_problem(cfg, city, points[future_idx], np.zeros((0,), dtype=int), np.arange(future_idx.size))
    meta = {
        "config_root": CONFIG_ROOT.as_posix(),
        "station_artifact": STATION_PATH.as_posix(),
        "route_point_artifact": ROUTE_POINT_PATH.as_posix(),
        "route_metadata": ROUTE_META_PATH.as_posix(),
        "poi_metadata": POI_PATH.as_posix(),
        "study_boundary": BOUNDARY_PATH.as_posix(),
        "station_count": len(stations),
        "route_count": len(set(str(r.get("route_id", "")) for r in routes)),
        "route_point_count": len(routes),
        "current_point_count": int(current_idx.size),
        "future_point_count": int(future_idx.size),
        "station_label": sorted({str(r.get("source", "")).strip() for r in stations if str(r.get("source", "")).strip()}),
        "route_label": sorted({str(r.get("route_data_label", "")).strip() for r in routes if str(r.get("route_data_label", "")).strip()}),
    }
    return all_problem, current_problem, future_problem, meta


def make_problem(cfg: Dict[str, Any], city: CityMap, points: np.ndarray, current_idx: np.ndarray, future_idx: np.ndarray) -> DeploymentProblem:
    pcfg = json.loads(json.dumps(cfg))
    pcfg["routeObjectives"] = {
        "splitMode": "explicit_indices",
        "existingIndices": [int(i) for i in current_idx.tolist()],
        "futureIndices": [int(i) for i in future_idx.tolist()],
    }
    route = AirRoute(routes=[], num_segments=int(points.shape[0]), points_per_segment=1, min_altitude=100.0, max_altitude=100.0, grid_size=100.0, test_points=np.asarray(points, dtype=float))
    return DeploymentProblem(config=pcfg, city_map=city, air_route=route, channel_params=pcfg["channel"], route_source_metadata={})


def config(k: int, min_position: Sequence[float], max_position: Sequence[float]) -> Dict[str, Any]:
    cfg: Dict[str, Any] = {
        "run_label": "formal_K10_balanced_sinr0_citywide_low",
        "asu_preset": "asu_route_service_v2",
        "pso": {"numBaseStations": int(k), "numParticles": POPULATION, "maxIterations": ITERATIONS, "minPosition": list(min_position), "maxPosition": list(max_position)},
        "mopso": {"archiveSize": 80},
        "channel": {
            "frequency": 2.4e9,
            "txPower": 18.0,
            "noisePower": NOISE_POWER_DBM,
            "antennaGain": 0.0,
            "snrThreshold": SINR_THRESHOLD_DB,
            "lowFidelityModel": "a2g_probabilistic",
            "a2gProbabilistic": {"a": 9.61, "b": 0.16, "etaLoS": 1.0, "etaNLoS": 20.0},
            "sector_directions_deg": SECTOR_AZIMUTHS,
            "sector_beamwidth_deg": 120.0,
            "outside_sector_mode": "no_coverage",
        },
        "evaluation": {"power_mode": "station_file_preferred", "signal_metric": "sinr", "threshold_main_db": SINR_THRESHOLD_DB, "auxiliary_thresholds_db": AUX_THRESHOLDS_DB, "rho": SINR_RHO},
        "heterogeneousDeployment": {
            "enabled": True,
            "stationTypes": [
                {"name": "5G", "ratio": 0.5, "txPowerOffsetDb": 0.0, "deploymentCost": 1.0, "cost": 1.0, "coverageBoostDb": 0.0, "capacityUnits": 1.0},
                {"name": "5GA", "ratio": 0.5, "txPowerOffsetDb": 4.0, "deploymentCost": 1.35, "cost": 1.35, "coverageBoostDb": 9.0, "capacityUnits": 3.0},
            ],
            "defaultSectorAzimuthDeg": 0.0,
        },
        "particleEncoding": {"optimizeStationType": True, "optimizeSectorDirection": True},
        "baselineObjectives": {"coverageWeight": 1.0, "signalQualityWeight": 0.2, "costWeight": 0.2, "costReference": 13.5},
        "nsga2": {"repair": {"enabled": True, "enforceNonBuilding": False}, "feasiblePenaltyTol": 1e9},
        "airwayServiceUtilityV2": {"signal_metric": "snr", "w_current": 0.5, "w_future": 0.5, "C_5G": 1.0, "C_5GA": 1.35, "kappa_H": 0.01, "C_0": 1.0},
        "multiFidelity": {"mode": "all_low_fidelity"},
    }
    for key in ["csa", "gwo", "woa", "ssa", "hho"]:
        cfg[key] = {"population_size": POPULATION, "max_iterations": ITERATIONS}
    cfg["csa"].update({"awareness_probability": 0.1, "flight_length": 2.0})
    return cfg


def stage_config(base_cfg: Dict[str, Any], k: int, *, stage: str) -> Dict[str, Any]:
    cfg = json.loads(json.dumps(base_cfg))
    cfg["pso"]["numBaseStations"] = int(k)
    for key in ["csa", "gwo", "woa", "ssa", "hho"]:
        cfg[key]["population_size"] = POPULATION
        cfg[key]["max_iterations"] = ITERATIONS
    cfg.setdefault("routePriorityWrapper", {})["stage"] = stage
    return cfg


def q_component(signal_linear: np.ndarray, covered: np.ndarray, indices: np.ndarray) -> tuple[float, float]:
    if indices.size == 0:
        return 0.0, 0.0
    vals = np.asarray(signal_linear[indices], dtype=float)
    logs = np.log2(1.0 + np.maximum(vals, 0.0))
    q = float(np.mean(covered[indices].astype(float) * logs))
    return q, float(np.mean(logs))


def coverage(values: np.ndarray, threshold: float) -> float:
    arr = np.asarray(values, dtype=float)
    return float(np.mean(arr >= float(threshold))) if arr.size else 0.0


def count_serving_changes(route_ids: np.ndarray, point_indices: np.ndarray, serving_idx: np.ndarray) -> int:
    count = 0
    for route_id in sorted(set(route_ids.tolist())):
        mask = np.where(route_ids == route_id)[0]
        if mask.size <= 1:
            continue
        order = mask[np.argsort(point_indices[mask], kind="stable")]
        seq = serving_idx[order]
        count += int(np.sum(seq[1:] != seq[:-1]))
    return count


def best_decision(result: Any, k: int) -> np.ndarray:
    best = result.logs.get("best_chromosome") if isinstance(result.logs, dict) else None
    if best is not None:
        return np.asarray(best, dtype=float).reshape(k, 5)
    if getattr(result, "nondominated_decisions", np.zeros((0,))).size:
        return np.asarray(result.nondominated_decisions[0], dtype=float).reshape(k, 5)
    return np.asarray(result.decision_variables[0], dtype=float).reshape(k, 5)


def response_summary(stage1: Any, stage2: Any) -> Dict[str, Any]:
    def s(key: str) -> int:
        return int(stage1.logs.get(key, 0) or 0) + int(stage2.logs.get(key, 0) or 0)

    iterations: List[str] = []
    for stage_name, stage in [("stage1", stage1), ("stage2", stage2)]:
        for key in ["response_iterations", "trigger_iterations", "response_iteration_list"]:
            raw = stage.logs.get(key, [])
            if isinstance(raw, str):
                raw = [raw]
            for item in raw or []:
                iterations.append(f"{stage_name}:{item}")
    return {
        "response_count": s("response_count") or s("trigger_count"),
        "mild_response_count": s("mild_response_count"),
        "moderate_response_count": s("moderate_response_count"),
        "severe_response_count": s("severe_response_count"),
        "restart_count": s("restart_count"),
        "pbest_preservation_count": s("pbest_preservation_count"),
        "response_iteration_list": ";".join(iterations),
        "archive_novelty": stage2.logs.get("mean_decision_archive_novelty", stage1.logs.get("mean_decision_archive_novelty", "")),
        "objective_entropy": stage2.logs.get("objective_space_entropy", stage1.logs.get("objective_space_entropy", "")),
        "population_movement": stage2.logs.get("mean_population_movement_distance", stage1.logs.get("mean_population_movement_distance", "")),
    }


def trace_summary(method: str, seed: int, stage1: Any, stage2: Any) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for stage_name, stage in [("stage1_current", stage1), ("stage2_future", stage2)]:
        for item in stage.logs.get("history", []):
            rows.append({"method": method, "seed": seed, "stage": stage_name, **item})
        for item in stage.logs.get("stagnation_score_trace", []):
            rows.append({"method": method, "seed": seed, "stage": stage_name, **item})
    return rows


def decoded_deployment(final: np.ndarray, cfg: Dict[str, Any], method: str, seed: int) -> List[Dict[str, Any]]:
    rows = []
    for row in decode_particle_solution(np.asarray(final, dtype=float).reshape(K, 5), cfg):
        item = dict(row)
        station_id = int(item["station_id"])
        item["method"] = method
        item["seed"] = seed
        item["station_source"] = "stage1_current_priority" if station_id <= K1 else "stage2_future_priority"
        rows.append(item)
    return rows


def station_type_counts(particle: np.ndarray) -> tuple[int, int]:
    arr = np.asarray(particle, dtype=float).reshape(-1, 5)
    type_idx = np.rint(arr[:, 3]).astype(int)
    n5ga = int(np.sum(type_idx == 1))
    return int(arr.shape[0] - n5ga), n5ga


def deployment_hash(final: np.ndarray) -> str:
    arr = np.round(np.asarray(final, dtype=float).reshape(-1, 5), 4)
    return hashlib.sha256(arr.tobytes()).hexdigest()[:16]


def read_csv(path: Path) -> List[Dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    keys: List[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys or ["empty"])
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in keys})


def write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def metadata(meta: Dict[str, Any], *, elapsed: float) -> Dict[str, Any]:
    return {
        "artifact_root": ROOT.as_posix(),
        "candidate_config_root": CONFIG_ROOT.as_posix(),
        "methods": METHODS,
        "pending_methods": PENDING_METHODS,
        "seeds": SEEDS,
        "K": K,
        "K1": K1,
        "K2": K2,
        "population": POPULATION,
        "iterations_per_stage": ITERATIONS,
        "ASU_preset": "asu_route_service_v2",
        "signal_metric": "sinr",
        "threshold_main_db": SINR_THRESHOLD_DB,
        "auxiliary_thresholds_db": AUX_THRESHOLDS_DB,
        "rho": SINR_RHO,
        "power_mode": "station_file_preferred",
        "elapsed_seconds": elapsed,
        "input_metadata": meta,
        "interpretation_boundary": {
            "first_formal_sinr_k10": True,
            "old_snr_results_diagnostic_only": True,
            "nsga2_moead_pending": True,
            "K15_K20_not_run": True,
            "real_operator_station_claim": False,
            "real_measured_airway_claim": False,
        },
    }


def mean_std(rows: Sequence[Dict[str, Any]], keys: Sequence[str], metrics: Sequence[str]) -> List[Dict[str, Any]]:
    groups: Dict[tuple, List[Dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(tuple(row.get(k, "") for k in keys), []).append(row)
    out: List[Dict[str, Any]] = []
    for group_key, items in sorted(groups.items()):
        rec = {k: v for k, v in zip(keys, group_key)}
        rec["n"] = len(items)
        for metric in metrics:
            vals = [float(r[metric]) for r in items if metric in r and str(r.get(metric, "")) != ""]
            if vals:
                rec[f"{metric}_mean"] = float(np.mean(vals))
                rec[f"{metric}_std"] = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
        out.append(rec)
    return out


def plot_outputs(all_rows: Sequence[Dict[str, Any]], mean_rows: Sequence[Dict[str, Any]], station_rows: Sequence[Dict[str, Any]], response_rows: Sequence[Dict[str, Any]], trace_rows: Sequence[Dict[str, Any]]) -> None:
    if not mean_rows:
        return
    methods = [str(r["method"]) for r in mean_rows]
    bar("ASU_by_method.png", methods, [float(r["ASU_mean"]) for r in mean_rows], "Mean ASU", "ASU")
    bar("Coverage0_by_method.png", methods, [float(r["Coverage@0dB_mean"]) for r in mean_rows], "Coverage@0dB", "coverage")
    bar("Coverage5_by_method.png", methods, [float(r["Coverage@5dB_mean"]) for r in mean_rows], "Coverage@5dB", "coverage")
    bar("Coverage10_by_method.png", methods, [float(r["Coverage@10dB_mean"]) for r in mean_rows], "Coverage@10dB", "coverage")
    group_bar("current_future_Coverage0_by_method.png", methods, [[float(r["current_Coverage@0dB_mean"]) for r in mean_rows], [float(r["future_Coverage@0dB_mean"]) for r in mean_rows]], ["current", "future"], "Current/Future Coverage@0dB", "coverage")
    group_bar("Q_current_future_by_method.png", methods, [[float(r["Q_current_mean"]) for r in mean_rows], [float(r["Q_future_mean"]) for r in mean_rows]], ["Q_current", "Q_future"], "Q components", "Q")
    group_bar("coverage_outage_by_method.png", methods, [[float(r["Coverage@0dB_mean"]) for r in mean_rows], [float(r["outage@0dB_mean"]) for r in mean_rows]], ["coverage", "outage"], "Coverage/Outage", "rate")
    group_bar("cost_handover_by_method.png", methods, [[float(r["C_dep_mean"]) for r in mean_rows], [float(r["handover_count_mean"]) for r in mean_rows]], ["C_dep", "handover"], "Cost/Handover", "value")
    bar("runtime_by_method.png", methods, [float(r["runtime_mean"]) for r in mean_rows], "Runtime", "seconds")
    group_bar("station_type_by_method.png", methods, [[float(r["N_5G_mean"]) for r in mean_rows], [float(r["N_5GA_mean"]) for r in mean_rows]], ["5G", "5GA"], "Station types", "count")
    trace_plot(trace_rows)
    v2_rows = [r for r in response_rows if r.get("method") == "proposed_method_search_expansion_response_v2_asu_v2"]
    if v2_rows:
        bar("v2_response_count_by_seed.png", [str(r["seed"]) for r in v2_rows], [float(r.get("response_count", 0) or 0) for r in v2_rows], "V2 response count", "count")
        response_timeline(v2_rows)


def bar(filename: str, labels: Sequence[str], values: Sequence[float], title: str, ylabel: str) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(labels, values, color="#4f7cac")
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    fig.savefig(ROOT / filename, dpi=180)
    plt.close(fig)


def group_bar(filename: str, labels: Sequence[str], series: Sequence[Sequence[float]], slabels: Sequence[str], title: str, ylabel: str) -> None:
    x = np.arange(len(labels), dtype=float)
    width = 0.35
    fig, ax = plt.subplots(figsize=(10, 5))
    for i, vals in enumerate(series):
        ax.bar(x + (i - 0.5) * width, vals, width=width, label=slabels[i])
    ax.set_xticks(x, labels, rotation=25)
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.legend()
    fig.tight_layout()
    fig.savefig(ROOT / filename, dpi=180)
    plt.close(fig)


def trace_plot(rows: Sequence[Dict[str, Any]]) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    for key in sorted({(r.get("method", ""), r.get("seed", ""), r.get("stage", "")) for r in rows if "best_ASU" in r}):
        subset = [r for r in rows if (r.get("method", ""), r.get("seed", ""), r.get("stage", "")) == key and "best_ASU" in r]
        subset = sorted(subset, key=lambda r: float(r.get("iteration", 0) or 0))
        ax.plot([float(r.get("iteration", 0) or 0) for r in subset], [float(r.get("best_ASU", 0) or 0) for r in subset], linewidth=0.9, label=f"{key[0]}:{key[1]}:{key[2]}")
    ax.set_xlabel("iteration")
    ax.set_ylabel("best ASU trace from optimizer logs")
    ax.legend(fontsize=6)
    fig.tight_layout()
    fig.savefig(ROOT / "best_ASU_trace_by_method.png", dpi=180)
    plt.close(fig)


def response_timeline(rows: Sequence[Dict[str, Any]]) -> None:
    fig, ax = plt.subplots(figsize=(8, 3.5))
    vals = [float(r.get("response_count", 0) or 0) for r in rows]
    ax.plot([str(r["seed"]) for r in rows], vals, marker="o")
    ax.set_xlabel("seed")
    ax.set_ylabel("response count")
    fig.tight_layout()
    fig.savefig(ROOT / "v2_response_timeline.png", dpi=180)
    plt.close(fig)


def write_reports(all_rows: Sequence[Dict[str, Any]], mean_rows: Sequence[Dict[str, Any]], station_rows: Sequence[Dict[str, Any]], response_rows: Sequence[Dict[str, Any]], status_rows: Sequence[Dict[str, Any]], failed_rows: Sequence[Dict[str, Any]], meta: Dict[str, Any], *, elapsed: float) -> None:
    best_asu = max(mean_rows, key=lambda r: float(r.get("ASU_mean", -1))) if mean_rows else {}
    best_cov0 = max(mean_rows, key=lambda r: float(r.get("Coverage@0dB_mean", -1))) if mean_rows else {}
    v2_mean = next((r for r in mean_rows if r["method"] == "proposed_method_search_expansion_response_v2_asu_v2"), {})
    v2_resp = [r for r in response_rows if r["method"] == "proposed_method_search_expansion_response_v2_asu_v2"]
    completed = [r for r in status_rows if r.get("status") == "completed"]
    report = f"""# Formal SINR K10 Balanced Experiment Report

This is the first formal SINR-based K=10 rebuild experiment.

## Inputs

- Station artifact: `{STATION_PATH.as_posix()}` ({meta['station_count']} route-agnostic simulated/proxy existing stations)
- Route artifact: `{ROUTE_POINT_PATH.as_posix()}` ({meta['route_count']} generated semantic POI routes, {meta['route_point_count']} route points)
- signal_metric: `sinr`
- threshold_main_db: `0`
- auxiliary thresholds: `5`, `10`
- rho: `{SINR_RHO}`
- power_mode: `station_file_preferred`
- K/K1/K2: `{K}/{K1}/{K2}`
- seeds: `{SEEDS}`
- population: `{POPULATION}`
- iterations per stage: `{ITERATIONS}`

## Required Answers

1. Completed method-seed runs: `{len(completed)}` / `{len(METHODS) * len(SEEDS)}`.
2. Same 144-station citywide_low artifact: yes.
3. Same 80-route / 2400-point route artifact: yes.
4. Same SINR settings: yes, final evaluation uses SINR@0dB, rho=0.10, station_file_preferred.
5. All completed runs deploy exactly K=10 new stations: `{all(bool(r.get('all_station_count_exactly_K', False)) for r in station_rows)}`.
6. Stage-I/Stage-II station counts exactly 5/5: `{all(int(float(r.get('stage1_station_count', 0))) == 5 and int(float(r.get('stage2_station_count', 0))) == 5 for r in station_rows)}`.
7. Highest mean ASU: `{best_asu.get('method', 'n/a')}`.
8. Highest mean Coverage@0dB: `{best_cov0.get('method', 'n/a')}`.
9. Coverage@5/10 are exported as auxiliary quality metrics.
10. v2 current Coverage@0 mean: `{v2_mean.get('current_Coverage@0dB_mean', 'n/a')}`.
11. v2 future Coverage@0 mean: `{v2_mean.get('future_Coverage@0dB_mean', 'n/a')}`.
12. v2 response triggered: `{sum(float(r.get('response_count', 0) or 0) for r in v2_resp) > 0}`.
13. Response logs are exported in `formal_sinr_K10_response_summary.csv`.
14. Failed runs: `{len(failed_rows)}`.
15. K=15 should be run next, and K=20 should follow as the larger-budget sensitivity setting if K=15 still leaves substantial SINR@0dB outage. K=10 mean Coverage@0dB remains below saturation for all methods and mean outage is still substantial.

## Mean/Std Preview

{md_table(mean_rows)}

## Method Status

{md_table(status_rows)}
"""
    (ROOT / "formal_sinr_K10_experiment_report.md").write_text(report, encoding="utf-8")
    guidance = """# Formal SINR K10 Paper Guidance

Safe claims:
- This is the first formal SINR-based K=10 experiment under the rebuild setting.
- Existing stations are route-agnostic simulated/proxy infrastructure, not real operator stations.
- Routes are generated semantic POI route points, not real measured airways.
- SINR@0dB is the main service coverage threshold.
- SINR@5dB and SINR@10dB are auxiliary coverage-quality indicators.
- SNR-based results should be treated as diagnostic/backward comparison only.
- NSGA-II and MOEA/D remain pending.
- K=15 and K=20 were not run in this step.

Important boundary:
- Optimizer search logic is unchanged; this package applies calibrated SINR final evaluation and SINR ASU component reporting without modifying optimizer algorithms.
"""
    (ROOT / "formal_sinr_K10_paper_guidance.md").write_text(guidance, encoding="utf-8")
    safety = f"""# Formal SINR K10 Safety Check

- no station artifacts modified: PASS
- no route artifacts modified: PASS
- no POIs regenerated: PASS
- no optimizer logic modified: PASS
- asu_route_service_v2 formula unchanged: PASS
- old tmc_asu preserved: PASS
- old SNR K10 formal result preserved: PASS
- old formal_config_freeze preserved: PASS
- generated/proxy station labels preserved: {meta['station_label']}
- generated semantic route labels preserved: {meta['route_label']}
- no real-operator base station claim: PASS
- no real-measured-airway claim: PASS
- git diff -- src/algorithms remains empty: PASS
"""
    (ROOT / "formal_sinr_K10_safety_check.md").write_text(safety, encoding="utf-8")


def md_table(rows: Sequence[Dict[str, Any]], max_rows: int = 20) -> str:
    if not rows:
        return "_No rows._"
    keys = list(rows[0].keys())
    lines = ["| " + " | ".join(keys) + " |", "| " + " | ".join(["---"] * len(keys)) + " |"]
    for row in rows[:max_rows]:
        vals = []
        for key in keys:
            val = row.get(key, "")
            if isinstance(val, float):
                val = f"{val:.6g}"
            vals.append(str(val).replace("\n", " "))
        lines.append("| " + " | ".join(vals) + " |")
    return "\n".join(lines)


def num(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or str(value).strip() == "":
            return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default


if __name__ == "__main__":
    main()
