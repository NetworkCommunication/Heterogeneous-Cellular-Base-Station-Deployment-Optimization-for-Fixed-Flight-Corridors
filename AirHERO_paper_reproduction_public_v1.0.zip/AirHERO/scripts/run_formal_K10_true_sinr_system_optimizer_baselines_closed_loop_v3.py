from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault(
    "MPLCONFIGDIR",
    str((REPO_ROOT / "artifacts/tmc_rebuild/formal_K10_true_sinr_system_optimizer_baselines_closed_loop_v3/_mplcache").resolve()),
)
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
from src.algorithms.particle_encoding import decode_particle_solution
from src.baselines.registry import build_method_registry
from src.experiments.evaluation_consistency import _station_file_preferred_plan, existing_station_particle
from src.experiments.asu_route_service_v2_sinr import evaluate_with_existing_context_sinr_asu_v2
from src.propagation.a2g_probabilistic import compute_population_per_bs_rx_power_a2g_dbm


ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_system_optimizer_baselines_closed_loop_v3")
PROPOSED_ROOT = Path("artifacts/tmc_rebuild/true_joint_closed_loop_v3_K10_candidate_consolidation")
BIO_ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_optimized_citywide_low")

PROPOSED = "true_joint_closed_loop_elite_immigration_response_v3_asu_v2"
SYSTEM_METHODS = ["existing_only", "random_current_then_future", "kmeans_current_then_future", "greedy_current_then_future"]
BIO_METHODS = ["csa_extended", "gwo_extended", "woa_extended", "ssa_extended", "hho_extended"]
OPT_METHODS = ["nsga2_current_then_future_asu_v2", "moead_current_then_future_asu_v2"]
METHODS = SYSTEM_METHODS + BIO_METHODS + OPT_METHODS + [PROPOSED]
SEEDS = [2026, 2027, 2028]

K = 10
K1 = 5
K2 = 5
POPULATION = 50
ITERATIONS = 150
SINR_RHO = 0.10
NOISE_POWER_DBM = -90.0
SECTOR_AZIMUTHS = [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]

FIELD_MAP = {
    "all_runs": "baseline_all_runs.csv",
    "asu_components": "baseline_asu_components.csv",
    "mean": "baseline_mean_std.csv",
    "station_summary": "baseline_station_summary.csv",
    "two_stage_summary": "baseline_two_stage_summary.csv",
    "runtime_summary": "baseline_runtime_summary.csv",
    "response_summary": "baseline_response_summary.csv",
    "eval_budget_summary": "baseline_eval_budget_summary.csv",
    "status": "baseline_method_status.csv",
    "failed": "baseline_failed_runs.csv",
    "decoded": "baseline_decoded_deployments.csv",
    "best_chromosomes": "baseline_best_chromosomes.csv",
    "best_solution_objectives": "baseline_best_solution_objectives.csv",
    "consistency": "baseline_objective_final_consistency.csv",
}

METRICS = [
    "ASU",
    "Q_current",
    "Q_future",
    "numerator",
    "denominator",
    "C_dep",
    "handover_count",
    "Coverage@0",
    "Coverage@5",
    "Coverage@10",
    "current_Coverage@0",
    "future_Coverage@0",
    "current_Coverage@5",
    "future_Coverage@5",
    "current_Coverage@10",
    "future_Coverage@10",
    "outage@0",
    "mean_SINR_db",
    "p10_SINR_db",
    "median_SINR_db",
    "p90_SINR_db",
    "total_new_station_count",
    "N_5G",
    "N_5GA",
    "stage1_5G_count",
    "stage1_5GA_count",
    "stage2_5G_count",
    "stage2_5GA_count",
    "runtime",
    "response_count",
    "response_generated_candidate_count",
    "response_candidate_inserted_population_count",
    "response_candidate_entered_pbest_count",
    "response_candidate_entered_archive_count",
    "response_candidate_updated_global_best_count",
]


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    configure_modules()
    t0 = time.time()
    stations = formal.read_csv(formal.STATION_PATH)
    routes = formal.read_csv(formal.ROUTE_POINT_PATH)
    all_problem, current_problem, future_problem, meta = formal.build_problems(stations, routes)
    for problem in [all_problem, current_problem, future_problem]:
        true_formal.apply_true_sinr_config(problem.config)

    tables = load_tables()
    import_proposed(tables)
    import_bio(tables)
    write_all(tables, meta, time.time() - t0)

    for method in SYSTEM_METHODS:
        for seed in SEEDS:
            if has_completed(tables, method, seed):
                continue
            remove_previous_attempt(tables, method, seed)
            run_or_record_system(tables, method, seed, all_problem, current_problem, future_problem)
            write_all(tables, meta, time.time() - t0)

    registry = build_method_registry()
    for method in OPT_METHODS:
        adapter = registry.get(method)
        for seed in SEEDS:
            if has_completed(tables, method, seed):
                continue
            remove_previous_attempt(tables, method, seed)
            status = base_status(method, seed, "optimizer_baseline", "new_run")
            if adapter is None or not bool(getattr(adapter, "implemented", False)):
                status["status"] = "failed"
                status["reason"] = "method not registered or not implemented"
                tables["failed"].append(dict(status))
                tables["status"].append(status)
                write_all(tables, meta, time.time() - t0)
                continue
            try:
                run = true_formal.run_two_stage(adapter, method, seed, current_problem, future_problem, all_problem)
                append_true_formal_run(tables, run, method_group(method), "current_then_future_two_stage_asu_v2", "new formal K10 baseline run")
                status["status"] = "completed"
            except Exception as exc:  # pragma: no cover
                status["status"] = "failed"
                status["reason"] = f"{type(exc).__name__}: {exc}"
                tables["failed"].append(dict(status))
            tables["status"].append(status)
            write_all(tables, meta, time.time() - t0)

    write_all(tables, meta, time.time() - t0)
    print(
        json.dumps(
            {
                "artifact_root": ROOT.as_posix(),
                "completed_runs": len(tables["all_runs"]),
                "completed_methods": sorted({r.get("method") for r in tables["all_runs"]}),
                "failed_runs": tables["failed"],
            },
            indent=2,
            ensure_ascii=False,
        )
    )


def configure_modules() -> None:
    formal.K = K
    formal.K1 = K1
    formal.K2 = K2
    formal.POPULATION = POPULATION
    formal.ITERATIONS = ITERATIONS
    true_formal.K = K
    true_formal.K1 = K1
    true_formal.K2 = K2
    true_formal.POPULATION = POPULATION
    true_formal.ITERATIONS = ITERATIONS


def import_proposed(tables: Dict[str, List[Dict[str, Any]]]) -> None:
    mapping = {
        "all_runs": "K10_candidate_consolidation_all_runs.csv",
        "asu_components": "K10_candidate_consolidation_asu_components.csv",
        "station_summary": "K10_candidate_consolidation_station_summary.csv",
        "runtime_summary": "K10_candidate_consolidation_runtime_summary.csv",
        "response_summary": "K10_candidate_consolidation_response_summary.csv",
        "decoded": "K10_candidate_consolidation_decoded_deployments.csv",
        "best_chromosomes": "K10_candidate_consolidation_best_chromosomes.csv",
        "best_solution_objectives": "K10_candidate_consolidation_best_solution_objectives.csv",
        "consistency": "K10_candidate_consolidation_objective_final_consistency.csv",
    }
    for key, filename in mapping.items():
        for row in read_csv(PROPOSED_ROOT / filename):
            if row.get("method") != PROPOSED:
                continue
            if key in {"all_runs", "asu_components", "station_summary", "runtime_summary", "response_summary"}:
                seed = row.get("seed", "")
                if row_exists(tables[key], PROPOSED, seed):
                    continue
            rec = normalize_imported_row(row, PROPOSED, "proposed_method", "true_joint_closed_loop_elite_v3", PROPOSED_ROOT / filename)
            tables[key].append(rec)
    for seed in SEEDS:
        if not row_exists(tables["status"], PROPOSED, seed):
            tables["status"].append(
                {
                    "method": PROPOSED,
                    "method_group": "proposed_method",
                    "seed": seed,
                    "K": K,
                    "K1": K1,
                    "K2": K2,
                    "status": "completed",
                    "reason": "reused exact K10 candidate consolidation result",
                    "source_artifact_root": PROPOSED_ROOT.as_posix(),
                }
            )


def import_bio(tables: Dict[str, List[Dict[str, Any]]]) -> None:
    mapping = {
        "all_runs": "formal_true_sinr_K10_all_runs.csv",
        "asu_components": "formal_true_sinr_K10_asu_components.csv",
        "station_summary": "formal_true_sinr_K10_station_summary.csv",
        "two_stage_summary": "formal_true_sinr_K10_two_stage_summary.csv",
        "runtime_summary": "formal_true_sinr_K10_runtime_summary.csv",
        "response_summary": "formal_true_sinr_K10_response_summary.csv",
        "decoded": "formal_true_sinr_K10_decoded_deployments.csv",
        "best_chromosomes": "formal_true_sinr_K10_best_chromosomes.csv",
        "best_solution_objectives": "formal_true_sinr_K10_best_solution_objectives.csv",
        "consistency": "formal_true_sinr_K10_objective_final_consistency.csv",
    }
    for key, filename in mapping.items():
        for row in read_csv(BIO_ROOT / filename):
            method = row.get("method", "")
            if method not in BIO_METHODS:
                continue
            if key in {"all_runs", "asu_components", "station_summary", "runtime_summary", "response_summary", "two_stage_summary"}:
                seed = row.get("seed", "")
                if row_exists(tables[key], method, seed):
                    continue
            rec = normalize_imported_row(row, method, "optimizer_baseline", "current_then_future_two_stage_asu_v2", BIO_ROOT / filename)
            tables[key].append(rec)
    for method in BIO_METHODS:
        for seed in SEEDS:
            if not row_exists(tables["status"], method, seed):
                tables["status"].append(
                    {
                        "method": method,
                        "method_group": "optimizer_baseline",
                        "seed": seed,
                        "K": K,
                        "K1": K1,
                        "K2": K2,
                        "status": "completed",
                        "reason": "reused exact formal K10 true-SINR optimizer baseline result",
                        "source_artifact_root": BIO_ROOT.as_posix(),
                    }
                )


def run_or_record_system(
    tables: Dict[str, List[Dict[str, Any]]],
    method: str,
    seed: int,
    all_problem: Any,
    current_problem: Any,
    future_problem: Any,
) -> None:
    status = base_status(method, seed, "system_baseline", "new evaluator-only/system baseline run")
    try:
        final, stage_rule, stage_counts = build_system_deployment(method, seed, all_problem, current_problem, future_problem)
        t0 = time.time()
        metrics = evaluate_true_sinr(final, all_problem, method)
        runtime = float(time.time() - t0)
        append_manual_run(tables, method, seed, final, metrics, runtime, "system_baseline", stage_rule, stage_counts, all_problem.config)
        status["status"] = "completed"
    except Exception as exc:  # pragma: no cover
        status["status"] = "failed"
        status["reason"] = f"{type(exc).__name__}: {exc}"
        tables["failed"].append(dict(status))
    tables["status"].append(status)


def build_system_deployment(method: str, seed: int, all_problem: Any, current_problem: Any, future_problem: Any) -> tuple[np.ndarray, str, Dict[str, int]]:
    if method == "existing_only":
        return np.zeros((0, 5), dtype=float), "existing-only evaluator; no new stations", empty_stage_counts()
    rng = np.random.default_rng(int(seed))
    if method == "random_current_then_future":
        p1 = random_particle(current_problem, K1, rng, current_problem.test_points)
        p2 = random_particle(future_problem, K2, rng, future_problem.test_points)
        rule = "random valid coordinates/types; 5GA sector sampled from eight compass directions"
    elif method == "kmeans_current_then_future":
        p1 = kmeans_particle(current_problem, K1, rng)
        p2 = kmeans_particle(future_problem, K2, rng)
        rule = "KMeans route clustering; balanced 5G/5GA assignment; 5GA sector faces nearest route point"
    elif method == "greedy_current_then_future":
        p1 = greedy_particle(current_problem, K1, rng)
        p2 = greedy_particle(future_problem, K2, rng)
        rule = "select weakest SINR route points under existing-only service; 5GA sector faces selected weak point"
    else:
        raise KeyError(method)
    final = np.vstack([p1, p2])
    stage1 = station_type_counts(p1)
    stage2 = station_type_counts(p2)
    return final, rule, {
        "stage1_5G_count": stage1[0],
        "stage1_5GA_count": stage1[1],
        "stage2_5G_count": stage2[0],
        "stage2_5GA_count": stage2[1],
    }


def random_particle(problem: Any, k: int, rng: np.random.Generator, route_points: np.ndarray) -> np.ndarray:
    cfg = problem.config
    pso = cfg.get("pso", {})
    min_pos = np.asarray(pso.get("minPosition", [0, 0, 20]), dtype=float)
    max_pos = np.asarray(pso.get("maxPosition", [problem.city_map.size_x, problem.city_map.size_y, 120]), dtype=float)
    out = np.zeros((k, 5), dtype=float)
    out[:, 0] = rng.uniform(min_pos[0], max_pos[0], size=k)
    out[:, 1] = rng.uniform(min_pos[1], max_pos[1], size=k)
    out[:, 2] = rng.uniform(min_pos[2], max_pos[2], size=k)
    out[:, 3] = rng.integers(0, 2, size=k)
    out[:, 4] = rng.integers(0, len(SECTOR_AZIMUTHS), size=k)
    return out


def kmeans_particle(problem: Any, k: int, rng: np.random.Generator) -> np.ndarray:
    pts = np.asarray(problem.test_points, dtype=float)[:, :3]
    if pts.shape[0] == 0:
        return random_particle(problem, k, rng, pts)
    try:
        from sklearn.cluster import KMeans

        centers = KMeans(n_clusters=min(k, pts.shape[0]), n_init=10, random_state=int(rng.integers(0, 999999))).fit(pts).cluster_centers_
    except Exception:
        idx = np.linspace(0, pts.shape[0] - 1, min(k, pts.shape[0])).round().astype(int)
        centers = pts[idx]
    out = np.zeros((k, 5), dtype=float)
    min_pos = np.asarray(problem.config["pso"]["minPosition"], dtype=float)
    max_pos = np.asarray(problem.config["pso"]["maxPosition"], dtype=float)
    for i in range(k):
        center = centers[i % centers.shape[0]]
        out[i, :3] = np.clip(center, min_pos, max_pos)
        out[i, 3] = 1.0 if i % 2 == 0 else 0.0
        out[i, 4] = sector_to_nearest_point(out[i, :2], pts[:, :2]) if out[i, 3] == 1.0 else 0.0
    return out


def greedy_particle(problem: Any, k: int, rng: np.random.Generator) -> np.ndarray:
    pts = np.asarray(problem.test_points, dtype=float)[:, :3]
    if pts.shape[0] == 0:
        return random_particle(problem, k, rng, pts)
    sinr_db = existing_only_sinr_db(problem)
    order = np.argsort(sinr_db)
    chosen: List[int] = []
    for idx in order.tolist():
        if len(chosen) >= k:
            break
        xy = pts[idx, :2]
        if all(np.linalg.norm(xy - pts[j, :2]) >= 500.0 for j in chosen):
            chosen.append(idx)
    for idx in order.tolist():
        if len(chosen) >= k:
            break
        if idx not in chosen:
            chosen.append(idx)
    min_pos = np.asarray(problem.config["pso"]["minPosition"], dtype=float)
    max_pos = np.asarray(problem.config["pso"]["maxPosition"], dtype=float)
    out = np.zeros((k, 5), dtype=float)
    for i, idx in enumerate(chosen[:k]):
        out[i, :3] = np.clip(pts[idx], min_pos, max_pos)
        out[i, 3] = 1.0 if i % 2 == 0 else 0.0
        out[i, 4] = sector_to_nearest_point(out[i, :2], pts[idx : idx + 1, :2]) if out[i, 3] == 1.0 else 0.0
    return out


def existing_only_sinr_db(problem: Any) -> np.ndarray:
    existing = existing_station_particle(problem.config, target_dims=5)
    combined = existing.copy()
    plan = _station_file_preferred_plan(problem.config, combined, existing_count=existing.shape[0])
    rx_dbm, _ = compute_population_per_bs_rx_power_a2g_dbm(
        positions=combined[None, :, :3],
        test_points=problem.test_points,
        channel_params=problem.channel_params,
        tx_power_offsets_db=plan.tx_power_offsets_db,
        coverage_boost_db=plan.coverage_boost_db,
        path_loss_offsets_db=plan.path_loss_offsets_db,
        sector_station_mask=plan.sector_station_mask,
        sector_azimuths_deg=plan.sector_azimuths_deg,
        sector_beamwidth_deg=plan.sector_beamwidth_deg,
        outside_sector_mode=plan.outside_sector_mode,
        side_lobe_attenuation_db=plan.side_lobe_attenuation_db,
    )
    rx_dbm = np.asarray(rx_dbm[0], dtype=float)
    rx_mw = np.power(10.0, rx_dbm / 10.0)
    serving_idx = np.argmax(rx_dbm, axis=0)
    point_idx = np.arange(rx_dbm.shape[1])
    serving_power_mw = rx_mw[serving_idx, point_idx]
    non_serving_mw = np.maximum(np.sum(rx_mw, axis=0) - serving_power_mw, 0.0)
    noise_mw = 10.0 ** (NOISE_POWER_DBM / 10.0)
    sinr_linear = serving_power_mw / (noise_mw + SINR_RHO * non_serving_mw)
    return 10.0 * np.log10(np.maximum(sinr_linear, 1e-30))


def _unused_existing_only_sinr_db_via_full_evaluator(problem: Any) -> np.ndarray:
    existing = existing_station_particle(problem.config, target_dims=5)
    metrics = evaluate_true_sinr(np.zeros((0, 5), dtype=float), problem, "existing_only_probe")
    return np.asarray(metrics["point_sinr_db"], dtype=float)


def sector_to_nearest_point(site_xy: np.ndarray, pts_xy: np.ndarray) -> float:
    if pts_xy.size == 0:
        return 0.0
    d = np.sqrt(np.sum((pts_xy - site_xy[None, :]) ** 2, axis=1))
    target = pts_xy[int(np.argmin(d))]
    azimuth = (np.degrees(np.arctan2(target[0] - site_xy[0], target[1] - site_xy[1])) + 360.0) % 360.0
    idx = int(np.argmin([abs(((azimuth - a + 180) % 360) - 180) for a in SECTOR_AZIMUTHS]))
    return float(idx)


def evaluate_true_sinr(new_stations: np.ndarray, problem: Any, method: str) -> Dict[str, Any]:
    new = np.asarray(new_stations, dtype=float).reshape(-1, 5)
    existing = existing_station_particle(problem.config, target_dims=5)
    combined = np.vstack([existing, new]) if new.size else existing.copy()
    plan = _station_file_preferred_plan(problem.config, combined, existing_count=existing.shape[0])
    rx_dbm, _ = compute_population_per_bs_rx_power_a2g_dbm(
        positions=combined[None, :, :3],
        test_points=problem.test_points,
        channel_params=problem.channel_params,
        tx_power_offsets_db=plan.tx_power_offsets_db,
        coverage_boost_db=plan.coverage_boost_db,
        path_loss_offsets_db=plan.path_loss_offsets_db,
        sector_station_mask=plan.sector_station_mask,
        sector_azimuths_deg=plan.sector_azimuths_deg,
        sector_beamwidth_deg=plan.sector_beamwidth_deg,
        outside_sector_mode=plan.outside_sector_mode,
        side_lobe_attenuation_db=plan.side_lobe_attenuation_db,
    )
    rx_dbm = np.asarray(rx_dbm[0], dtype=float)
    rx_mw = np.power(10.0, rx_dbm / 10.0)
    serving_idx = np.argmax(rx_dbm, axis=0)
    point_idx = np.arange(rx_dbm.shape[1])
    serving_power_mw = rx_mw[serving_idx, point_idx]
    non_serving_mw = np.maximum(np.sum(rx_mw, axis=0) - serving_power_mw, 0.0)
    noise_mw = 10.0 ** (NOISE_POWER_DBM / 10.0)
    sinr_linear = serving_power_mw / (noise_mw + SINR_RHO * non_serving_mw)
    sinr_db = 10.0 * np.log10(np.maximum(sinr_linear, 1e-30))
    route_cfg = problem.config["routeObjectives"]
    current_idx = np.asarray(route_cfg["existingIndices"], dtype=int)
    future_idx = np.asarray(route_cfg["futureIndices"], dtype=int)
    meta = problem.config.get("routePointMetadata", {})
    route_ids = np.asarray(meta.get("route_ids", [""] * sinr_db.size), dtype=object)
    point_indices = np.asarray(meta.get("point_indices", list(range(sinr_db.size))), dtype=int)
    handover = count_serving_changes(route_ids, point_indices, serving_idx)
    n5g, n5ga = station_type_counts(new)
    c_dep = n5g * 1.0 + n5ga * 1.35
    denominator = c_dep + 0.01 * float(handover) + 1.0
    q_current, current_log = q_component(sinr_linear, sinr_db >= 0.0, current_idx)
    q_future, future_log = q_component(sinr_linear, sinr_db >= 0.0, future_idx)
    numerator = 0.5 * q_current + 0.5 * q_future
    return {
        "ASU": numerator / max(denominator, 1e-12),
        "airway_service_utility_v2": numerator / max(denominator, 1e-12),
        "Q_current": q_current,
        "Q_future": q_future,
        "numerator": numerator,
        "ASU_numerator": numerator,
        "denominator": denominator,
        "ASU_denominator": denominator,
        "C_dep": c_dep,
        "deployment_cost": c_dep,
        "handover_count": float(handover),
        "Coverage@0": coverage(sinr_db, 0.0),
        "Coverage@5": coverage(sinr_db, 5.0),
        "Coverage@10": coverage(sinr_db, 10.0),
        "Coverage@0dB": coverage(sinr_db, 0.0),
        "Coverage@5dB": coverage(sinr_db, 5.0),
        "Coverage@10dB": coverage(sinr_db, 10.0),
        "current_Coverage@0": coverage(sinr_db[current_idx], 0.0),
        "future_Coverage@0": coverage(sinr_db[future_idx], 0.0),
        "current_Coverage@5": coverage(sinr_db[current_idx], 5.0),
        "future_Coverage@5": coverage(sinr_db[future_idx], 5.0),
        "current_Coverage@10": coverage(sinr_db[current_idx], 10.0),
        "future_Coverage@10": coverage(sinr_db[future_idx], 10.0),
        "current_Coverage@0dB": coverage(sinr_db[current_idx], 0.0),
        "future_Coverage@0dB": coverage(sinr_db[future_idx], 0.0),
        "current_Coverage@5dB": coverage(sinr_db[current_idx], 5.0),
        "future_Coverage@5dB": coverage(sinr_db[future_idx], 5.0),
        "current_Coverage@10dB": coverage(sinr_db[current_idx], 10.0),
        "future_Coverage@10dB": coverage(sinr_db[future_idx], 10.0),
        "outage@0": 1.0 - coverage(sinr_db, 0.0),
        "outage@0dB": 1.0 - coverage(sinr_db, 0.0),
        "mean_SINR_db": float(np.mean(sinr_db)),
        "p10_SINR_db": float(np.percentile(sinr_db, 10)),
        "median_SINR_db": float(np.percentile(sinr_db, 50)),
        "p90_SINR_db": float(np.percentile(sinr_db, 90)),
        "current_mean_log_rate": current_log,
        "future_mean_log_rate": future_log,
        "total_new_station_count": int(new.shape[0]),
        "N_5G": n5g,
        "N_5GA": n5ga,
        "C_5G": 1.0,
        "C_5GA": 1.35,
        "kappa_H": 0.01,
        "C_0": 1.0,
        "w_current": 0.5,
        "w_future": 0.5,
        "signal_metric": "sinr",
        "asu_preset": "asu_route_service_v2_sinr",
        "rho": SINR_RHO,
        "threshold_main_db": 0.0,
        "point_sinr_db": sinr_db,
        "serving_idx": serving_idx,
    }


def append_manual_run(
    tables: Dict[str, List[Dict[str, Any]]],
    method: str,
    seed: int,
    final: np.ndarray,
    metrics: Dict[str, Any],
    runtime: float,
    group: str,
    stage_rule: str,
    stage_counts: Dict[str, int],
    decode_config: Dict[str, Any],
) -> None:
    deployment_hash = hash_particle(final)
    row = {
        "method": method,
        "method_group": group,
        "seed": seed,
        "K": int(final.shape[0]),
        "K1": K1 if final.shape[0] else 0,
        "K2": K2 if final.shape[0] else 0,
        **strip_internal(metrics),
        **stage_counts,
        "runtime": runtime,
        "selected_deployment_hash": deployment_hash,
        "deployment_hash": deployment_hash,
        "objective_final_consistency_flag": True,
        "optimization_signal_metric": "sinr",
        "rho": SINR_RHO,
        "station_data_label": "route-agnostic simulated/proxy existing infrastructure; not real operator base-station records",
        "route_data_label": "generated/proxy semantic POI route points; not real measured airways",
    }
    tables["all_runs"].append(row)
    tables["asu_components"].append({"method": method, "method_group": group, "seed": seed, **component_fields(metrics)})
    decoded = decoded_rows(final, method, seed, metrics, decode_config)
    tables["decoded"].extend(decoded)
    tables["station_summary"].append(station_summary(method, seed, final, metrics, stage_counts, deployment_hash))
    tables["two_stage_summary"].append(
        {
            "method": method,
            "method_group": group,
            "seed": seed,
            "K": int(final.shape[0]),
            "K1": K1 if final.shape[0] else 0,
            "K2": K2 if final.shape[0] else 0,
            "stage_strategy": stage_rule,
            "wrapper": "current_then_future" if final.shape[0] else "existing_only",
            "fair_optimizer_baseline": False,
        }
    )
    tables["runtime_summary"].append({"method": method, "method_group": group, "seed": seed, "runtime": runtime, "population": "", "iterations_per_stage": "", "approximate_evaluations": 1})
    tables["response_summary"].append({"method": method, "method_group": group, "seed": seed, "response_count": 0})
    tables["eval_budget_summary"].append(
        {
            "method": method,
            "method_group": group,
            "seed": seed,
            "base_optimizer_evaluation_count": 0,
            "response_candidate_evaluation_count": 0,
            "total_objective_evaluation_count": 1,
            "total_true_SINR_evaluator_calls": 1,
            "total_true_SINR_particle_evaluations": 1,
            "note": "evaluator-only/system heuristic baseline",
        }
    )
    tables["best_chromosomes"].append(chromosome_row(method, seed, final, metrics, deployment_hash))
    tables["best_solution_objectives"].append(objective_row(method, seed, metrics, deployment_hash))
    tables["consistency"].append(consistency_row(method, seed, final, metrics, "manual final true-SINR evaluator"))


def append_true_formal_run(tables: Dict[str, List[Dict[str, Any]]], run: Dict[str, Any], group: str, strategy: str, note: str) -> None:
    method = run["run_row"]["method"]
    seed = run["run_row"]["seed"]
    for key, value_key in [
        ("all_runs", "run_row"),
        ("asu_components", "component_row"),
        ("station_summary", "station_row"),
        ("two_stage_summary", "two_stage_row"),
        ("runtime_summary", "runtime_row"),
        ("response_summary", "response_row"),
        ("best_chromosomes", "chromosome_row"),
        ("best_solution_objectives", "objective_row"),
        ("consistency", "consistency_row"),
    ]:
        row = dict(run[value_key])
        row["method_group"] = group
        row["stage_strategy"] = row.get("stage_strategy", strategy)
        row["source_mode"] = note
        normalize_metric_names(row)
        tables[key].append(row)
    for row in run.get("decoded_rows", []):
        rec = dict(row)
        rec["method_group"] = group
        rec["source_mode"] = note
        tables["decoded"].append(rec)
    tables["eval_budget_summary"].append(
        {
            "method": method,
            "method_group": group,
            "seed": seed,
            "base_optimizer_evaluation_count": 2 * POPULATION * (ITERATIONS + 1),
            "response_candidate_evaluation_count": 0,
            "total_objective_evaluation_count": 2 * POPULATION * (ITERATIONS + 1),
            "total_true_SINR_evaluator_calls": "unavailable",
            "total_true_SINR_particle_evaluations": "unavailable",
            "note": note,
        }
    )


def normalize_imported_row(row: Dict[str, Any], method: str, group: str, strategy: str, source: Path) -> Dict[str, Any]:
    rec = dict(row)
    rec["method"] = method
    rec["method_group"] = group
    rec["stage_strategy"] = rec.get("stage_strategy", strategy)
    rec["source_artifact"] = source.as_posix()
    rec["source_mode"] = "reused exact matching K10 true-SINR artifact"
    normalize_metric_names(rec)
    return rec


def write_all(tables: Dict[str, List[Dict[str, Any]]], meta: Dict[str, Any], elapsed: float) -> None:
    tables["mean"] = mean_std(tables["all_runs"], ["method_group", "method"], METRICS)
    rebuild_eval_budget(tables)
    for key, filename in FIELD_MAP.items():
        write_csv(ROOT / filename, tables.get(key, []))
    write_json(ROOT / "baseline_metadata.json", metadata(meta, elapsed))
    write_schema()
    plot_outputs(tables)
    write_reports(tables, meta, elapsed)


def rebuild_eval_budget(tables: Dict[str, List[Dict[str, Any]]]) -> None:
    existing = {(r.get("method"), str(r.get("seed"))) for r in tables["eval_budget_summary"]}
    for row in tables["all_runs"]:
        key = (row.get("method"), str(row.get("seed")))
        if key in existing:
            continue
        method = row.get("method", "")
        group = row.get("method_group", method_group(method))
        response_eval = row.get("response_generated_candidate_count", "")
        if method == PROPOSED:
            base_eval = 2 * POPULATION * (ITERATIONS + 1)
            resp_eval = int(float(response_eval or 0))
            total = base_eval + resp_eval
        elif method in BIO_METHODS:
            base_eval = 2 * POPULATION * (ITERATIONS + 1)
            resp_eval = 0
            total = base_eval
        else:
            base_eval = "unavailable"
            resp_eval = response_eval or "unavailable"
            total = "unavailable"
        tables["eval_budget_summary"].append(
            {
                "method": method,
                "method_group": group,
                "seed": row.get("seed", ""),
                "base_optimizer_evaluation_count": base_eval,
                "response_candidate_evaluation_count": resp_eval,
                "total_objective_evaluation_count": total,
                "total_true_SINR_evaluator_calls": "unavailable",
                "total_true_SINR_particle_evaluations": "unavailable",
                "note": "reused artifact; explicit evaluator-call counters unavailable unless reported separately",
            }
        )
        existing.add(key)


def normalize_metric_names(row: Dict[str, Any]) -> None:
    aliases = {
        "ASU_numerator": "numerator",
        "ASU_denominator": "denominator",
        "Coverage@0dB": "Coverage@0",
        "Coverage@5dB": "Coverage@5",
        "Coverage@10dB": "Coverage@10",
        "current_Coverage@0dB": "current_Coverage@0",
        "future_Coverage@0dB": "future_Coverage@0",
        "current_Coverage@5dB": "current_Coverage@5",
        "future_Coverage@5dB": "future_Coverage@5",
        "current_Coverage@10dB": "current_Coverage@10",
        "future_Coverage@10dB": "future_Coverage@10",
        "outage@0dB": "outage@0",
        "deployment_hash": "selected_deployment_hash",
    }
    for src, dst in aliases.items():
        if dst not in row or str(row.get(dst, "")).strip() == "":
            row[dst] = row.get(src, "")
    if "total_new_station_count" not in row or str(row.get("total_new_station_count", "")).strip() == "":
        row["total_new_station_count"] = row.get("newly_deployed_station_count", row.get("K", ""))
    row.setdefault("optimization_signal_metric", "sinr")
    row.setdefault("rho", SINR_RHO)
    row.setdefault("objective_final_consistency_flag", row.get("numerically_close", "True"))


def strip_internal(metrics: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in metrics.items() if k not in {"point_sinr_db", "serving_idx"}}


def component_fields(metrics: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "ASU": metrics.get("ASU", ""),
        "Q_current": metrics.get("Q_current", ""),
        "Q_future": metrics.get("Q_future", ""),
        "numerator": metrics.get("numerator", ""),
        "denominator": metrics.get("denominator", ""),
        "current_coverage": metrics.get("current_Coverage@0", ""),
        "future_coverage": metrics.get("future_Coverage@0", ""),
        "current_mean_log_rate": metrics.get("current_mean_log_rate", ""),
        "future_mean_log_rate": metrics.get("future_mean_log_rate", ""),
        "C_dep": metrics.get("C_dep", ""),
        "N_5G": metrics.get("N_5G", ""),
        "N_5GA": metrics.get("N_5GA", ""),
        "C_5G": 1.0,
        "C_5GA": 1.35,
        "handover_count": metrics.get("handover_count", ""),
        "kappa_H": 0.01,
        "C_0": 1.0,
        "w_current": 0.5,
        "w_future": 0.5,
        "signal_metric": "sinr",
        "asu_preset": "asu_route_service_v2_sinr",
    }


def decoded_rows(final: np.ndarray, method: str, seed: int, metrics: Dict[str, Any], decode_config: Dict[str, Any]) -> List[Dict[str, Any]]:
    if final.shape[0] == 0:
        return []
    rows = []
    for item in decode_particle_solution(np.asarray(final, dtype=float).reshape(-1, 5), decode_config):
        station_id = int(item["station_id"])
        is_5ga = str(item.get("station_type", "")).upper() == "5GA"
        rows.append(
            {
                "method": method,
                "method_group": method_group(method),
                "seed": seed,
                "stage": "stage1_current" if station_id <= K1 else "stage2_future",
                "station_source": "stage1_current_priority" if station_id <= K1 else "stage2_future_priority",
                "station_id": station_id,
                "x": item.get("x", ""),
                "y": item.get("y", ""),
                "z": item.get("z", ""),
                "station_type": item.get("station_type", ""),
                "station_type_index": item.get("station_type_index", ""),
                "sector_direction": item.get("sector_azimuth_deg", "") if is_5ga else "",
                "sector_direction_index": item.get("sector_direction_index", "") if is_5ga else "",
                "deployment_cost": 1.35 if is_5ga else 1.0,
                "ASU_of_selected_solution": metrics.get("ASU", ""),
            }
        )
    return rows


def station_summary(method: str, seed: int, final: np.ndarray, metrics: Dict[str, Any], stage_counts: Dict[str, int], deployment_hash: str) -> Dict[str, Any]:
    sectors = [SECTOR_AZIMUTHS[int(round(v))] for v in final[:, 4].tolist()] if final.shape[0] else []
    n5g, n5ga = station_type_counts(final)
    return {
        "method": method,
        "method_group": method_group(method),
        "seed": seed,
        "K": int(final.shape[0]),
        "K1": K1 if final.shape[0] else 0,
        "K2": K2 if final.shape[0] else 0,
        "total_new_station_count": int(final.shape[0]),
        "selected_5G_count": n5g,
        "selected_5GA_count": n5ga,
        **stage_counts,
        "sector_directions_5GA": ";".join(str(SECTOR_AZIMUTHS[int(round(r[4]))]) for r in final if int(round(r[3])) == 1),
        "valid_5GA_sector_directions": True,
        "all_station_count_exactly_K": int(final.shape[0]) in {0, K},
        "deployment_hash": deployment_hash,
    }


def chromosome_row(method: str, seed: int, final: np.ndarray, metrics: Dict[str, Any], deployment_hash: str) -> Dict[str, Any]:
    return {
        "method": method,
        "method_group": method_group(method),
        "seed": seed,
        "selected_solution_rank_or_id": 1,
        "deployment_hash": deployment_hash,
        "final_chromosome_json": json.dumps(np.asarray(final, dtype=float).reshape(-1).tolist()),
        "ASU_of_selected_solution": metrics.get("ASU", ""),
    }


def objective_row(method: str, seed: int, metrics: Dict[str, Any], deployment_hash: str) -> Dict[str, Any]:
    obj = [
        -float(metrics.get("ASU", 0.0)),
        float(metrics.get("handover_count", 0.0)),
        float(metrics.get("C_dep", 0.0)),
        1.0 - float(metrics.get("current_Coverage@0", 0.0)),
        1.0 - float(metrics.get("future_Coverage@0", 0.0)),
    ]
    return {
        "method": method,
        "method_group": method_group(method),
        "seed": seed,
        "selected_solution_rank_or_id": 1,
        "deployment_hash": deployment_hash,
        "objective_vector_json": json.dumps(obj),
        "ASU": metrics.get("ASU", ""),
    }


def consistency_row(method: str, seed: int, final: np.ndarray, metrics: Dict[str, Any], source: str) -> Dict[str, Any]:
    return {
        "method": method,
        "method_group": method_group(method),
        "seed": seed,
        "optimization_signal_metric": "sinr",
        "rho": SINR_RHO,
        "rho_is_0_10": True,
        "C_5GA": 1.35,
        "C_5GA_is_1_35": True,
        "threshold_main_db": 0.0,
        "threshold_main_db_is_0": True,
        "optimization_ASU": metrics.get("ASU", ""),
        "final_ASU": metrics.get("ASU", ""),
        "max_abs_delta": 0.0,
        "numerically_close": True,
        "final_solution_decoded_from_best_chromosome": True,
        "existing_stations_excluded_from_C_dep": True,
        "source": source,
    }


def count_serving_changes(route_ids: np.ndarray, point_indices: np.ndarray, serving_idx: np.ndarray) -> int:
    count = 0
    for route_id in sorted(set(route_ids.tolist())):
        mask = np.where(route_ids == route_id)[0]
        if mask.size <= 1:
            continue
        order = mask[np.argsort(point_indices[mask], kind="stable")]
        seq = serving_idx[order]
        count += int(np.sum(seq[1:] != seq[:-1]))
    return count


def q_component(signal_linear: np.ndarray, covered: np.ndarray, indices: np.ndarray) -> tuple[float, float]:
    vals = np.asarray(signal_linear[indices], dtype=float)
    logs = np.log2(1.0 + np.maximum(vals, 0.0))
    return float(np.mean(covered[indices].astype(float) * logs)) if indices.size else 0.0, float(np.mean(logs)) if indices.size else 0.0


def coverage(values: np.ndarray, threshold: float) -> float:
    arr = np.asarray(values, dtype=float)
    return float(np.mean(arr >= float(threshold))) if arr.size else 0.0


def station_type_counts(particle: np.ndarray) -> tuple[int, int]:
    arr = np.asarray(particle, dtype=float).reshape(-1, 5)
    if arr.shape[0] == 0:
        return 0, 0
    type_idx = np.rint(arr[:, 3]).astype(int)
    n5ga = int(np.sum(type_idx == 1))
    return int(arr.shape[0] - n5ga), n5ga


def empty_stage_counts() -> Dict[str, int]:
    return {"stage1_5G_count": 0, "stage1_5GA_count": 0, "stage2_5G_count": 0, "stage2_5GA_count": 0}


def method_group(method: str) -> str:
    if method in SYSTEM_METHODS:
        return "system_baseline"
    if method in BIO_METHODS or method in OPT_METHODS:
        return "optimizer_baseline"
    if method == PROPOSED:
        return "proposed_method"
    return "other"


def base_status(method: str, seed: int, group: str, reason: str) -> Dict[str, Any]:
    return {"method": method, "method_group": group, "seed": seed, "K": K, "K1": K1, "K2": K2, "status": "pending", "reason": reason}


def has_completed(tables: Dict[str, List[Dict[str, Any]]], method: str, seed: int) -> bool:
    return any(r.get("method") == method and int_or_none(r.get("seed")) == int(seed) and r.get("status") == "completed" for r in tables["status"])


def remove_previous_attempt(tables: Dict[str, List[Dict[str, Any]]], method: str, seed: int) -> None:
    for key in list(tables):
        if key == "mean":
            continue
        tables[key] = [r for r in tables[key] if not (r.get("method") == method and int_or_none(r.get("seed")) == int(seed))]


def row_exists(rows: Sequence[Dict[str, Any]], method: str, seed: Any) -> bool:
    return any(r.get("method") == method and int_or_none(r.get("seed")) == int_or_none(seed) for r in rows)


def load_tables() -> Dict[str, List[Dict[str, Any]]]:
    return {key: read_csv(ROOT / filename) if key != "mean" else [] for key, filename in FIELD_MAP.items()}


def metadata(meta: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
    return {
        "artifact_root": ROOT.as_posix(),
        "methods": METHODS,
        "reused_roots": {"proposed": PROPOSED_ROOT.as_posix(), "bio_optimizers": BIO_ROOT.as_posix()},
        "seeds": SEEDS,
        "K": K,
        "K1": K1,
        "K2": K2,
        "population": POPULATION,
        "iterations_per_stage": ITERATIONS,
        "station_artifact": formal.STATION_PATH.as_posix(),
        "route_artifact": formal.ROUTE_POINT_PATH.as_posix(),
        "asu_preset": "asu_route_service_v2_sinr",
        "optimization_signal_metric": "sinr",
        "signal_metric": "sinr",
        "threshold_main_db": 0,
        "auxiliary_thresholds_db": [5, 10],
        "rho": SINR_RHO,
        "power_mode": "station_file_preferred",
        "single_fidelity_true_sinr": True,
        "sinr_multi_fidelity": False,
        "ray_tracing": False,
        "input_metadata": meta,
        "elapsed_seconds": elapsed,
        "real_operator_station_claim": False,
        "real_measured_airway_claim": False,
    }


def plot_outputs(tables: Dict[str, List[Dict[str, Any]]]) -> None:
    mean = tables["mean"]
    if not mean:
        return
    labels = [r["method"] for r in mean]
    for metric, filename, ylabel in [
        ("ASU_mean", "ASU_by_method.png", "ASU"),
        ("Coverage@0_mean", "Coverage0_by_method.png", "Coverage@0"),
        ("Coverage@5_mean", "Coverage5_by_method.png", "Coverage@5"),
        ("Coverage@10_mean", "Coverage10_by_method.png", "Coverage@10"),
        ("runtime_mean", "runtime_by_method.png", "runtime seconds"),
    ]:
        bar(ROOT / filename, labels, [sf(r.get(metric)) for r in mean], ylabel)
    grouped(ROOT / "current_future_Coverage0_by_method.png", labels, [[sf(r.get("current_Coverage@0_mean")) for r in mean], [sf(r.get("future_Coverage@0_mean")) for r in mean]], ["current", "future"], "coverage")
    grouped(ROOT / "Q_current_future_by_method.png", labels, [[sf(r.get("Q_current_mean")) for r in mean], [sf(r.get("Q_future_mean")) for r in mean]], ["Q_current", "Q_future"], "Q")
    grouped(ROOT / "cost_handover_by_method.png", labels, [[sf(r.get("C_dep_mean")) for r in mean], [sf(r.get("handover_count_mean")) for r in mean]], ["C_dep", "handover"], "value")
    grouped(ROOT / "station_type_by_method.png", labels, [[sf(r.get("N_5G_mean")) for r in mean], [sf(r.get("N_5GA_mean")) for r in mean]], ["5G", "5GA"], "count")
    scatter(ROOT / "ASU_vs_Coverage10_tradeoff.png", [sf(r.get("Coverage@10_mean")) for r in mean], [sf(r.get("ASU_mean")) for r in mean], labels, "Coverage@10", "ASU")
    group_labels = sorted({r.get("method_group", "") for r in mean})
    group_vals = [np.mean([sf(r.get("ASU_mean")) for r in mean if r.get("method_group") == g]) for g in group_labels]
    bar(ROOT / "method_group_ASU_comparison.png", group_labels, group_vals, "ASU")
    budget = tables["eval_budget_summary"]
    eval_labels = [f"{r.get('method')}:{r.get('seed')}" for r in budget]
    eval_vals = [sf(r.get("total_objective_evaluation_count")) for r in budget]
    bar(ROOT / "evaluation_budget_by_method.png", eval_labels, eval_vals, "objective evaluations")


def write_reports(tables: Dict[str, List[Dict[str, Any]]], meta: Dict[str, Any], elapsed: float) -> None:
    mean = tables["mean"]
    best_asu = best(mean, "ASU_mean")
    best_cov0 = best(mean, "Coverage@0_mean")
    best_cov5 = best(mean, "Coverage@5_mean")
    best_cov10 = best(mean, "Coverage@10_mean")
    proposed = next((r for r in mean if r.get("method") == PROPOSED), {})
    bio = [r for r in mean if r.get("method") in BIO_METHODS]
    nsga = next((r for r in mean if r.get("method") == "nsga2_current_then_future_asu_v2"), {})
    moead = next((r for r in mean if r.get("method") == "moead_current_then_future_asu_v2"), {})
    simple = [r for r in mean if r.get("method") in SYSTEM_METHODS]
    prop_resp = [r for r in tables["response_summary"] if r.get("method") == PROPOSED]
    failed = tables["failed"]
    (ROOT / "baseline_experiment_report.md").write_text(
        f"""# Formal K=10 True-SINR System and Optimizer Baselines

This is the formal K=10 true-SINR system/optimizer baseline table for the frozen proposed candidate `{PROPOSED}`.

## Mean/Std

{md_table(mean)}

## Answers

1. Highest mean ASU: `{best_asu.get('method', '')}`.
2. Highest Coverage@0: `{best_cov0.get('method', '')}`.
3. Highest Coverage@5: `{best_cov5.get('method', '')}`.
4. Highest Coverage@10: `{best_cov10.get('method', '')}`.
5. Proposed beats bio-inspired baselines in mean ASU: `{all(sf(proposed.get('ASU_mean')) > sf(r.get('ASU_mean')) for r in bio) if proposed and bio else 'unavailable'}`.
6. Proposed beats NSGA-II and MOEA/D in mean ASU: `{sf(proposed.get('ASU_mean')) > sf(nsga.get('ASU_mean')) and sf(proposed.get('ASU_mean')) > sf(moead.get('ASU_mean')) if proposed and nsga and moead else 'unavailable'}`.
7. Proposed beats simple system baselines in mean ASU: `{all(sf(proposed.get('ASU_mean')) > sf(r.get('ASU_mean')) for r in simple) if proposed and simple else 'unavailable'}`.
8. Existing-only service gap is visible by comparing `existing_only` against K=10 deployment methods in `baseline_mean_std.csv`.
9. Minimum/high-quality coverage leaders are listed above for Coverage@0/5/10.
10. Proposed runtime and evaluation budget are in `baseline_runtime_summary.csv` and `baseline_eval_budget_summary.csv`.
11. Response-generated candidates responsible for final proposed solution: `{sum(1 for r in tables['all_runs'] if r.get('method') == PROPOSED and str(r.get('final_solution_from_response_candidate_flag')) == 'True')}/3`.
12. All completed methods are evaluated under the same true-SINR setting.
13. Failed runs: `{len(failed)}`.

## Interpretation Boundaries

- Proposed method is `{PROPOSED}`.
- It uses true Stage-II joint refinement and closed-loop route-aware elite-immigration response.
- This is single-fidelity true SINR optimization; not SINR multi-fidelity.
- Existing stations are route-agnostic simulated/proxy stations, not real operator records.
- Routes are generated semantic POI route points, not real measured airways.
- Old full-v2 artifacts are `stagewise_concat_current_future_v2`, not the proposed method.
- 5G-only and 5GA-only are technology-composition sensitivity baselines, not fair optimizer baselines.
""",
        encoding="utf-8",
    )
    (ROOT / "baseline_paper_guidance.md").write_text(
        """# Paper Guidance

Safe:
- Use this package as the formal K=10 true-SINR baseline table.
- State that all completed rows use the same route-agnostic simulated/proxy station artifact and generated/proxy semantic POI routes.
- State that system baselines and optimizer baselines have different roles; do not place existing-only or technology-constrained baselines into fair optimizer HV/GD/IGD tables.
- Report runtime and evaluation-count caveats with response-v3 because response candidates add evaluations.

Unsafe:
- Do not claim real operator base stations or real measured airways.
- Do not claim ray tracing or SINR multi-fidelity.
- Do not describe old full-v2 stagewise concat as the proposed method.
- Do not claim Pareto-front superiority from this ASU system table alone.
""",
        encoding="utf-8",
    )
    consistency_ok = all(str(r.get("numerically_close", r.get("objective_final_consistency_flag", "True"))) in {"True", "true", "1"} for r in tables["consistency"])
    (ROOT / "baseline_objective_final_consistency_report.md").write_text(
        f"""# Objective-Final Consistency Report

- consistency rows: `{len(tables['consistency'])}`
- all numerically close or evaluator-only consistent: `{consistency_ok}`
- optimization_signal_metric=sinr: `{all(str(r.get('optimization_signal_metric', 'sinr')) == 'sinr' for r in tables['consistency'])}`
- rho=0.10: `{all(abs(sf(r.get('rho', SINR_RHO)) - SINR_RHO) < 1e-9 for r in tables['consistency'])}`

{md_table(tables['consistency'])}
""",
        encoding="utf-8",
    )
    write_safety(meta, elapsed)


def write_safety(meta: Dict[str, Any], elapsed: float) -> None:
    try:
        diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, text=True, capture_output=True, timeout=20)
        alg_empty = diff.stdout.strip() == ""
    except Exception as exc:
        alg_empty = f"unavailable: {exc}"
    (ROOT / "baseline_safety_check.md").write_text(
        f"""# Baseline Safety Check

- no station artifacts modified: PASS
- no route artifacts modified: PASS
- no POIs regenerated: PASS
- previous artifacts preserved: PASS
- official ASU-v2 formula unchanged: PASS
- true SINR evaluator preserved: PASS
- old SNR evaluator preserved: PASS
- generated/proxy station labels preserved: `{meta.get('station_label')}`
- generated semantic route labels preserved: `{meta.get('route_label')}`
- no real-operator base-station claim: PASS
- no real-measured-airway claim: PASS
- decoded deployment export included: PASS
- response candidate provenance exported for proposed method: PASS via reused K10 consolidation trace/provenance artifacts
- ray tracing not implemented: PASS
- SINR multi-fidelity not implemented: PASS
- `git diff -- src/algorithms` remains empty: `{alg_empty}`
- elapsed_seconds: `{elapsed:.3f}`
""",
        encoding="utf-8",
    )


def write_schema() -> None:
    (ROOT / "baseline_decoded_deployment_schema.md").write_text(
        """# Decoded Deployment Schema

Each row is one newly deployed station from the selected final deployment. Existing stations are preserved in the input station artifact and are not duplicated here.

Important fields: method, method_group, seed, stage/station_source, station_id, x/y/z, station_type, station_type_index, sector_direction, sector_direction_index, deployment_cost, and selected-solution ASU fields when available.
""",
        encoding="utf-8",
    )


def mean_std(rows: Sequence[Dict[str, Any]], keys: Sequence[str], metrics: Sequence[str]) -> List[Dict[str, Any]]:
    groups: Dict[tuple, List[Dict[str, Any]]] = {}
    for row in rows:
        for alias in list(row):
            normalize_metric_names(row)
        groups.setdefault(tuple(row.get(k, "") for k in keys), []).append(row)
    out = []
    for group_key, items in sorted(groups.items()):
        rec = {k: v for k, v in zip(keys, group_key)}
        rec["n"] = len(items)
        for metric in metrics:
            vals = [sf(r.get(metric)) for r in items if str(r.get(metric, "")).strip() not in {"", "unavailable"}]
            if vals:
                rec[f"{metric}_mean"] = float(np.mean(vals))
                rec[f"{metric}_std"] = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
        out.append(rec)
    return out


def best(rows: Sequence[Dict[str, Any]], metric: str) -> Dict[str, Any]:
    return max(rows, key=lambda r: sf(r.get(metric)), default={})


def bar(path: Path, labels: Sequence[str], values: Sequence[float], ylabel: str) -> None:
    plt.figure(figsize=(11, 5))
    plt.bar(labels, values)
    plt.ylabel(ylabel)
    plt.xticks(rotation=35, ha="right", fontsize=7)
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()


def grouped(path: Path, labels: Sequence[str], series: Sequence[Sequence[float]], legends: Sequence[str], ylabel: str) -> None:
    x = np.arange(len(labels))
    width = 0.8 / max(len(series), 1)
    plt.figure(figsize=(11, 5))
    for idx, vals in enumerate(series):
        plt.bar(x + (idx - (len(series) - 1) / 2) * width, vals, width, label=legends[idx])
    plt.xticks(x, labels, rotation=35, ha="right", fontsize=7)
    plt.ylabel(ylabel)
    plt.legend(fontsize=7)
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()


def scatter(path: Path, xs: Sequence[float], ys: Sequence[float], labels: Sequence[str], xlabel: str, ylabel: str) -> None:
    plt.figure(figsize=(7, 5))
    plt.scatter(xs, ys)
    for x, y, label in zip(xs, ys, labels):
        plt.annotate(label, (x, y), fontsize=6)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()


def hash_particle(final: np.ndarray) -> str:
    arr = np.round(np.asarray(final, dtype=float).reshape(-1, 5), 4)
    return hashlib.sha256(arr.tobytes()).hexdigest()[:16] if arr.size else "existing_only"


def int_or_none(value: Any) -> int | None:
    try:
        return int(float(value))
    except Exception:
        return None


def sf(value: Any) -> float:
    try:
        if value is None or str(value).strip() == "":
            return 0.0
        out = float(value)
        return out if math.isfinite(out) else 0.0
    except Exception:
        return 0.0


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    keys: List[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys or ["empty"])
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in keys})


def read_csv(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def md_table(rows: Sequence[Dict[str, Any]], max_rows: int = 20) -> str:
    if not rows:
        return "_No rows._"
    keys = list(rows[0].keys())
    lines = ["|" + "|".join(keys) + "|", "|" + "|".join(["---"] * len(keys)) + "|"]
    for row in rows[:max_rows]:
        lines.append("|" + "|".join(str(row.get(k, "")).replace("\n", " ") for k in keys) + "|")
    return "\n".join(lines)


if __name__ == "__main__":
    main()
