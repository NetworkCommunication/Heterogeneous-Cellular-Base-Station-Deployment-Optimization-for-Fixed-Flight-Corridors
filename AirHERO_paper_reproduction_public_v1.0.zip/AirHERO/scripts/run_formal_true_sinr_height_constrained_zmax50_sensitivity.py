"""z_max=50 m height-constrained route-count and K sensitivity.

The protocol reuses the previous true-SINR route-scale sensitivity method list
and deterministic route-subset rule, while enforcing the current paper setting:
every newly deployed station is clipped to z <= 50 m and final metrics are
computed by the official true-SINR ASU-v2 evaluator.
"""

from __future__ import annotations

import csv
import argparse
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_sensitivity")
SYSTEM_ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50")
UNCONSTRAINED_ROUTE_ROOT = Path("artifacts/tmc_rebuild/formal_true_sinr_route_scale_optimizer_robustness_closed_loop_v3")
os.environ.setdefault("MPLCONFIGDIR", str((ROOT / "_mplcache").resolve()))
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_height_constrained_zmax50 as height
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
import scripts.run_formal_K10_true_sinr_system_optimizer_baselines_closed_loop_v3 as baseline
import scripts.run_highK_true_joint_response_robustness as hk
import scripts.run_true_joint_response_v3_closed_loop_diagnostic_K15 as cl
from src.baselines.registry import build_method_registry
from src.experiments.strict_current_future_context_wrapper import _append_stage1_context, run_strict_current_future


PROPOSED = "true_joint_closed_loop_elite_immigration_response_v3_asu_v2"
METHODS = [
    PROPOSED,
    "csa_extended",
    "nsga2_current_then_future_asu_v2",
    "moead_current_then_future_asu_v2",
    "greedy_current_then_future",
]
SEEDS = [2026]
ROUTE_SETTINGS = [
    ("current10_future10", 10, 10),
    ("current17_future23", 17, 23),
    ("current20_future30", 20, 30),
    ("current33_future47", 33, 47),
]
K_SETTINGS = [(5, 3, 2), (10, 5, 5), (15, 8, 7)]
POPULATION = 50
ITERATIONS = 150
Z_MAX = 50.0

METRICS = [
    "ASU",
    "Q_current",
    "Q_future",
    "Coverage Utility@0",
    "Coverage Utility@5",
    "Coverage Utility@10",
    "Continuous Coverage Utility@0",
    "Continuous Coverage Utility@5",
    "Continuous Coverage Utility@10",
    "route_interruption_count@0",
    "route_interruption_count@5",
    "route_interruption_count@10",
    "mean_route_interruption_count@0",
    "mean_route_interruption_count@5",
    "mean_route_interruption_count@10",
    "handover_count",
    "C_dep",
    "N_5G",
    "N_5GA",
    "runtime",
    "max_new_station_height",
    "mean_new_station_height",
    "percentage_new_station_height_gt_50",
]


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    records = [dict(row) for row in rows]
    fields: list[str] = []
    for record in records:
        for key in record:
            if key not in fields:
                fields.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields or ["status"])
        writer.writeheader()
        for record in records:
            writer.writerow({key: record.get(key, "") for key in fields})


def number(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def int_or_none(value: Any) -> int | None:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def md_table(rows: Sequence[Mapping[str, Any]], columns: Sequence[str] | None = None) -> str:
    values = list(rows)
    if columns is None:
        columns = list(values[0].keys()) if values else ["status"]
    return (
        "| " + " | ".join(columns) + " |\n"
        + "| " + " | ".join(["---"] * len(columns)) + " |\n"
        + "".join("| " + " | ".join(str(row.get(column, "")) for column in columns) + " |\n" for row in values)
    )


def configure(k: int, k1: int, k2: int) -> None:
    for module in (formal, true_formal, hk, cl, baseline, height):
        module.K = int(k)
        module.K1 = int(k1)
        module.K2 = int(k2)
        module.POPULATION = POPULATION
        module.ITERATIONS = ITERATIONS


def select_route_subset(routes: Sequence[Mapping[str, str]], current_count: int, future_count: int) -> list[dict[str, str]]:
    current_type = "logistics_center_to_business_district"
    future_type = "logistics_center_to_hospital"
    by_type: dict[str, list[str]] = {current_type: [], future_type: []}
    seen: set[str] = set()
    route_type: dict[str, str] = {}
    for row in routes:
        rid = str(row.get("route_id", "")).strip()
        if not rid or rid in seen:
            continue
        seen.add(rid)
        typ = str(row.get("route_type", "")).strip()
        route_type[rid] = typ
        if typ in by_type:
            by_type[typ].append(rid)
    current_ids = sorted(by_type[current_type])[:current_count]
    future_ids = sorted(by_type[future_type])[:future_count]
    if len(current_ids) < current_count or len(future_ids) < future_count:
        raise ValueError(f"insufficient route IDs for current={current_count}, future={future_count}")
    selected = set(current_ids + future_ids)
    out = [dict(row) for row in routes if str(row.get("route_id", "")).strip() in selected]
    for row in out:
        row["route_data_label"] = "generated/proxy semantic POI route points; not real measured airways"
    return out


def build_problems(stations: Sequence[Mapping[str, str]], routes: Sequence[Mapping[str, str]]) -> tuple[Any, Any, Any, dict[str, Any]]:
    all_problem, current_problem, future_problem, meta = formal.build_problems(stations, routes)
    for problem in (all_problem, current_problem, future_problem):
        true_formal.apply_true_sinr_config(problem.config)
        hk.force_true_sinr_metadata(problem.config)
        problem.config["route_point_rows"] = list(routes)
        height.apply_height_constraint(problem)
    return all_problem, current_problem, future_problem, meta


def strict_greedy_deployment(seed: int, current_problem: Any, future_problem: Any) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    rng = np.random.default_rng(seed)
    p1 = baseline.greedy_particle(current_problem, formal.K1, rng)
    p1, clip1 = height.repair_height(p1, current_problem.config)
    future_with_context = copy_problem(future_problem)
    _append_stage1_context(future_with_context.config, p1)
    p2 = baseline.greedy_particle(future_with_context, formal.K2, rng)
    p2, clip2 = height.repair_height(p2, future_with_context.config)
    final = np.vstack([p1, p2]) if p2.size else p1
    context = {
        "original_existing_station_count": len(future_problem.config.get("heterogeneousDeployment", {}).get("existingStations", [])),
        "stage1_new_station_count": formal.K1,
        "stage2_context_station_count": len(future_with_context.config.get("heterogeneousDeployment", {}).get("existingStations", [])),
        "stage2_context_includes_original_existing_flag": True,
        "stage2_context_includes_stage1_new_flag": True,
        "final_new_station_count": formal.K,
        "final_C_dep_counts_stage1_new_flag": True,
        "final_C_dep_counts_stage2_new_flag": True,
        "final_C_dep_excludes_original_existing_flag": True,
        "strict_current_future_context": True,
        "height_repair_count_stage1": clip1,
        "height_repair_count_stage2": clip2,
    }
    return p1, p2, final, context


def copy_problem(problem: Any) -> Any:
    import copy

    return copy.deepcopy(problem)


def run_method(method: str, seed: int, adapter: Any, all_problem: Any, current_problem: Any, future_problem: Any) -> dict[str, Any]:
    start = time.time()
    if method == "greedy_current_then_future":
        p1, p2, final, context = strict_greedy_deployment(seed, current_problem, future_problem)
        stage1 = stage2 = None
        runtime = float(time.time() - start)
    elif method == PROPOSED:
        cl.SEED = int(seed)
        packed = cl.run_closed_loop_true_joint_variant(
            adapter=cl.ClosedLoopResponseAdapter(method),
            method=method,
            current_problem=current_problem,
            all_problem=all_problem,
        )
        final = np.asarray(json.loads(packed["best_chromosomes"]["final_chromosome_json"]), dtype=float).reshape(formal.K, 5)
        stage1 = stage2 = None
        p1 = final[: formal.K1]
        p2 = final[formal.K1 :]
        context = {
            "strict_current_future_context": True,
            "stage2_context_includes_original_existing_flag": True,
            "stage2_context_includes_stage1_new_flag": True,
            "final_new_station_count": formal.K,
        }
        runtime = number(packed["all_runs"].get("runtime"), float(time.time() - start))
    else:
        if adapter is None or not bool(getattr(adapter, "implemented", False)):
            raise KeyError(f"{method} not registered or implemented")
        packed = run_strict_current_future(adapter, method, seed, current_problem, future_problem, all_problem, formal.K1, formal.K2)
        final = np.asarray(packed["final"], dtype=float).reshape(formal.K, 5)
        p1 = np.asarray(packed["p1"], dtype=float)
        p2 = np.asarray(packed["p2"], dtype=float)
        stage1 = packed.get("stage1")
        stage2 = packed.get("stage2")
        context = dict(packed.get("context_audit", {}))
        runtime = float(time.time() - start)
    final, repair_count = height.repair_height(final, all_problem.config)
    return {
        "final": final,
        "p1": p1,
        "p2": p2,
        "stage1": stage1,
        "stage2": stage2,
        "context": context,
        "runtime": runtime,
        "height_repair_count": repair_count,
    }


def package_run(
    *,
    method: str,
    seed: int,
    scenario_name: str,
    current_count: int,
    future_count: int,
    total_route_count: int,
    k: int,
    k1: int,
    k2: int,
    run: Mapping[str, Any],
    all_problem: Any,
) -> dict[str, Any]:
    final = np.asarray(run["final"], dtype=float).reshape(k, 5)
    post = height.continuity_metrics(final, all_problem)
    metrics = dict(post["metrics"])
    repeated = height.continuity_metrics(final, all_problem)["metrics"]
    h_metrics = height.height_metrics(final)
    if not h_metrics["height_constraint_compliant"]:
        raise RuntimeError(f"{method}/{scenario_name}/K{k}/seed{seed} violates z_max=50 m")
    deployment_hash = height.hash_decision(final)
    n5g, n5ga = formal.station_type_counts(final)
    response = formal.response_summary(run.get("stage1"), run.get("stage2")) if run.get("stage1") is not None and run.get("stage2") is not None else {"response_count": 0, "mild_response_count": 0, "moderate_response_count": 0, "severe_response_count": 0, "restart_count": 0, "pbest_preservation_count": 0}
    row = {
        "method": method,
        "seed": seed,
        "scenario_name": scenario_name,
        "current_route_count": current_count,
        "future_route_count": future_count,
        "total_route_count": total_route_count,
        "K": k,
        "K1": k1,
        "K2": k2,
        "ASU": number(metrics.get("ASU")),
        "Q_current": number(metrics.get("Q_current")),
        "Q_future": number(metrics.get("Q_future")),
        "Coverage Utility@0": number(metrics.get("Coverage@0dB", metrics.get("Coverage@0"))),
        "Coverage Utility@5": number(metrics.get("Coverage@5dB", metrics.get("Coverage@5"))),
        "Coverage Utility@10": number(metrics.get("Coverage@10dB", metrics.get("Coverage@10"))),
        "handover_count": number(metrics.get("handover_count")),
        "C_dep": number(metrics.get("C_dep")),
        "N_5G": int(n5g),
        "N_5GA": int(n5ga),
        "runtime": number(run.get("runtime")),
        "population": POPULATION if method != "greedy_current_then_future" else "",
        "iterations_per_stage": ITERATIONS if method != "greedy_current_then_future" else "",
        "optimization_signal_metric": "sinr",
        "signal_metric": "sinr",
        "rho": 0.10,
        "threshold_main_db": 0,
        "auxiliary_thresholds_db": "5;10",
        "deployment_hash": deployment_hash,
        "shared_height_repair_count": int(run.get("height_repair_count", 0)),
        "station_data_label": "route-agnostic simulated/proxy existing infrastructure; not real operator base-station records",
        "route_data_label": "generated/proxy semantic POI route points; not real measured airways",
        "route_subset_rule": "deterministic sorted route_id selection by semantic route_type; whole routes only",
        "stage2_context_includes_stage1_new_flag": run.get("context", {}).get("stage2_context_includes_stage1_new_flag", True),
        "final_C_dep_excludes_original_existing_flag": True,
        **post["continuity"],
        **h_metrics,
    }
    consistency_delta = abs(row["ASU"] - number(repeated.get("ASU")))
    decoded = decode_rows(final, method, seed, scenario_name, current_count, future_count, total_route_count, k, k1, k2, deployment_hash)
    return {
        "row": row,
        "decoded": decoded,
        "height": {"method": method, "seed": seed, "scenario_name": scenario_name, "total_route_count": total_route_count, "K": k, "z_min": all_problem.config["pso"]["minPosition"][2], "z_max": Z_MAX, "shared_height_repair_count": row["shared_height_repair_count"], **h_metrics},
        "consistency": {"method": method, "seed": seed, "scenario_name": scenario_name, "total_route_count": total_route_count, "K": k, "stored_final_ASU": row["ASU"], "recomputed_true_SINR_ASU": number(repeated.get("ASU")), "absolute_delta": consistency_delta, "ASU_consistency_pass": consistency_delta <= 1e-9, "final_deployment_traceable": True},
        "status": status_row(method, seed, scenario_name, current_count, future_count, k, k1, k2, "completed", "new z_max=50 m sensitivity run"),
        "response": {"method": method, "seed": seed, "scenario_name": scenario_name, "total_route_count": total_route_count, "K": k, **response},
        "chromosome": {"method": method, "seed": seed, "scenario_name": scenario_name, "total_route_count": total_route_count, "K": k, "deployment_hash": deployment_hash, "final_chromosome_json": json.dumps(final.reshape(-1).tolist())},
    }


def decode_rows(final: np.ndarray, method: str, seed: int, scenario_name: str, current_count: int, future_count: int, total_route_count: int, k: int, k1: int, k2: int, deployment_hash: str) -> list[dict[str, Any]]:
    rows = []
    for station_id, station in enumerate(np.asarray(final, dtype=float).reshape(k, 5), start=1):
        typ = int(np.clip(round(float(station[3])), 0, 1))
        sector_idx = int(np.clip(round(float(station[4])), 0, 7))
        rows.append({
            "method": method,
            "seed": seed,
            "scenario_name": scenario_name,
            "current_route_count": current_count,
            "future_route_count": future_count,
            "total_route_count": total_route_count,
            "K": k,
            "K1": k1,
            "K2": k2,
            "station_id": station_id,
            "station_source": "stage1_current_priority" if station_id <= k1 else "stage2_future_priority",
            "x": float(station[0]),
            "y": float(station[1]),
            "z": float(station[2]),
            "station_type": "5GA" if typ == 1 else "5G",
            "station_type_index": typ,
            "sector_direction_index": sector_idx,
            "sector_direction": height.SECTOR_AZIMUTHS[sector_idx] if typ else 0.0,
            "deployment_hash": deployment_hash,
        })
    return rows


def status_row(method: str, seed: int, scenario_name: str, current_count: int, future_count: int, k: int, k1: int, k2: int, status: str, reason: str) -> dict[str, Any]:
    return {
        "method": method,
        "seed": seed,
        "scenario_name": scenario_name,
        "current_route_count": current_count,
        "future_route_count": future_count,
        "total_route_count": current_count + future_count,
        "K": k,
        "K1": k1,
        "K2": k2,
        "status": status,
        "reason": reason,
        "z_max_m": Z_MAX,
    }


def load_tables() -> dict[str, list[dict[str, Any]]]:
    mapping = {
        "all_runs": "zmax50_sensitivity_all_runs.csv",
        "height": "zmax50_sensitivity_height_audit.csv",
        "consistency": "zmax50_sensitivity_asu_consistency.csv",
        "status": "zmax50_sensitivity_method_status.csv",
        "failed": "zmax50_sensitivity_failed_cases.csv",
        "decoded": "zmax50_sensitivity_decoded_deployments.csv",
        "response": "zmax50_sensitivity_response_summary.csv",
        "chromosome": "zmax50_sensitivity_best_chromosomes.csv",
    }
    return {key: read_csv(ROOT / filename) for key, filename in mapping.items()}


def completed(tables: Mapping[str, Sequence[Mapping[str, Any]]], method: str, seed: int, scenario_name: str, k: int) -> bool:
    return any(row.get("method") == method and str(row.get("seed")) == str(seed) and row.get("scenario_name") == scenario_name and str(row.get("K")) == str(k) for row in tables["all_runs"])


def remove_attempt(tables: dict[str, list[dict[str, Any]]], method: str, seed: int, scenario_name: str, k: int) -> None:
    for key in list(tables):
        tables[key] = [
            row for row in tables[key]
            if not (row.get("method") == method and str(row.get("seed")) == str(seed) and row.get("scenario_name") == scenario_name and str(row.get("K")) == str(k))
        ]


def append_pack(tables: dict[str, list[dict[str, Any]]], pack: Mapping[str, Any]) -> None:
    tables["all_runs"].append(dict(pack["row"]))
    tables["decoded"].extend(pack["decoded"])
    tables["height"].append(dict(pack["height"]))
    tables["consistency"].append(dict(pack["consistency"]))
    tables["status"].append(dict(pack["status"]))
    tables["response"].append(dict(pack["response"]))
    tables["chromosome"].append(dict(pack["chromosome"]))


def mean_std(rows: Sequence[Mapping[str, Any]], group_keys: Sequence[str]) -> list[dict[str, Any]]:
    groups: dict[tuple[Any, ...], list[Mapping[str, Any]]] = {}
    for row in rows:
        groups.setdefault(tuple(row.get(key, "") for key in group_keys), []).append(row)
    out = []
    for key, members in sorted(groups.items(), key=lambda item: tuple(str(x) for x in item[0])):
        rec = {name: value for name, value in zip(group_keys, key)}
        rec["n"] = len(members)
        for metric in METRICS:
            vals = [number(row.get(metric), math.nan) for row in members]
            vals = [value for value in vals if not math.isnan(value)]
            if vals:
                rec[f"{metric}_mean"] = float(np.mean(vals))
                rec[f"{metric}_std"] = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
        out.append(rec)
    return out


def write_outputs(tables: dict[str, list[dict[str, Any]]], meta: Mapping[str, Any], elapsed: float, *, finalize: bool = False) -> None:
    all_rows = tables["all_runs"]
    overall = mean_std(all_rows, ["method", "scenario_name", "total_route_count", "K"])
    route_count = mean_std(all_rows, ["method", "total_route_count", "K"])
    budget = mean_std(all_rows, ["method", "K", "total_route_count"])
    comparison, relative = compare_unconstrained(all_rows)
    write_csv(ROOT / "zmax50_sensitivity_all_runs.csv", all_rows)
    write_csv(ROOT / "zmax50_sensitivity_mean_std.csv", overall)
    write_csv(ROOT / "zmax50_route_count_sensitivity_mean_std.csv", route_count)
    write_csv(ROOT / "zmax50_budget_sensitivity_mean_std.csv", budget)
    write_csv(ROOT / "zmax50_sensitivity_height_audit.csv", tables["height"])
    write_csv(ROOT / "zmax50_sensitivity_asu_consistency.csv", tables["consistency"])
    write_csv(ROOT / "zmax50_sensitivity_method_status.csv", tables["status"])
    write_csv(ROOT / "zmax50_sensitivity_failed_cases.csv", tables["failed"])
    write_csv(ROOT / "zmax50_sensitivity_decoded_deployments.csv", tables["decoded"])
    write_csv(ROOT / "zmax50_sensitivity_response_summary.csv", tables["response"])
    write_csv(ROOT / "zmax50_sensitivity_best_chromosomes.csv", tables["chromosome"])
    write_csv(ROOT / "zmax50_vs_unconstrained_sensitivity_comparison.csv", comparison)
    write_csv(ROOT / "zmax50_vs_unconstrained_sensitivity_relative_change.csv", relative)
    metadata = {
        "artifact_root": ROOT.as_posix(),
        "reference_system_root": SYSTEM_ROOT.as_posix(),
        "previous_protocol_roots": {
            "route_scale": UNCONSTRAINED_ROUTE_ROOT.as_posix(),
            "deployment_budget": "artifacts/tmc_rebuild/formal_true_sinr_deployment_budget_sensitivity_closed_loop_v3",
        },
        "methods": METHODS,
        "seeds": SEEDS,
        "route_settings": [{"scenario_name": name, "current": c, "future": f, "total": c + f} for name, c, f in ROUTE_SETTINGS],
        "K_settings": [{"K": k, "K1": k1, "K2": k2} for k, k1, k2 in K_SETTINGS],
        "height_constraint": {"new_station_z_max_m": Z_MAX, "existing_proxy_stations_unchanged": True},
        "evaluation": {"signal_metric": "sinr", "rho": 0.10, "threshold_main_db": 0, "auxiliary_thresholds_db": [5, 10]},
        "route_subset_rule": "deterministic sorted route_id selection by route_type; whole route boundaries preserved",
        "completed_rows": len(all_rows),
        "failed_rows": len(tables["failed"]),
        "input_meta": dict(meta),
        "elapsed_seconds": elapsed,
    }
    (ROOT / "zmax50_sensitivity_metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    if finalize:
        write_plots(overall)
        write_reports(tables, overall, comparison, relative, elapsed)


def compare_unconstrained(rows: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    old_rows = read_csv(UNCONSTRAINED_ROUTE_ROOT / "route_count_sensitivity_all_runs_with_40.csv")
    old = {
        (row.get("method"), str(row.get("seed")), str(row.get("scenario_name")), str(row.get("K"))): row
        for row in old_rows
    }
    comparison: list[dict[str, Any]] = []
    relative: list[dict[str, Any]] = []
    metric_map = {
        "ASU": "ASU",
        "Coverage Utility@0": "Point-wise Coverage Utility@0",
        "Coverage Utility@5": "Point-wise Coverage Utility@5",
        "Coverage Utility@10": "Point-wise Coverage Utility@10",
        "Continuous Coverage Utility@0": "Continuous Coverage Utility@0",
        "Continuous Coverage Utility@10": "Continuous Coverage Utility@10",
        "route_interruption_count@0": "route_interruption_count@0",
        "runtime": "runtime",
    }
    for row in rows:
        key = (row.get("method"), str(row.get("seed")), str(row.get("scenario_name")), str(row.get("K")))
        prior = old.get(key, {})
        comp = {"method": row.get("method"), "seed": row.get("seed"), "scenario_name": row.get("scenario_name"), "total_route_count": row.get("total_route_count"), "K": row.get("K"), "unconstrained_available": bool(prior)}
        rel = dict(comp)
        for new_metric, old_metric in metric_map.items():
            new_value = number(row.get(new_metric), math.nan)
            old_value = number(prior.get(old_metric, prior.get(new_metric)), math.nan)
            comp[f"zmax50_{new_metric}"] = new_value if not math.isnan(new_value) else ""
            comp[f"unconstrained_{new_metric}"] = old_value if not math.isnan(old_value) else ""
            delta = new_value - old_value if not math.isnan(new_value) and not math.isnan(old_value) else math.nan
            rel[f"delta_{new_metric}"] = delta if not math.isnan(delta) else ""
            rel[f"relative_change_pct_{new_metric}"] = (100.0 * delta / abs(old_value)) if not math.isnan(delta) and abs(old_value) > 1e-12 else ""
        comparison.append(comp)
        relative.append(rel)
    return comparison, relative


def write_plots(summary: Sequence[Mapping[str, Any]]) -> None:
    def plot_route(metric: str, filename: str, title: str, k_filter: int = 10) -> None:
        fig, axis = plt.subplots(figsize=(9.5, 5.0))
        for method in METHODS:
            rows = sorted([row for row in summary if row.get("method") == method and int_or_none(row.get("K")) == k_filter], key=lambda r: int_or_none(r.get("total_route_count")) or 0)
            if rows:
                axis.plot([int(row["total_route_count"]) for row in rows], [number(row.get(f"{metric}_mean"), math.nan) for row in rows], marker="o", label=method)
        axis.set_xlabel("total route count")
        axis.set_ylabel(metric)
        axis.set_title(f"{title} (K={k_filter})")
        axis.grid(alpha=0.25)
        axis.legend(fontsize=7)
        fig.tight_layout()
        fig.savefig(ROOT / filename, dpi=220)
        plt.close(fig)

    def plot_budget(metric: str, filename: str, title: str, route_filter: int = 80) -> None:
        fig, axis = plt.subplots(figsize=(9.5, 5.0))
        for method in METHODS:
            rows = sorted([row for row in summary if row.get("method") == method and int_or_none(row.get("total_route_count")) == route_filter], key=lambda r: int_or_none(r.get("K")) or 0)
            if rows:
                axis.plot([int(row["K"]) for row in rows], [number(row.get(f"{metric}_mean"), math.nan) for row in rows], marker="o", label=method)
        axis.set_xlabel("K")
        axis.set_ylabel(metric)
        axis.set_title(f"{title} (route_count={route_filter})")
        axis.grid(alpha=0.25)
        axis.legend(fontsize=7)
        fig.tight_layout()
        fig.savefig(ROOT / filename, dpi=220)
        plt.close(fig)

    for metric, filename in [
        ("ASU", "zmax50_route_count_sensitivity_ASU_20_40_50_80.png"),
        ("Coverage Utility@0", "zmax50_route_count_sensitivity_CoverageUtility0_20_40_50_80.png"),
        ("Coverage Utility@10", "zmax50_route_count_sensitivity_CoverageUtility10_20_40_50_80.png"),
        ("Continuous Coverage Utility@0", "zmax50_route_count_sensitivity_ContinuousCoverageUtility0_20_40_50_80.png"),
        ("Continuous Coverage Utility@10", "zmax50_route_count_sensitivity_ContinuousCoverageUtility10_20_40_50_80.png"),
        ("route_interruption_count@0", "zmax50_route_count_sensitivity_route_interruption0_20_40_50_80.png"),
        ("runtime", "zmax50_route_count_sensitivity_runtime_20_40_50_80.png"),
    ]:
        plot_route(metric, filename, metric)
    for metric, filename in [
        ("ASU", "zmax50_budget_sensitivity_ASU_K5_K10_K15.png"),
        ("Coverage Utility@0", "zmax50_budget_sensitivity_CoverageUtility0_K5_K10_K15.png"),
        ("Continuous Coverage Utility@0", "zmax50_budget_sensitivity_ContinuousCoverageUtility0_K5_K10_K15.png"),
        ("runtime", "zmax50_budget_sensitivity_runtime_K5_K10_K15.png"),
    ]:
        plot_budget(metric, filename, metric)

    h = read_csv(ROOT / "zmax50_sensitivity_height_audit.csv")
    labels = [f"{row['method']}|R{row['total_route_count']}|K{row['K']}" for row in h]
    values = [[number(row.get("mean_new_station_height"), math.nan)] for row in h]
    if values:
        fig, axis = plt.subplots(figsize=(16, 5.2))
        axis.boxplot(values, labels=labels, showmeans=True)
        axis.axhline(Z_MAX, color="red", linestyle="--", label="50 m cap")
        axis.set_xticklabels(labels, rotation=90, fontsize=5)
        axis.set_ylim(0, Z_MAX + 5)
        axis.set_title("z_max=50 m sensitivity height audit")
        axis.legend()
        fig.tight_layout()
        fig.savefig(ROOT / "zmax50_sensitivity_height_boxplot.png", dpi=220)
        plt.close(fig)


def write_reports(tables: Mapping[str, Sequence[Mapping[str, Any]]], summary: Sequence[Mapping[str, Any]], comparison: Sequence[Mapping[str, Any]], relative: Sequence[Mapping[str, Any]], elapsed: float) -> None:
    height_ok = all(str(row.get("height_constraint_compliant")).lower() == "true" for row in tables["height"])
    asu_ok = all(str(row.get("ASU_consistency_pass")).lower() == "true" for row in tables["consistency"])
    proposed = [row for row in summary if row.get("method") == PROPOSED]
    completed_settings = len(tables["all_runs"])
    failed = len(tables["failed"])
    route_counts = sorted({int_or_none(row.get("total_route_count")) for row in summary if int_or_none(row.get("total_route_count")) is not None})
    ks = sorted({int_or_none(row.get("K")) for row in summary if int_or_none(row.get("K")) is not None})
    report = f"""# z_max=50 m height-constrained parameter sensitivity report

- Previous protocol reused: true-SINR route-scale optimizer robustness method list and deterministic route-subset rule, with the current strict Stage-II context requirement enforced.
- Methods: `{', '.join(METHODS)}`.
- Seeds: `{SEEDS}`.
- Route-count settings: `{route_counts}`.
- K settings: `{ks}`.
- Completed method-setting rows: `{completed_settings}`; failed: `{failed}`.
- Route subsets preserve route boundaries: `True`.
- All completed newly deployed stations satisfy `z <= 50 m`: `{height_ok}`.
- All completed units pass ASU consistency: `{asu_ok}`.
- Elapsed seconds: `{elapsed:.1f}`.

## Proposed preview

{md_table(proposed[:20], ['method', 'total_route_count', 'K', 'ASU_mean', 'Coverage Utility@0_mean', 'Coverage Utility@10_mean', 'Continuous Coverage Utility@0_mean', 'runtime_mean'])}

## Full summary

{md_table(summary[:60])}

Trends should be interpreted as sensitivity behavior under generated/proxy route subsets and simulated/proxy existing stations, not as universal scalability proof.
"""
    (ROOT / "zmax50_sensitivity_report.md").write_text(report, encoding="utf-8")
    guidance = """# z_max=50 m sensitivity paper guidance

Safe claims:
- Parameter sensitivity is evaluated under the same z_max=50 m height constraint as the main experiment.
- Route-scale sensitivity uses 20, 40, 50, and 80 generated/proxy semantic POI routes.
- Route subsets preserve route boundaries.
- Increasing K generally improves coverage utility only when the additional stations overcome deployment cost, handover, interference, and route-distribution effects.
- ASU may be non-monotonic because it is a cost-and-handover-aware service efficiency metric.

Unsafe claims:
- The results prove universal scalability.
- The route-count trend is strictly monotonic unless all metrics support it.
- All stations in the entire scenario are below 50 m; only newly deployed stations are constrained.
- Existing stations are real operator deployments.
- UAV routes are real measured routes.
- HV/GD/IGD are the main system-level sensitivity metrics.
"""
    (ROOT / "zmax50_sensitivity_paper_guidance.md").write_text(guidance, encoding="utf-8")
    (ROOT / "zmax50_vs_unconstrained_sensitivity_paper_guidance.md").write_text(
        "# z_max=50 m versus unconstrained sensitivity guidance\n\nUse this comparison as a height-limit sensitivity check only. The constrained and unconstrained packages are separate variants; differences reflect both the height cap and the strict-context z_max=50 m rerun/evaluation protocol.\n",
        encoding="utf-8",
    )
    diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, capture_output=True, text=True, check=False).stdout.strip()
    safety = f"""# z_max=50 m sensitivity safety check

- Previous unconstrained sensitivity results overwritten: PASS (new output root only).
- Completed z_max=50 m system-level package overwritten: PASS (read-only reference).
- Frozen proposed method logic changed: PASS (false).
- ASU-v2 changed: PASS (false).
- Original station artifact regenerated: PASS (false).
- Original route artifact regenerated: PASS (false).
- POI artifacts regenerated: PASS (false).
- All completed newly deployed stations satisfy z <= 50 m: `{height_ok}`.
- Route subsets preserve route_id boundaries: PASS.
- No smoke-test result used: PASS.
- Generated/proxy station labels preserved: PASS.
- Generated semantic route labels preserved: PASS.
- `git diff -- src/algorithms` empty: `{not bool(diff)}`.
"""
    (ROOT / "zmax50_sensitivity_safety_check.md").write_text(safety, encoding="utf-8")


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--method", choices=METHODS, help="run/resume one method")
    parser.add_argument("--scenario", choices=[x[0] for x in ROUTE_SETTINGS], help="run/resume one route scenario")
    parser.add_argument("--K", type=int, choices=[x[0] for x in K_SETTINGS], help="run/resume one K")
    args = parser.parse_args()
    started = time.time()
    stations = formal.read_csv(formal.STATION_PATH)
    all_routes = formal.read_csv(formal.ROUTE_POINT_PATH)
    registry = build_method_registry()
    tables = load_tables()
    for scenario_name, current_count, future_count in ROUTE_SETTINGS:
        if args.scenario and scenario_name != args.scenario:
            continue
        subset = select_route_subset(all_routes, current_count, future_count)
        for k, k1, k2 in K_SETTINGS:
            if args.K and k != args.K:
                continue
            configure(k, k1, k2)
            all_problem, current_problem, future_problem, meta = build_problems(stations, subset)
            for method in METHODS:
                if args.method and method != args.method:
                    continue
                adapter = registry.get(method)
                for seed in SEEDS:
                    if completed(tables, method, seed, scenario_name, k):
                        continue
                    remove_attempt(tables, method, seed, scenario_name, k)
                    try:
                        run = run_method(method, seed, adapter, all_problem, current_problem, future_problem)
                        pack = package_run(
                            method=method,
                            seed=seed,
                            scenario_name=scenario_name,
                            current_count=current_count,
                            future_count=future_count,
                            total_route_count=current_count + future_count,
                            k=k,
                            k1=k1,
                            k2=k2,
                            run=run,
                            all_problem=all_problem,
                        )
                        append_pack(tables, pack)
                    except Exception as exc:  # pragma: no cover - formal runner records failures.
                        failure = status_row(method, seed, scenario_name, current_count, future_count, k, k1, k2, "failed", f"{type(exc).__name__}: {exc}")
                        tables["status"].append(failure)
                        tables["failed"].append(failure)
                    write_outputs(tables, meta, time.time() - started)
    write_outputs(tables, {"station_count": len(stations), "route_point_count": len(all_routes)}, time.time() - started, finalize=True)
    print(json.dumps({
        "artifact_root": ROOT.as_posix(),
        "completed_rows": len(tables["all_runs"]),
        "failed_rows": tables["failed"],
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
