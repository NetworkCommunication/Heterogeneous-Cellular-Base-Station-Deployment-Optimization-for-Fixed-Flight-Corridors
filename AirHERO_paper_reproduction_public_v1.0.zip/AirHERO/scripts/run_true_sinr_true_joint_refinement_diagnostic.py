from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault(
    "MPLCONFIGDIR",
    str((REPO_ROOT / "artifacts/tmc_rebuild/formal_K10_true_sinr_true_joint_refinement_diagnostic/_mplcache").resolve()),
)
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
import src.baselines.proposed_search_expansion_response_v2.adapter as v2_module
from src.algorithms.particle_encoding import decode_particle_solution
from src.baselines.registry import build_method_registry
from src.experiments.asu_route_service_v2_sinr import evaluate_with_existing_context_sinr_asu_v2


ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_true_joint_refinement_diagnostic")
STAGEWISE_ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_optimized_citywide_low")
FROZEN_ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_frozen_stage1_ablation")

STAGEWISE_SRC = "proposed_method_search_expansion_response_v2_asu_v2"
FROZEN_SRC = "v2_frozen_stage1_sequential_asu_v2"
STAGEWISE = "stagewise_concat_current_future_v2"
FROZEN = "frozen_stage1_sequential_asu_v2"
JOINT = "true_joint_refinement_v2_asu_v2"

SEEDS = [2026, 2027, 2028]
K = 10
K1 = 5
K2 = 5
POPULATION = 50
ITERATIONS = 150
SINR_RHO = 0.10
SECTOR_AZIMUTHS = [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]

METRICS = [
    "ASU",
    "Q_current",
    "Q_future",
    "ASU_numerator",
    "ASU_denominator",
    "denominator",
    "C_dep",
    "handover_count",
    "Coverage@0dB",
    "Coverage@5dB",
    "Coverage@10dB",
    "current_Coverage@0dB",
    "future_Coverage@0dB",
    "current_Coverage@5dB",
    "future_Coverage@5dB",
    "current_Coverage@10dB",
    "future_Coverage@10dB",
    "outage@0dB",
    "mean_SINR_db",
    "N_5G",
    "N_5GA",
    "runtime",
    "response_count",
]


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    configure()
    t0 = time.time()

    stations = formal.read_csv(formal.STATION_PATH)
    routes = formal.read_csv(formal.ROUTE_POINT_PATH)
    all_problem, current_problem, future_problem, meta = formal.build_problems(stations, routes)
    for problem in [all_problem, current_problem, future_problem]:
        true_formal.apply_true_sinr_config(problem.config)

    registry = build_method_registry()
    adapter = registry[STAGEWISE_SRC]

    if (ROOT / "joint_refinement_diagnostic_all_runs.csv").exists():
        all_rows = read_csv(ROOT / "joint_refinement_diagnostic_all_runs.csv")
        comp_rows = read_csv(ROOT / "joint_refinement_diagnostic_asu_components.csv")
        station_rows = read_csv(ROOT / "joint_refinement_diagnostic_station_summary.csv")
        runtime_rows = read_csv(ROOT / "joint_refinement_diagnostic_runtime_summary.csv")
        response_rows = read_csv(ROOT / "joint_refinement_diagnostic_response_summary.csv")
        status_rows = read_csv(ROOT / "joint_refinement_diagnostic_method_status.csv")
        failed_rows = read_csv(ROOT / "joint_refinement_diagnostic_failed_runs.csv")
        decoded_rows = read_csv(ROOT / "joint_refinement_diagnostic_decoded_deployments.csv")
        stage1_rows = read_csv(ROOT / "joint_refinement_diagnostic_stage1_seed_deployments.csv")
        chrom_rows = read_csv(ROOT / "joint_refinement_diagnostic_best_chromosomes.csv")
        objective_rows = read_csv(ROOT / "joint_refinement_diagnostic_best_solution_objectives.csv")
        verification_rows = read_csv(ROOT / "true_joint_refinement_verification_by_seed.csv")
    else:
        all_rows: List[Dict[str, Any]] = []
        comp_rows: List[Dict[str, Any]] = []
        station_rows: List[Dict[str, Any]] = []
        runtime_rows: List[Dict[str, Any]] = []
        response_rows: List[Dict[str, Any]] = []
        status_rows: List[Dict[str, Any]] = []
        failed_rows: List[Dict[str, Any]] = []
        decoded_rows: List[Dict[str, Any]] = []
        stage1_rows: List[Dict[str, Any]] = []
        chrom_rows: List[Dict[str, Any]] = []
        objective_rows: List[Dict[str, Any]] = []
        verification_rows: List[Dict[str, Any]] = []
        import_reused_rows(all_rows, comp_rows, station_rows, runtime_rows, response_rows, status_rows, decoded_rows, chrom_rows, objective_rows)

    for seed in SEEDS:
        if any(r.get("method") == JOINT and str(r.get("seed")) == str(seed) for r in all_rows):
            continue
        status = {
            "method": JOINT,
            "seed": seed,
            "stage_strategy": "true K=10 Stage-II joint refinement",
            "registered": False,
            "implemented_by": "additive diagnostic runner with runtime Stage-II initialization hook",
            "status": "pending",
            "reason": "",
        }
        try:
            run = run_true_joint(adapter, int(seed), current_problem, all_problem)
            all_rows.append(run["run_row"])
            comp_rows.append(run["component_row"])
            station_rows.append(run["station_row"])
            runtime_rows.append(run["runtime_row"])
            response_rows.append(run["response_row"])
            decoded_rows.extend(run["decoded_rows"])
            stage1_rows.extend(run["stage1_rows"])
            chrom_rows.append(run["chromosome_row"])
            objective_rows.append(run["objective_row"])
            verification_rows.append(run["verification_row"])
            status["status"] = "completed"
        except Exception as exc:  # pragma: no cover - diagnostic runner records failures.
            status["status"] = "failed"
            status["reason"] = f"{type(exc).__name__}: {exc}"
            failed_rows.append(dict(status))
        status_rows.append(status)
        write_all(all_rows, comp_rows, station_rows, runtime_rows, response_rows, status_rows, failed_rows, decoded_rows, stage1_rows, chrom_rows, objective_rows, verification_rows, meta, time.time() - t0)

    mean_rows = mean_std(all_rows, ["method", "stage_strategy"], METRICS)
    write_csv(ROOT / "joint_refinement_diagnostic_mean_std.csv", mean_rows)
    plot_outputs(mean_rows)
    write_reports(all_rows, mean_rows, status_rows, failed_rows, verification_rows, meta, time.time() - t0)
    write_all(all_rows, comp_rows, station_rows, runtime_rows, response_rows, status_rows, failed_rows, decoded_rows, stage1_rows, chrom_rows, objective_rows, verification_rows, meta, time.time() - t0)
    print(json.dumps({"artifact_root": ROOT.as_posix(), "completed_runs": len([r for r in status_rows if r.get("status") == "completed"]), "failed_runs": len(failed_rows)}, indent=2))


def configure() -> None:
    formal.K = K
    formal.K1 = K1
    formal.K2 = K2
    formal.POPULATION = POPULATION
    formal.ITERATIONS = ITERATIONS
    true_formal.K = K
    true_formal.K1 = K1
    true_formal.K2 = K2
    true_formal.POPULATION = POPULATION
    true_formal.ITERATIONS = ITERATIONS


def run_true_joint(adapter: Any, seed: int, current_problem: Any, all_problem: Any) -> Dict[str, Any]:
    t0 = time.time()
    s1_cfg = formal.stage_config(current_problem.config, K1, stage="current")
    true_formal.apply_true_sinr_config(s1_cfg)
    stage1 = adapter.run(current_problem, seed=seed, config=s1_cfg)
    stage1_best = formal.best_decision(stage1, K1)

    s2_cfg = formal.stage_config(all_problem.config, K, stage="true_joint_refinement_all_routes")
    true_formal.apply_true_sinr_config(s2_cfg)
    original_init = v2_module._initialize_population
    init_records: List[Dict[str, Any]] = []

    def seeded_init(problem: Any, cfg: Dict[str, Any], rng: np.random.Generator, pop_size: int, k: int, min_pos: np.ndarray, max_pos: np.ndarray):
        particles, summary = original_init(problem, cfg, rng, pop_size, k, min_pos, max_pos)
        s1 = np.asarray(stage1_best, dtype=float).reshape(K1, 5)
        for p in range(pop_size):
            particles[p, :K1, :] = s1
            if p > 0:
                particles[p, :K1, :3] += rng.normal(0.0, 45.0, size=(K1, 3))
        particles = v2_module._repair_particles(particles, problem, cfg, rng, min_pos, max_pos)
        exact = int(np.sum(np.all(np.isclose(particles[:, :K1, :], s1[None, :, :], atol=1e-9), axis=(1, 2))))
        init_records.append(
            {
                "stage2_population": int(pop_size),
                "stage2_k": int(k),
                "stage1_seed_station_count_per_particle": int(K1),
                "additional_station_count_per_particle": int(k - K1),
                "exact_stage1_seed_particle_count": int(exact),
                "stage1_seeded_initialization": True,
                "all_K10_blocks_optimizable_after_initialization": True,
            }
        )
        return particles, list(summary) + init_records[-1:]

    try:
        v2_module._initialize_population = seeded_init  # type: ignore[assignment]
        stage2 = adapter.run(all_problem, seed=seed + 1009, config=s2_cfg)
    finally:
        v2_module._initialize_population = original_init  # type: ignore[assignment]

    final = formal.best_decision(stage2, K)
    runtime = float(time.time() - t0)
    eval_pack = evaluate_with_existing_context_sinr_asu_v2(
        decisions=final.reshape(1, K, 5),
        problem=all_problem,
        config=all_problem.config,
        method_name=JOINT,
    )
    row = dict(eval_pack.metrics[0])
    response = response_summary(stage1, stage2)
    stage1_counts = formal.station_type_counts(stage1_best)
    final_stage1_counts = formal.station_type_counts(final[:K1])
    final_stage2_counts = formal.station_type_counts(final[K1:])
    deployment_hash = hash_particle(final)
    modified = not np.allclose(final[:K1], stage1_best, atol=1e-8, rtol=0.0)
    consistency = consistency_row(final, all_problem, row)
    run_row = {
        "method": JOINT,
        "source_method": STAGEWISE_SRC,
        "seed": seed,
        "stage_strategy": "true_joint_refinement",
        **row,
        "numerator": row.get("ASU_numerator", ""),
        "denominator": row.get("ASU_denominator", row.get("denominator", "")),
        "Coverage@0": row.get("Coverage@0dB", ""),
        "Coverage@5": row.get("Coverage@5dB", ""),
        "Coverage@10": row.get("Coverage@10dB", ""),
        "runtime": runtime,
        "K": K,
        "K1": K1,
        "K2": K2,
        "population": POPULATION,
        "iterations_per_stage": ITERATIONS,
        "stage1_5G_count": stage1_counts[0],
        "stage1_5GA_count": stage1_counts[1],
        "stage2_5G_count": final_stage2_counts[0],
        "stage2_5GA_count": final_stage2_counts[1],
        "stage1_modified_in_stage2_flag": bool(modified),
        "optimization_signal_metric": "sinr",
        "signal_metric": "sinr",
        "rho": row.get("rho", SINR_RHO),
        "objective_final_consistency_flag": bool(consistency["numerically_close"]),
        "selected_deployment_hash": deployment_hash,
        "deployment_hash": deployment_hash,
        "station_data_label": "route-agnostic simulated/proxy existing infrastructure; not real operator base-station records",
        "route_data_label": "generated/proxy semantic POI route points; not real measured airways",
        **response,
    }
    decoded = decoded_rows(final, all_problem.config, JOINT, seed, row, deployment_hash, stage1_best)
    return {
        "run_row": run_row,
        "component_row": {"method": JOINT, "seed": seed, "stage_strategy": "true_joint_refinement", **component_fields(row)},
        "station_row": station_summary(JOINT, seed, decoded, row, stage1_counts, final_stage1_counts, final_stage2_counts, deployment_hash, modified),
        "runtime_row": {
            "method": JOINT,
            "seed": seed,
            "stage_strategy": "true_joint_refinement",
            "runtime": runtime,
            "stage1_runtime_seconds": stage1.runtime_seconds,
            "stage2_runtime_seconds": stage2.runtime_seconds,
            "population": POPULATION,
            "iterations_per_stage": ITERATIONS,
            "approximate_evaluations": 2 * POPULATION * (ITERATIONS + 1),
        },
        "response_row": {"method": JOINT, "seed": seed, "stage_strategy": "true_joint_refinement", **response},
        "decoded_rows": decoded,
        "stage1_rows": stage1_seed_rows(stage1_best, all_problem.config, seed, row, deployment_hash),
        "chromosome_row": {
            "method": JOINT,
            "seed": seed,
            "stage_strategy": "true_joint_refinement",
            "deployment_hash": deployment_hash,
            "stage1_seed_chromosome_json": json.dumps(stage1_best.reshape(-1).tolist()),
            "stage2_joint_chromosome_json": json.dumps(final.reshape(-1).tolist()),
            "final_chromosome_json": json.dumps(final.reshape(-1).tolist()),
            "ASU_of_selected_solution": row.get("ASU", ""),
        },
        "objective_row": objective_row(JOINT, seed, row, eval_pack, deployment_hash),
        "verification_row": {
            "method": JOINT,
            "seed": seed,
            "stage2_chromosome_station_count": int(final.shape[0]),
            "stage2_chromosome_length_values": int(final.size),
            "stage2_chromosome_represents_K10": bool(final.shape == (K, 5)),
            "stage2_initialization_includes_stage1_derived": bool(init_records and init_records[-1]["stage1_seeded_initialization"]),
            "exact_stage1_seed_particle_count": init_records[-1].get("exact_stage1_seed_particle_count", "") if init_records else "",
            "mutation_repair_can_modify_all_K10": True,
            "stage1_derived_stations_not_frozen": True,
            "stage1_modified_in_stage2_flag": bool(modified),
            "final_selected_from_stage2_K10_chromosome": True,
            "final_ASU_current_future_routes": True,
            "optimization_final_ASU_match": bool(consistency["numerically_close"]),
            "max_abs_objective_final_delta": consistency["max_abs_delta"],
            "rho": row.get("rho", ""),
            "rho_is_0_10": abs(float(row.get("rho", 0.0)) - SINR_RHO) < 1e-12,
            "optimization_signal_metric": "sinr",
        },
    }


def import_reused_rows(
    all_rows: List[Dict[str, Any]],
    comp_rows: List[Dict[str, Any]],
    station_rows: List[Dict[str, Any]],
    runtime_rows: List[Dict[str, Any]],
    response_rows: List[Dict[str, Any]],
    status_rows: List[Dict[str, Any]],
    decoded_rows: List[Dict[str, Any]],
    chrom_rows: List[Dict[str, Any]],
    objective_rows: List[Dict[str, Any]],
) -> None:
    import_method(
        root=STAGEWISE_ROOT,
        prefix="formal_true_sinr_K10",
        src_method=STAGEWISE_SRC,
        dst_method=STAGEWISE,
        strategy="stagewise_concat_current_future",
        all_rows=all_rows,
        comp_rows=comp_rows,
        station_rows=station_rows,
        runtime_rows=runtime_rows,
        response_rows=response_rows,
        status_rows=status_rows,
        decoded_rows=decoded_rows,
        chrom_rows=chrom_rows,
        objective_rows=objective_rows,
    )
    import_method(
        root=FROZEN_ROOT,
        prefix="frozen_stage1_ablation",
        src_method=FROZEN_SRC,
        dst_method=FROZEN,
        strategy="frozen_stage1_sequential",
        all_rows=all_rows,
        comp_rows=comp_rows,
        station_rows=station_rows,
        runtime_rows=runtime_rows,
        response_rows=response_rows,
        status_rows=status_rows,
        decoded_rows=decoded_rows,
        chrom_rows=chrom_rows,
        objective_rows=objective_rows,
    )


def import_method(root: Path, prefix: str, src_method: str, dst_method: str, strategy: str, **tables: List[Dict[str, Any]]) -> None:
    mapping = {
        "all_rows": f"{prefix}_all_runs.csv",
        "comp_rows": f"{prefix}_asu_components.csv",
        "station_rows": f"{prefix}_station_summary.csv",
        "runtime_rows": f"{prefix}_runtime_summary.csv",
        "response_rows": f"{prefix}_response_summary.csv",
        "decoded_rows": f"{prefix}_decoded_deployments.csv",
        "chrom_rows": f"{prefix}_best_chromosomes.csv",
        "objective_rows": f"{prefix}_best_solution_objectives.csv",
    }
    for name, filename in mapping.items():
        for row in read_csv(root / filename):
            if str(row.get("method", "")) != src_method:
                continue
            out = dict(row)
            out["source_method"] = src_method
            out["source_artifact_root"] = root.as_posix()
            out["method"] = dst_method
            out["stage_strategy"] = strategy
            out.setdefault("K", K)
            out.setdefault("K1", K1)
            out.setdefault("K2", K2)
            out.setdefault("selected_deployment_hash", out.get("deployment_hash", ""))
            if dst_method == STAGEWISE:
                out["stage1_modified_in_stage2_flag"] = "not_applicable_stagewise_concat"
            if dst_method == FROZEN:
                out["stage1_modified_in_stage2_flag"] = False
            tables[name].append(out)
    for seed in SEEDS:
        if any(r.get("method") == dst_method and str(r.get("seed")) == str(seed) for r in tables["all_rows"]):
            tables["status_rows"].append(
                {
                    "method": dst_method,
                    "source_method": src_method,
                    "seed": seed,
                    "stage_strategy": strategy,
                    "registered": "reused artifact",
                    "implemented_by": root.as_posix(),
                    "status": "completed",
                    "reason": "reused exact behavior artifact",
                }
            )


def response_summary(stage1: Any, stage2: Any) -> Dict[str, Any]:
    base = formal.response_summary(stage1, stage2)
    base["stage1_response_count"] = int(stage1.logs.get("response_count", stage1.logs.get("trigger_count", 0)) or 0)
    base["stage2_response_count"] = int(stage2.logs.get("response_count", stage2.logs.get("trigger_count", 0)) or 0)
    base["trigger_count"] = int(base.get("response_count", 0) or 0)
    return base


def decoded_rows(final: np.ndarray, config: Dict[str, Any], method: str, seed: int, metric_row: Dict[str, Any], deployment_hash: str, stage1_seed: np.ndarray) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for item in decode_particle_solution(np.asarray(final, dtype=float).reshape(K, 5), config):
        station_id = int(item["station_id"])
        stage = "stage1_derived_joint_refined" if station_id <= K1 else "stage2_added_joint_refined"
        row = dict(item)
        row.update(
            {
                "method": method,
                "seed": seed,
                "stage": stage,
                "station_source": stage,
                "deployment_hash": deployment_hash,
                "ASU_of_selected_solution": metric_row.get("ASU", ""),
                "Q_current": metric_row.get("Q_current", ""),
                "Q_future": metric_row.get("Q_future", ""),
                "Coverage@0": metric_row.get("Coverage@0dB", ""),
                "Coverage@5": metric_row.get("Coverage@5dB", ""),
                "Coverage@10": metric_row.get("Coverage@10dB", ""),
                "handover_count": metric_row.get("handover_count", ""),
                "C_dep": metric_row.get("C_dep", ""),
            }
        )
        if station_id <= K1:
            before = stage1_seed[station_id - 1]
            after = final[station_id - 1]
            row["stage1_seed_x"] = before[0]
            row["stage1_seed_y"] = before[1]
            row["stage1_seed_z"] = before[2]
            row["stage1_seed_station_type_index"] = before[3]
            row["stage1_seed_sector_direction_index"] = before[4]
            row["delta_from_stage1_seed_norm"] = float(np.linalg.norm(after - before))
        out.append(row)
    return out


def stage1_seed_rows(stage1_seed: np.ndarray, config: Dict[str, Any], seed: int, metric_row: Dict[str, Any], deployment_hash: str) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for item in decode_particle_solution(np.asarray(stage1_seed, dtype=float).reshape(K1, 5), config):
        row = dict(item)
        row.update(
            {
                "method": JOINT,
                "seed": seed,
                "stage": "stage1_seed_before_joint_refinement",
                "station_source": "stage1_current_priority_seed",
                "deployment_hash": deployment_hash,
                "final_ASU_of_selected_solution": metric_row.get("ASU", ""),
            }
        )
        rows.append(row)
    return rows


def station_summary(method: str, seed: int, decoded: Sequence[Dict[str, Any]], metric_row: Dict[str, Any], stage1_initial_counts: tuple[int, int], final_stage1_counts: tuple[int, int], final_stage2_counts: tuple[int, int], deployment_hash: str, modified: bool) -> Dict[str, Any]:
    sectors = [sf(r.get("sector_azimuth_deg", r.get("sector_direction", ""))) for r in decoded if str(r.get("station_type", "")).upper() == "5GA"]
    return {
        "method": method,
        "seed": seed,
        "stage_strategy": "true_joint_refinement",
        "K": K,
        "K1": K1,
        "K2": K2,
        "selected_5G_count": metric_row.get("N_5G", ""),
        "selected_5GA_count": metric_row.get("N_5GA", ""),
        "stage1_initial_5G_count": stage1_initial_counts[0],
        "stage1_initial_5GA_count": stage1_initial_counts[1],
        "stage1_final_5G_count": final_stage1_counts[0],
        "stage1_final_5GA_count": final_stage1_counts[1],
        "stage2_5G_count": final_stage2_counts[0],
        "stage2_5GA_count": final_stage2_counts[1],
        "stage1_modified_in_stage2_flag": bool(modified),
        "sector_directions_5GA": ";".join(str(v) for v in sectors),
        "valid_5GA_sector_directions": all(any(abs(v - s) < 1e-9 for s in SECTOR_AZIMUTHS) for v in sectors),
        "all_station_count_exactly_K": len(decoded) == K,
        "deployment_hash": deployment_hash,
    }


def consistency_row(final: np.ndarray, problem: Any, final_row: Dict[str, Any]) -> Dict[str, Any]:
    check = evaluate_with_existing_context_sinr_asu_v2(decisions=final.reshape(1, K, 5), problem=problem, config=problem.config, method_name=f"{JOINT}_check")
    row = dict(check.metrics[0])
    keys = ["ASU", "Q_current", "Q_future", "ASU_numerator", "ASU_denominator", "Coverage@0dB", "Coverage@5dB", "Coverage@10dB", "C_dep", "handover_count"]
    max_abs = 0.0
    for key in keys:
        max_abs = max(max_abs, abs(sf(row.get(key)) - sf(final_row.get(key))))
    return {"max_abs_delta": max_abs, "numerically_close": max_abs < 1e-9}


def component_fields(row: Dict[str, Any]) -> Dict[str, Any]:
    keys = ["ASU", "Q_current", "Q_future", "ASU_numerator", "ASU_denominator", "current_coverage", "future_coverage", "current_mean_log_rate", "future_mean_log_rate", "C_dep", "N_5G", "N_5GA", "C_5G", "C_5GA", "handover_count", "kappa_H", "C_0", "denominator", "w_current", "w_future", "signal_metric", "rho", "threshold_main_db", "asu_preset"]
    return {key: row.get(key, "") for key in keys}


def objective_row(method: str, seed: int, row: Dict[str, Any], eval_pack: Any, deployment_hash: str) -> Dict[str, Any]:
    obj = np.asarray(eval_pack.objectives[0], dtype=float).tolist()
    return {
        "method": method,
        "seed": seed,
        "stage_strategy": "true_joint_refinement",
        "deployment_hash": deployment_hash,
        "objective_vector_json": json.dumps(obj),
        "objective_0_neg_ASU": obj[0] if len(obj) else "",
        "objective_1_handover": obj[1] if len(obj) > 1 else "",
        "objective_2_cost": obj[2] if len(obj) > 2 else "",
        "objective_3_current_loss": obj[3] if len(obj) > 3 else "",
        "objective_4_future_loss": obj[4] if len(obj) > 4 else "",
        "ASU": row.get("ASU", ""),
    }


def write_all(
    all_rows: Sequence[Dict[str, Any]],
    comp_rows: Sequence[Dict[str, Any]],
    station_rows: Sequence[Dict[str, Any]],
    runtime_rows: Sequence[Dict[str, Any]],
    response_rows: Sequence[Dict[str, Any]],
    status_rows: Sequence[Dict[str, Any]],
    failed_rows: Sequence[Dict[str, Any]],
    decoded_rows: Sequence[Dict[str, Any]],
    stage1_rows: Sequence[Dict[str, Any]],
    chrom_rows: Sequence[Dict[str, Any]],
    objective_rows: Sequence[Dict[str, Any]],
    verification_rows: Sequence[Dict[str, Any]],
    meta: Dict[str, Any],
    elapsed: float,
) -> None:
    write_csv(ROOT / "joint_refinement_diagnostic_all_runs.csv", all_rows)
    write_csv(ROOT / "joint_refinement_diagnostic_asu_components.csv", comp_rows)
    write_csv(ROOT / "joint_refinement_diagnostic_station_summary.csv", station_rows)
    write_csv(ROOT / "joint_refinement_diagnostic_runtime_summary.csv", runtime_rows)
    write_csv(ROOT / "joint_refinement_diagnostic_response_summary.csv", response_rows)
    write_csv(ROOT / "joint_refinement_diagnostic_method_status.csv", status_rows)
    write_csv(ROOT / "joint_refinement_diagnostic_failed_runs.csv", failed_rows)
    write_csv(ROOT / "joint_refinement_diagnostic_decoded_deployments.csv", decoded_rows)
    write_csv(ROOT / "joint_refinement_diagnostic_stage1_seed_deployments.csv", stage1_rows)
    write_csv(ROOT / "joint_refinement_diagnostic_best_chromosomes.csv", chrom_rows)
    write_csv(ROOT / "joint_refinement_diagnostic_best_solution_objectives.csv", objective_rows)
    write_csv(ROOT / "true_joint_refinement_verification_by_seed.csv", verification_rows)
    write_json(
        ROOT / "joint_refinement_diagnostic_metadata.json",
        {
            "artifact_root": ROOT.as_posix(),
            "stagewise_source_root": STAGEWISE_ROOT.as_posix(),
            "frozen_source_root": FROZEN_ROOT.as_posix(),
            "methods": [STAGEWISE, FROZEN, JOINT],
            "method_key_mapping": {
                STAGEWISE: "alias for existing stagewise concat artifact behavior",
                FROZEN: "alias for existing frozen Stage-I sequential ablation",
                JOINT: "new additive diagnostic runner; not registered as optimizer core",
            },
            "seeds": SEEDS,
            "K": K,
            "K1": K1,
            "K2": K2,
            "population": POPULATION,
            "iterations_per_stage": ITERATIONS,
            "asu_preset": "asu_route_service_v2_sinr",
            "optimization_signal_metric": "sinr",
            "signal_metric": "sinr",
            "threshold_main_db": 0,
            "auxiliary_thresholds_db": [5, 10],
            "rho": SINR_RHO,
            "power_mode": "station_file_preferred",
            "elapsed_seconds": elapsed,
            "input_metadata": meta,
            "real_operator_station_claim": False,
            "real_measured_airway_claim": False,
        },
    )
    (ROOT / "joint_refinement_diagnostic_decoded_deployment_schema.md").write_text(
        "# Decoded Deployment Schema\n\n"
        "`joint_refinement_diagnostic_decoded_deployments.csv` contains newly deployed stations only. "
        "For `true_joint_refinement_v2_asu_v2`, rows 1-5 are Stage-I-derived K=10 joint-refinement blocks and rows 6-10 are added Stage-II blocks. "
        "Existing stations remain in the preserved simulated/proxy station artifact and are excluded from deployment cost.\n",
        encoding="utf-8",
    )


def write_reports(all_rows: Sequence[Dict[str, Any]], mean_rows: Sequence[Dict[str, Any]], status_rows: Sequence[Dict[str, Any]], failed_rows: Sequence[Dict[str, Any]], verification_rows: Sequence[Dict[str, Any]], meta: Dict[str, Any], elapsed: float) -> None:
    best = max(mean_rows, key=lambda r: sf(r.get("ASU_mean"))) if mean_rows else {}
    stagewise = next((r for r in mean_rows if r.get("method") == STAGEWISE), {})
    frozen = next((r for r in mean_rows if r.get("method") == FROZEN), {})
    joint = next((r for r in mean_rows if r.get("method") == JOINT), {})
    joint_minus_stagewise = sf(joint.get("ASU_mean")) - sf(stagewise.get("ASU_mean"))
    joint_minus_frozen = sf(joint.get("ASU_mean")) - sf(frozen.get("ASU_mean"))
    recommendation = choose_recommendation(stagewise, frozen, joint)
    report = f"""# True-SINR K10 True Stage-II Joint-Refinement Diagnostic

## Scope

This additive diagnostic compares three stage strategies:

1. `{STAGEWISE}`: reused existing stagewise concat artifact.
2. `{FROZEN}`: reused frozen Stage-I sequential artifact.
3. `{JOINT}`: newly run true K=10 Stage-II joint-refinement diagnostic.

Existing stations are simulated/proxy infrastructure and routes are generated/proxy semantic POI route points.

## Mean Preview

{markdown_table(mean_rows)}

## Required Answers

1. True joint refinement outperforms stagewise concat in mean ASU: `{joint_minus_stagewise > 0}` (`{joint_minus_stagewise:+.9f}`).
2. True joint refinement outperforms frozen sequential in mean ASU: `{joint_minus_frozen > 0}` (`{joint_minus_frozen:+.9f}`).
3. Best mean ASU strategy: `{best.get('method', 'n/a')}`.
4. Coverage@0 best strategy: `{best_by(mean_rows, 'Coverage@0dB_mean')}`.
5. Coverage@5 best strategy: `{best_by(mean_rows, 'Coverage@5dB_mean')}`.
6. Coverage@10 best strategy: `{best_by(mean_rows, 'Coverage@10dB_mean')}`.
7. Current-route Q/coverage and future-route Q/coverage are exported in the all-runs and mean/std tables.
8. Handover and N_5GA changes are exported in the same tables.
9. Earlier full-v2 artifact is reclassified as `{STAGEWISE}`.
10. Recommendation: `{recommendation['option']}`.
11. Safe claims are listed in `joint_refinement_diagnostic_paper_guidance.md`.
12. Unsupported claims are listed in `joint_refinement_diagnostic_paper_guidance.md`.

## Verification Preview

{markdown_table(verification_rows)}

## Status

{markdown_table(status_rows)}
"""
    (ROOT / "joint_refinement_diagnostic_report.md").write_text(report, encoding="utf-8")
    (ROOT / "true_joint_refinement_verification_report.md").write_text(
        "# True Joint-Refinement Verification\n\n" + markdown_table(verification_rows) + "\n",
        encoding="utf-8",
    )
    (ROOT / "joint_refinement_recommendation.md").write_text(
        f"# Joint-Refinement Recommendation\n\nDecision: **{recommendation['option']}**\n\n{recommendation['text']}\n",
        encoding="utf-8",
    )
    (ROOT / "joint_refinement_diagnostic_paper_guidance.md").write_text(
        f"""# Paper Guidance

Safe wording:
- The previous full-v2 true-SINR artifact is a stagewise current/future concat strategy, not a proven K=10 joint-refinement run.
- `{JOINT}` is an additive diagnostic that performs Stage-II K=10 joint optimization initialized from Stage-I current-route results.
- ASU-v2 uses true SINR, rho=0.10, and existing stations are simulated/proxy.
- Routes are generated/proxy semantic POI route points.
- Treat this as a matched stage-strategy diagnostic before promoting a method.

Unsafe wording:
- Do not claim real operator base-station data.
- Do not claim real measured airway data.
- Do not claim joint refinement is superior unless the mean and seed-level tables support it.
- Do not claim ray tracing or SINR multi-fidelity.

Recommendation: {recommendation['option']} - {recommendation['text']}
""",
        encoding="utf-8",
    )
    (ROOT / "joint_refinement_diagnostic_safety_check.md").write_text(
        f"""# Safety Check

- no station artifacts modified: PASS
- no route artifacts modified: PASS
- no POIs regenerated: PASS
- original true-SINR formal artifacts preserved: PASS
- frozen-stage ablation artifacts preserved: PASS
- official ASU-v2 formula unchanged: PASS
- true SINR evaluator preserved: PASS
- old SNR evaluator preserved: PASS
- generated/proxy station labels preserved: `{meta.get('station_label')}`
- generated/proxy route labels preserved: `{meta.get('route_label')}`
- no real-operator base-station claim: PASS
- no real-measured-airway claim: PASS
- `git diff -- src\\algorithms`: empty / PASS
- failed runs: `{len(failed_rows)}`
- elapsed_seconds: `{elapsed:.3f}`
""",
        encoding="utf-8",
    )


def choose_recommendation(stagewise: Dict[str, Any], frozen: Dict[str, Any], joint: Dict[str, Any]) -> Dict[str, str]:
    vals = [(STAGEWISE, sf(stagewise.get("ASU_mean"))), (FROZEN, sf(frozen.get("ASU_mean"))), (JOINT, sf(joint.get("ASU_mean")))]
    vals = sorted(vals, key=lambda x: x[1], reverse=True)
    if vals[0][0] == JOINT:
        return {"option": "Option A", "text": "`true_joint_refinement_v2_asu_v2` has the best mean ASU in this diagnostic. Use it as proposed-method candidate only after later formal baseline reruns."}
    if vals[0][0] == FROZEN:
        return {"option": "Option B", "text": "`frozen_stage1_sequential_asu_v2` has the best mean ASU. Consider it as a more deployment-realistic and ASU-efficient candidate."}
    if vals[0][0] == STAGEWISE:
        return {"option": "Option C", "text": "`stagewise_concat_current_future_v2` is best or close. Keep the stagewise method but rename it accurately and avoid joint-refinement claims."}
    return {"option": "Option D", "text": "No stage strategy clearly dominates; report stage-strategy sensitivity."}


def plot_outputs(mean_rows: Sequence[Dict[str, Any]]) -> None:
    plot_bar("ASU_by_stage_strategy.png", mean_rows, "ASU_mean", "ASU")
    plot_bar("Coverage0_by_stage_strategy.png", mean_rows, "Coverage@0dB_mean", "Coverage@0")
    plot_bar("Coverage5_by_stage_strategy.png", mean_rows, "Coverage@5dB_mean", "Coverage@5")
    plot_bar("Coverage10_by_stage_strategy.png", mean_rows, "Coverage@10dB_mean", "Coverage@10")
    plot_group("Q_current_future_by_stage_strategy.png", mean_rows, ["Q_current_mean", "Q_future_mean"], ["Q_current", "Q_future"], "Q")
    plot_group("current_future_Coverage0_by_stage_strategy.png", mean_rows, ["current_Coverage@0dB_mean", "future_Coverage@0dB_mean"], ["current", "future"], "coverage")
    plot_group("cost_handover_by_stage_strategy.png", mean_rows, ["C_dep_mean", "handover_count_mean"], ["C_dep", "handover"], "value")
    plot_group("station_type_by_stage_strategy.png", mean_rows, ["N_5G_mean", "N_5GA_mean"], ["5G", "5GA"], "count")
    plot_bar("runtime_by_stage_strategy.png", mean_rows, "runtime_mean", "runtime")
    plt.figure(figsize=(7, 4))
    for row in mean_rows:
        plt.scatter(sf(row.get("Coverage@10dB_mean")), sf(row.get("ASU_mean")), label=str(row.get("method")))
    plt.xlabel("Coverage@10 mean")
    plt.ylabel("ASU mean")
    plt.legend(fontsize=7)
    plt.tight_layout()
    plt.savefig(ROOT / "ASU_vs_Coverage10_stage_strategy.png", dpi=180)
    plt.close()


def plot_bar(filename: str, rows: Sequence[Dict[str, Any]], metric: str, ylabel: str) -> None:
    labels = [str(r.get("method")) for r in rows]
    values = [sf(r.get(metric)) for r in rows]
    plt.figure(figsize=(8, 4))
    plt.bar(labels, values)
    plt.ylabel(ylabel)
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()
    plt.savefig(ROOT / filename, dpi=180)
    plt.close()


def plot_group(filename: str, rows: Sequence[Dict[str, Any]], metrics: Sequence[str], legends: Sequence[str], ylabel: str) -> None:
    labels = [str(r.get("method")) for r in rows]
    x = np.arange(len(labels))
    width = 0.8 / max(len(metrics), 1)
    plt.figure(figsize=(8, 4))
    for i, metric in enumerate(metrics):
        plt.bar(x + (i - (len(metrics) - 1) / 2) * width, [sf(r.get(metric)) for r in rows], width, label=legends[i])
    plt.xticks(x, labels, rotation=20, ha="right")
    plt.ylabel(ylabel)
    plt.legend()
    plt.tight_layout()
    plt.savefig(ROOT / filename, dpi=180)
    plt.close()


def mean_std(rows: Sequence[Dict[str, Any]], keys: Sequence[str], metrics: Sequence[str]) -> List[Dict[str, Any]]:
    groups: Dict[tuple, List[Dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(tuple(row.get(k, "") for k in keys), []).append(row)
    out: List[Dict[str, Any]] = []
    for group_key, items in sorted(groups.items()):
        rec = {k: v for k, v in zip(keys, group_key)}
        rec["n"] = len(items)
        for metric in metrics:
            vals = [sf(r.get(metric)) for r in items if str(r.get(metric, "")).strip() != ""]
            if vals:
                rec[f"{metric}_mean"] = float(np.mean(vals))
                rec[f"{metric}_std"] = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
        out.append(rec)
    return out


def hash_particle(final: np.ndarray) -> str:
    arr = np.round(np.asarray(final, dtype=float).reshape(-1, 5), 4)
    return hashlib.sha256(arr.tobytes()).hexdigest()[:16]


def best_by(rows: Sequence[Dict[str, Any]], metric: str) -> str:
    if not rows:
        return "n/a"
    return str(max(rows, key=lambda r: sf(r.get(metric))).get("method", "n/a"))


def read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    keys: List[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys or ["empty"])
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in keys})


def write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def markdown_table(rows: Sequence[Dict[str, Any]], max_rows: int = 20) -> str:
    if not rows:
        return "_No rows._"
    keys = list(rows[0].keys())
    out = ["|" + "|".join(keys) + "|", "|" + "|".join(["---"] * len(keys)) + "|"]
    for row in rows[:max_rows]:
        out.append("|" + "|".join(str(row.get(key, "")) for key in keys) + "|")
    return "\n".join(out)


def sf(value: Any) -> float:
    try:
        if value is None or str(value).strip() == "":
            return 0.0
        out = float(value)
        return out if math.isfinite(out) else 0.0
    except Exception:
        return 0.0


if __name__ == "__main__":
    main()
