"""z_max=50 m final-population optimization robustness diagnostic.

The runner is additive and writes a new output root. It reuses the previously
defined exploration metrics (AN/DCR/OE) and computes HV/GD/IGD from valid
final-population nondominated objective vectors only.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
ROOT = Path("artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_optimization_robustness_final_population")
os.environ.setdefault("MPLCONFIGDIR", str((ROOT / "_mplcache").resolve()))
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_height_constrained_zmax50 as height
import scripts.run_formal_true_sinr_optimizer_exploration_diversity_closed_loop_v3 as old_exp
import scripts.run_formal_true_sinr_route_scale_optimizer_robustness_closed_loop_v3 as route_scale
import scripts.run_highK_true_joint_response_robustness as hk
import scripts.run_true_joint_response_v3_closed_loop_diagnostic_K15 as closed_loop
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
from src.baselines.registry import build_method_registry
from src.experiments.multiobjective_metrics import nondominated_mask


PROPOSED = "true_joint_closed_loop_elite_immigration_response_v3_asu_v2"
NSGA2 = "nsga2_current_then_future_asu_v2"
MOEAD = "moead_current_then_future_asu_v2"
METHODS = [PROPOSED, NSGA2, MOEAD, "csa_extended", "hho_extended"]
SEEDS = [2026]
ROUTE_SETTINGS = [("current10_future10", 10, 10), ("current20_future30", 20, 30), ("current33_future47", 33, 47)]
K_SETTINGS = [(10, 5, 5)]
POPULATION = 50
ITERATIONS = 150
Z_MAX = 50.0
OBJECTIVE_COLUMNS = ["C_dep", "handover_count", "minus_Q_current", "minus_Q_future"]
REFERENCE_POINT = np.asarray([1.1, 1.1, 1.1, 1.1], dtype=float)
MC_SAMPLES = 120000


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    records = [dict(row) for row in rows]
    fields: list[str] = []
    for record in records:
        for key in record:
            if key not in fields:
                fields.append(str(key))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields or ["status"])
        writer.writeheader()
        for record in records:
            writer.writerow({key: record.get(key, "") for key in fields})


def number(value: Any, default: float = math.nan) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def as_bool(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def md_table(rows: Sequence[Mapping[str, Any]], columns: Sequence[str] | None = None, limit: int = 20) -> str:
    vals = list(rows)[:limit]
    if not vals:
        return "| status |\n| --- |\n| empty |\n"
    cols = list(columns or vals[0].keys())
    return (
        "| " + " | ".join(cols) + " |\n"
        + "| " + " | ".join(["---"] * len(cols)) + " |\n"
        + "".join("| " + " | ".join(str(row.get(col, "")) for col in cols) + " |\n" for row in vals)
    )


def stable_seed(*parts: Any) -> int:
    digest = hashlib.sha256("|".join(str(p) for p in parts).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "little") % (2**32)


def configure(k: int, k1: int, k2: int) -> None:
    for module in [formal, true_formal, route_scale, hk, closed_loop, old_exp, height]:
        module.K = int(k)
        module.K1 = int(k1)
        module.K2 = int(k2)
        module.POPULATION = POPULATION
        module.ITERATIONS = ITERATIONS
    closed_loop.SEED = 2026


def build_zmax_problems(stations: Sequence[Mapping[str, Any]], route_rows: Sequence[Mapping[str, Any]]) -> tuple[Any, Any, Any, dict[str, Any]]:
    all_problem, current_problem, future_problem, meta = route_scale.build_true_sinr_problems(stations, route_rows)
    for problem in (all_problem, current_problem, future_problem):
        problem.config["route_point_rows"] = list(route_rows)
        problem.config["explorationTrace"] = {"enabled": True, "fractions": [0.0, 0.25, 0.5, 0.75, 1.0]}
        height.apply_height_constraint(problem)
    return all_problem, current_problem, future_problem, meta


def source_key(method: str, scenario: str, k: int, seed: int) -> tuple[str, str, int, int]:
    return method, scenario, int(k), int(seed)


def completed(status_rows: Sequence[Mapping[str, Any]], method: str, scenario: str, k: int, seed: int) -> bool:
    return any(
        row.get("method") == method
        and row.get("scenario_name") == scenario
        and str(row.get("K")) == str(k)
        and str(row.get("seed")) == str(seed)
        and row.get("status") == "completed"
        for row in status_rows
    )


def enrich_candidate_height(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for row in rows:
        decision = np.asarray(json.loads(str(row["decision_vector_json"])), dtype=float).reshape(-1, 5)
        h = height.height_metrics(decision)
        obj_valid = all(math.isfinite(number(row.get(key))) for key in ["objective_C_dep", "objective_handover_count", "objective_neg_Q_current", "objective_neg_Q_future"])
        row = dict(row)
        row["max_new_station_height"] = h["max_new_station_height"]
        row["mean_new_station_height"] = h["mean_new_station_height"]
        row["height_compliance_flag"] = bool(h["height_constraint_compliant"])
        row["objective_valid_flag"] = bool(obj_valid)
        row["deployment_hash"] = height.hash_decision(decision)
        out.append(row)
    return out


def run_missing() -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    status_rows = read_csv(ROOT / "zmax50_robustness_method_status.csv")
    all_rows = read_csv(ROOT / "zmax50_robustness_run_rows.csv")
    candidates = read_csv(ROOT / "zmax50_robustness_all_candidates.csv")
    failed = read_csv(ROOT / "zmax50_robustness_failed_cases.csv")
    registry = build_method_registry()
    stations = formal.read_csv(formal.STATION_PATH)
    routes = formal.read_csv(formal.ROUTE_POINT_PATH)
    meta: dict[str, Any] = {"station_count": len(stations), "route_point_count": len(routes), "reduced_diagnostic_set": True}
    for scenario_name, n_current, n_future in ROUTE_SETTINGS:
        subset = route_scale.select_route_subset(routes, n_current, n_future)
        for k, k1, k2 in K_SETTINGS:
            configure(k, k1, k2)
            all_problem, current_problem, future_problem, build_meta = build_zmax_problems(stations, subset)
            meta.update({f"{scenario_name}_route_point_count": build_meta.get("route_point_count", len(subset))})
            for method in METHODS:
                adapter = registry.get(method)
                for seed in SEEDS:
                    if completed(status_rows, method, scenario_name, k, seed):
                        continue
                    try:
                        run = old_exp._run(method, adapter, seed, all_problem, current_problem, future_problem)
                        run_row = old_exp._run_row(run, method, seed, scenario_name, n_current, n_future, k, k1, k2)
                        all_rows.append(run_row)
                        trace = run.get("exploration_candidate_trace", []) if isinstance(run, Mapping) else []
                        stage1_best = np.asarray(run.get("stage1_best_decision", []), dtype=float)
                        added = old_exp._materialize_trace(trace, method, seed, scenario_name, n_current, n_future, k, k1, k2, stage1_best, all_problem)
                        candidates.extend(enrich_candidate_height(added))
                        status_rows.append({"method": method, "scenario_name": scenario_name, "route_count": n_current + n_future, "K": k, "K1": k1, "K2": k2, "seed": seed, "status": "completed", "reason": "z_max=50 final-population trace captured"})
                    except Exception as exc:  # pragma: no cover - diagnostic records failures.
                        failure = {"method": method, "scenario_name": scenario_name, "route_count": n_current + n_future, "K": k, "K1": k1, "K2": k2, "seed": seed, "status": "failed", "reason": f"{type(exc).__name__}: {exc}"}
                        status_rows.append(failure)
                        failed.append(failure)
                    write_csv(ROOT / "zmax50_robustness_run_rows.csv", all_rows)
                    write_csv(ROOT / "zmax50_robustness_all_candidates.csv", candidates)
                    write_csv(ROOT / "zmax50_robustness_method_status.csv", status_rows)
                    write_csv(ROOT / "zmax50_robustness_failed_cases.csv", failed)
    return all_rows, candidates, status_rows, meta


def objective_array(rows: Sequence[Mapping[str, Any]]) -> np.ndarray:
    return np.asarray(
        [[number(r["objective_C_dep"]), number(r["objective_handover_count"]), number(r["objective_neg_Q_current"]), number(r["objective_neg_Q_future"])] for r in rows],
        dtype=float,
    )


def unique_rows(values: np.ndarray) -> np.ndarray:
    return np.unique(np.asarray(values, dtype=float), axis=0) if values.size else np.zeros((0, 4), dtype=float)


def normalized(values: np.ndarray, ideal: np.ndarray, nadir: np.ndarray) -> np.ndarray:
    return (values - ideal) / np.maximum(nadir - ideal, 1e-12)


def rms_nearest(source: np.ndarray, target: np.ndarray) -> float:
    if source.size == 0 or target.size == 0:
        return math.nan
    distances = np.linalg.norm(source[:, None, :] - target[None, :, :], axis=2)
    return float(np.sqrt(np.mean(np.square(np.min(distances, axis=1)))))


def shared_mc_hv(fronts: Mapping[str, np.ndarray], seed: int) -> dict[str, float]:
    rng = np.random.default_rng(seed)
    samples = rng.random((MC_SAMPLES, 4)) * REFERENCE_POINT[None, :]
    volume = float(np.prod(REFERENCE_POINT))
    out = {}
    for method, values in fronts.items():
        front = unique_rows(values[nondominated_mask(values)]) if values.size else np.zeros((0, 4))
        dominated = np.any(np.all(front[:, None, :] <= samples[None, :, :], axis=2), axis=0) if front.size else np.zeros(samples.shape[0], dtype=bool)
        out[method] = float(volume * np.mean(dominated))
    return out


def final_population_rows(candidates: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    source_audit = []
    population = []
    validity = []
    groups: dict[tuple[str, str, int, int], list[Mapping[str, Any]]] = defaultdict(list)
    for row in candidates:
        groups[source_key(str(row["method"]), str(row["scenario_name"]), int(row["K"]), int(row["seed"]))].append(row)
    for (method, scenario, k, seed), rows in sorted(groups.items()):
        final_iter = max(int(row["iteration"]) for row in rows)
        pop = [
            row for row in rows
            if int(row["iteration"]) == final_iter
            and str(row.get("candidate_source", "")) == "population"
            and not as_bool(row.get("is_archive_member"))
        ]
        valid = [r for r in pop if as_bool(r.get("height_compliance_flag")) and as_bool(r.get("objective_valid_flag"))]
        raw = objective_array(valid) if valid else np.zeros((0, 4), dtype=float)
        finite = raw[np.isfinite(raw).all(axis=1)] if raw.size else raw
        dedup = unique_rows(finite)
        nd = dedup[nondominated_mask(dedup)] if dedup.size else dedup
        source_audit.append({
            "method": method, "scenario_name": scenario, "K": k, "seed": seed,
            "source_file": str(ROOT / "zmax50_robustness_all_candidates.csv"),
            "source_type": "last_population_trace_snapshot",
            "valid_final_population_snapshot": bool(pop),
            "represents_final_population_not_archive": True,
            "represents_full_K_candidates": True,
            "best_only_flag": False,
            "archive_only_flag": False,
            "smoke_artifact_used": False,
            "note": "Last iteration, candidate_source=population, is_archive_member=false; candidates re-evaluated on all routes.",
        })
        validity.append({
            "method": method, "scenario_name": scenario, "K": k, "seed": seed,
            "final_population_size": len(pop),
            "valid_objective_vector_count": int(finite.shape[0]),
            "duplicate_count": int(finite.shape[0] - dedup.shape[0]),
            "nondominated_count": int(nd.shape[0]),
            "nondominated_fraction": float(nd.shape[0] / max(finite.shape[0], 1)),
            "height_violation_count": int(sum(1 for r in pop if not as_bool(r.get("height_compliance_flag")))),
            "invalid_objective_count": int(len(pop) - finite.shape[0]),
        })
        for idx, row in enumerate(pop):
            population.append({
                "method": method, "scenario_name": scenario, "route_count": int(row["current_route_count"]) + int(row["future_route_count"]),
                "K": k, "seed": seed, "candidate_id": row.get("candidate_id", idx),
                "C_dep": row.get("objective_C_dep", ""), "handover_count": row.get("objective_handover_count", ""),
                "Q_current": row.get("Q_current", ""), "Q_future": row.get("Q_future", ""),
                "minus_Q_current": row.get("objective_neg_Q_current", ""), "minus_Q_future": row.get("objective_neg_Q_future", ""),
                "ASU_for_reference_only": row.get("ASU", ""), "N_5G": "", "N_5GA": "",
                "max_new_station_height": row.get("max_new_station_height", ""), "mean_new_station_height": row.get("mean_new_station_height", ""),
                "height_compliance_flag": row.get("height_compliance_flag", ""),
                "objective_valid_flag": row.get("objective_valid_flag", ""),
                "deployment_hash": row.get("deployment_hash", ""),
            })
    return source_audit, population, validity


def final_pop_metrics(population: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    nd_rows = []
    metrics = []
    grouped: dict[tuple[str, int, int, str], list[Mapping[str, Any]]] = defaultdict(list)
    for row in population:
        if as_bool(row.get("height_compliance_flag")) and as_bool(row.get("objective_valid_flag")):
            grouped[(str(row["scenario_name"]), int(row["K"]), int(row["seed"]), str(row["method"]))].append(row)
    by_group: dict[tuple[str, int, int], dict[str, np.ndarray]] = defaultdict(dict)
    for (scenario, k, seed, method), rows in sorted(grouped.items()):
        arr = np.asarray([[number(r["C_dep"]), number(r["handover_count"]), number(r["minus_Q_current"]), number(r["minus_Q_future"])] for r in rows], dtype=float)
        arr = arr[np.isfinite(arr).all(axis=1)] if arr.size else arr
        unique = unique_rows(arr)
        nd = unique[nondominated_mask(unique)] if unique.size else unique
        by_group[(scenario, k, seed)][method] = nd
        for i, obj in enumerate(nd.tolist()):
            nd_rows.append({"method": method, "scenario_name": scenario, "K": k, "seed": seed, "nd_id": i, "C_dep": obj[0], "handover_count": obj[1], "minus_Q_current": obj[2], "minus_Q_future": obj[3]})
    for (scenario, k, seed), method_map in sorted(by_group.items()):
        if len(method_map) < 2:
            continue
        raw_union = np.vstack([v for v in method_map.values() if v.size])
        ideal, nadir = raw_union.min(axis=0), raw_union.max(axis=0)
        zero_dims = [OBJECTIVE_COLUMNS[i] for i, span in enumerate(nadir - ideal) if abs(float(span)) <= 1e-12]
        norm = {method: normalized(values, ideal, nadir) for method, values in method_map.items() if values.size}
        reference_raw = unique_rows(np.vstack(list(norm.values())))
        reference_front = reference_raw[nondominated_mask(reference_raw)]
        hv = shared_mc_hv(norm, stable_seed("zmax50", scenario, k, seed))
        for method, values in norm.items():
            metrics.append({
                "method": method, "scenario_name": scenario, "K": k, "seed": seed,
                "final_population_HV": hv[method],
                "final_population_GD": rms_nearest(values, reference_front),
                "final_population_IGD": rms_nearest(reference_front, values),
                "nondominated_count": int(values.shape[0]),
                "reference_front_size": int(reference_front.shape[0]),
                "normalization_ideal": json.dumps(ideal.tolist()),
                "normalization_nadir": json.dumps(nadir.tolist()),
                "zero_range_dimensions": json.dumps(zero_dims),
                "reference_point": json.dumps(REFERENCE_POINT.tolist()),
                "normalization_scope": "shared union within scenario/K/seed",
                "reference_front_type": "empirical_union_nondominated_final_population",
                "ASU_used_for_HV_GD_IGD": False,
            })
    return nd_rows, metrics


def metric_definition_audit() -> list[dict[str, Any]]:
    return [
        {
            "metric_name": "HV/GD/IGD",
            "recovered_definition": "Computed on nondominated objective vectors with shared normalization/reference front.",
            "source_file": "scripts/audit_final_population_hv_gd_igd.py; src/experiments/multiobjective_metrics.py",
            "formula_or_algorithm": "Objectives [C_dep, handover_count, -Q_current, -Q_future], minimization; shared ideal/nadir; HV reference [1.1]*4 here.",
            "higher_or_lower_is_better": "HV higher; GD/IGD lower",
            "required_inputs": "valid final-population objective vectors",
            "whether_metric_uses_objective_vectors": True,
            "whether_metric_uses_ASU": False,
            "paper_safe_description": "Pareto-front diagnostic from final-population objective vectors only.",
        },
        {
            "metric_name": "DCR",
            "recovered_definition": "Decision Coverage Ratio: unique (20x20 spatial cell, station type, sector) bins occupied by checkpoint candidates divided by union bins for the scenario/K group.",
            "source_file": "scripts/run_formal_true_sinr_optimizer_exploration_diversity_closed_loop_v3.py::_dcr_rows",
            "formula_or_algorithm": "DCR = |occupied decision bins by method| / |union occupied decision bins across methods|.",
            "higher_or_lower_is_better": "higher indicates broader decision-bin occupation; not necessarily better service",
            "required_inputs": "checkpoint candidate decision vectors",
            "whether_metric_uses_objective_vectors": False,
            "whether_metric_uses_ASU": False,
            "paper_safe_description": "Complementary exploration/diversity diagnostic.",
        },
        {
            "metric_name": "AN",
            "recovered_definition": "Archive Novelty: mean nearest-neighbor distance from each new unique archive decision vector to previous archive decision vectors after canonical station sorting/normalization.",
            "source_file": "scripts/run_formal_true_sinr_optimizer_exploration_diversity_closed_loop_v3.py::_an_rows",
            "formula_or_algorithm": "Mean nearest distance among unique archive snapshots; unavailable when no archive trace exists.",
            "higher_or_lower_is_better": "higher indicates more novel archive entries; not necessarily better service",
            "required_inputs": "archive checkpoint decision vectors",
            "whether_metric_uses_objective_vectors": False,
            "whether_metric_uses_ASU": False,
            "paper_safe_description": "Archive novelty diagnostic; unavailable for methods without archive trace.",
        },
        {
            "metric_name": "OE",
            "recovered_definition": "Objective Entropy: normalized entropy over 10-bin-per-objective cells of final nondominated/archive objective vectors.",
            "source_file": "scripts/run_formal_true_sinr_optimizer_exploration_diversity_closed_loop_v3.py::_oe_rows",
            "formula_or_algorithm": "Normalize objective vectors by scenario/K universe, map to 10^4 grid, compute -sum(p log p)/log(max(min(n,10000),2)).",
            "higher_or_lower_is_better": "higher indicates broader objective-space spread; not necessarily better service",
            "required_inputs": "objective vectors from final archive or nondominated population",
            "whether_metric_uses_objective_vectors": True,
            "whether_metric_uses_ASU": False,
            "paper_safe_description": "Objective-space diversity diagnostic separate from HV/GD/IGD.",
        },
    ]


def an_dcr_oe(candidates: Sequence[Mapping[str, Any]], stations: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    valid_candidates = [dict(r) for r in candidates if as_bool(r.get("height_compliance_flag")) and as_bool(r.get("objective_valid_flag"))]
    dcr = old_exp._dcr_rows(valid_candidates)
    an, unavailable = old_exp._an_rows(valid_candidates, stations)
    oe = old_exp._oe_rows(valid_candidates)
    lookup: dict[tuple[str, str, int], dict[str, Any]] = {}
    for source, name, better, uses_obj in [(dcr, "DCR", "higher", False), (an, "AN", "higher", False), (oe, "OE", "higher", True)]:
        for row in source:
            key = (str(row["method"]), str(row["scenario_name"]), int(row["K"]))
            rec = lookup.setdefault(key, {"method": key[0], "scenario_name": key[1], "K": key[2]})
            rec.update(row)
            rec[f"{name}_higher_or_lower_is_better"] = better
            rec[f"{name}_input_source"] = "checkpoint candidates/archive trace" if name != "OE" else row.get("OE_source", "objective vectors")
            rec[f"{name}_comparability_flag"] = True
            rec[f"{name}_caveat"] = "Diagnostic only; not a system-level utility metric."
            rec[f"{name}_uses_objective_vectors"] = uses_obj
            rec[f"{name}_uses_ASU"] = False
    for row in unavailable:
        key = (str(row["method"]), str(row["scenario_name"]), int(row["K"]))
        rec = lookup.setdefault(key, {"method": key[0], "scenario_name": key[1], "K": key[2]})
        rec["AN"] = ""
        rec["AN_comparability_flag"] = False
        rec["AN_caveat"] = row.get("reason", "unavailable")
    return list(lookup.values()), unavailable


def combine_metrics(hv_rows: Sequence[Mapping[str, Any]], aux_rows: Sequence[Mapping[str, Any]], validity: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    aux = {(r["method"], r["scenario_name"], str(r["K"])): r for r in aux_rows}
    valid = {(r["method"], r["scenario_name"], str(r["K"]), str(r["seed"])): r for r in validity}
    out = []
    for row in hv_rows:
        key3 = (row["method"], row["scenario_name"], str(row["K"]))
        key4 = (row["method"], row["scenario_name"], str(row["K"]), str(row["seed"]))
        out.append({**dict(row), **aux.get(key3, {}), **valid.get(key4, {})})
    return out


def proposed_vs(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    metrics = {(r["method"], r["scenario_name"], str(r["K"]), str(r["seed"])): r for r in rows}
    out = []
    for r in rows:
        if r["method"] != PROPOSED:
            continue
        for baseline in [NSGA2, MOEAD, "csa_extended", "hho_extended"]:
            b = metrics.get((baseline, r["scenario_name"], str(r["K"]), str(r["seed"])))
            if not b:
                out.append({"scenario_name": r["scenario_name"], "K": r["K"], "seed": r["seed"], "baseline": baseline, "classification": "insufficient_data"})
                continue
            hv_better = number(r["final_population_HV"]) > number(b["final_population_HV"])
            gd_better = number(r["final_population_GD"]) < number(b["final_population_GD"])
            igd_better = number(r["final_population_IGD"]) < number(b["final_population_IGD"])
            better_count = sum([hv_better, gd_better, igd_better])
            classification = "proposed_advantage_consistent" if better_count == 3 else ("proposed_advantage_mixed" if better_count > 0 else "proposed_advantage_absent")
            out.append({
                "scenario_name": r["scenario_name"], "K": r["K"], "seed": r["seed"], "baseline": baseline,
                "proposed_HV_over_baseline_HV": number(r["final_population_HV"]) / max(number(b["final_population_HV"], 0.0), 1e-12),
                "proposed_GD_minus_baseline_GD": number(r["final_population_GD"]) - number(b["final_population_GD"]),
                "proposed_IGD_minus_baseline_IGD": number(r["final_population_IGD"]) - number(b["final_population_IGD"]),
                "proposed_AN_minus_baseline_AN": number(r.get("AN")) - number(b.get("AN")) if str(r.get("AN", "")) and str(b.get("AN", "")) else "",
                "proposed_DCR_minus_baseline_DCR": number(r.get("DCR")) - number(b.get("DCR")) if str(r.get("DCR", "")) and str(b.get("DCR", "")) else "",
                "proposed_OE_minus_baseline_OE": number(r.get("OE")) - number(b.get("OE")) if str(r.get("OE", "")) and str(b.get("OE", "")) else "",
                "classification": classification,
            })
    return out


def write_plots(rows: Sequence[Mapping[str, Any]], diagnosis: Sequence[Mapping[str, Any]]) -> None:
    def bar(metric: str, filename: str) -> None:
        vals = [r for r in rows if str(r.get(metric, "")) not in {"", "nan"}]
        if not vals:
            return
        labels = [f"{r['method']}\n{r['scenario_name']}" for r in vals]
        nums = [number(r[metric]) for r in vals]
        fig, ax = plt.subplots(figsize=(max(10, len(vals) * 0.42), 4.8))
        ax.bar(range(len(vals)), nums)
        ax.set_xticks(range(len(vals)))
        ax.set_xticklabels(labels, rotation=90, fontsize=6)
        ax.set_ylabel(metric)
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()
        fig.savefig(ROOT / filename, dpi=180)
        plt.close(fig)

    bar("final_population_HV", "zmax50_final_population_HV_by_method.png")
    bar("final_population_GD", "zmax50_final_population_GD_by_method.png")
    bar("final_population_IGD", "zmax50_final_population_IGD_by_method.png")
    bar("AN", "zmax50_final_population_AN_by_method.png")
    bar("DCR", "zmax50_final_population_DCR_by_method.png")
    bar("OE", "zmax50_final_population_OE_by_method.png")
    bar("nondominated_count", "zmax50_final_population_ND_count_by_method.png")
    for baseline, filename in [(NSGA2, "zmax50_proposed_vs_nsga2_HV_by_group.png"), (MOEAD, "zmax50_proposed_vs_moead_HV_by_group.png")]:
        vals = [r for r in diagnosis if r.get("baseline") == baseline and str(r.get("proposed_HV_over_baseline_HV", ""))]
        if not vals:
            continue
        fig, ax = plt.subplots(figsize=(7, 4))
        labels = [f"{r['scenario_name']}/K{r['K']}" for r in vals]
        ax.axhline(1.0, color="black", linewidth=0.8)
        ax.bar(range(len(vals)), [number(r["proposed_HV_over_baseline_HV"]) for r in vals])
        ax.set_xticks(range(len(vals)))
        ax.set_xticklabels(labels, rotation=30, ha="right")
        ax.set_ylabel("Proposed HV / baseline HV")
        fig.tight_layout()
        fig.savefig(ROOT / filename, dpi=180)
        plt.close(fig)
    # Compact summary plot.
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for method in sorted({r["method"] for r in rows}):
        vals = [r for r in rows if r["method"] == method]
        ax.plot([r["scenario_name"] for r in vals], [number(r["final_population_HV"]) for r in vals], marker="o", label=method)
    ax.set_ylabel("final-population HV")
    ax.legend(fontsize=6)
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    fig.savefig(ROOT / "zmax50_robustness_metric_radar_or_summary.png", dpi=180)
    plt.close(fig)


def write_reports(all_metrics: Sequence[Mapping[str, Any]], diagnosis: Sequence[Mapping[str, Any]], failed: Sequence[Mapping[str, Any]], unavailable: Sequence[Mapping[str, Any]], elapsed: float) -> None:
    cols = ["method", "scenario_name", "K", "final_population_HV", "final_population_GD", "final_population_IGD", "AN", "DCR", "OE", "nondominated_count"]
    diag_cols = ["scenario_name", "K", "baseline", "proposed_HV_over_baseline_HV", "proposed_GD_minus_baseline_GD", "proposed_IGD_minus_baseline_IGD", "classification"]
    report = [
        "# z_max=50 m Final-Population Optimization Robustness Report",
        "",
        "- Scope: reduced diagnostic set `route_count=20,50,80; K=10; seed=2026`.",
        "- Full 4 route counts x 3 K robustness grid remains optional because final-population snapshots were not present in completed z_max=50 packages.",
        f"- Completed metric rows: `{len(all_metrics)}`.",
        f"- Failed runs: `{len(failed)}`.",
        f"- Unavailable auxiliary metric records: `{len(unavailable)}`.",
        f"- Elapsed seconds: `{elapsed:.2f}`.",
        "",
        "## Metric Preview",
        "",
        md_table(all_metrics, cols, limit=30),
        "",
        "## Proposed Versus Baselines",
        "",
        md_table(diagnosis, diag_cols, limit=30),
        "",
        "## Answers",
        "",
        "1. AN/DCR/OE definitions were recovered from the previous optimizer exploration/diversity runner.",
        "2. DCR uses decision-bin occupation; AN uses archive novelty; OE uses objective-space entropy over objective bins.",
        "3. Completed z_max=50 packages did not contain verified final-population snapshots; this runner captured missing traces.",
        "4. Missing method-setting combinations were rerun only for trace/final-population logging under z_max=50.",
        "5. Height compliance is audited in `zmax50_robustness_height_audit.csv`.",
        "6. HV/GD/IGD use only `[C_dep, handover_count, -Q_current, -Q_future]`.",
        "7. ASU is excluded from HV/GD/IGD.",
        "8. Shared group normalization and shared reference point `[1.1]*4` are used.",
        "9-13. Proposed-versus-baseline rows show whether evidence is consistent or mixed.",
        "14. Do not claim stable universal Pareto superiority from this reduced diagnostic.",
    ]
    (ROOT / "zmax50_robustness_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    guidance = [
        "# z_max=50 m Robustness Paper Guidance",
        "",
        "Safe claims:",
        "- Optimization robustness is evaluated under the same z_max=50 m height-constrained setting.",
        "- HV, GD, and IGD are computed from the nondominated subset of the final population.",
        "- The four-objective minimization vector is [C_dep, handover_count, -Q_current, -Q_future].",
        "- AN, DCR, and OE follow the same definitions used in previous robustness diagnostics.",
        "- These indicators are optimization diagnostics rather than sole evidence of system-level superiority.",
        "- Main system-level conclusions rely on ASU-v2, Coverage Utility, Continuous Coverage Utility, and route-interruption metrics.",
        "",
        "Unsafe claims:",
        "- HV/GD/IGD are computed from ASU.",
        "- All baselines optimize exactly the same objective vector unless separately verified.",
        "- Final population and archive are the same source.",
        "- The results prove universal Pareto superiority.",
        "- Existing stations are real operator base stations.",
        "- Routes are real measured UAV routes.",
    ]
    (ROOT / "zmax50_robustness_paper_guidance.md").write_text("\n".join(guidance) + "\n", encoding="utf-8")
    diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, capture_output=True, text=True, check=False)
    safety = [
        "# z_max=50 m Robustness Safety Check",
        "",
        "- Previous unconstrained robustness results overwritten: PASS (new root only).",
        "- Completed z_max=50 system/sensitivity/ablation packages overwritten: PASS (new root only).",
        "- Frozen proposed method logic changed: PASS (false).",
        "- ASU-v2 changed: PASS (false).",
        "- Original station/route/POI artifacts regenerated: PASS (false).",
        "- All newly deployed final-population rows satisfy z <= 50 m: PASS if height audit all true.",
        "- ASU used for HV/GD/IGD: PASS (false).",
        "- Per-method normalization/reference point used: PASS (false).",
        "- Generated/proxy labels preserved: PASS.",
        f"- `git diff -- src/algorithms` empty: `{diff.stdout.strip() == ''}`.",
    ]
    (ROOT / "zmax50_robustness_safety_check.md").write_text("\n".join(safety) + "\n", encoding="utf-8")


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    started = time.time()
    write_csv(ROOT / "zmax50_robustness_metric_definition_audit.csv", metric_definition_audit())
    all_rows, candidates, status, meta = run_missing()
    stations = formal.read_csv(formal.STATION_PATH)
    source_audit, population, validity = final_population_rows(candidates)
    nd_sets, hv_rows = final_pop_metrics(population)
    aux_rows, unavailable = an_dcr_oe(candidates, stations)
    all_metrics = combine_metrics(hv_rows, aux_rows, validity)
    diagnosis = proposed_vs(all_metrics)
    height_rows = [
        {
            "method": row["method"], "scenario_name": row["scenario_name"], "K": row["K"], "seed": row["seed"],
            "candidate_id": row["candidate_id"], "max_new_station_height": row["max_new_station_height"],
            "mean_new_station_height": row["mean_new_station_height"],
            "height_compliance_flag": row["height_compliance_flag"],
        }
        for row in population
    ]
    failed = read_csv(ROOT / "zmax50_robustness_failed_cases.csv")
    write_csv(ROOT / "zmax50_final_population_source_audit.csv", source_audit)
    write_csv(ROOT / "zmax50_final_population_objective_validity_audit.csv", validity)
    write_csv(ROOT / "zmax50_final_population_nondominated_sets.csv", nd_sets)
    write_csv(ROOT / "zmax50_final_population_hv_gd_igd.csv", hv_rows)
    write_csv(ROOT / "zmax50_final_population_an_dcr_oe.csv", aux_rows)
    write_csv(ROOT / "zmax50_final_population_all_robustness_metrics.csv", all_metrics)
    write_csv(ROOT / "zmax50_proposed_vs_optimizer_diagnosis.csv", diagnosis)
    write_csv(ROOT / "zmax50_robustness_height_audit.csv", height_rows)
    write_csv(ROOT / "zmax50_final_population_rows.csv", population)
    metadata = {
        "artifact_root": ROOT.as_posix(),
        "reduced_diagnostic_set": True,
        "route_settings": ROUTE_SETTINGS,
        "K_settings": K_SETTINGS,
        "methods": METHODS,
        "seeds": SEEDS,
        "z_max_m": Z_MAX,
        "objective_vector": ["C_dep", "handover_count", "-Q_current", "-Q_future"],
        "ASU_used_for_HV_GD_IGD": False,
        "reference_point": REFERENCE_POINT.tolist(),
        "mc_samples_for_hv": MC_SAMPLES,
        "input_meta": meta,
        "elapsed_seconds": time.time() - started,
    }
    (ROOT / "zmax50_robustness_metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    write_plots(all_metrics, diagnosis)
    write_reports(all_metrics, diagnosis, failed, unavailable, time.time() - started)
    print(json.dumps({"artifact_root": ROOT.as_posix(), "completed_status_rows": len(status), "metric_rows": len(all_metrics), "failed": failed}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
