"""Extract traceable plotting datasets for the four final AirHERO figures.

The script is additive: it reads completed experiment packages and writes only
under ``07_figure_data``.  The sole optimization work is a deterministic
Stage-I-only replay for the representative seed, needed because the adopted
main run did not persist the Stage-I decision or the Stage-II seed particle.
Stage-II optimization is never rerun.
"""
from __future__ import annotations

import csv
import json
import math
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
import scripts.run_true_joint_response_v3_closed_loop_diagnostic_K15 as closed_loop
import scripts.tmc_rebuild.airhero_allk_stage2_refinement_common as airhero
from src.experiments.evaluation_consistency import _station_file_preferred_plan, existing_station_particle
from src.propagation.a2g_probabilistic import compute_population_per_bs_rx_power_a2g_dbm


PACKAGE_ROOT = Path("artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50")
OUT = PACKAGE_ROOT / "07_figure_data"
SPATIAL = OUT / "01_spatial_stage_evolution"
PROFILES = OUT / "02_representative_route_profiles"
HEATMAPS = OUT / "03_route_budget_heatmaps"
ROBUSTNESS = OUT / "04_fair_optimizer_robustness"
MAIN = PACKAGE_ROOT / "01_main_system"
ABLATION = PACKAGE_ROOT / "02_ablation"
SENSITIVITY = PACKAGE_ROOT / "03_route_budget_sensitivity"
ROBUST_SOURCE = PACKAGE_ROOT / "06_fair_optimizer_robustness_same_space"
RAW_MAIN = Path("artifacts/tmc_rebuild/airhero_allk_main_candidate_zmax50/01_main_system")
ROUTE_PATH = Path("artifacts/tmc_rebuild/route_resampling/shenyang_predicted_routes_resampled_points.csv")
STATION_PATH = Path("artifacts/tmc_rebuild/station_generation_citywide_route_agnostic/generated_existing_stations_citywide_route_agnostic_low.csv")
BOUNDARY_PATH = Path("data/real/shenyang/shenyang_study_area_boundary.geojson")

SEEDS = [2026, 2027, 2028]
K, K1, K2 = 10, 5, 5
THRESHOLDS = [0.0, 5.0, 10.0]
SECTORS = [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]
COORDINATE_SYSTEM = "local projected x/y coordinates in metres; geographic source coordinates are WGS84 lon/lat"


def read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def write_csv(path: Path, rows: Iterable[Mapping[str, Any]], fields: Sequence[str] | None = None) -> None:
    records = [dict(row) for row in rows]
    columns = list(fields or [])
    if not columns:
        for row in records:
            for key in row:
                if key not in columns:
                    columns.append(key)
    if not columns:
        columns = ["status"]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in records:
            writer.writerow({key: row.get(key, "") for key in columns})


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def number(value: Any, default: float = math.nan) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def truthy(value: Any) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes"}


def sample_std(values: Sequence[float]) -> float | str:
    return float(np.std(np.asarray(values, dtype=float), ddof=1)) if len(values) > 1 else ""


def select_representative_seed() -> Tuple[int, float, List[Dict[str, Any]]]:
    rows = [row for row in read_csv(MAIN / "per_seed_results.csv") if truthy(row.get("success"))]
    values = [(int(number(row["seed"])), number(row["ASU"])) for row in rows]
    if {seed for seed, _ in values} != set(SEEDS):
        raise RuntimeError(f"AirHERO main seed inventory is incomplete: {values}")
    mean_asu = float(np.mean([value for _, value in values]))
    selected = min(values, key=lambda item: (abs(item[1] - mean_asu), item[0]))[0]
    audit = [
        {
            "seed": seed,
            "ASU": value,
            "three_seed_mean_ASU": mean_asu,
            "absolute_distance_to_mean": abs(value - mean_asu),
            "selected": seed == selected,
        }
        for seed, value in values
    ]
    return selected, mean_asu, audit


def decision_from_rows(rows: Sequence[Mapping[str, Any]]) -> np.ndarray:
    ordered = sorted(rows, key=lambda row: int(number(row.get("station_id", row.get("station_slot_id", 0)), 0)))
    out: List[List[float]] = []
    for row in ordered:
        station_type = str(row.get("station_type", "5G")).upper()
        type_idx = int(number(row.get("station_type_index"), 1.0 if station_type == "5GA" else 0.0))
        sector_idx = int(number(row.get("sector_direction_index"), 0.0))
        out.append([number(row.get("x")), number(row.get("y")), number(row.get("z")), type_idx, sector_idx])
    return np.asarray(out, dtype=float).reshape(-1, 5)


def decode_station(station: np.ndarray, slot: int) -> Dict[str, Any]:
    type_idx = int(np.clip(round(float(station[3])), 0, 1))
    sector_idx = int(np.clip(round(float(station[4])), 0, len(SECTORS) - 1))
    return {
        "station_slot_id": slot,
        "x": float(station[0]),
        "y": float(station[1]),
        "z": float(station[2]),
        "station_type": "5GA" if type_idx else "5G",
        "station_type_index": type_idx,
        "sector_direction_index": sector_idx,
        "sector_direction_deg": SECTORS[sector_idx] if type_idx else 0.0,
    }


def extract_stage1_and_stage2_seed(seed: int) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    """Replay only Stage-I and capture the deterministic first all-K Stage-II seed."""
    airhero.configure_modules(seed)
    all_problem, current_problem, future_problem, _ = airhero.build_problems()
    adapter = closed_loop.ClosedLoopResponseAdapter(airhero.FORMAL_AIRHERO)
    stage1_cfg = formal.stage_config(current_problem.config, K1, stage=f"{airhero.METHOD_KEY}_stage1_current_exact_airhero")
    true_formal.apply_true_sinr_config(stage1_cfg)
    stage1 = adapter.run(current_problem, seed=seed, config=stage1_cfg)
    stage1_best = formal.best_decision(stage1, K1)
    stage1_best, repairs = airhero.zmax.repair_height(stage1_best, current_problem.config)

    stage2_cfg = formal.stage_config(all_problem.config, K, stage=f"{airhero.METHOD_KEY}_stage2_allK_current_future_refinement")
    true_formal.apply_true_sinr_config(stage2_cfg)
    cfg = closed_loop.asu_v2_adapter._method_config_asu_v2(
        stage2_cfg,
        airhero.FORMAL_AIRHERO,
        response_enabled=True,
        mild_only=False,
        severe_restart_fraction=0.20,
    )
    pso = cfg.get("pso", {})
    pop_size = int(pso.get("numParticles", airhero.POPULATION))
    min_pos = np.asarray(pso.get("minPosition"), dtype=float)
    max_pos = np.asarray(pso.get("maxPosition"), dtype=float)
    rng = np.random.default_rng(seed + 1009)
    initializer = airhero._make_stage2_initializer(
        stage1_best,
        future_problem,
        closed_loop.v2_module._initialize_population,
    )
    particles, summary = initializer(all_problem, cfg, rng, pop_size, K, min_pos, max_pos)
    seed_solution = np.asarray(particles[0], dtype=float).reshape(K, 5)
    prefix_matches = bool(np.allclose(seed_solution[:K1], stage1_best, atol=1e-8, rtol=0.0))
    if not prefix_matches:
        raise RuntimeError("captured Stage-II seed does not preserve the exact Stage-I prefix")
    meta = {
        "stage1_runtime_seconds": float(stage1.runtime_seconds),
        "stage1_height_repair_count": int(repairs),
        "stage1_count": int(stage1_best.shape[0]),
        "stage2_seed_count": int(seed_solution.shape[0]),
        "stage1_prefix_matches_stage2_seed": prefix_matches,
        "stage2_initializer_summary": summary,
        "extraction_only_rerun": True,
        "stage2_optimization_rerun": False,
        "actual_population": int(pop_size),
        "actual_iterations_per_stage": int(pso.get("maxIterations", airhero.ITERATIONS)),
    }
    return np.asarray(stage1_best, dtype=float), seed_solution, meta


def point_state(decision: np.ndarray, problem: Any, existing_rows: Sequence[Mapping[str, Any]], method_key: str) -> Dict[str, Any]:
    new = np.asarray(decision, dtype=float).reshape(-1, 5)
    existing = existing_station_particle(problem.config, target_dims=5)
    combined = np.vstack([existing, new]) if new.size else existing.copy()
    plan = _station_file_preferred_plan(problem.config, combined, existing_count=existing.shape[0])
    rx_dbm, _ = compute_population_per_bs_rx_power_a2g_dbm(
        positions=combined[None, :, :3],
        test_points=problem.test_points,
        channel_params=problem.channel_params,
        tx_power_offsets_db=plan.tx_power_offsets_db,
        coverage_boost_db=plan.coverage_boost_db,
        path_loss_offsets_db=plan.path_loss_offsets_db,
        sector_station_mask=plan.sector_station_mask,
        sector_azimuths_deg=plan.sector_azimuths_deg,
        sector_beamwidth_deg=plan.sector_beamwidth_deg,
        outside_sector_mode=plan.outside_sector_mode,
        side_lobe_attenuation_db=plan.side_lobe_attenuation_db,
    )
    rx = np.asarray(rx_dbm[0], dtype=float)
    power_mw = np.power(10.0, rx / 10.0)
    serving = np.argmax(rx, axis=0)
    idx = np.arange(rx.shape[1])
    serving_mw = power_mw[serving, idx]
    interference_mw = np.maximum(np.sum(power_mw, axis=0) - serving_mw, 0.0)
    noise_mw = 10.0 ** (float(problem.channel_params.get("noisePower", -90.0)) / 10.0)
    sinr_linear = serving_mw / np.maximum(noise_mw + 0.10 * interference_mw, 1e-30)
    sinr_db = 10.0 * np.log10(np.maximum(sinr_linear, 1e-30))

    station_ids = [str(row.get("station_id", f"existing_{i + 1:03d}")) for i, row in enumerate(existing_rows)]
    station_types = [str(row.get("station_type", "5G")) for row in existing_rows]
    is_existing = [True] * len(station_ids)
    for slot, station in enumerate(new, start=1):
        station_ids.append(f"{method_key}_new_{slot:02d}")
        station_types.append("5GA" if int(round(float(station[3]))) == 1 else "5G")
        is_existing.append(False)
    return {
        "sinr_db": sinr_db,
        "serving_index": serving,
        "station_ids": station_ids,
        "station_types": station_types,
        "station_is_existing": is_existing,
    }


def route_groups(route_rows: Sequence[Mapping[str, Any]]) -> Dict[str, List[int]]:
    groups: Dict[str, List[int]] = {}
    for idx, row in enumerate(route_rows):
        groups.setdefault(str(row.get("route_id", "")), []).append(idx)
    for route_id, indices in groups.items():
        groups[route_id] = sorted(indices, key=lambda i: int(number(route_rows[i].get("point_index"), i)))
    return groups


def route_category(row: Mapping[str, Any]) -> str:
    return "current" if str(row.get("route_priority_label", "")).strip().lower() == "current" else "predicted"


def cumulative_distances(indices: Sequence[int], route_rows: Sequence[Mapping[str, Any]]) -> List[float]:
    values = [0.0]
    for a, b in zip(indices[:-1], indices[1:]):
        pa = np.asarray([number(route_rows[a].get(k), 0.0) for k in ("x", "y", "z")], dtype=float)
        pb = np.asarray([number(route_rows[b].get(k), 0.0) for k in ("x", "y", "z")], dtype=float)
        values.append(values[-1] + float(np.linalg.norm(pb - pa)))
    return values


def ccu(covered: np.ndarray) -> float:
    return float(np.mean(covered[:-1] & covered[1:])) if covered.size > 1 else 0.0


def outage_segment_ids(covered: np.ndarray) -> List[int]:
    ids: List[int] = []
    current = 0
    in_outage = False
    for flag in covered.tolist():
        if flag:
            ids.append(0)
            in_outage = False
        else:
            if not in_outage:
                current += 1
                in_outage = True
            ids.append(current)
    return ids


def build_spatial_data(
    selected_seed: int,
    selected_asu: float,
    route_rows: Sequence[Mapping[str, Any]],
    station_rows: Sequence[Mapping[str, Any]],
    all_problem: Any,
    initial_state: Mapping[str, Any],
    stage1: np.ndarray,
    stage2_seed: np.ndarray,
    final_decision: np.ndarray,
) -> Dict[str, Any]:
    pso = all_problem.config["pso"]
    write_csv(
        SPATIAL / "map_extent.csv",
        [{
            "min_x": pso["minPosition"][0], "max_x": pso["maxPosition"][0],
            "min_y": pso["minPosition"][1], "max_y": pso["maxPosition"][1],
            "coordinate_system": COORDINATE_SYSTEM, "source_file": BOUNDARY_PATH.as_posix(),
        }],
    )
    groups = route_groups(route_rows)
    cumulative: Dict[int, float] = {}
    for indices in groups.values():
        for idx, distance in zip(indices, cumulative_distances(indices, route_rows)):
            cumulative[idx] = distance
    sinr = np.asarray(initial_state["sinr_db"], dtype=float)
    sample_rows = []
    for idx, row in enumerate(route_rows):
        sample_rows.append({
            "route_id": row.get("route_id", ""), "route_category": route_category(row),
            "sample_index": int(number(row.get("point_index"), idx)),
            "x": number(row.get("x")), "y": number(row.get("y")), "z": number(row.get("z")),
            "cumulative_distance": cumulative[idx], "initial_sinr_db": float(sinr[idx]),
            "initial_covered_at_0db": bool(sinr[idx] >= 0.0),
            "initial_covered_at_5db": bool(sinr[idx] >= 5.0),
            "initial_covered_at_10db": bool(sinr[idx] >= 10.0),
            "initial_low_service_flag": bool(sinr[idx] < 0.0),
        })
    write_csv(SPATIAL / "route_samples.csv", sample_rows)

    features = []
    for route_id, indices in groups.items():
        features.append({
            "type": "Feature",
            "properties": {"route_id": route_id, "route_category": route_category(route_rows[indices[0]])},
            "geometry": {"type": "LineString", "coordinates": [[number(route_rows[i]["x"]), number(route_rows[i]["y"])] for i in indices]},
        })
    write_json(SPATIAL / "route_polylines.geojson", {
        "type": "FeatureCollection",
        "name": "generated_proxy_semantic_POI_routes_projected_xy",
        "coordinate_system_note": COORDINATE_SYSTEM,
        "features": features,
    })

    existing_out = []
    for idx, row in enumerate(station_rows, start=1):
        existing_out.append({
            "station_id": row.get("station_id", idx), "x": number(row.get("x")), "y": number(row.get("y")),
            "z": number(row.get("z", row.get("height")), 35.0), "station_type": row.get("station_type", "5G"),
            "sector_direction_deg": row.get("sector_azimuth_deg", ""),
            "data_provenance": row.get("source", "simulated/proxy existing infrastructure"),
        })
    write_csv(SPATIAL / "existing_stations.csv", existing_out)

    stage1_rows = []
    for slot, station in enumerate(stage1, start=1):
        decoded = decode_station(station, slot)
        stage1_rows.append({
            "seed": selected_seed, "stage1_slot_id": slot, **{k: v for k, v in decoded.items() if k != "station_slot_id"},
            "source_artifact": "deterministic Stage-I-only extraction replay using the adopted main-run code path",
            "extraction_status": "extraction_only_rerun_original_seed_and_source_configuration",
        })
    write_csv(SPATIAL / "stage1_deployment.csv", stage1_rows)

    stage2_seed_rows = []
    for slot, station in enumerate(stage2_seed, start=1):
        stage2_seed_rows.append({
            "seed": selected_seed, "station_slot_id": slot,
            "initialization_source": "stage1_seed" if slot <= K1 else "predicted_route_seed",
            **{k: v for k, v in decode_station(station, slot).items() if k not in {"station_slot_id", "station_type_index", "sector_direction_index"}},
        })
    write_csv(SPATIAL / "stage2_initial_population_seed_solution.csv", stage2_seed_rows)

    final_rows = []
    for slot, station in enumerate(final_decision, start=1):
        final_rows.append({
            "seed": selected_seed, "station_slot_id": slot,
            **{k: v for k, v in decode_station(station, slot).items() if k not in {"station_slot_id", "station_type_index", "sector_direction_index"}},
            "final_asu": selected_asu,
            "source_artifact": (RAW_MAIN / f"seed_{selected_seed}" / "decoded_deployment.csv").as_posix(),
        })
    write_csv(SPATIAL / "final_airhero_deployment.csv", final_rows)

    refinement = []
    for idx in range(K1):
        before, after = stage1[idx], final_decision[idx]
        b = decode_station(before, idx + 1)
        a = decode_station(after, idx + 1)
        horizontal = float(np.linalg.norm(after[:2] - before[:2]))
        vertical = abs(float(after[2] - before[2]))
        sector_delta = abs(float(a["sector_direction_deg"]) - float(b["sector_direction_deg"]))
        sector_delta = min(sector_delta, 360.0 - sector_delta)
        refinement.append({
            "seed": selected_seed, "station_slot_id": idx + 1,
            "stage1_x": before[0], "stage1_y": before[1], "stage1_z": before[2],
            "final_x": after[0], "final_y": after[1], "final_z": after[2],
            "horizontal_displacement": horizontal, "vertical_displacement": vertical,
            "total_3d_displacement": float(np.linalg.norm(after[:3] - before[:3])),
            "stage1_station_type": b["station_type"], "final_station_type": a["station_type"],
            "station_type_changed": b["station_type"] != a["station_type"],
            "stage1_sector_direction_deg": b["sector_direction_deg"], "final_sector_direction_deg": a["sector_direction_deg"],
            "circular_sector_change_deg": sector_delta,
            "sector_changed": sector_delta > 1e-9,
            "correspondence_status": "proven_by_first_K1_slot_encoding_and_stage2_seed_prefix",
        })
    write_csv(SPATIAL / "stage1_to_final_refinement.csv", refinement)

    checks = [
        {"criterion": "stage1_station_count_is_K1", "pass": len(stage1_rows) == K1, "detail": len(stage1_rows)},
        {"criterion": "final_station_count_is_K", "pass": len(final_rows) == K, "detail": len(final_rows)},
        {"criterion": "slot_correspondence_proven", "pass": all(row["correspondence_status"].startswith("proven") for row in refinement), "detail": "first K1 slots preserved by all-K encoding"},
        {"criterion": "stage1_is_actual_optimized_output", "pass": True, "detail": "deterministic Stage-I-only replay; no centroid reconstruction"},
    ]
    write_csv(SPATIAL / "spatial_figure_readiness.csv", checks)
    (SPATIAL / "spatial_figure_notes.md").write_text(
        "# Spatial figure data notes\n\n"
        f"Representative seed: `{selected_seed}`. Stage-I was not persisted by the adopted main run, so it was recovered with a deterministic Stage-I-only replay using the original source configuration and seed. Stage-II optimization was not rerun. The captured Stage-II seed is the first `p1_plus_future_anchors` all-K particle, whose first five slots exactly match the recovered Stage-I decision. `initial_low_service_flag` means existing-only SINR below 0 dB. Coordinates are projected local x/y values in metres from the source artifacts. Routes and existing stations remain generated/proxy data.\n",
        encoding="utf-8",
    )
    return {"stage1_count": len(stage1_rows), "final_count": len(final_rows), "slot_correspondence": True}


def build_route_profiles(
    selected_seed: int,
    route_rows: Sequence[Mapping[str, Any]],
    station_rows: Sequence[Mapping[str, Any]],
    all_problem: Any,
    final_decision: np.ndarray,
) -> Dict[str, Any]:
    stagewise_path = ABLATION / "stagewise_concat_runs" / f"seed_{selected_seed}" / "decoded_deployment.csv"
    stagewise = decision_from_rows(read_csv(stagewise_path))
    methods = [
        ("existing_only", "Existing only", np.zeros((0, 5), dtype=float)),
        ("airhero_stagewise_concat_ablation", "Stagewise concat", stagewise),
        ("airhero_allk_stage2_refinement_v1", "AirHERO", final_decision),
    ]
    groups = route_groups(route_rows)
    states = {key: point_state(decision, all_problem, station_rows, key) for key, _, decision in methods}
    summaries: List[Dict[str, Any]] = []
    per_route_cache: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for method_key, method_label, _ in methods:
        state = states[method_key]
        sinr_all = np.asarray(state["sinr_db"], dtype=float)
        serving_all = np.asarray(state["serving_index"], dtype=int)
        for route_id, indices in groups.items():
            arr = np.asarray(indices, dtype=int)
            sinr = sinr_all[arr]
            serving = serving_all[arr]
            distances = cumulative_distances(indices, route_rows)
            row: Dict[str, Any] = {
                "seed": selected_seed, "route_id": route_id, "route_category": route_category(route_rows[indices[0]]),
                "method_key": method_key, "method_label": method_label, "route_sample_count": len(indices),
                "route_length": distances[-1] if distances else 0.0,
                "mean_sinr_db": float(np.mean(sinr)), "minimum_sinr_db": float(np.min(sinr)),
                "handover_count": int(np.sum(serving[1:] != serving[:-1])) if serving.size > 1 else 0,
            }
            for threshold in THRESHOLDS:
                suffix = int(threshold)
                covered = sinr >= threshold
                row[f"coverage_at_{suffix}"] = float(np.mean(covered))
                row[f"ccu_at_{suffix}"] = ccu(covered)
            summaries.append(row)
            per_route_cache[(method_key, route_id)] = {"indices": indices, "distances": distances, "sinr": sinr, "serving": serving}
    write_csv(PROFILES / "all_route_summary.csv", summaries)

    def choose(category: str) -> Dict[str, Any]:
        air_rows = {row["route_id"]: row for row in summaries if row["method_key"] == "airhero_allk_stage2_refinement_v1" and row["route_category"] == category}
        stage_rows = {row["route_id"]: row for row in summaries if row["method_key"] == "airhero_stagewise_concat_ablation" and row["route_category"] == category}
        candidates = []
        for route_id in sorted(air_rows):
            delta_ccu = number(air_rows[route_id]["ccu_at_0"]) - number(stage_rows[route_id]["ccu_at_0"])
            delta_cov = number(air_rows[route_id]["coverage_at_0"]) - number(stage_rows[route_id]["coverage_at_0"])
            candidates.append((route_id, delta_ccu, delta_cov))
        positive = [item for item in candidates if item[1] > 0.0]
        pool = positive if positive else candidates
        target = float(median([item[1] for item in pool]))
        chosen = min(pool, key=lambda item: (abs(item[1] - target), -item[2], item[0]))
        return {
            "route_category": category,
            "selected_route_id": chosen[0],
            "selection_metric": "AirHERO_minus_Stagewise_concat_CCU@0",
            "selected_delta_ccu_at_0": chosen[1],
            "selected_delta_coverage_at_0": chosen[2],
            "median_positive_delta_ccu_at_0": target if positive else "",
            "selection_reason": "closest_to_median_positive_improvement" if positive else "no_positive_improvement_closest_to_median_all_routes",
            "selected_seed": selected_seed,
        }

    selections = [choose("current"), choose("predicted")]
    write_csv(PROFILES / "representative_route_selection.csv", selections)
    selected_ids = {str(row["selected_route_id"]) for row in selections}
    selected_summary = [row for row in summaries if str(row["route_id"]) in selected_ids]
    write_csv(PROFILES / "representative_route_method_summary.csv", selected_summary)
    write_csv(PROFILES / "representative_route_thresholds.csv", [{"threshold_db": int(value)} for value in THRESHOLDS])

    profile_rows: List[Dict[str, Any]] = []
    for method_key, method_label, _ in methods:
        state = states[method_key]
        for route_id in sorted(selected_ids):
            cached = per_route_cache[(method_key, route_id)]
            sinr = np.asarray(cached["sinr"], dtype=float)
            serving = np.asarray(cached["serving"], dtype=int)
            outage0 = outage_segment_ids(sinr >= 0.0)
            outage10 = outage_segment_ids(sinr >= 10.0)
            for local_idx, global_idx in enumerate(cached["indices"]):
                serving_idx = int(serving[local_idx])
                profile_rows.append({
                    "seed": selected_seed, "route_id": route_id, "route_category": route_category(route_rows[global_idx]),
                    "method_key": method_key, "method_label": method_label,
                    "sample_index": int(number(route_rows[global_idx].get("point_index"), local_idx)),
                    "cumulative_distance": cached["distances"][local_idx],
                    "x": number(route_rows[global_idx].get("x")), "y": number(route_rows[global_idx].get("y")), "z": number(route_rows[global_idx].get("z")),
                    "sinr_db": float(sinr[local_idx]),
                    "serving_station_id": state["station_ids"][serving_idx],
                    "serving_station_type": state["station_types"][serving_idx],
                    "serving_station_is_existing": state["station_is_existing"][serving_idx],
                    "covered_at_0db": bool(sinr[local_idx] >= 0.0),
                    "covered_at_5db": bool(sinr[local_idx] >= 5.0),
                    "covered_at_10db": bool(sinr[local_idx] >= 10.0),
                    "handover_event": 0 if local_idx == 0 else int(serving[local_idx] != serving[local_idx - 1]),
                    "outage_segment_id_at_0db": outage0[local_idx],
                    "outage_segment_id_at_10db": outage10[local_idx],
                })
    write_csv(PROFILES / "representative_route_profiles.csv", profile_rows)
    checks = [
        {"criterion": "matched_representative_seed", "pass": all(int(row["seed"]) == selected_seed for row in profile_rows), "detail": selected_seed},
        {"criterion": "same_route_samples_for_all_methods", "pass": len(profile_rows) == 2 * 3 * 30, "detail": len(profile_rows)},
        {"criterion": "first_sample_handover_zero", "pass": all(int(row["handover_event"]) == 0 for row in profile_rows if int(row["sample_index"]) == 0), "detail": "within-route only"},
        {"criterion": "route_selection_is_non_extreme_rule", "pass": True, "detail": "median-positive CCU@0 improvement with deterministic tie breaks"},
    ]
    write_csv(PROFILES / "route_profile_readiness.csv", checks)
    (PROFILES / "representative_route_notes.md").write_text(
        "# Representative route profile notes\n\n"
        f"All 80 generated/proxy semantic POI routes were evaluated for Existing only, Stagewise concat, and AirHERO with seed `{selected_seed}` where applicable. Current and predicted representative routes were selected independently using the median-positive AirHERO-minus-Stagewise CCU@0 rule. CCU is the mean of adjacent covered-pair indicators within one route. Handover events are counted only between adjacent samples of the same route; the first point is always zero. Outage segment ID `0` denotes a covered sample.\n",
        encoding="utf-8",
    )
    return {"current_route_id": selections[0]["selected_route_id"], "predicted_route_id": selections[1]["selected_route_id"], "profile_row_count": len(profile_rows)}


def build_heatmaps() -> Dict[str, Any]:
    raw = [row for row in read_csv(SENSITIVITY / "route_budget_sensitivity_all_runs.csv") if truthy(row.get("success"))]
    canonical_splits = {20: (8, 12), 40: (17, 23), 50: (21, 29), 80: (33, 47)}
    canonical_k = {5: (2, 3), 10: (5, 5), 15: (7, 8)}
    groups: Dict[Tuple[int, int], List[Dict[str, str]]] = {}
    for row in raw:
        route_count, k = int(number(row.get("route_count"))), int(number(row.get("K")))
        if route_count in canonical_splits and k in canonical_k:
            groups.setdefault((route_count, k), []).append(row)
    long_rows = []
    metric_map = {
        "ASU": "ASU", "Coverage_at_0": "Coverage@0", "runtime_seconds": "runtime_seconds",
        "CCU_at_0": "CCU@0", "Q_current": "Q_current", "Q_future": "Q_future",
        "handover_count": "handover_count", "C_dep": "C_dep",
    }
    for route_count in canonical_splits:
        for k in canonical_k:
            rows = groups.get((route_count, k), [])
            current, predicted = canonical_splits[route_count]
            k1, k2 = canonical_k[k]
            out: Dict[str, Any] = {
                "route_count": route_count, "current_route_count": current, "predicted_route_count": predicted,
                "K": k, "K1": k1, "K2": k2, "seed_count": len(rows),
                "seed_policy": ";".join(str(int(number(row.get("seed")))) for row in sorted(rows, key=lambda r: int(number(r.get("seed"))))),
                "source_artifact": (SENSITIVITY / "route_budget_sensitivity_all_runs.csv").as_posix(),
            }
            for target, source in metric_map.items():
                values = [number(row.get(source)) for row in rows]
                values = [value for value in values if not math.isnan(value)]
                out[f"{target}_mean"] = float(np.mean(values)) if values else ""
                if target in {"ASU", "Coverage_at_0", "runtime_seconds", "CCU_at_0"}:
                    out[f"{target}_std"] = sample_std(values)
            long_rows.append(out)
    write_csv(HEATMAPS / "route_budget_heatmap_long.csv", long_rows)

    def pivot(metric: str, filename: str) -> None:
        rows = []
        lookup = {(int(row["route_count"]), int(row["K"])): row for row in long_rows}
        for route_count in canonical_splits:
            rows.append({"route_count": route_count, **{f"K={k}": lookup[(route_count, k)].get(metric, "") for k in canonical_k}})
        write_csv(HEATMAPS / filename, rows, ["route_count", "K=5", "K=10", "K=15"])

    pivot("ASU_mean", "heatmap_ASU_mean.csv")
    pivot("Coverage_at_0_mean", "heatmap_Coverage_at_0_mean.csv")
    pivot("runtime_seconds_mean", "heatmap_runtime_seconds_mean.csv")
    pivot("CCU_at_0_mean", "heatmap_CCU_at_0_mean.csv")
    pivot("Q_current_mean", "heatmap_Q_current_mean.csv")
    pivot("Q_future_mean", "heatmap_Q_future_mean.csv")
    split_ok = all((int(row["current_route_count"]), int(row["predicted_route_count"])) == canonical_splits[int(row["route_count"])] for row in long_rows)
    k_ok = all((int(row["K1"]), int(row["K2"])) == canonical_k[int(row["K"])] for row in long_rows)
    checks = [
        {"criterion": "exactly_12_unique_canonical_cells", "pass": len(long_rows) == 12 and len({(row["route_count"], row["K"]) for row in long_rows}) == 12, "detail": len(long_rows)},
        {"criterion": "canonical_route_splits_match", "pass": split_ok, "detail": canonical_splits},
        {"criterion": "canonical_K_splits_match", "pass": k_ok, "detail": canonical_k},
        {"criterion": "all_cells_use_airhero_allK", "pass": all(str(row.get("method_key")) == "airhero_allk_stage2_refinement_v1" for row in raw), "detail": "source raw rows"},
        {"criterion": "single_seed_std_left_blank", "pass": all(row["ASU_std"] == "" for row in long_rows if int(row["seed_count"]) == 1), "detail": "not encoded as zero"},
    ]
    write_csv(HEATMAPS / "heatmap_readiness.csv", checks)
    (HEATMAPS / "route_budget_heatmap_notes.md").write_text(
        "# Route-count by deployment-budget heatmap notes\n\n"
        "All 12 canonical AirHERO all-K cells are present. The source package contains seed 2026 only for each cell, so `seed_count=1` and standard deviations are intentionally blank rather than zero. These heatmaps show single-seed sensitivity, not multi-seed variability.\n",
        encoding="utf-8",
    )
    return {"cell_count": len(long_rows), "all_seed_counts": sorted({int(row["seed_count"]) for row in long_rows})}


def build_robustness() -> Dict[str, Any]:
    source = read_csv(ROBUST_SOURCE / "robustness_per_seed_metrics.csv")
    methods = [
        ("airhero_search_same_initialization", "AirHERO-search", 1, "MOPSO / AirHERO search"),
        ("nsga2_extended_allk_same_space", "NSGA-II", 2, "evolutionary multiobjective"),
        ("moead_extended_allk_same_space", "MOEA/D", 3, "decomposition multiobjective"),
        ("csa_extended_allk_same_space", "CSA", 4, "crow search"),
        ("clpso_extended_allk_same_space", "CLPSO", 5, "PSO family"),
        ("immogwo_extended_allk_same_space", "IMMOGWO", 6, "grey-wolf multiobjective adapted"),
        ("scenario_sampling_robust_deployment_allk_same_space", "Scenario sampling", 7, "scenario-sampling inspired"),
    ]
    meta = {key: {"label": label, "order": order, "family": family} for key, label, order, family in methods}
    directions = {"HV": "higher_is_better", "GD": "lower_is_better", "IGD": "lower_is_better", "AN": "higher_is_better"}
    long_rows: List[Dict[str, Any]] = []
    source_path = (ROBUST_SOURCE / "robustness_per_seed_metrics.csv").as_posix()
    for row in source:
        key = str(row.get("method"))
        if key not in meta:
            continue
        for metric, direction in directions.items():
            long_rows.append({
                "method_key": key, "method_label": meta[key]["label"], "method_order": meta[key]["order"],
                "seed": int(number(row.get("seed"))), "metric": metric, "value": number(row.get(metric)), "direction": direction,
                "K": int(number(row.get("K"))), "same_search_space": True, "shared_initialization": True,
                "objective_vector": "[C_dep, H, -Q_E, -Q_P]", "ASU_used_for_metric": False, "source_artifact": source_path,
            })
    write_csv(ROBUSTNESS / "robustness_plot_long.csv", long_rows)
    summary_rows: List[Dict[str, Any]] = []
    for key, label, order, _ in methods:
        for metric, direction in directions.items():
            values = [number(row["value"]) for row in long_rows if row["method_key"] == key and row["metric"] == metric]
            summary_rows.append({
                "method_key": key, "method_label": label, "method_order": order, "metric": metric,
                "mean": float(np.mean(values)), "std_sample": sample_std(values), "min": min(values), "max": max(values),
                "median": float(np.median(values)), "seed_count": len(values), "rank_by_mean": 0, "direction": direction,
            })
    for metric, direction in directions.items():
        rows = [row for row in summary_rows if row["metric"] == metric]
        rows.sort(key=lambda row: (number(row["mean"]) if direction == "lower_is_better" else -number(row["mean"]), int(row["method_order"])))
        for rank, row in enumerate(rows, start=1):
            row["rank_by_mean"] = rank
    write_csv(ROBUSTNESS / "robustness_plot_summary.csv", summary_rows)
    write_csv(ROBUSTNESS / "robustness_method_labels.csv", [
        {"method_key": key, "method_label": label, "method_order": order, "optimizer_family": family}
        for key, label, order, family in methods
    ])

    existing_summary = read_csv(ROBUST_SOURCE / "robustness_summary.csv")
    existing_lookup = {(row.get("method"), metric): (number(row.get(f"{metric}_mean")), number(row.get(f"{metric}_std"))) for row in existing_summary for metric in directions}
    tolerance = 1e-12
    summary_match = True
    mismatch_details = []
    for row in summary_rows:
        key = (row["method_key"], row["metric"])
        old = existing_lookup.get(key)
        if old is None:
            summary_match = False
            mismatch_details.append(f"missing {key}")
            continue
        if abs(number(row["mean"]) - old[0]) > tolerance or abs(number(row["std_sample"]) - old[1]) > tolerance:
            summary_match = False
            mismatch_details.append(f"{key}: recomputed=({row['mean']},{row['std_sample']}), source={old}")
    checks = [
        {"criterion": "seven_methods_three_seeds_four_metrics", "pass": len(long_rows) == 7 * 3 * 4, "detail": len(long_rows)},
        {"criterion": "exactly_three_seeds_each", "pass": all(int(row["seed_count"]) == 3 for row in summary_rows), "detail": SEEDS},
        {"criterion": "no_missing_values", "pass": all(not math.isnan(number(row["value"])) for row in long_rows), "detail": "HV/GD/IGD/AN"},
        {"criterion": "all_K10", "pass": all(int(row["K"]) == 10 for row in long_rows), "detail": 10},
        {"criterion": "asu_not_used", "pass": all(not truthy(row["ASU_used_for_metric"]) for row in long_rows), "detail": "objective vectors only"},
        {"criterion": "DCR_OE_not_invented", "pass": all(row["metric"] not in {"DCR", "OE"} for row in long_rows), "detail": "not applicable"},
        {"criterion": "recomputed_summary_matches_source", "pass": summary_match, "detail": "; ".join(mismatch_details) if mismatch_details else f"tolerance={tolerance}"},
    ]
    write_csv(ROBUSTNESS / "robustness_figure_readiness.csv", checks)
    caveat = (
        "# Robustness plot caveats\n\n"
        "All methods use K=10, the same all-K decision encoding, and the same initial population for each seed. HV, GD, IGD, and AN use `[C_dep, H, -Q_E, -Q_P]`; ASU is not used. AirHERO final-population vectors are postprocessed into this unified objective vector. This is a same-space and same-initialization robustness diagnostic. Internal search scalarization and objective mechanisms are not necessarily identical. DCR and OE are unavailable and are not included.\n"
    )
    (ROBUSTNESS / "robustness_plot_caveats.md").write_text(caveat, encoding="utf-8")
    (ROBUSTNESS / "robustness_figure_notes.md").write_text(caveat, encoding="utf-8")
    return {"long_row_count": len(long_rows), "summary_matches": summary_match}


def main() -> None:
    for path in (SPATIAL, PROFILES, HEATMAPS, ROBUSTNESS):
        path.mkdir(parents=True, exist_ok=True)

    selected_seed, mean_asu, seed_audit = select_representative_seed()
    selected_main = next(row for row in read_csv(MAIN / "per_seed_results.csv") if int(number(row.get("seed"))) == selected_seed)
    selected_asu = number(selected_main.get("ASU"))
    route_rows = read_csv(ROUTE_PATH)
    station_rows = read_csv(STATION_PATH)
    airhero.configure_modules(selected_seed)
    all_problem, _, _, _ = airhero.build_problems()
    final_rows = [row for row in read_csv(MAIN / "decoded_deployments.csv") if int(number(row.get("seed"))) == selected_seed]
    final_decision = decision_from_rows(final_rows)
    if final_decision.shape != (K, 5):
        raise RuntimeError(f"selected final deployment has shape {final_decision.shape}, expected {(K, 5)}")

    stage1, stage2_seed, extraction_meta = extract_stage1_and_stage2_seed(selected_seed)
    existing_state = point_state(np.zeros((0, 5), dtype=float), all_problem, station_rows, "existing_only")
    spatial_meta = build_spatial_data(selected_seed, selected_asu, route_rows, station_rows, all_problem, existing_state, stage1, stage2_seed, final_decision)
    profile_meta = build_route_profiles(selected_seed, route_rows, station_rows, all_problem, final_decision)
    heatmap_meta = build_heatmaps()
    robustness_meta = build_robustness()

    write_csv(OUT / "representative_seed_selection_audit.csv", seed_audit)
    algorithm_diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, capture_output=True, text=True, check=False).stdout.strip()
    source_iterations = int(number(json.loads((RAW_MAIN / f"seed_{selected_seed}" / "config_snapshot.json").read_text(encoding="utf-8")).get("iterations_per_stage")))
    iteration_discrepancy = source_iterations != 500
    index_rows = [
        {
            "figure_id": "Figure 1", "proposed_caption": "Stage-I to Stage-II spatial deployment evolution",
            "source_experiment": RAW_MAIN.as_posix(), "primary_data_file": (SPATIAL / "route_samples.csv").as_posix(),
            "secondary_data_files": ";".join((SPATIAL / name).as_posix() for name in ["existing_stations.csv", "stage1_deployment.csv", "stage2_initial_population_seed_solution.csv", "final_airhero_deployment.csv", "stage1_to_final_refinement.csv", "route_polylines.geojson"]),
            "representative_seed": selected_seed, "ready_for_plotting": all(item.values() for item in []),
            "caveat": "Stage-I and Stage-II seed were recovered by deterministic extraction-only Stage-I replay; source package actually uses 150 iterations per stage.",
        },
        {
            "figure_id": "Figure 2", "proposed_caption": "Representative current and predicted route SINR/service profiles",
            "source_experiment": f"{MAIN.as_posix()};{ABLATION.as_posix()}", "primary_data_file": (PROFILES / "representative_route_profiles.csv").as_posix(),
            "secondary_data_files": ";".join((PROFILES / name).as_posix() for name in ["all_route_summary.csv", "representative_route_selection.csv", "representative_route_method_summary.csv", "representative_route_thresholds.csv"]),
            "representative_seed": selected_seed, "ready_for_plotting": True,
            "caveat": "Routes are deterministic median-positive CCU@0 examples, not maximum-improvement examples.",
        },
        {
            "figure_id": "Figure 3", "proposed_caption": "Route-count by deployment-budget sensitivity",
            "source_experiment": SENSITIVITY.as_posix(), "primary_data_file": (HEATMAPS / "route_budget_heatmap_long.csv").as_posix(),
            "secondary_data_files": ";".join((HEATMAPS / name).as_posix() for name in ["heatmap_ASU_mean.csv", "heatmap_Coverage_at_0_mean.csv", "heatmap_runtime_seconds_mean.csv"]),
            "representative_seed": "", "ready_for_plotting": heatmap_meta["cell_count"] == 12,
            "caveat": "Each canonical cell has one seed (2026); standard deviation is blank and the heatmap is single-seed sensitivity.",
        },
        {
            "figure_id": "Figure 4", "proposed_caption": "Fair optimizer robustness under matched search space and initialization",
            "source_experiment": ROBUST_SOURCE.as_posix(), "primary_data_file": (ROBUSTNESS / "robustness_plot_long.csv").as_posix(),
            "secondary_data_files": ";".join((ROBUSTNESS / name).as_posix() for name in ["robustness_plot_summary.csv", "robustness_method_labels.csv", "robustness_plot_caveats.md"]),
            "representative_seed": "", "ready_for_plotting": robustness_meta["long_row_count"] == 84 and robustness_meta["summary_matches"],
            "caveat": "Same-space/same-initialization diagnostic; internal search scalarization is not necessarily identical.",
        },
    ]
    index_rows[0]["ready_for_plotting"] = spatial_meta["stage1_count"] == K1 and spatial_meta["final_count"] == K and spatial_meta["slot_correspondence"]
    write_csv(OUT / "figure_data_index.csv", index_rows)

    readiness = [
        {"criterion": "no_src_algorithms_modifications", "pass": not bool(algorithm_diff), "detail": "git diff -- src/algorithms"},
        {"criterion": "no_completed_experiment_artifacts_overwritten", "pass": True, "detail": "writes confined to 07_figure_data"},
        {"criterion": "representative_seed_ASU_nearest_to_mean", "pass": True, "detail": f"seed={selected_seed}, mean_ASU={mean_asu}"},
        {"criterion": "representative_routes_median_positive_rule", "pass": True, "detail": f"current={profile_meta['current_route_id']}, predicted={profile_meta['predicted_route_id']}"},
        {"criterion": "stage1_actual_optimized_not_centroids", "pass": True, "detail": "deterministic original Stage-I code-path replay"},
        {"criterion": "final_deployment_K10", "pass": spatial_meta["final_count"] == K, "detail": spatial_meta["final_count"]},
        {"criterion": "stage1_deployment_K1_5", "pass": spatial_meta["stage1_count"] == K1, "detail": spatial_meta["stage1_count"]},
        {"criterion": "route_profiles_matched_seed_and_samples", "pass": profile_meta["profile_row_count"] == 180, "detail": profile_meta["profile_row_count"]},
        {"criterion": "all_12_route_budget_cells", "pass": heatmap_meta["cell_count"] == 12, "detail": heatmap_meta["cell_count"]},
        {"criterion": "robustness_7x3x4", "pass": robustness_meta["long_row_count"] == 84, "detail": robustness_meta["long_row_count"]},
        {"criterion": "ASU_not_used_for_pareto_robustness", "pass": True, "detail": "[C_dep,H,-Q_E,-Q_P]"},
        {"criterion": "no_DCR_OE_invented", "pass": True, "detail": "excluded"},
        {"criterion": "requested_500_iterations_matches_completed_source", "pass": not iteration_discrepancy, "detail": f"completed source uses {source_iterations} iterations per stage; request states 500"},
    ]
    write_csv(OUT / "readiness_check.csv", readiness)

    metadata = {
        "generation_timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "output_root": OUT.as_posix(),
        "source_paths": {
            "main_system": MAIN.as_posix(), "raw_main_seed_root": RAW_MAIN.as_posix(), "ablation": ABLATION.as_posix(),
            "route_budget_sensitivity": SENSITIVITY.as_posix(), "fair_optimizer_robustness": ROBUST_SOURCE.as_posix(),
            "route_points": ROUTE_PATH.as_posix(), "existing_stations": STATION_PATH.as_posix(), "study_boundary": BOUNDARY_PATH.as_posix(),
        },
        "script_used": Path(__file__).as_posix(),
        "selected_seed": selected_seed,
        "selected_seed_rule": "minimum absolute distance to three-seed AirHERO mean ASU; smaller seed breaks ties",
        "three_seed_mean_ASU": mean_asu,
        "selected_current_route_id": profile_meta["current_route_id"],
        "selected_predicted_route_id": profile_meta["predicted_route_id"],
        "route_selection_rule": "positive AirHERO-minus-Stagewise CCU@0 closest to median positive improvement; then larger Coverage@0 delta; then ascending route_id",
        "thresholds_db": THRESHOLDS,
        "coordinate_system": COORDINATE_SYSTEM,
        "extraction_only_rerun_used": True,
        "extraction_only_scope": "Stage-I optimization and Stage-II initializer capture for selected seed only; no Stage-II optimization",
        "extraction_metadata": extraction_meta,
        "completed_source_population": airhero.POPULATION,
        "completed_source_iterations_per_stage": source_iterations,
        "requested_text_iterations": 500,
        "iteration_setting_mismatch_caveat": iteration_discrepancy,
        "git_diff_src_algorithms_empty": not bool(algorithm_diff),
        "proxy_labels_preserved": True,
        "verification_previews_generated": False,
    }
    write_json(OUT / "metadata.json", metadata)

    ready_count = sum(truthy(row["ready_for_plotting"]) for row in index_rows)
    index_md = f"""# Final figure data index

All four datasets are extracted without generating publication figures. `{ready_count}/4` figure datasets are structurally ready for plotting.

| Figure | Demonstrates | Primary plotting file | Ready | Key caveat |
|---|---|---|---:|---|
""" + "\n".join(
        f"| {row['figure_id']} | {row['proposed_caption']} | `{row['primary_data_file']}` | {row['ready_for_plotting']} | {row['caveat']} |"
        for row in index_rows
    ) + f"""

Representative AirHERO seed: `{selected_seed}`, selected because ASU `{selected_asu:.12g}` is closest to the three-seed mean `{mean_asu:.12g}`.

- Selected current route: `{profile_meta['current_route_id']}`.
- Selected predicted route: `{profile_meta['predicted_route_id']}`.
- Stage-I intermediate data: recovered by a deterministic Stage-I-only replay; no Stage-II optimization rerun.
- Missing data: none among required outputs after the scoped recovery.
- Route-budget cells: `{heatmap_meta['cell_count']}/12`; each uses seed 2026 only.
- Robustness rows: `{robustness_meta['long_row_count']}/84` (7 methods x 3 seeds x 4 metrics).
- Configuration caveat: the completed adopted source package records `{source_iterations}` iterations per stage, whereas the task text states 500. Plot data preserve the completed source rather than silently changing it.
"""
    (OUT / "figure_data_index.md").write_text(index_md, encoding="utf-8")
    print(json.dumps({
        "output_root": OUT.as_posix(), "selected_seed": selected_seed,
        "selected_current_route": profile_meta["current_route_id"], "selected_predicted_route": profile_meta["predicted_route_id"],
        "heatmap_cells": heatmap_meta["cell_count"], "robustness_rows": robustness_meta["long_row_count"],
        "source_iterations_per_stage": source_iterations, "all_four_structurally_ready": ready_count == 4,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
