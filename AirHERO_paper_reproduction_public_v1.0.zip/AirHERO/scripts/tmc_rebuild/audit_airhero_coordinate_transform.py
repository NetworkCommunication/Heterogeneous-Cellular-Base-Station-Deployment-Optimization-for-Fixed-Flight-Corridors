"""Read-only coordinate provenance audit for the final AirHERO figure data."""
from __future__ import annotations

import csv
import json
import math
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.data.real_map_loader import _meters_per_degree


ROOT = Path("artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/07_figure_data/01_spatial_stage_evolution")
BOUNDARY = Path("data/real/shenyang/shenyang_study_area_boundary.geojson")
ROUTE_SOURCE = Path("artifacts/tmc_rebuild/route_resampling/shenyang_predicted_routes_resampled_points.csv")
STATION_SOURCE = Path("artifacts/tmc_rebuild/station_generation_citywide_route_agnostic/generated_existing_stations_citywide_route_agnostic_low.csv")
POI_SOURCE = Path("data/real/shenyang/shenyang_pois.csv")
ORIGINAL_ROUTE_SOURCE = Path("data/real/shenyang/shenyang_predicted_routes.csv")

MAIN_WINDOW = (113700.0, 118100.0, 11750.0, 16850.0)
SECONDARY_WINDOW = (89600.0, 103800.0, 52250.0, 89000.0)


def read_csv(path: Path) -> List[Dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def write_csv(path: Path, rows: Iterable[Mapping[str, Any]], fields: Sequence[str] | None = None) -> None:
    records = [dict(row) for row in rows]
    columns = list(fields or [])
    if not columns:
        for row in records:
            for key in row:
                if key not in columns:
                    columns.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in records:
            writer.writerow({key: row.get(key, "") for key in columns})


def number(value: Any) -> float:
    return float(value)


def boundary_bbox() -> Tuple[float, float, float, float]:
    obj = json.loads(BOUNDARY.read_text(encoding="utf-8"))
    coords = obj["features"][0]["geometry"]["coordinates"][0]
    lon = [float(point[0]) for point in coords]
    lat = [float(point[1]) for point in coords]
    return min(lon), min(lat), max(lon), max(lat)


def transform_parameters() -> Dict[str, float]:
    min_lon, min_lat, max_lon, max_lat = boundary_bbox()
    center_lat = 0.5 * (min_lat + max_lat)
    m_lon, m_lat = _meters_per_degree(center_lat)
    return {
        "min_lon": min_lon,
        "min_lat": min_lat,
        "max_lon": max_lon,
        "max_lat": max_lat,
        "center_lat": center_lat,
        "m_per_deg_lon": float(m_lon),
        "m_per_deg_lat": float(m_lat),
        "local_bbox_max_x": float((max_lon - min_lon) * m_lon),
        "local_bbox_max_y": float((max_lat - min_lat) * m_lat),
    }


def fit_station_affine(rows: Sequence[Mapping[str, Any]]) -> Dict[str, float]:
    """Recover the affine frame encoded by station lon/lat metadata.

    This is an empirical provenance check, not a substitute for missing source
    metadata.  Separate least-squares fits are valid here because the stored
    artifact is demonstrably axis aligned and contains 144 control points.
    """
    lon = np.asarray([number(row["lon"]) for row in rows], dtype=float)
    lat = np.asarray([number(row["lat"]) for row in rows], dtype=float)
    x = np.asarray([number(row["x"]) for row in rows], dtype=float)
    y = np.asarray([number(row["y"]) for row in rows], dtype=float)
    m_lon, b_x = np.polyfit(lon, x, 1)
    m_lat, b_y = np.polyfit(lat, y, 1)
    return {
        "min_lon": float(-b_x / m_lon),
        "min_lat": float(-b_y / m_lat),
        "max_lon": math.nan,
        "max_lat": math.nan,
        "center_lat": math.nan,
        "m_per_deg_lon": float(m_lon),
        "m_per_deg_lat": float(m_lat),
        "fit_intercept_x": float(b_x),
        "fit_intercept_y": float(b_y),
    }


def forward(lon: float, lat: float, p: Mapping[str, float]) -> Tuple[float, float]:
    return (
        (float(lon) - p["min_lon"]) * p["m_per_deg_lon"],
        (float(lat) - p["min_lat"]) * p["m_per_deg_lat"],
    )


def inverse(x: float, y: float, p: Mapping[str, float]) -> Tuple[float, float]:
    return (
        p["min_lon"] + float(x) / p["m_per_deg_lon"],
        p["min_lat"] + float(y) / p["m_per_deg_lat"],
    )


def residual_rows(rows: Sequence[Mapping[str, Any]], source_kind: str, p: Mapping[str, float], transform_variant: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for index, row in enumerate(rows):
        lon, lat = number(row["lon"]), number(row["lat"])
        observed_x, observed_y = number(row["x"]), number(row["y"])
        calc_x, calc_y = forward(lon, lat, p)
        dx, dy = calc_x - observed_x, calc_y - observed_y
        object_id = str(row.get("station_id") or f"{row.get('route_id', 'route')}:{row.get('point_index', index)}")
        out.append({
            "source_kind": source_kind,
            "transform_variant": transform_variant,
            "object_id": object_id,
            "route_id": row.get("route_id", ""),
            "point_index": row.get("point_index", ""),
            "lon_wgs84": lon,
            "lat_wgs84": lat,
            "observed_x_m": observed_x,
            "observed_y_m": observed_y,
            "recomputed_x_m": calc_x,
            "recomputed_y_m": calc_y,
            "residual_x_m": dx,
            "residual_y_m": dy,
            "residual_2d_m": math.hypot(dx, dy),
        })
    return out


def selected_controls(route_residuals: Sequence[Dict[str, Any]], station_residuals: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    def picks(rows: Sequence[Dict[str, Any]], count: int) -> List[Dict[str, Any]]:
        if not rows:
            return []
        indices = np.linspace(0, len(rows) - 1, count).round().astype(int).tolist()
        return [dict(rows[index]) for index in indices]

    controls = picks(route_residuals, 6) + picks(station_residuals, 6)
    for idx, row in enumerate(controls, start=1):
        row["control_point_index"] = idx
        row["verification_status"] = "pass" if float(row["residual_2d_m"]) <= 0.01 else "review"
    return controls


def convert_route_table(source: Path, destination: Path, p: Mapping[str, float], observed_route_lookup: Mapping[Tuple[str, int], Mapping[str, Any]]) -> None:
    rows = read_csv(source)
    out: List[Dict[str, Any]] = []
    for row in rows:
        lon, lat = inverse(number(row["x"]), number(row["y"]), p)
        converted = dict(row)
        converted["longitude_wgs84"] = lon
        converted["latitude_wgs84"] = lat
        converted["coordinate_transform"] = "LOCAL_METERS_affine_bbox_origin_center_lat_scale"
        key = (str(row.get("route_id", "")), int(float(row.get("sample_index", 0))))
        observed = observed_route_lookup.get(key)
        if observed:
            converted["source_longitude_wgs84"] = number(observed["lon"])
            converted["source_latitude_wgs84"] = number(observed["lat"])
            calc_x, calc_y = forward(number(observed["lon"]), number(observed["lat"]), p)
            converted["source_xy_residual_m"] = math.hypot(calc_x - number(row["x"]), calc_y - number(row["y"]))
        converted["conversion_status"] = "verified_route_frame"
        out.append(converted)
    write_csv(destination, out)


def convert_deployment_ambiguous(source: Path, destination: Path, route_p: Mapping[str, float], station_p: Mapping[str, float]) -> None:
    """Export both evidence-backed candidate locations without choosing one."""
    out: List[Dict[str, Any]] = []
    for row in read_csv(source):
        x, y = number(row["x"]), number(row["y"])
        route_lon, route_lat = inverse(x, y, route_p)
        station_lon, station_lat = inverse(x, y, station_p)
        mean_lat = math.radians(0.5 * (route_lat + station_lat))
        east_m = (route_lon - station_lon) * 111320.0 * math.cos(mean_lat)
        north_m = (route_lat - station_lat) * 111132.0
        converted = dict(row)
        converted.update({
            "longitude_wgs84": "",
            "latitude_wgs84": "",
            "conversion_status": "unverified_mixed_route_and_station_coordinate_frames",
            "route_frame_candidate_longitude_wgs84": route_lon,
            "route_frame_candidate_latitude_wgs84": route_lat,
            "station_frame_candidate_longitude_wgs84": station_lon,
            "station_frame_candidate_latitude_wgs84": station_lat,
            "candidate_frame_separation_m": math.hypot(east_m, north_m),
        })
        out.append(converted)
    write_csv(destination, out)


def crop_outputs(name: str, window: Tuple[float, float, float, float], route_p: Mapping[str, float], station_p: Mapping[str, float]) -> Dict[str, Any]:
    min_x, max_x, min_y, max_y = window
    route_min_lon, route_min_lat = inverse(min_x, min_y, route_p)
    route_max_lon, route_max_lat = inverse(max_x, max_y, route_p)
    station_min_lon, station_min_lat = inverse(min_x, min_y, station_p)
    station_max_lon, station_max_lat = inverse(max_x, max_y, station_p)
    route_corners = [[route_min_lon, route_min_lat], [route_max_lon, route_min_lat], [route_max_lon, route_max_lat], [route_min_lon, route_max_lat], [route_min_lon, route_min_lat]]
    station_corners = [[station_min_lon, station_min_lat], [station_max_lon, station_min_lat], [station_max_lon, station_max_lat], [station_min_lon, station_max_lat], [station_min_lon, station_min_lat]]
    row = {
        "crop_name": name,
        "min_x_m": min_x,
        "max_x_m": max_x,
        "min_y_m": min_y,
        "max_y_m": max_y,
        "min_longitude_wgs84": "",
        "max_longitude_wgs84": "",
        "min_latitude_wgs84": "",
        "max_latitude_wgs84": "",
        "transform_verified": False,
        "verification_status": "unverified_mixed_route_and_station_coordinate_frames",
        "route_frame_candidate_min_longitude": route_min_lon,
        "route_frame_candidate_max_longitude": route_max_lon,
        "route_frame_candidate_min_latitude": route_min_lat,
        "route_frame_candidate_max_latitude": route_max_lat,
        "station_frame_candidate_min_longitude": station_min_lon,
        "station_frame_candidate_max_longitude": station_max_lon,
        "station_frame_candidate_min_latitude": station_min_lat,
        "station_frame_candidate_max_latitude": station_max_lat,
    }
    write_csv(ROOT / f"verified_{name}_crop_wgs84.csv", [row])
    geojson = {
        "type": "FeatureCollection",
        "features": [
            {"type": "Feature", "properties": {"crop_name": name, "status": "candidate_only", "frame": "verified_route_frame", "coordinate_reference_system": "EPSG:4326"}, "geometry": {"type": "Polygon", "coordinates": [route_corners]}},
            {"type": "Feature", "properties": {"crop_name": name, "status": "candidate_only", "frame": "empirically_recovered_station_frame", "coordinate_reference_system": "EPSG:4326"}, "geometry": {"type": "Polygon", "coordinates": [station_corners]}},
        ],
    }
    (ROOT / f"verified_{name}_crop.geojson").write_text(json.dumps(geojson, ensure_ascii=False, indent=2), encoding="utf-8")
    return row


def point_in_window(row: Mapping[str, Any], window: Tuple[float, float, float, float]) -> bool:
    min_x, max_x, min_y, max_y = window
    return min_x <= number(row["x"]) <= max_x and min_y <= number(row["y"]) <= max_y


def linestring_vertex_count(text: str) -> int:
    value = str(text).strip()
    if not value.upper().startswith("LINESTRING"):
        return 0
    body = value[value.find("(") + 1 : value.rfind(")")]
    return len([part for part in body.split(",") if part.strip()])


def main() -> None:
    route_params = transform_parameters()
    route_source_rows = read_csv(ROUTE_SOURCE)
    station_source_rows = read_csv(STATION_SOURCE)
    station_params = fit_station_affine(station_source_rows)
    route_residuals = residual_rows(route_source_rows, "final_route_sample", route_params, "verified_route_POI_frame")
    route_under_station = residual_rows(route_source_rows, "final_route_sample", station_params, "station_frame_cross_check")
    station_residuals = residual_rows(station_source_rows, "final_existing_proxy_station", station_params, "empirically_recovered_station_frame")
    station_under_route = residual_rows(station_source_rows, "final_existing_proxy_station", route_params, "route_frame_cross_check")
    controls = selected_controls(route_residuals, station_residuals)
    route_cross = {row["object_id"]: row for row in route_under_station}
    station_cross = {row["object_id"]: row for row in station_under_route}
    for row in controls:
        cross = route_cross.get(row["object_id"]) if row["source_kind"] == "final_route_sample" else station_cross.get(row["object_id"])
        row["residual_under_other_frame_m"] = cross["residual_2d_m"] if cross else ""
    write_csv(ROOT / "coordinate_control_points.csv", controls)

    route_lookup = {
        (str(row["route_id"]), int(float(row["point_index"]))): row
        for row in route_source_rows
    }
    convert_deployment_ambiguous(ROOT / "stage1_deployment.csv", ROOT / "stage1_deployment_wgs84.csv", route_params, station_params)
    convert_deployment_ambiguous(ROOT / "final_airhero_deployment.csv", ROOT / "final_airhero_deployment_wgs84.csv", route_params, station_params)
    convert_route_table(ROOT / "route_samples.csv", ROOT / "route_samples_wgs84.csv", route_params, route_lookup)

    main_crop = crop_outputs("main", MAIN_WINDOW, route_params, station_params)
    secondary_crop = crop_outputs("secondary", SECONDARY_WINDOW, route_params, station_params)

    poi_rows = read_csv(POI_SOURCE)
    main_pois = [row for row in poi_rows if point_in_window(row, MAIN_WINDOW)]
    secondary_pois = [row for row in poi_rows if point_in_window(row, SECONDARY_WINDOW)]
    main_routes = [row for row in route_source_rows if point_in_window(row, MAIN_WINDOW)]
    secondary_routes = [row for row in route_source_rows if point_in_window(row, SECONDARY_WINDOW)]
    main_stations = [row for row in station_source_rows if point_in_window(row, MAIN_WINDOW)]
    secondary_stations = [row for row in station_source_rows if point_in_window(row, SECONDARY_WINDOW)]

    original_routes = read_csv(ORIGINAL_ROUTE_SOURCE)
    two_vertex_count = sum(linestring_vertex_count(row.get("geometry", "")) == 2 for row in original_routes)
    endpoint_matches = 0
    poi_by_id = {str(row["poi_id"]): row for row in poi_rows}
    grouped: Dict[str, List[Dict[str, str]]] = {}
    for row in route_source_rows:
        grouped.setdefault(str(row["route_id"]), []).append(row)
    endpoint_residuals: List[float] = []
    for route_id, rows in grouped.items():
        ordered = sorted(rows, key=lambda row: int(float(row["point_index"])))
        first, last = ordered[0], ordered[-1]
        origin = poi_by_id.get(str(first.get("origin_poi_id", "")))
        destination = poi_by_id.get(str(first.get("destination_poi_id", "")))
        if origin and destination:
            start_error = math.hypot(number(first["x"]) - number(origin["x"]), number(first["y"]) - number(origin["y"]))
            end_error = math.hypot(number(last["x"]) - number(destination["x"]), number(last["y"]) - number(destination["y"]))
            endpoint_residuals.extend([start_error, end_error])
            if max(start_error, end_error) <= 0.01:
                endpoint_matches += 1

    route_max = max(float(row["residual_2d_m"]) for row in route_residuals)
    route_cross_max = max(float(row["residual_2d_m"]) for row in route_under_station)
    station_native_max = max(float(row["residual_2d_m"]) for row in station_residuals)
    station_cross_max = max(float(row["residual_2d_m"]) for row in station_under_route)
    route_frame_verified = route_max <= 0.01
    station_frame_empirically_verified = station_native_max <= 0.01
    single_transform_verified = route_frame_verified and station_cross_max <= 0.01
    route_main_sw = inverse(MAIN_WINDOW[0], MAIN_WINDOW[2], route_params)
    route_main_ne = inverse(MAIN_WINDOW[1], MAIN_WINDOW[3], route_params)
    station_main_sw = inverse(MAIN_WINDOW[0], MAIN_WINDOW[2], station_params)
    station_main_ne = inverse(MAIN_WINDOW[1], MAIN_WINDOW[3], station_params)
    route_secondary_sw = inverse(SECONDARY_WINDOW[0], SECONDARY_WINDOW[2], route_params)
    route_secondary_ne = inverse(SECONDARY_WINDOW[1], SECONDARY_WINDOW[3], route_params)
    station_secondary_sw = inverse(SECONDARY_WINDOW[0], SECONDARY_WINDOW[2], station_params)
    station_secondary_ne = inverse(SECONDARY_WINDOW[1], SECONDARY_WINDOW[3], station_params)
    algorithm_diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, capture_output=True, text=True, check=False).stdout.strip()

    report = f"""# AirHERO coordinate-transform provenance audit

## Verdict

There is **no single verified local-x/y to WGS84 transformation for the final AirHERO experiment**. The route/POI artifact and the existing-proxy-station artifact encode two different affine scales in nominally the same local coordinate space. Route samples can be placed on WGS84 reliably, but optimized Stage-I/final stations and the requested crop windows cannot be assigned one exact WGS84 location without choosing one of two conflicting frames.

The verified route/POI frame is a repository-defined `LOCAL_METERS` transform, not UTM, AEQD, Web Mercator, or a `pyproj` CRS:

```text
x = (longitude - {route_params['min_lon']:.12f}) * {route_params['m_per_deg_lon']:.12f}
y = (latitude  - {route_params['min_lat']:.12f}) * {route_params['m_per_deg_lat']:.12f}
```

The existing-station CSV instead encodes this empirically recovered affine frame:

```text
x = (longitude - {station_params['min_lon']:.12f}) * {station_params['m_per_deg_lon']:.12f}
y = (latitude  - {station_params['min_lat']:.12f}) * {station_params['m_per_deg_lat']:.12f}
```

## Provenance

- Source CRS: `EPSG:4326` / WGS84 longitude-latitude.
- Destination: repository-defined `LOCAL_METERS`; it has no EPSG code.
- Configured bbox: `[{route_params['min_lon']}, {route_params['min_lat']}, {route_params['max_lon']}, {route_params['max_lat']}]`.
- Both frames have an origin numerically equal to the southwest bbox corner within CSV-fit precision.
- Route scale latitude: bbox midpoint `{route_params['center_lat']:.12f}` degrees.
- Route scales: longitude `{route_params['m_per_deg_lon']:.12f} m/degree`; latitude `{route_params['m_per_deg_lat']:.12f} m/degree`.
- Existing-station encoded scales: longitude `{station_params['m_per_deg_lon']:.12f} m/degree`; latitude `{station_params['m_per_deg_lat']:.12f} m/degree`.
- False easting/northing: effectively `0 m, 0 m` at the bbox southwest corner.
- Axis orientation: x increases eastward; y increases northward.
- Rotation/shear: none. Normalization: none.
- The optimizer later clips new-station decisions to its experiment candidate bounds; that is a decision constraint, not a geographic reprojection.

The route-producing code path is `src/data/shenyang_real_map_preparation.py::extract_shenyang_pois()`, whose local `to_xy()` uses `_meters_per_degree(center_lat)` from `src/data/real_map_loader.py`. Generated routes retain those POI coordinates and the resampled artifact interpolates endpoint lon/lat and endpoint x/y. The generic station module `src/data_generation/existing_bs_nonuniform_hardcore.py::_xy_to_lonlat()` uses `CityMap.geo_m_per_deg`, but the final route-agnostic station package does not preserve the exact source function/configuration that supplied its differing scale. Its frame can be recovered from 144 control points, but its code provenance is incomplete.

## Control-point validation

- Route samples under the route frame: `{len(route_residuals)}` checked; maximum residual `{route_max:.6f} m`; verified: `{route_frame_verified}`.
- Existing stations under their empirically recovered frame: `{len(station_residuals)}` checked; maximum residual `{station_native_max:.6f} m`; internally consistent: `{station_frame_empirically_verified}`.
- Existing stations forced through the route frame: maximum residual `{station_cross_max:.6f} m`.
- Routes forced through the station frame: maximum residual `{route_cross_max:.6f} m`.
- A single common transform is verified: `{single_transform_verified}`.
- Millimetre-scale native residuals reflect CSV rounding; the hundreds-of-metres cross-frame residual is not rounding.

## Why the earlier bbox-stretch conversion is wrong

Mapping `map_extent.csv` min/max directly onto the WGS84 bbox is incorrect because the extent is a padded experiment candidate window, not the geographic bbox extent. More importantly, even the correct route-frame inverse cannot reproduce the existing-station lon/lat metadata. The earlier conversion therefore had both an extent-stretch error and an unrecognized mixed-frame error.

## Crop bounds: not exactly recoverable

No exact verified WGS84 bounds can be reported. The requested CSV/GeoJSON files contain both candidates and mark them `unverified`:

- Main, route-frame candidate: lon `[{route_main_sw[0]:.10f}, {route_main_ne[0]:.10f}]`, lat `[{route_main_sw[1]:.10f}, {route_main_ne[1]:.10f}]`.
- Main, station-frame candidate: lon `[{station_main_sw[0]:.10f}, {station_main_ne[0]:.10f}]`, lat `[{station_main_sw[1]:.10f}, {station_main_ne[1]:.10f}]`.
- Secondary, route-frame candidate: lon `[{route_secondary_sw[0]:.10f}, {route_secondary_ne[0]:.10f}]`, lat `[{route_secondary_sw[1]:.10f}, {route_secondary_ne[1]:.10f}]`.
- Secondary, station-frame candidate: lon `[{station_secondary_sw[0]:.10f}, {station_secondary_ne[0]:.10f}]`, lat `[{station_secondary_sw[1]:.10f}, {station_secondary_ne[1]:.10f}]`.

## Geographic interpretation limits

- Main crop inventory: `{len(main_pois)}` real-map-derived POIs, `{len(main_routes)}` generated route samples, `{len(main_stations)}` simulated/proxy existing stations.
- Secondary crop inventory: `{len(secondary_pois)}` real-map-derived POIs, `{len(secondary_routes)}` generated route samples, `{len(secondary_stations)}` simulated/proxy existing stations.
- The main deployment cluster cannot be scientifically classified as a sparsely developed area from the frozen inputs. Road density, building footprints/heights, land use, and population density were explicitly unavailable to the route-agnostic station generator.
- Route endpoints are aligned to their source POIs: `{endpoint_matches}/{len(grouped)}` routes match both POI endpoints within 0.01 m; maximum endpoint residual is `{max(endpoint_residuals) if endpoint_residuals else math.nan:.6f} m`.
- Original route geometry is two-point straight-line OD geometry for `{two_vertex_count}/{len(original_routes)}` routes. Therefore routes are POI-aligned at endpoints but are not road-network-constrained and must not be described as following visible roads.

## Publication safety

The mixed x/y data are **not safe for a single real-map basemap overlay of routes, existing stations, and optimized deployments**. A route-only overlay is reliable under the route frame. A combined publication figure requires rebuilding or explicitly reconciling the station artifact into the route/POI frame, then re-evaluating the experiment because station relocation changes SINR results. Until then, the local-coordinate spatial figure is safe only as a proxy-coordinate schematic.

## Safety

- Optimizations rerun: false.
- Algorithms modified: false.
- `git diff -- src/algorithms` empty: `{not bool(algorithm_diff)}`.
- Route/station/POI source artifacts modified: false.
"""
    (ROOT / "coordinate_transform_audit.md").write_text(report, encoding="utf-8")
    print(json.dumps({
        "single_transform_verified": single_transform_verified,
        "route_frame_verified": route_frame_verified,
        "station_frame_empirically_verified": station_frame_empirically_verified,
        "station_under_route_max_residual_m": station_cross_max,
        "route_under_station_max_residual_m": route_cross_max,
        "main_crop": main_crop,
        "secondary_crop": secondary_crop,
        "endpoint_matched_routes": endpoint_matches,
        "two_vertex_routes": two_vertex_count,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
