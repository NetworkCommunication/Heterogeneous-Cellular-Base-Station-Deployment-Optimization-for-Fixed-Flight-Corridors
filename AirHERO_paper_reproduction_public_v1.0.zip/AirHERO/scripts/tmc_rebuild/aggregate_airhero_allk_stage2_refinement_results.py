"""Aggregate exploratory AirHERO all-K Stage-II refinement results."""
from __future__ import annotations

import json
import math
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import scripts.run_formal_K10_true_sinr_height_constrained_zmax50 as zmax
from scripts.tmc_rebuild.airhero_allk_stage2_refinement_common import (
    FORMAL_AIRHERO,
    METHOD_KEY,
    PAPER_NAME,
    ROOT,
    SEEDS,
    _as_float,
    load_seed_results,
    mean_std,
)


FORMAL_ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50")


def _read_csv(path: Path) -> List[Dict[str, str]]:
    return zmax.read_csv(path)


def _write_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    zmax.write_csv(path, rows)


def _success(row: Mapping[str, Any]) -> bool:
    value = row.get("success")
    return value is True or str(value).strip().lower() == "true"


def formal_airhero_rows() -> List[Dict[str, Any]]:
    rows = []
    for row in _read_csv(FORMAL_ROOT / "height_constrained_zmax50_all_runs.csv"):
        if row.get("method") == FORMAL_AIRHERO:
            rows.append(dict(row))
    return rows


def compare_to_formal(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    formal_by_seed = {int(float(row.get("seed", -1))): row for row in formal_airhero_rows()}
    out: List[Dict[str, Any]] = []
    for row in rows:
        seed = int(row.get("seed", -1))
        baseline = formal_by_seed.get(seed, {})
        record: Dict[str, Any] = {
            "seed": seed,
            "method_key": METHOD_KEY,
            "paper_facing_name": PAPER_NAME,
            "formal_airhero_method": FORMAL_AIRHERO,
            "variant_success": _success(row),
            "formal_found": bool(baseline),
        }
        for metric, formal_metric in [
            ("ASU", "ASU"),
            ("Q_current", "Q_current"),
            ("Q_future", "Q_future"),
            ("Coverage@0", "Coverage Utility@0"),
            ("Coverage@5", "Coverage Utility@5"),
            ("Coverage@10", "Coverage Utility@10"),
            ("CCU@0", "Continuous Coverage Utility@0"),
            ("CCU@5", "Continuous Coverage Utility@5"),
            ("CCU@10", "Continuous Coverage Utility@10"),
            ("handover_count", "handover_count"),
            ("C_dep", "C_dep"),
            ("runtime_seconds", "runtime"),
        ]:
            variant_value = _as_float(row.get(metric), math.nan)
            formal_value = _as_float(baseline.get(formal_metric), math.nan)
            record[f"variant_{metric}"] = variant_value
            record[f"formal_{metric}"] = formal_value
            record[f"delta_{metric}"] = variant_value - formal_value if not (math.isnan(variant_value) or math.isnan(formal_value)) else ""
            if metric in {"ASU", "Coverage@0", "Coverage@5", "Coverage@10", "CCU@0", "CCU@5", "CCU@10", "Q_current", "Q_future"}:
                record[f"improves_{metric}"] = bool(variant_value > formal_value + 1e-12) if not (math.isnan(variant_value) or math.isnan(formal_value)) else False
        out.append(record)
    return out


def readiness(rows: List[Dict[str, Any]], comparison: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    successful = [row for row in rows if _success(row)]
    variant_mean = np.mean([_as_float(row.get("ASU"), math.nan) for row in successful]) if successful else math.nan
    formal_rows = formal_airhero_rows()
    formal_mean = np.mean([_as_float(row.get("ASU"), math.nan) for row in formal_rows]) if formal_rows else math.nan
    seed_improve = sum(1 for row in comparison if bool(row.get("improves_ASU")))
    coverage_collapse = any(_as_float(row.get("Coverage@0"), 0.0) < 0.50 for row in successful)
    ccu_collapse = any(_as_float(row.get("CCU@0"), 0.0) < 0.45 for row in successful)
    runtime_mean = np.mean([_as_float(row.get("runtime_seconds"), math.nan) for row in successful]) if successful else math.nan
    formal_runtime = np.mean([_as_float(row.get("runtime"), math.nan) for row in formal_rows]) if formal_rows else math.nan
    criteria = [
        ("all_3_seeds_success", len(successful) == len(SEEDS), f"{len(successful)}/{len(SEEDS)} successful"),
        ("height_violations_zero", all(int(_as_float(row.get("height_violation_count"), 1)) == 0 for row in successful), "all successful rows have zero height violations"),
        ("asu_recompute_mismatch_zero", all(not bool(row.get("asu_recompute_mismatch")) for row in successful), "stored and recomputed ASU match"),
        ("mean_ASU_higher_than_formal", bool(variant_mean > formal_mean + 1e-12) if not (math.isnan(variant_mean) or math.isnan(formal_mean)) else False, f"variant={variant_mean}, formal={formal_mean}"),
        ("at_least_2_of_3_seeds_improve_ASU", seed_improve >= 2, f"{seed_improve}/3 seeds improve ASU"),
        ("coverage_CCU_do_not_collapse", not (coverage_collapse or ccu_collapse), f"coverage_collapse={coverage_collapse}; ccu_collapse={ccu_collapse}"),
        ("runtime_increase_reported", True, f"variant_mean_runtime={runtime_mean}; formal_mean_runtime={formal_runtime}"),
    ]
    accepted = all(bool(item[1]) for item in criteria[:-1])
    rows_out = [{"criterion": key, "pass": bool(ok), "detail": detail} for key, ok, detail in criteria]
    rows_out.append({"criterion": "overall_acceptance", "pass": bool(accepted), "detail": "exploratory variant is paper-candidate only if all required criteria pass"})
    return rows_out


def write_report(rows: List[Dict[str, Any]], summary: List[Dict[str, Any]], comparison: List[Dict[str, Any]], check: List[Dict[str, Any]]) -> None:
    successful = [row for row in rows if _success(row)]
    accepted = any(row.get("criterion") == "overall_acceptance" and bool(row.get("pass")) for row in check)
    best = max(successful, key=lambda row: _as_float(row.get("ASU"), -math.inf), default={})
    lines = [
        "# AirHERO-AllKRefine exploratory report",
        "",
        "This package is exploratory only. It does not overwrite frozen formal AirHERO artifacts.",
        "",
        "## Design",
        f"- Method key: `{METHOD_KEY}`",
        f"- Paper-facing temporary name: `{PAPER_NAME}`",
        "- Stage-I is the frozen AirHERO current-route stage.",
        "- Stage-II jointly refines all K=10 stations initialized by Stage-I plus future low-service anchors.",
        "- The frozen response-v3 loop is reused; only Stage-II initialization is replaced in the exploratory script process.",
        "",
        "## Result preview",
        f"- Completed seeds: {len(successful)}/{len(SEEDS)}",
        f"- Best seed ASU: {best.get('ASU', '')} (seed {best.get('seed', '')})",
        f"- Mean ASU: {summary[0].get('ASU_mean', '') if summary else ''}",
        "",
        "## Comparison to formal AirHERO",
    ]
    for row in comparison:
        lines.append(
            f"- Seed {row.get('seed')}: delta ASU={row.get('delta_ASU')}, "
            f"delta Coverage@0={row.get('delta_Coverage@0')}, delta CCU@0={row.get('delta_CCU@0')}"
        )
    lines += [
        "",
        "## Readiness",
    ]
    for row in check:
        lines.append(f"- {row.get('criterion')}: {row.get('pass')} ({row.get('detail')})")
    lines += [
        "",
        "## Verdict",
        "Accepted for broader validation." if accepted else "Not accepted as a replacement; keep diagnostic/exploratory unless explicitly promoted later.",
        "",
        "## Safety",
        "- Existing station artifacts remain simulated/proxy and unchanged.",
        "- Route artifacts remain generated/proxy semantic POI route points and unchanged.",
        "- ASU-v2, true-SINR evaluator, cost, handover, and z_max=50 settings are unchanged.",
        "- No ray tracing or SINR multi-fidelity claim is made.",
    ]
    (ROOT / "airhero_allk_stage2_refinement_final_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    rows = load_seed_results()
    summary = mean_std(rows)
    comparison = compare_to_formal(rows)
    check = readiness(rows, comparison)
    _write_csv(ROOT / "airhero_allk_stage2_refinement_per_seed_results.csv", rows)
    _write_csv(ROOT / "airhero_allk_stage2_refinement_summary.csv", summary)
    _write_csv(ROOT / "airhero_allk_stage2_refinement_comparison_to_formal_airhero.csv", comparison)
    _write_csv(ROOT / "airhero_allk_stage2_refinement_readiness_check.csv", check)
    algorithm_diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, capture_output=True, text=True, check=False).stdout.strip()
    safety = [
        "# Safety check",
        "",
        f"- no frozen formal artifacts overwritten: true",
        f"- legacy/proposed optimizer source files modified by this script: false",
        f"- `git diff -- src/algorithms` empty: {not bool(algorithm_diff)}",
        "- ASU-v2 formula unchanged: true",
        "- station/route/POI artifacts regenerated: false",
        "- generated/proxy labels preserved: true",
        "- exploratory variant clearly separated from formal AirHERO: true",
    ]
    (ROOT / "airhero_allk_stage2_refinement_safety_check.md").write_text("\n".join(safety) + "\n", encoding="utf-8")
    write_report(rows, summary, comparison, check)
    print(json.dumps({"artifact_root": ROOT.as_posix(), "completed": len(rows), "accepted": any(r.get("criterion") == "overall_acceptance" and r.get("pass") for r in check)}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

