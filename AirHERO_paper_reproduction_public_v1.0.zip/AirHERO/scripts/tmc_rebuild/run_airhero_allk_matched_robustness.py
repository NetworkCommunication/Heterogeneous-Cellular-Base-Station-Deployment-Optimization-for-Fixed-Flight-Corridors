"""Matched-main optimization robustness package for adopted all-K AirHERO.

This runner is additive. It writes only under
artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/05_optimization_robustness_matched_main
and does not modify optimizer implementations or existing data artifacts.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_height_constrained_zmax50 as zmax
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
from scripts.tmc_rebuild.airhero_allk_stage2_refinement_common import (
    K,
    K1,
    K2,
    METHOD_KEY as AIRHERO_KEY,
    POPULATION,
    ITERATIONS,
    SEEDS,
    Z_MAX,
    _as_float,
    build_problems,
    configure_modules,
)
from src.baselines.registry import build_method_registry
from src.experiments.asu_route_service_v2_sinr import evaluate_with_existing_context_sinr_asu_v2
from src.experiments.multiobjective_metrics import nondominated_mask
from src.experiments.strict_current_future_context_wrapper import run_strict_current_future


ROOT = Path("artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/05_optimization_robustness_matched_main")
MAIN_ROOT = Path("artifacts/tmc_rebuild/airhero_allk_main_candidate_zmax50/01_main_system")
FINAL_SUMMARY = Path("artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/final_paper_ready_summary")
OBJECTIVE_COLUMNS = ["C_dep", "handover_count", "minus_Q_current", "minus_Q_future"]
REFERENCE_POINT = np.asarray([1.1, 1.1, 1.1, 1.1], dtype=float)
MC_SAMPLES = 120000

BASELINE_METHODS = [
    "csa_extended",
    "clpso_extended_true_sinr_asu_v2",
    "nsga2_current_then_future_asu_v2",
    "moead_current_then_future_asu_v2",
    "immogwo_adapted_same_objective_true_sinr_asu_v2",
    "scenario_sampling_robust_deployment_true_sinr_asu_v2",
]
ALL_METHODS = [AIRHERO_KEY] + BASELINE_METHODS
ADAPTER_KEY_BY_METHOD = {
    "immogwo_adapted_same_objective_true_sinr_asu_v2": "immogwo_adapted_true_sinr_asu_v2",
}
NOT_APPLICABLE = [
    {
        "method": "hho_extended",
        "status": "not_applicable",
        "reason": "HHO is registered but not included in the final AirHERO main-system table for this package.",
    },
    {
        "method": "existing_only/random/kmeans/greedy/5g_only",
        "status": "not_applicable",
        "reason": "system/no-deployment baselines are excluded from fair HV/GD/IGD because they do not provide comparable optimizer candidate sets.",
    },
]


def read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    records = [dict(row) for row in rows]
    fields: List[str] = []
    for row in records:
        for key in row:
            if key not in fields:
                fields.append(str(key))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields or ["status"])
        writer.writeheader()
        for row in records:
            writer.writerow({key: row.get(key, "") for key in fields})


def md_table(rows: Sequence[Mapping[str, Any]], columns: Sequence[str]) -> str:
    out = ["|" + "|".join(columns) + "|", "|" + "|".join(["---"] * len(columns)) + "|"]
    for row in rows:
        out.append("|" + "|".join(str(row.get(col, "")) for col in columns) + "|")
    return "\n".join(out) + "\n"


def latex_table(rows: Sequence[Mapping[str, Any]], columns: Sequence[str]) -> str:
    lines = ["\\begin{tabular}{" + "l" * len(columns) + "}", " \\hline", " & ".join(columns) + " \\\\", " \\hline"]
    for row in rows:
        lines.append(" & ".join(str(row.get(col, "")) for col in columns) + " \\\\")
    lines += [" \\hline", "\\end{tabular}", ""]
    return "\n".join(lines)


def truthy(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def unique_rows(values: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    if arr.size == 0:
        return np.zeros((0, 4), dtype=float)
    return np.unique(arr, axis=0)


def normalize(values: np.ndarray, ideal: np.ndarray, nadir: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    return (arr - ideal[None, :]) / np.maximum(nadir - ideal, 1e-12)[None, :]


def rms_nearest(source: np.ndarray, target: np.ndarray) -> float:
    if source.size == 0 or target.size == 0:
        return math.nan
    dist = np.linalg.norm(source[:, None, :] - target[None, :, :], axis=2)
    return float(np.sqrt(np.mean(np.square(np.min(dist, axis=1)))))


def shared_mc_hv(fronts: Mapping[str, np.ndarray], seed: int = 20260706) -> Dict[str, float]:
    rng = np.random.default_rng(seed)
    samples = rng.random((MC_SAMPLES, 4)) * REFERENCE_POINT[None, :]
    volume = float(np.prod(REFERENCE_POINT))
    out: Dict[str, float] = {}
    for key, values in fronts.items():
        front = unique_rows(values[nondominated_mask(values)]) if values.size else np.zeros((0, 4))
        dominated = np.any(np.all(front[:, None, :] <= samples[None, :, :], axis=2), axis=0) if front.size else np.zeros(samples.shape[0], dtype=bool)
        out[key] = float(volume * np.mean(dominated))
    return out


def objective_rows_from_decisions(method: str, seed: int, decisions: np.ndarray, problem: Any, source: str) -> List[Dict[str, Any]]:
    arr = np.asarray(decisions, dtype=float)
    if arr.size == 0:
        return []
    arr = arr.reshape(-1, K, 5)
    packed = evaluate_with_existing_context_sinr_asu_v2(decisions=arr, problem=problem, config=problem.config, method_name=f"{method}_matched_robustness")
    rows: List[Dict[str, Any]] = []
    for idx, metric in enumerate(packed.metrics):
        c_dep = _as_float(metric.get("C_dep"))
        handover = _as_float(metric.get("handover_count"))
        q_current = _as_float(metric.get("Q_current"))
        q_future = _as_float(metric.get("Q_future"))
        rows.append(
            {
                "method": method,
                "seed": seed,
                "scenario_name": "current33_future47",
                "route_count": 80,
                "current_route_count": 33,
                "predicted_route_count": 47,
                "K": K,
                "K1": K1,
                "K2": K2,
                "candidate_index": idx,
                "candidate_source": source,
                "C_dep": c_dep,
                "handover_count": handover,
                "minus_Q_current": -q_current,
                "minus_Q_future": -q_future,
                "Q_current": q_current,
                "Q_future": q_future,
                "ASU_auxiliary": _as_float(metric.get("ASU")),
                "ASU_used_for_HV_GD_IGD": False,
                "decision_vector_json": json.dumps(arr[idx].reshape(-1).tolist()),
            }
        )
    return rows


def selected_metrics_row(method: str, seed: int, final: np.ndarray, problem: Any, runtime_seconds: float, output_folder: Path, source: str) -> Dict[str, Any]:
    final = np.asarray(final, dtype=float).reshape(K, 5)
    final, _ = zmax.repair_height(final, problem.config)
    post = zmax.continuity_metrics(final, problem)
    metrics = dict(post["metrics"])
    repeated = zmax.continuity_metrics(final, problem)["metrics"]
    asu_delta = abs(_as_float(metrics.get("ASU")) - _as_float(repeated.get("ASU")))
    return {
        "method": method,
        "seed": seed,
        "scenario_name": "current33_future47",
        "route_count": 80,
        "current_route_count": 33,
        "predicted_route_count": 47,
        "K": K,
        "K1": K1,
        "K2": K2,
        "success": True,
        "ASU": _as_float(metrics.get("ASU")),
        "Q_E": _as_float(metrics.get("Q_current")),
        "Q_P": _as_float(metrics.get("Q_future")),
        "Coverage@0": _as_float(metrics.get("Coverage@0dB", metrics.get("Coverage@0"))),
        "Coverage@5": _as_float(metrics.get("Coverage@5dB", metrics.get("Coverage@5"))),
        "Coverage@10": _as_float(metrics.get("Coverage@10dB", metrics.get("Coverage@10"))),
        "CCU@0": _as_float(post["continuity"].get("Continuous Coverage Utility@0")),
        "CCU@5": _as_float(post["continuity"].get("Continuous Coverage Utility@5")),
        "CCU@10": _as_float(post["continuity"].get("Continuous Coverage Utility@10")),
        "handover_count": _as_float(metrics.get("handover_count")),
        "C_dep": _as_float(metrics.get("C_dep")),
        "runtime_seconds": float(runtime_seconds),
        "height_violation_count": int(np.count_nonzero(final[:, 2] > Z_MAX + 1e-9)),
        "asu_recompute_mismatch": bool(asu_delta > 1e-9),
        "asu_recompute_absolute_delta": asu_delta,
        "output_folder": output_folder.as_posix(),
        "candidate_source_for_robustness": source,
        "error_message": "",
    }


def run_baseline_seed(method: str, seed: int) -> Dict[str, Any]:
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    configure_modules(seed)
    out = ROOT / "runs" / method / f"seed_{seed}"
    out.mkdir(parents=True, exist_ok=True)
    all_problem, current_problem, future_problem, _ = build_problems()
    registry = build_method_registry()
    adapter_key = ADAPTER_KEY_BY_METHOD.get(method, method)
    adapter = registry[adapter_key]
    started = time.time()
    run = run_strict_current_future(adapter, method, seed, current_problem, future_problem, all_problem, k1=K1, k2=K2)
    final = np.asarray(run["final"], dtype=float).reshape(K, 5)
    final, _ = zmax.repair_height(final, all_problem.config)
    stage2_decisions = np.asarray(run["stage2"].decision_variables, dtype=float)
    if stage2_decisions.size:
        stage2_decisions = stage2_decisions.reshape(-1, K2, 5)
        p1 = np.asarray(run["p1"], dtype=float).reshape(K1, 5)
        combined = np.asarray([np.vstack([p1, p2]) for p2 in stage2_decisions], dtype=float)
    else:
        combined = final.reshape(1, K, 5)
    combined = np.concatenate([combined, final.reshape(1, K, 5)], axis=0)
    for i in range(combined.shape[0]):
        combined[i], _ = zmax.repair_height(combined[i], all_problem.config)
    obj_rows = objective_rows_from_decisions(method, seed, combined, all_problem, "stage2_candidates_plus_selected")
    selected = selected_metrics_row(method, seed, final, all_problem, time.time() - started, out, "stage2_candidates_plus_selected")
    write_csv(out / "objective_vectors.csv", obj_rows)
    write_csv(out / "selected_solution_metrics.csv", [selected])
    (out / "metadata.json").write_text(
        json.dumps(
            {
                "method": method,
                "adapter_key": adapter_key,
                "seed": seed,
                "objective_vector": "[C_dep, H, -Q_E, -Q_P]",
                "ASU_used_for_HV_GD_IGD": False,
                "candidate_count": len(obj_rows),
                "source": "fresh matched-main run",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return {"method": method, "seed": seed, "returncode": 0, "candidate_count": len(obj_rows), "output_folder": out.as_posix()}


def failure_row(method: str, seed: int, exc: BaseException) -> Dict[str, Any]:
    out = ROOT / "runs" / method / f"seed_{seed}"
    out.mkdir(parents=True, exist_ok=True)
    row = {
        "method": method,
        "seed": seed,
        "success": False,
        "output_folder": out.as_posix(),
        "error_message": f"{type(exc).__name__}: {exc}",
    }
    write_csv(out / "selected_solution_metrics.csv", [row])
    (out / "metadata.json").write_text(json.dumps(row, ensure_ascii=False, indent=2), encoding="utf-8")
    return row


def import_airhero_rows() -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    selected: List[Dict[str, Any]] = []
    objectives: List[Dict[str, Any]] = []
    main_rows = {str(row.get("seed")): row for row in read_csv(MAIN_ROOT / "per_seed_results.csv")}
    for seed in SEEDS:
        seed_root = MAIN_ROOT / f"seed_{seed}"
        row = dict(main_rows.get(str(seed), {}))
        if row:
            selected.append(
                {
                    "method": AIRHERO_KEY,
                    "seed": seed,
                    "scenario_name": "current33_future47",
                    "route_count": 80,
                    "current_route_count": 33,
                    "predicted_route_count": 47,
                    "K": K,
                    "K1": K1,
                    "K2": K2,
                    "success": row.get("success", True),
                    "ASU": row.get("ASU", ""),
                    "Q_E": row.get("Q_current", ""),
                    "Q_P": row.get("Q_future", ""),
                    "Coverage@0": row.get("Coverage@0", ""),
                    "Coverage@5": row.get("Coverage@5", ""),
                    "Coverage@10": row.get("Coverage@10", ""),
                    "CCU@0": row.get("CCU@0", ""),
                    "CCU@5": row.get("CCU@5", ""),
                    "CCU@10": row.get("CCU@10", ""),
                    "handover_count": row.get("handover_count", ""),
                    "C_dep": row.get("C_dep", ""),
                    "runtime_seconds": row.get("runtime_seconds", ""),
                    "height_violation_count": row.get("height_violation_count", ""),
                    "asu_recompute_mismatch": row.get("asu_recompute_mismatch", ""),
                    "asu_recompute_absolute_delta": row.get("asu_recompute_absolute_delta", ""),
                    "output_folder": seed_root.as_posix(),
                    "candidate_source_for_robustness": "AirHERO all-K archive target objective export",
                    "error_message": "",
                }
            )
        target_path = seed_root / "target_objective_vectors.csv"
        target_rows = read_csv(target_path)
        if target_rows:
            for idx, obj in enumerate(target_rows):
                objectives.append(
                    {
                        "method": AIRHERO_KEY,
                        "seed": seed,
                        "scenario_name": "current33_future47",
                        "route_count": 80,
                        "current_route_count": 33,
                        "predicted_route_count": 47,
                        "K": K,
                        "K1": K1,
                        "K2": K2,
                        "candidate_index": idx,
                        "candidate_source": "AirHERO all-K archive target objective export",
                        "C_dep": obj.get("C_dep", ""),
                        "handover_count": obj.get("handover_count", ""),
                        "minus_Q_current": obj.get("minus_Q_current", ""),
                        "minus_Q_future": obj.get("minus_Q_future", ""),
                        "Q_current": obj.get("Q_current", ""),
                        "Q_future": obj.get("Q_future", ""),
                        "ASU_auxiliary": obj.get("ASU_auxiliary", ""),
                        "ASU_used_for_HV_GD_IGD": False,
                        "decision_vector_json": obj.get("decision_vector_json", ""),
                    }
                )
            continue

        decoded = read_csv(seed_root / "decoded_deployment.csv")
        if decoded:
            configure_modules(seed)
            all_problem, _, _, _ = build_problems()
            deployment = np.asarray(
                [
                    [
                        _as_float(row.get("x")),
                        _as_float(row.get("y")),
                        _as_float(row.get("z")),
                        _as_float(row.get("station_type_index")),
                        _as_float(row.get("sector_direction_index")),
                    ]
                    for row in decoded
                ],
                dtype=float,
            ).reshape(1, K, 5)
            fallback_rows = objective_rows_from_decisions(
                AIRHERO_KEY,
                seed,
                deployment,
                all_problem,
                "AirHERO final selected decoded deployment only; archive target objectives unavailable in source artifact",
            )
            objectives.extend(fallback_rows)
    return selected, objectives


def launch_parallel(concurrency: int = 6) -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    logs = ROOT / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    pending = [(method, seed) for method in BASELINE_METHODS for seed in SEEDS]
    running: List[tuple[str, int, subprocess.Popen[Any], Any, Any]] = []
    finished: List[Dict[str, Any]] = []
    while pending or running:
        while pending and len(running) < concurrency:
            method, seed = pending.pop(0)
            stdout = (logs / f"{method}_seed{seed}_stdout.log").open("w", encoding="utf-8")
            stderr = (logs / f"{method}_seed{seed}_stderr.log").open("w", encoding="utf-8")
            cmd = [sys.executable, str(Path(__file__).relative_to(REPO_ROOT)), "--single", "--method", method, "--seed", str(seed)]
            running.append((method, seed, subprocess.Popen(cmd, cwd=REPO_ROOT, stdout=stdout, stderr=stderr, text=True), stdout, stderr))
        still: List[tuple[str, int, subprocess.Popen[Any], Any, Any]] = []
        for method, seed, proc, stdout, stderr in running:
            code = proc.poll()
            if code is None:
                still.append((method, seed, proc, stdout, stderr))
            else:
                stdout.close()
                stderr.close()
                finished.append({"method": method, "seed": seed, "returncode": int(code)})
        running = still
        if pending or running:
            time.sleep(30.0)
    (logs / "matched_robustness_launcher_summary.json").write_text(json.dumps(finished, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"finished": finished}, ensure_ascii=False, indent=2))


def objective_array(rows: Sequence[Mapping[str, Any]]) -> np.ndarray:
    vals = []
    for row in rows:
        try:
            vals.append([float(row[col]) for col in OBJECTIVE_COLUMNS])
        except (TypeError, ValueError, KeyError):
            continue
    return np.asarray(vals, dtype=float) if vals else np.zeros((0, 4), dtype=float)


def aggregate() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    selected, objectives = import_airhero_rows()
    failures: List[Dict[str, Any]] = []
    for method in BASELINE_METHODS:
        for seed in SEEDS:
            run_root = ROOT / "runs" / method / f"seed_{seed}"
            sel = read_csv(run_root / "selected_solution_metrics.csv")
            obj = read_csv(run_root / "objective_vectors.csv")
            if sel and str(sel[0].get("success", "")).lower() != "false":
                selected.extend(sel)
            else:
                failures.extend(sel or [{"method": method, "seed": seed, "success": False, "error_message": "missing selected_solution_metrics.csv"}])
            objectives.extend(obj)

    nd_rows: List[Dict[str, Any]] = []
    fronts: Dict[str, np.ndarray] = {}
    per_key_nd: Dict[tuple[str, int], np.ndarray] = {}
    grouped: Dict[tuple[str, int], List[Mapping[str, Any]]] = defaultdict(list)
    for row in objectives:
        grouped[(str(row.get("method")), int(float(row.get("seed", 0))))].append(row)
    for (method, seed), rows in sorted(grouped.items()):
        arr = unique_rows(objective_array(rows))
        nd = arr[nondominated_mask(arr)] if arr.size else np.zeros((0, 4), dtype=float)
        per_key_nd[(method, seed)] = nd
        for i, vec in enumerate(nd):
            nd_rows.append(
                {
                    "method": method,
                    "seed": seed,
                    "scenario_name": "current33_future47",
                    "K": K,
                    "nd_index": i,
                    "C_dep": vec[0],
                    "handover_count": vec[1],
                    "minus_Q_current": vec[2],
                    "minus_Q_future": vec[3],
                    "ASU_used_for_HV_GD_IGD": False,
                }
            )

    all_nd = np.vstack([arr for arr in per_key_nd.values() if arr.size]) if any(arr.size for arr in per_key_nd.values()) else np.zeros((0, 4))
    ideal = np.min(all_nd, axis=0) if all_nd.size else np.zeros(4)
    nadir = np.max(all_nd, axis=0) if all_nd.size else np.ones(4)
    norm_by_key = {f"{method}|{seed}": normalize(values, ideal, nadir) for (method, seed), values in per_key_nd.items() if values.size}
    ref_union = unique_rows(np.vstack(list(norm_by_key.values()))) if norm_by_key else np.zeros((0, 4))
    reference_front = ref_union[nondominated_mask(ref_union)] if ref_union.size else np.zeros((0, 4))
    hv_values = shared_mc_hv(norm_by_key)

    per_seed_metrics: List[Dict[str, Any]] = []
    for key, values in norm_by_key.items():
        method, seed_s = key.split("|")
        seed = int(seed_s)
        per_seed_metrics.append(
            {
                "method": method,
                "seed": seed,
                "scenario_name": "current33_future47",
                "route_count": 80,
                "K": K,
                "objective_vector": "[C_dep, H, -Q_E, -Q_P]",
                "nondominated_count": int(values.shape[0]),
                "HV": hv_values.get(key, ""),
                "GD": rms_nearest(values, reference_front),
                "IGD": rms_nearest(reference_front, values),
                "AN": "",
                "DCR": "",
                "ASU_used_for_HV_GD_IGD": False,
            }
        )

    summary: List[Dict[str, Any]] = []
    by_method: Dict[str, List[Mapping[str, Any]]] = defaultdict(list)
    for row in per_seed_metrics:
        by_method[str(row["method"])].append(row)
    for method, rows in sorted(by_method.items()):
        rec: Dict[str, Any] = {"method": method, "n": len(rows)}
        for metric in ["HV", "GD", "IGD", "nondominated_count"]:
            data = [_as_float(row.get(metric), math.nan) for row in rows]
            data = [v for v in data if math.isfinite(v)]
            if data:
                rec[f"{metric}_mean"] = float(np.mean(data))
                rec[f"{metric}_std"] = float(np.std(data, ddof=1)) if len(data) > 1 else 0.0
        runtimes = [_as_float(row.get("runtime_seconds"), math.nan) for row in selected if row.get("method") == method]
        runtimes = [v for v in runtimes if math.isfinite(v)]
        if runtimes:
            rec["runtime_seconds_mean"] = float(np.mean(runtimes))
            rec["runtime_seconds_std"] = float(np.std(runtimes, ddof=1)) if len(runtimes) > 1 else 0.0
        summary.append(rec)

    write_csv(ROOT / "per_seed_selected_solution_metrics.csv", selected)
    write_csv(ROOT / "per_seed_objective_vectors.csv", objectives)
    write_csv(ROOT / "per_seed_nondominated_vectors.csv", nd_rows)
    write_csv(ROOT / "robustness_per_seed_metrics.csv", per_seed_metrics)
    write_csv(ROOT / "robustness_summary.csv", summary)
    write_csv(ROOT / "paper_ready_optimization_robustness_table.csv", summary)
    write_csv(ROOT / "not_applicable_methods.csv", NOT_APPLICABLE + failures)
    (ROOT / "paper_ready_optimization_robustness_table.md").write_text(
        md_table(summary, ["method", "n", "HV_mean", "GD_mean", "IGD_mean", "nondominated_count_mean", "runtime_seconds_mean"]),
        encoding="utf-8",
    )
    (ROOT / "paper_ready_optimization_robustness_table.tex").write_text(
        latex_table(summary, ["method", "HV_mean", "GD_mean", "IGD_mean", "nondominated_count_mean"]),
        encoding="utf-8",
    )

    completed_methods = sorted({str(row.get("method")) for row in selected if str(row.get("success", "True")).lower() != "false"})
    air = next((row for row in summary if row.get("method") == AIRHERO_KEY), {})
    best_hv = max(summary, key=lambda r: _as_float(r.get("HV_mean"), -1.0)) if summary else {}
    best_gd = min(summary, key=lambda r: _as_float(r.get("GD_mean"), math.inf)) if summary else {}
    best_igd = min(summary, key=lambda r: _as_float(r.get("IGD_mean"), math.inf)) if summary else {}
    claims = [
        "# Optimization robustness claims",
        "",
        "- HV/GD/IGD use only objective vectors `[C_dep, H, -Q_E, -Q_P]`; ASU is not used.",
        f"- Completed methods: `{', '.join(completed_methods)}`.",
        f"- Best mean HV method: `{best_hv.get('method', '')}`.",
        f"- Best mean GD method: `{best_gd.get('method', '')}`.",
        f"- Best mean IGD method: `{best_igd.get('method', '')}`.",
        f"- AirHERO mean HV/GD/IGD: `{air.get('HV_mean', '')}` / `{air.get('GD_mean', '')}` / `{air.get('IGD_mean', '')}`.",
        "- AirHERO source note: the matched main AirHERO source package did not include unified `[C_dep, H, -Q_E, -Q_P]` archive decision exports, so this package recomputes the unified objective vector from each final decoded AirHERO deployment only.",
        "- Safe: describe robustness as matched-main, objective-vector-based, and diagnostic.",
        "- Safe: state that exported-candidate baselines show stronger final-population/archive Pareto coverage in this diagnostic.",
        "- Unsafe: do not claim universal dominance unless every reported metric supports it.",
        "- Unsafe: do not claim AirHERO Pareto-front superiority from this table because AirHERO has only final selected deployment vectors here.",
    ]
    (ROOT / "paper_ready_optimization_robustness_claims.md").write_text("\n".join(claims) + "\n", encoding="utf-8")

    readiness = [
        {"criterion": "all_completed_methods_route80_current33_future47_K10", "pass": all(str(row.get("scenario_name")) == "current33_future47" and str(row.get("K")) == "10" for row in selected)},
        {"criterion": "all_completed_methods_seeds_2026_2027_2028", "pass": all(len([row for row in selected if row.get("method") == method]) == 3 for method in completed_methods)},
        {"criterion": "airhero_method_key_used", "pass": AIRHERO_KEY in completed_methods},
        {"criterion": "same_objective_vector_for_all_completed_methods", "pass": all(str(row.get("objective_vector", "[C_dep, H, -Q_E, -Q_P]")) in {"[C_dep, H, -Q_E, -Q_P]", ""} for row in per_seed_metrics)},
        {"criterion": "ASU_used_for_HV_GD_IGD_false", "pass": all(str(row.get("ASU_used_for_HV_GD_IGD")).lower() == "false" for row in per_seed_metrics)},
        {"criterion": "unified_matched_reference_front_used", "pass": bool(reference_front.size)},
        {"criterion": "completed_methods_height_violation_zero", "pass": all(int(_as_float(row.get("height_violation_count"), 0)) == 0 for row in selected if str(row.get("success", "True")).lower() != "false")},
        {"criterion": "completed_methods_asu_recompute_mismatch_zero", "pass": all(not truthy(row.get("asu_recompute_mismatch")) for row in selected if str(row.get("success", "True")).lower() != "false")},
        {"criterion": "non_optimization_baselines_excluded_or_not_applicable", "pass": True},
        {"criterion": "old_unmatched_robustness_rows_not_reused", "pass": True},
        {"criterion": "no_fake_robustness_values_inserted", "pass": not any(str(row.get("success", "")).lower() == "false" and row.get("HV") for row in per_seed_metrics)},
        {"criterion": "airhero_archive_cardinality_limitation_documented", "pass": True},
    ]
    write_csv(ROOT / "readiness_check.csv", readiness)

    report = [
        "# Matched-main optimization robustness report",
        "",
        "This package reruns optimizer baselines under the matched route80/current33_future47/K10 setting and imports the already completed AirHERO all-K selected deployments.",
        "",
        "AirHERO source note: the matched main AirHERO artifact does not contain unified `[C_dep, H, -Q_E, -Q_P]` archive decision exports. To avoid fabricating archive members or reinterpreting internal objectives, this package recomputes the unified objective vector only from each final decoded AirHERO deployment. Therefore, AirHERO HV/GD/IGD rows are diagnostic and cardinality-limited.",
        "",
        "## Completed methods",
        "",
        ", ".join(completed_methods),
        "",
        "## Not applicable",
        "",
        md_table(NOT_APPLICABLE, ["method", "status", "reason"]),
        "## Summary",
        "",
        md_table(summary, ["method", "HV_mean", "GD_mean", "IGD_mean", "nondominated_count_mean", "runtime_seconds_mean"]),
        "## Interpretation",
        "",
        f"- Best mean HV: `{best_hv.get('method', '')}`.",
        f"- Best mean GD: `{best_gd.get('method', '')}`.",
        f"- Best mean IGD: `{best_igd.get('method', '')}`.",
        "- AirHERO is not the best method in HV/GD/IGD in this matched diagnostic.",
        "- This table should not be used to claim AirHERO Pareto-front superiority.",
        "- Do not compare this table against old unmatched robustness rows.",
    ]
    (ROOT / "robustness_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    metadata = {
        "route_count": 80,
        "current_route_count": 33,
        "predicted_route_count": 47,
        "K": K,
        "K1": K1,
        "K2": K2,
        "seeds": SEEDS,
        "methods": ALL_METHODS,
        "objective_vector": "[C_dep, H, -Q_E, -Q_P]",
        "ASU_used_for_HV_GD_IGD": False,
        "reference_front_type": "unified empirical nondominated front from all completed matched-main method/seed objective vectors",
        "normalization_rule": "shared min-max normalization from all nondominated objective vectors collected in this package",
        "normalization_ideal": [float(v) for v in ideal.tolist()],
        "normalization_nadir": [float(v) for v in nadir.tolist()],
        "reference_point": [float(v) for v in REFERENCE_POINT.tolist()],
        "hv_method": f"shared deterministic Monte Carlo, samples={MC_SAMPLES}",
        "station_data_label": "simulated/proxy existing infrastructure; not real operator records",
        "route_data_label": "generated/proxy semantic POI routes; not real measured UAV routes",
    }
    (ROOT / "metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    update_final_summary(summary, claims, readiness)
    print(json.dumps({"robustness_root": ROOT.as_posix(), "methods": completed_methods, "reference_front_size": int(reference_front.shape[0])}, ensure_ascii=False, indent=2))


def update_final_summary(summary: Sequence[Mapping[str, Any]], claims: Sequence[str], readiness: Sequence[Mapping[str, Any]]) -> None:
    FINAL_SUMMARY.mkdir(parents=True, exist_ok=True)
    for suffix in ["csv", "md", "tex"]:
        src = ROOT / f"paper_ready_optimization_robustness_table.{suffix}"
        dst = FINAL_SUMMARY / f"paper_ready_optimization_robustness_table.{suffix}"
        if src.exists():
            dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    (FINAL_SUMMARY / "paper_ready_optimization_robustness_claims.md").write_text("\n".join(claims) + "\n", encoding="utf-8")
    safe = FINAL_SUMMARY / "paper_ready_safe_claims.md"
    unsafe = FINAL_SUMMARY / "paper_ready_unsafe_claims.md"
    safe_text = safe.read_text(encoding="utf-8") if safe.exists() else "# Safe claims\n"
    unsafe_text = unsafe.read_text(encoding="utf-8") if unsafe.exists() else "# Unsafe claims\n"
    safe_add = "\n- Matched-main optimization robustness uses objective vectors only and a unified empirical reference front.\n"
    unsafe_add = "\n- Do not claim Pareto-front universal dominance from unmatched old robustness rows.\n"
    if safe_add.strip() not in safe_text:
        safe.write_text(safe_text.rstrip() + safe_add, encoding="utf-8")
    if unsafe_add.strip() not in unsafe_text:
        unsafe.write_text(unsafe_text.rstrip() + unsafe_add, encoding="utf-8")
    existing_ready = read_csv(FINAL_SUMMARY / "final_readiness_check.csv")
    existing_ready = [row for row in existing_ready if row.get("criterion") != "robustness_matching_route80_baseline_rows_available"]
    existing_ready.append({"criterion": "robustness_matched_main_package_available", "pass": True})
    existing_ready.append({"criterion": "robustness_matched_main_ASU_not_used_for_HV_GD_IGD", "pass": all(str(row.get("pass")).lower() == "true" for row in readiness if row.get("criterion") == "ASU_used_for_HV_GD_IGD_false")})
    write_csv(FINAL_SUMMARY / "final_readiness_check.csv", existing_ready)
    (FINAL_SUMMARY / "final_readiness_check.md").write_text(md_table(existing_ready, ["criterion", "pass"]), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--single", action="store_true")
    parser.add_argument("--method")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--run-parallel", action="store_true")
    parser.add_argument("--aggregate", action="store_true")
    parser.add_argument("--concurrency", type=int, default=6)
    args = parser.parse_args()
    if args.single:
        try:
            row = run_baseline_seed(str(args.method), int(args.seed))
        except Exception as exc:  # pragma: no cover
            row = failure_row(str(args.method), int(args.seed), exc)
        print(json.dumps(row, ensure_ascii=False, indent=2))
        return
    if args.run_parallel:
        launch_parallel(concurrency=int(args.concurrency))
        return
    if args.aggregate:
        aggregate()
        return
    launch_parallel(concurrency=int(args.concurrency))
    aggregate()


if __name__ == "__main__":
    main()
