"""Build paper-ready tables for the AirHERO all-K main-candidate package."""
from __future__ import annotations

import csv
import json
import math
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import scripts.run_formal_K10_true_sinr_height_constrained_zmax50 as zmax


ROOT = Path("artifacts/tmc_rebuild/airhero_allk_main_candidate_zmax50")
MAIN = ROOT / "01_main_system"
ABLATION = ROOT / "02_ablation"
ROUTE_BUDGET = ROOT / "03_route_budget_sensitivity"
DENSE = ROOT / "04_dense_existing_sensitivity"
FINAL = ROOT / "final_paper_ready_summary"
OLD_READY = Path("artifacts/tmc_rebuild/final_paper_ready_zmax50_summary_with_clpso")
OLD_FORMAL = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50")
METHOD = "airhero_allk_stage2_refinement_v1"
PAPER = "AirHERO"
PREVIOUS = "true_joint_closed_loop_elite_immigration_response_v3_asu_v2"


def read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    zmax.write_csv(path, rows)


def number(value: Any, default: float = math.nan) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def fmt(mean: Any, std: Any) -> str:
    m = number(mean)
    s = number(std, 0.0)
    if math.isnan(m):
        return ""
    return f"{m:.4f} +/- {s:.4f}"


def main_summary() -> Dict[str, Any]:
    rows = read_csv(MAIN / "airhero_allk_stage2_refinement_summary.csv")
    return dict(rows[0]) if rows else {}


def proposed_table_row(summary: Mapping[str, Any]) -> Dict[str, Any]:
    return {
        "method": METHOD,
        "paper_name": PAPER,
        "method_role": "proposed method; all-K Stage-II refinement candidate",
        "ASU": fmt(summary.get("ASU_mean"), summary.get("ASU_std")),
        "Coverage@0": fmt(summary.get("Coverage@0_mean"), summary.get("Coverage@0_std")),
        "Coverage@10": fmt(summary.get("Coverage@10_mean"), summary.get("Coverage@10_std")),
        "CCU@0": fmt(summary.get("CCU@0_mean"), summary.get("CCU@0_std")),
        "CCU@10": fmt(summary.get("CCU@10_mean"), summary.get("CCU@10_std")),
        "handover_count": fmt(summary.get("handover_count_mean"), summary.get("handover_count_std")),
        "C_dep": fmt(summary.get("C_dep_mean"), summary.get("C_dep_std")),
        "runtime": fmt(summary.get("runtime_seconds_mean"), summary.get("runtime_seconds_std")),
        "_ASU_mean": summary.get("ASU_mean", ""),
        "_Coverage0_mean": summary.get("Coverage@0_mean", ""),
        "_Coverage10_mean": summary.get("Coverage@10_mean", ""),
        "_CCU0_mean": summary.get("CCU@0_mean", ""),
        "_CCU10_mean": summary.get("CCU@10_mean", ""),
        "_runtime_mean": summary.get("runtime_seconds_mean", ""),
    }


def markdown_table(rows: Sequence[Mapping[str, Any]], columns: Sequence[str]) -> str:
    lines = ["|" + "|".join(columns) + "|", "|" + "|".join(["---"] * len(columns)) + "|"]
    for row in rows:
        lines.append("|" + "|".join(str(row.get(col, "")) for col in columns) + "|")
    return "\n".join(lines) + "\n"


def latex_table(rows: Sequence[Mapping[str, Any]], columns: Sequence[str]) -> str:
    lines = ["\\begin{tabular}{" + "l" * len(columns) + "}", "\\toprule", " & ".join(columns) + " \\\\", "\\midrule"]
    for row in rows:
        lines.append(" & ".join(str(row.get(col, "")).replace("_", "\\_") for col in columns) + " \\\\")
    lines += ["\\bottomrule", "\\end{tabular}"]
    return "\n".join(lines) + "\n"


def build_main_system(summary: Mapping[str, Any]) -> None:
    MAIN.mkdir(parents=True, exist_ok=True)
    old_rows = read_csv(OLD_READY / "paper_ready_main_system_table.csv")
    new_row = proposed_table_row(summary)
    rows = [row for row in old_rows if row.get("method") != PREVIOUS]
    rows.append(new_row)
    columns = list(rows[0].keys()) if rows else []
    write_csv(MAIN / "paper_ready_main_system_table_allk_candidate.csv", rows)
    (MAIN / "paper_ready_main_system_table_allk_candidate.md").write_text(markdown_table(rows, columns[:11]), encoding="utf-8")
    (MAIN / "paper_ready_main_system_table_allk_candidate.tex").write_text(latex_table(rows, columns[:11]), encoding="utf-8")
    ranking_rows: List[Dict[str, Any]] = []
    deployment = [row for row in rows if row.get("method") != "existing_only"]
    metrics = [
        ("ASU", "_ASU_mean"),
        ("Coverage@0", "_Coverage0_mean"),
        ("Coverage@10", "_Coverage10_mean"),
        ("CCU@0", "_CCU0_mean"),
        ("CCU@10", "_CCU10_mean"),
    ]
    for label, key in metrics:
        ranked = sorted(deployment, key=lambda row: number(row.get(key), -math.inf), reverse=True)
        for rank, row in enumerate(ranked, start=1):
            ranking_rows.append({"metric": label, "rank": rank, "method": row.get("method"), "paper_name": row.get("paper_name"), "value": row.get(key)})
    write_csv(MAIN / "paper_ready_main_system_ranking_allk_candidate.csv", ranking_rows)
    proposed_ranks = [row for row in ranking_rows if row.get("method") == METHOD]
    claims = [
        "# Main-system claims with all-K AirHERO candidate",
        "",
        "- Baseline rows are reused from the frozen final paper-ready z_max=50 package; they were not rerun.",
        "- The previous formal AirHERO row is removed from the main deployment-method table and replaced by the all-K candidate row.",
        "- Existing-only remains a no-deployment reference, not a deployment optimizer.",
        "",
        "## Proposed ranks excluding existing-only",
    ]
    for row in proposed_ranks:
        claims.append(f"- {row['metric']}: rank {row['rank']} with value {row['value']}")
    claims += [
        "",
        "## Safe interpretation",
        "- The all-K candidate remains comparable against frozen deployment baselines under the same z_max=50 true-SINR setting.",
        "- The all-K candidate improves Coverage@0 and CCU@0 relative to the archived previous AirHERO, but its mean ASU is lower.",
        "- Replacement should be conditional on final readiness, not automatic.",
    ]
    (MAIN / "paper_ready_main_system_claims_allk_candidate.md").write_text("\n".join(claims) + "\n", encoding="utf-8")


def copy_main_aliases() -> None:
    """Create task-requested file aliases without modifying seed outputs."""
    aliases = {
        "airhero_allk_stage2_refinement_per_seed_results.csv": "per_seed_results.csv",
        "airhero_allk_stage2_refinement_summary.csv": "summary.csv",
        "airhero_allk_stage2_refinement_readiness_check.csv": "readiness_check.csv",
        "airhero_allk_stage2_refinement_final_report.md": "main_candidate_report.md",
    }
    for src_name, dst_name in aliases.items():
        src = MAIN / src_name
        if src.exists():
            shutil.copyfile(src, MAIN / dst_name)
    decoded: List[Dict[str, Any]] = []
    components: List[Dict[str, Any]] = []
    runtimes: List[Dict[str, Any]] = []
    (MAIN / "config_snapshots").mkdir(exist_ok=True)
    (MAIN / "logs").mkdir(exist_ok=True)
    for seed in (2026, 2027, 2028):
        seed_dir = MAIN / f"seed_{seed}"
        decoded.extend(read_csv(seed_dir / "decoded_deployment.csv"))
        components.extend(read_csv(seed_dir / "asu_components.csv"))
        runtimes.extend(read_csv(seed_dir / "runtime_summary.csv"))
        if (seed_dir / "config_snapshot.json").exists():
            shutil.copyfile(seed_dir / "config_snapshot.json", MAIN / "config_snapshots" / f"seed_{seed}_config_snapshot.json")
        for log_name in (f"seed_{seed}_stdout.log", f"seed_{seed}_stderr.log"):
            src = MAIN / log_name
            if src.exists():
                shutil.copyfile(src, MAIN / "logs" / log_name)
    write_csv(MAIN / "decoded_deployments.csv", decoded)
    write_csv(MAIN / "asu_components.csv", components)
    write_csv(MAIN / "runtime_summary.csv", runtimes)


def old_formal_summary_row() -> Dict[str, str]:
    for row in read_csv(OLD_FORMAL / "height_constrained_zmax50_mean_std.csv"):
        if row.get("method") == PREVIOUS:
            return row
    return {}


def old_formal_per_seed() -> List[Dict[str, str]]:
    return [row for row in read_csv(OLD_FORMAL / "height_constrained_zmax50_all_runs.csv") if row.get("method") == PREVIOUS]


def build_ablation(summary: Mapping[str, Any]) -> None:
    ABLATION.mkdir(parents=True, exist_ok=True)
    full = {
        "variant": "full_airhero_allk_refinement",
        "variant_role": "full new AirHERO candidate",
        "n": summary.get("n", 3),
        "ASU_mean": summary.get("ASU_mean", ""),
        "Q_current_mean": summary.get("Q_current_mean", ""),
        "Q_future_mean": summary.get("Q_future_mean", ""),
        "Coverage@0_mean": summary.get("Coverage@0_mean", ""),
        "Coverage@10_mean": summary.get("Coverage@10_mean", ""),
        "CCU@0_mean": summary.get("CCU@0_mean", ""),
        "CCU@10_mean": summary.get("CCU@10_mean", ""),
        "handover_count_mean": summary.get("handover_count_mean", ""),
        "C_dep_mean": summary.get("C_dep_mean", ""),
        "runtime_seconds_mean": summary.get("runtime_seconds_mean", ""),
        "height_violation_count": 0,
        "asu_recompute_mismatch": 0,
    }
    old = old_formal_summary_row()
    without_allk = {
        "variant": "without_allk_stage2_refinement",
        "variant_role": "previous context-aware current-to-future staged AirHERO; Stage-II optimizes K2 only",
        "n": old.get("n", 3),
        "ASU_mean": old.get("ASU_mean", ""),
        "Q_current_mean": old.get("Q_current_mean", ""),
        "Q_future_mean": old.get("Q_future_mean", ""),
        "Coverage@0_mean": old.get("Coverage Utility@0_mean", ""),
        "Coverage@10_mean": old.get("Coverage Utility@10_mean", ""),
        "CCU@0_mean": old.get("Continuous Coverage Utility@0_mean", ""),
        "CCU@10_mean": old.get("Continuous Coverage Utility@10_mean", ""),
        "handover_count_mean": old.get("handover_count_mean", ""),
        "C_dep_mean": old.get("C_dep_mean", ""),
        "runtime_seconds_mean": old.get("runtime_mean", ""),
        "height_violation_count": 0,
        "asu_recompute_mismatch": 0,
        "source": OLD_FORMAL.as_posix(),
    }
    rows = [full, without_allk]
    write_csv(ABLATION / "ablation_summary.csv", rows)
    write_csv(ABLATION / "per_seed_results.csv", read_csv(MAIN / "per_seed_results.csv") + old_formal_per_seed())
    write_csv(ABLATION / "decoded_deployments.csv", read_csv(MAIN / "decoded_deployments.csv"))
    write_csv(ABLATION / "asu_components.csv", read_csv(MAIN / "asu_components.csv"))
    write_csv(ABLATION / "runtime_summary.csv", read_csv(MAIN / "runtime_summary.csv"))
    delta = []
    metrics = ["ASU_mean", "Coverage@0_mean", "Coverage@10_mean", "CCU@0_mean", "CCU@10_mean", "runtime_seconds_mean"]
    for metric in metrics:
        delta.append({
            "metric": metric,
            "full_airhero_allk_refinement": full.get(metric, ""),
            "without_allk_stage2_refinement": without_allk.get(metric, ""),
            "delta_full_minus_without_allk": number(full.get(metric), math.nan) - number(without_allk.get(metric), math.nan),
        })
    write_csv(ABLATION / "ablation_delta_table.csv", delta)
    not_applicable = [
        {"variant": "without_stage1_current_priority_initialization", "status": "not_applicable", "reason": "no clean isolated all-K adapter switch without changing candidate initialization logic"},
        {"variant": "without_closed_loop_elite_immigration_response", "status": "not_applicable", "reason": "response-v3 disabling is not exposed as a clean switch for the reused frozen closed-loop path"},
        {"variant": "without_5ga_sector_optimization", "status": "not_applicable", "reason": "requires a separate fixed-sector all-K adapter; not implemented in this integration step"},
        {"variant": "without_heterogeneous_5g_5ga", "status": "not_applicable", "reason": "requires a separate 5G-only all-K adapter; not implemented in this integration step"},
        {"variant": "without_two_stage_deployment", "status": "not_applicable", "reason": "no safe existing one-stage all-K AirHERO adapter under identical response-v3 logic"},
    ]
    write_csv(ABLATION / "not_applicable_variants.csv", not_applicable)
    readiness = [
        {"criterion": "completed_variants_height_violation_zero", "pass": True, "detail": "full and previous formal staged variant have z_max=50 compliance"},
        {"criterion": "completed_variants_asu_recompute_mismatch_zero", "pass": True, "detail": "full all-K main rows have zero mismatch; previous formal rows use archived formal consistency"},
        {"criterion": "full_matches_part1", "pass": True, "detail": "full_airhero_allk_refinement is copied from Part 1 main-system output"},
        {"criterion": "all_requested_variants_completed", "pass": False, "detail": "several variants are not_applicable because no clean switch exists without changing core logic"},
    ]
    write_csv(ABLATION / "readiness_check.csv", readiness)
    claims = [
        "# Ablation claims",
        "",
        "- Completed comparison: full all-K refinement versus previous K2-only Stage-II formal AirHERO.",
        f"- Delta ASU full-minus-previous: {delta[0]['delta_full_minus_without_allk']}",
        "- All-K refinement improves Coverage@0/CCU@0 but lowers mean ASU and increases runtime in this three-seed setting.",
        "- Do not claim all-K refinement improves ASU.",
        "- Do not claim unsupported component ablations for not-applicable variants.",
    ]
    (ABLATION / "ablation_claims.md").write_text("\n".join(claims) + "\n", encoding="utf-8")


def build_final(summary: Mapping[str, Any]) -> None:
    FINAL.mkdir(parents=True, exist_ok=True)
    files = [
        ("main_system", MAIN / "paper_ready_main_system_table_allk_candidate.csv"),
        ("main_ranking", MAIN / "paper_ready_main_system_ranking_allk_candidate.csv"),
        ("ablation", ABLATION / "ablation_summary.csv"),
        ("ablation_delta", ABLATION / "ablation_delta_table.csv"),
    ]
    write_csv(FINAL / "paper_ready_experiment_package_index.csv", [{"section": k, "path": p.as_posix(), "exists": p.exists()} for k, p in files])
    (FINAL / "paper_ready_experiment_package_index.md").write_text(markdown_table([{"section": k, "path": p.as_posix(), "exists": p.exists()} for k, p in files], ["section", "path", "exists"]), encoding="utf-8")
    for src, names in [
        (MAIN / "paper_ready_main_system_table_allk_candidate.csv", ["paper_ready_main_system_table.csv"]),
        (MAIN / "paper_ready_main_system_table_allk_candidate.md", ["paper_ready_main_system_table.md"]),
        (MAIN / "paper_ready_main_system_table_allk_candidate.tex", ["paper_ready_main_system_table.tex"]),
        (MAIN / "paper_ready_main_system_ranking_allk_candidate.csv", ["paper_ready_main_system_ranking.csv"]),
        (MAIN / "paper_ready_main_system_claims_allk_candidate.md", ["paper_ready_main_system_claims.md"]),
        (ABLATION / "ablation_summary.csv", ["paper_ready_ablation_table.csv"]),
        (ABLATION / "ablation_delta_table.csv", ["paper_ready_ablation_delta_table.csv"]),
        (ABLATION / "ablation_claims.md", ["paper_ready_ablation_claims.md"]),
    ]:
        if src.exists():
            for name in names:
                shutil.copyfile(src, FINAL / name)
    ablation_rows = read_csv(ABLATION / "ablation_summary.csv")
    (FINAL / "paper_ready_ablation_table.md").write_text(markdown_table(ablation_rows, list(ablation_rows[0].keys()) if ablation_rows else []), encoding="utf-8")
    (FINAL / "paper_ready_ablation_table.tex").write_text(latex_table(ablation_rows, list(ablation_rows[0].keys())[:8] if ablation_rows else []), encoding="utf-8")
    delta_rows = read_csv(ABLATION / "ablation_delta_table.csv")
    (FINAL / "paper_ready_ablation_delta_table.md").write_text(markdown_table(delta_rows, list(delta_rows[0].keys()) if delta_rows else []), encoding="utf-8")
    (FINAL / "paper_ready_ablation_delta_table.tex").write_text(latex_table(delta_rows, list(delta_rows[0].keys()) if delta_rows else []), encoding="utf-8")
    for name in [
        "paper_ready_route_budget_sensitivity_tables.md",
        "paper_ready_route_budget_sensitivity_claims.md",
        "paper_ready_existing_density_sensitivity_table.csv",
        "paper_ready_existing_density_sensitivity_table.md",
        "paper_ready_existing_density_sensitivity_table.tex",
        "paper_ready_low_density_vs_dense_comparison.csv",
        "paper_ready_low_density_vs_dense_comparison.md",
        "paper_ready_existing_density_claims.md",
    ]:
        (FINAL / name).write_text("Not rerun in this partial package because main all-K candidate readiness did not pass replacement criteria.\n", encoding="utf-8")
    safe = [
        "# Safe claims",
        "",
        "- AirHERO can be described as a two-stage framework where Stage-II may jointly refine all newly deployed stations only for this candidate package.",
        "- The all-K candidate improves low-threshold route coverage/continuity relative to the previous formal AirHERO in the completed K10 z_max=50 rerun.",
        "- Existing stations are simulated/proxy; routes are generated/proxy semantic POI route samples.",
    ]
    unsafe = [
        "# Unsafe claims",
        "",
        "- Do not claim all-K refinement improves ASU; mean ASU is lower than the archived previous formal AirHERO.",
        "- Do not claim all requested ablations/sensitivities are complete.",
        "- Do not claim ray tracing, SINR multi-fidelity, QE hard gate, real operator base stations, or real measured UAV routes.",
    ]
    (FINAL / "paper_ready_safe_claims.md").write_text("\n".join(safe) + "\n", encoding="utf-8")
    (FINAL / "paper_ready_unsafe_claims.md").write_text("\n".join(unsafe) + "\n", encoding="utf-8")
    recommendation = [
        "# Final recommendation",
        "",
        "The all-K Stage-II refinement candidate should not replace the previous formal AirHERO in the paper at this point.",
        "",
        "Reason: the independent three-seed K10 z_max=50 rerun completed and was internally consistent, but mean ASU decreased from the archived formal AirHERO, only 1/3 seeds improved ASU, and runtime increased substantially. The candidate is useful as a coverage/continuity-oriented diagnostic.",
    ]
    (FINAL / "paper_ready_final_recommendation.md").write_text("\n".join(recommendation) + "\n", encoding="utf-8")
    readiness = [
        {"criterion": "main_proposed_method_uses_allK_stage2_refinement", "pass": True},
        {"criterion": "stage2_particle_dimension_is_K_not_K2", "pass": True},
        {"criterion": "stage2_can_mutate_stage1_stations", "pass": True},
        {"criterion": "final_deployment_is_ASU_best_allK_stage2_solution", "pass": True},
        {"criterion": "final_evaluation_uses_all_current_and_predicted_route_points", "pass": True},
        {"criterion": "baselines_not_rerun", "pass": True},
        {"criterion": "existing_baseline_tables_only_merged_not_modified", "pass": True},
        {"criterion": "all_new_proposed_runs_height_violation_zero", "pass": True},
        {"criterion": "all_new_proposed_runs_asu_recompute_mismatch_zero", "pass": True},
        {"criterion": "route_count_sensitivity_uses_canonical_splits", "pass": False, "detail": "not rerun in this partial package"},
        {"criterion": "dense_sensitivity_uses_generated_proxy_3gpp_uma_like", "pass": False, "detail": "not rerun in this partial package"},
        {"criterion": "no_real_operator_bs_claim", "pass": True},
        {"criterion": "no_real_measured_uav_route_claim", "pass": True},
        {"criterion": "no_ray_tracing_claim", "pass": True},
        {"criterion": "no_sinr_multi_fidelity_claim", "pass": True},
        {"criterion": "no_qe_hard_gate_claim", "pass": True},
        {"criterion": "overall_ready_to_replace_previous_formal_airhero", "pass": False},
    ]
    write_csv(FINAL / "final_readiness_check.csv", readiness)
    (FINAL / "final_readiness_check.md").write_text(markdown_table(readiness, ["criterion", "pass", "detail"]), encoding="utf-8")
    metadata = {
        "method_key": METHOD,
        "paper_facing_name": PAPER,
        "main_system_root": MAIN.as_posix(),
        "ablation_root": ABLATION.as_posix(),
        "final_summary_root": FINAL.as_posix(),
        "previous_formal_method": PREVIOUS,
        "replacement_recommended": False,
        "reason": "all-K candidate did not improve mean ASU and did not improve at least 2/3 seeds",
    }
    (FINAL / "allk_candidate_metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")


def build_unrun_sensitivity_sections() -> None:
    ROUTE_BUDGET.mkdir(parents=True, exist_ok=True)
    DENSE.mkdir(parents=True, exist_ok=True)
    reason = (
        "Not rerun because the independent K10 z_max=50 main-candidate rerun did not pass replacement "
        "readiness: mean ASU was lower than archived formal AirHERO and only 1/3 seeds improved ASU. "
        "No baseline or route/station artifact was modified."
    )
    route_status = [{
        "status": "not_run",
        "reason": reason,
        "canonical_splits_required": "20=8/12;40=17/23;50=21/29;80=33/47",
        "requested_K_values": "5;10;15",
    }]
    for name in [
        "per_run_results.csv",
        "route_budget_sensitivity_all_runs.csv",
        "route_budget_sensitivity_summary.csv",
        "paper_ready_route_count_sensitivity_table.csv",
        "paper_ready_budget_sensitivity_table.csv",
        "readiness_check.csv",
    ]:
        write_csv(ROUTE_BUDGET / name, route_status)
    (ROUTE_BUDGET / "paper_ready_sensitivity_claims.md").write_text(
        "# Route-budget sensitivity claims\n\n"
        "The all-K candidate route-budget sensitivity was not rerun in this package because the main candidate did not pass replacement readiness. "
        "Do not claim route-count or K sensitivity for the all-K candidate from this package.\n",
        encoding="utf-8",
    )
    (ROUTE_BUDGET / "logs").mkdir(exist_ok=True)

    dense_status = [{
        "status": "not_run",
        "reason": reason,
        "dense_package_reference": "artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_existing_density_sensitivity_3gpp_uma_like",
        "existing_only_role": "no-deployment reference if used later",
    }]
    for name in [
        "dense_per_seed_results.csv",
        "dense_summary.csv",
        "dense_decoded_deployments.csv",
        "dense_asu_components.csv",
        "dense_runtime_summary.csv",
        "dense_readiness_check.csv",
        "dense_comparison_to_existing_dense_baselines.csv",
        "paper_ready_existing_density_sensitivity_table_allk_candidate.csv",
        "paper_ready_low_density_vs_dense_comparison_allk_candidate.csv",
    ]:
        write_csv(DENSE / name, dense_status)
    (DENSE / "paper_ready_existing_density_claims_allk_candidate.md").write_text(
        "# Existing-density claims\n\n"
        "The dense-infrastructure rerun for the all-K candidate was not executed in this package. "
        "Do not make dense-infrastructure claims for the all-K candidate from these placeholder files.\n",
        encoding="utf-8",
    )
    (DENSE / "dense_report.md").write_text(
        "# Dense existing-infrastructure sensitivity\n\n" + reason + "\n",
        encoding="utf-8",
    )


def main() -> None:
    copy_main_aliases()
    summary = main_summary()
    build_main_system(summary)
    build_ablation(summary)
    build_unrun_sensitivity_sections()
    build_final(summary)
    algorithm_diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, capture_output=True, text=True, check=False).stdout.strip()
    print(json.dumps({"root": ROOT.as_posix(), "main_summary_exists": bool(summary), "src_algorithms_diff_empty": not bool(algorithm_diff)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
