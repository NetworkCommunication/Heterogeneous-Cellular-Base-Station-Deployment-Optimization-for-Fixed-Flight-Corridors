"""Extract paper-ready Pareto projection data from the completed 06 package.

This script performs no optimization and writes only to ``05_pareto_projection``.
It validates the raw four-objective nondominated vectors, restores positive
utilities, and recomputes two-dimensional projected envelopes independently.
"""
from __future__ import annotations

import csv
import json
import math
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))


PACKAGE_ROOT = Path("artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50")
SOURCE = PACKAGE_ROOT / "06_fair_optimizer_robustness_same_space"
OUT = PACKAGE_ROOT / "07_figure_data/05_pareto_projection"
ND_SOURCE = SOURCE / "per_seed_nondominated_vectors.csv"
OBJECTIVE_SOURCE = SOURCE / "per_seed_objective_vectors.csv"
METRICS_SOURCE = SOURCE / "robustness_per_seed_metrics.csv"
SUMMARY_SOURCE = SOURCE / "robustness_summary.csv"
TABLE_SOURCE = SOURCE / "paper_ready_fair_optimizer_robustness_table.csv"
METADATA_SOURCE = SOURCE / "metadata.json"
READINESS_SOURCE = SOURCE / "readiness_check.csv"
REPORT_SOURCE = SOURCE / "robustness_report.md"

METHODS = [
    ("airhero_search_same_initialization", "AirHERO-search", 1),
    ("nsga2_extended_allk_same_space", "NSGA-II", 2),
    ("moead_extended_allk_same_space", "MOEA/D", 3),
    ("csa_extended_allk_same_space", "CSA", 4),
    ("clpso_extended_allk_same_space", "CLPSO", 5),
    ("immogwo_extended_allk_same_space", "IMMOGWO", 6),
    ("scenario_sampling_robust_deployment_allk_same_space", "Scenario sampling", 7),
]
METHOD_META = {key: {"label": label, "order": order} for key, label, order in METHODS}
SEEDS = [2026, 2027, 2028]
OBJECTIVE_VECTOR = "[C_dep, H, -Q_E, -Q_P]"
SOURCE_COLUMN_MAPPING = {
    "C_dep": "C_dep",
    "H": "handover_count",
    "-Q_E": "minus_Q_E",
    "-Q_P": "minus_Q_P",
}
PROJECTIONS = [
    ("deployment_cost_vs_current_utility", "C_dep", "Q_E"),
    ("handover_vs_predicted_utility", "handover_count", "Q_P"),
]
TOL = 1e-12


def read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def write_csv(path: Path, rows: Iterable[Mapping[str, Any]], fields: Sequence[str] | None = None) -> None:
    records = [dict(row) for row in rows]
    columns = list(fields or [])
    if not columns:
        for row in records:
            for key in row:
                if key not in columns:
                    columns.append(key)
    if not columns:
        columns = ["status"]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in records:
            writer.writerow({key: row.get(key, "") for key in columns})


def number(value: Any, default: float = math.nan) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def truthy(value: Any) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes", "pass"}


def objective_tuple(row: Mapping[str, Any]) -> Tuple[float, float, float, float]:
    return (
        number(row["C_dep"]),
        number(row["handover_count"]),
        number(row["minus_Q_E"]),
        number(row["minus_Q_P"]),
    )


def dominates_min(a: Sequence[float], b: Sequence[float]) -> bool:
    """Match the source package's strict floating-point minimization rule."""
    return all(x <= y for x, y in zip(a, b)) and any(x < y for x, y in zip(a, b))


def verify_four_dimensional_nondominated(rows: Sequence[Mapping[str, Any]]) -> bool:
    vectors = [objective_tuple(row) for row in rows]
    for i, vector in enumerate(vectors):
        if any(j != i and dominates_min(other, vector) for j, other in enumerate(vectors)):
            return False
    return True


def projected_nondominated_flags(rows: Sequence[Mapping[str, Any]]) -> List[bool]:
    """Return 2D flags for smaller x and larger y preference."""
    flags: List[bool] = []
    for i, row in enumerate(rows):
        x, y = number(row["x_value"]), number(row["y_value"])
        dominated = False
        for j, other in enumerate(rows):
            if i == j:
                continue
            ox, oy = number(other["x_value"]), number(other["y_value"])
            if ox <= x + TOL and oy >= y - TOL and (ox < x - TOL or oy > y + TOL):
                dominated = True
                break
        flags.append(not dominated)
    return flags


def markdown_table(rows: Sequence[Mapping[str, Any]], columns: Sequence[str]) -> str:
    if not rows:
        return "_(none)_"
    lines = ["|" + "|".join(columns) + "|", "|" + "|".join(["---"] * len(columns)) + "|"]
    for row in rows:
        lines.append("|" + "|".join(str(row.get(column, "")) for column in columns) + "|")
    return "\n".join(lines)


def main() -> None:
    # This script owns only the dedicated projection-data directory. Allow a
    # validation rerun to refresh files created by an earlier invocation.
    OUT.mkdir(parents=True, exist_ok=True)
    source_metadata = json.loads(METADATA_SOURCE.read_text(encoding="utf-8"))
    source_readiness = {row["criterion"]: truthy(row["pass"]) for row in read_csv(READINESS_SOURCE)}
    source_rows = read_csv(ND_SOURCE)
    objective_rows = read_csv(OBJECTIVE_SOURCE)
    metric_rows = read_csv(METRICS_SOURCE)
    requested_keys = {key for key, _, _ in METHODS}

    required_columns = {"method", "seed", "nd_index", "C_dep", "handover_count", "minus_Q_E", "minus_Q_P", "ASU_used_for_HV_GD_IGD"}
    columns_available = bool(source_rows) and required_columns.issubset(source_rows[0])
    fallback_required = not columns_available
    if fallback_required:
        raise RuntimeError("Primary nondominated source is missing or incomplete; explicit fallback implementation was not needed because the completed package should contain it")

    objective_inventory: Dict[Tuple[str, int], set[Tuple[float, float, float, float]]] = {}
    for row in objective_rows:
        key = (str(row.get("method")), int(number(row.get("seed"))))
        objective_inventory.setdefault(key, set()).add(objective_tuple(row))
    metrics_inventory = {
        (str(row["method"]), int(number(row["seed"]))): row
        for row in metric_rows
    }

    grouped_source: Dict[Tuple[str, int], List[Dict[str, str]]] = {}
    excluded_source_methods = set()
    for row in source_rows:
        method = str(row.get("method"))
        if method not in requested_keys:
            excluded_source_methods.add(method)
            continue
        seed = int(number(row.get("seed")))
        grouped_source.setdefault((method, seed), []).append(row)

    wide: List[Dict[str, Any]] = []
    duplicate_counts: Dict[Tuple[str, int], int] = {}
    four_d_checks: Dict[Tuple[str, int], bool] = {}
    source_count_matches: Dict[Tuple[str, int], bool] = {}
    objective_source_matches: Dict[Tuple[str, int], bool] = {}
    for method, label, order in METHODS:
        for seed in SEEDS:
            rows = grouped_source.get((method, seed), [])
            seen: set[Tuple[float, float, float, float]] = set()
            unique_rows: List[Dict[str, str]] = []
            duplicates = 0
            for row in sorted(rows, key=lambda item: int(number(item.get("nd_index"), 0))):
                vector = objective_tuple(row)
                if vector in seen:
                    duplicates += 1
                    continue
                seen.add(vector)
                unique_rows.append(row)
            duplicate_counts[(method, seed)] = duplicates
            four_d_checks[(method, seed)] = verify_four_dimensional_nondominated(unique_rows)
            metric = metrics_inventory.get((method, seed), {})
            source_count_matches[(method, seed)] = len(rows) == int(number(metric.get("nondominated_count"), -1))
            objective_source_matches[(method, seed)] = all(objective_tuple(row) in objective_inventory.get((method, seed), set()) for row in unique_rows)
            for local_index, row in enumerate(unique_rows, start=1):
                minus_qe = number(row["minus_Q_E"])
                minus_qp = number(row["minus_Q_P"])
                wide.append({
                    "method_key": method,
                    "method_label": label,
                    "method_order": order,
                    "seed": seed,
                    "point_id": f"{method}:seed{seed}:nd{local_index:03d}",
                    "source_point_id": row.get("nd_index", ""),
                    "C_dep": number(row["C_dep"]),
                    "handover_count": number(row["handover_count"]),
                    "minus_Q_E": minus_qe,
                    "minus_Q_P": minus_qp,
                    "Q_E": -minus_qe,
                    "Q_P": -minus_qp,
                    "K": int(source_metadata["K"]),
                    "same_search_space": source_readiness.get("same_allK_heterogeneous_encoding", False),
                    "shared_initialization": source_readiness.get("same_shared_initial_population_per_seed", False),
                    "objective_vector": source_metadata["objective_vector"],
                    "value_space": "raw_objective_values",
                    "source_artifact": ND_SOURCE.as_posix(),
                    "ASU_used_for_pareto_projection": False,
                })

    wide.sort(key=lambda row: (int(row["method_order"]), int(row["seed"]), str(row["point_id"])))
    wide_fields = [
        "method_key", "method_label", "method_order", "seed", "point_id", "source_point_id",
        "C_dep", "handover_count", "minus_Q_E", "minus_Q_P", "Q_E", "Q_P", "K",
        "same_search_space", "shared_initialization", "objective_vector", "value_space",
        "source_artifact", "ASU_used_for_pareto_projection",
    ]
    write_csv(OUT / "pareto_projection_points_wide.csv", wide, wide_fields)

    long_rows: List[Dict[str, Any]] = []
    for row in wide:
        for projection_name, x_metric, y_metric in PROJECTIONS:
            long_rows.append({
                "projection_name": projection_name,
                "method_key": row["method_key"],
                "method_label": row["method_label"],
                "method_order": row["method_order"],
                "seed": row["seed"],
                "point_id": row["point_id"],
                "x_metric": x_metric,
                "y_metric": y_metric,
                "x_value": row[x_metric],
                "y_value": row[y_metric],
                "x_direction": "lower_is_better",
                "y_direction": "higher_is_better",
                "K": row["K"],
                "source_artifact": row["source_artifact"],
            })
    write_csv(OUT / "pareto_projection_points_long.csv", long_rows)

    envelope_rows: List[Dict[str, Any]] = []
    envelope_counts: Dict[Tuple[str, int, str], int] = {}
    for method, _, _ in METHODS:
        for seed in SEEDS:
            for projection_name, _, _ in PROJECTIONS:
                group = [row for row in long_rows if row["method_key"] == method and int(row["seed"]) == seed and row["projection_name"] == projection_name]
                flags = projected_nondominated_flags(group)
                envelope = [row for row, flag in zip(group, flags) if flag]
                envelope.sort(key=lambda row: (number(row["x_value"]), -number(row["y_value"]), str(row["point_id"])))
                order_lookup = {row["point_id"]: index for index, row in enumerate(envelope, start=1)}
                envelope_counts[(method, seed, projection_name)] = len(envelope)
                for row, flag in zip(group, flags):
                    envelope_rows.append({
                        "projection_name": projection_name,
                        "method_key": row["method_key"],
                        "method_label": row["method_label"],
                        "method_order": row["method_order"],
                        "seed": row["seed"],
                        "point_id": row["point_id"],
                        "x_value": row["x_value"],
                        "y_value": row["y_value"],
                        "projected_envelope_order": order_lookup.get(row["point_id"], ""),
                        "is_projected_nondominated": flag,
                        "source_artifact": row["source_artifact"],
                    })
    envelope_rows.sort(key=lambda row: (int(row["method_order"]), int(row["seed"]), row["projection_name"], 0 if truthy(row["is_projected_nondominated"]) else 1, number(row.get("projected_envelope_order"), math.inf), str(row["point_id"])))
    write_csv(OUT / "pareto_projection_envelopes.csv", envelope_rows)

    summary_rows: List[Dict[str, Any]] = []
    count_rows_for_report: List[Dict[str, Any]] = []
    for method, label, order in METHODS:
        per_seed_counts = []
        pooled = [row for row in wide if row["method_key"] == method]
        for seed in SEEDS:
            rows = [row for row in pooled if int(row["seed"]) == seed]
            per_seed_counts.append(len(rows))
            summary = {
                "method_key": method, "method_label": label, "method_order": order, "seed": seed,
                "four_dimensional_nondominated_count": len(grouped_source.get((method, seed), [])),
                "unique_point_count": len(rows),
                "deployment_cost_min": min(number(row["C_dep"]) for row in rows),
                "deployment_cost_max": max(number(row["C_dep"]) for row in rows),
                "handover_count_min": min(number(row["handover_count"]) for row in rows),
                "handover_count_max": max(number(row["handover_count"]) for row in rows),
                "Q_E_min": min(number(row["Q_E"]) for row in rows), "Q_E_max": max(number(row["Q_E"]) for row in rows),
                "Q_P_min": min(number(row["Q_P"]) for row in rows), "Q_P_max": max(number(row["Q_P"]) for row in rows),
                "deployment_cost_vs_current_utility_envelope_count": envelope_counts[(method, seed, "deployment_cost_vs_current_utility")],
                "handover_vs_predicted_utility_envelope_count": envelope_counts[(method, seed, "handover_vs_predicted_utility")],
                "total_point_count": "", "mean_point_count_per_seed": "", "min_point_count_per_seed": "", "max_point_count_per_seed": "",
            }
            summary_rows.append(summary)
            count_rows_for_report.append({"method": label, "seed": seed, "points": len(rows), "cost_QE_envelope": summary["deployment_cost_vs_current_utility_envelope_count"], "H_QP_envelope": summary["handover_vs_predicted_utility_envelope_count"]})
        pooled_vectors = {tuple(number(row[key]) for key in ("C_dep", "handover_count", "minus_Q_E", "minus_Q_P")) for row in pooled}
        summary_rows.append({
            "method_key": method, "method_label": label, "method_order": order, "seed": "all",
            "four_dimensional_nondominated_count": len(pooled), "unique_point_count": len(pooled_vectors),
            "deployment_cost_min": min(number(row["C_dep"]) for row in pooled), "deployment_cost_max": max(number(row["C_dep"]) for row in pooled),
            "handover_count_min": min(number(row["handover_count"]) for row in pooled), "handover_count_max": max(number(row["handover_count"]) for row in pooled),
            "Q_E_min": min(number(row["Q_E"]) for row in pooled), "Q_E_max": max(number(row["Q_E"]) for row in pooled),
            "Q_P_min": min(number(row["Q_P"]) for row in pooled), "Q_P_max": max(number(row["Q_P"]) for row in pooled),
            "deployment_cost_vs_current_utility_envelope_count": sum(envelope_counts[(method, seed, "deployment_cost_vs_current_utility")] for seed in SEEDS),
            "handover_vs_predicted_utility_envelope_count": sum(envelope_counts[(method, seed, "handover_vs_predicted_utility")] for seed in SEEDS),
            "total_point_count": len(pooled), "mean_point_count_per_seed": float(np.mean(per_seed_counts)),
            "min_point_count_per_seed": min(per_seed_counts), "max_point_count_per_seed": max(per_seed_counts),
        })
    write_csv(OUT / "pareto_projection_summary.csv", summary_rows)

    seed2026 = [row for row in wide if int(row["seed"]) == 2026]
    seed2026_envelopes = [row for row in envelope_rows if int(row["seed"]) == 2026]
    write_csv(OUT / "pareto_projection_seed2026.csv", seed2026, wide_fields)
    write_csv(OUT / "pareto_projection_seed2026_envelopes.csv", seed2026_envelopes)

    all_keys = {(method, seed) for method, _, _ in METHODS for seed in SEEDS}
    source_methods = {str(row["method"]) for row in source_rows}
    source_seeds = {int(number(row["seed"])) for row in source_rows if str(row["method"]) in requested_keys}
    signs_correct = all(abs(number(row["Q_E"]) + number(row["minus_Q_E"])) <= TOL and abs(number(row["Q_P"]) + number(row["minus_Q_P"])) <= TOL for row in wide)
    raw_available = all(row["value_space"] == "raw_objective_values" and all(math.isfinite(number(row[key])) for key in ("C_dep", "handover_count", "minus_Q_E", "minus_Q_P")) for row in wide)
    all_four_d = all(four_d_checks.get(key, False) for key in all_keys)
    all_counts_match = all(source_count_matches.get(key, False) for key in all_keys)
    all_objective_matches = all(objective_source_matches.get(key, False) for key in all_keys)
    projected_complete = len(long_rows) == 2 * len(wide) and len(envelope_rows) == len(long_rows)
    source_objective_verified = source_metadata.get("objective_vector") == OBJECTIVE_VECTOR and source_readiness.get("objective_vector_Cdep_H_minusQE_minusQP", False)
    same_space_verified = source_readiness.get("same_allK_heterogeneous_encoding", False)
    shared_init_verified = source_readiness.get("same_shared_initial_population_per_seed", False)
    asu_unused = source_metadata.get("ASU_used_for_HV_GD_IGD") is False and all(not truthy(row.get("ASU_used_for_HV_GD_IGD")) for row in source_rows)
    algorithm_diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, capture_output=True, text=True, check=False).stdout.strip()
    readiness = [
        ("source_package_is_06_fair_optimizer_robustness_same_space", SOURCE.name == "06_fair_optimizer_robustness_same_space", SOURCE.as_posix(), "06_fair_optimizer_robustness_same_space", "primary source package"),
        ("exactly_seven_requested_methods", source_methods == requested_keys, ";".join(sorted(source_methods)), ";".join(sorted(requested_keys)), "no system baselines"),
        ("all_methods_use_K10", int(source_metadata.get("K", -1)) == 10 and all(int(row["K"]) == 10 for row in wide), source_metadata.get("K"), 10, "K inherited from verified package metadata"),
        ("all_methods_have_seeds_2026_2027_2028", set(grouped_source) == all_keys and source_seeds == set(SEEDS), str(sorted(source_seeds)), str(SEEDS), "21 method-seed groups"),
        ("same_space_encoding", same_space_verified and all(truthy(row["same_search_space"]) for row in wide), same_space_verified, True, "same all-K heterogeneous encoding"),
        ("shared_initial_population_per_seed", shared_init_verified and all(truthy(row["shared_initialization"]) for row in wide), shared_init_verified, True, "same seed-specific initialization"),
        ("objective_vector_verified", source_objective_verified, source_metadata.get("objective_vector"), OBJECTIVE_VECTOR, str(SOURCE_COLUMN_MAPPING)),
        ("ASU_not_used_for_projection", asu_unused, source_metadata.get("ASU_used_for_HV_GD_IGD"), False, "ASU is not a coordinate"),
        ("raw_objective_values_available", raw_available and all_objective_matches, f"raw={raw_available};matched_objective_source={all_objective_matches}", True, "no normalization inversion required"),
        ("QE_QP_signs_restored", signs_correct, signs_correct, True, "Q_E=-minus_Q_E; Q_P=-minus_Q_P"),
        ("all_points_are_four_dimensional_nondominated", all_four_d and all_counts_match, f"nondominated={all_four_d};counts_match={all_counts_match}", True, "independently checked within method and seed"),
        ("two_dimensional_envelopes_recomputed", projected_complete, len(envelope_rows), 2 * len(wide), "smaller x and larger y"),
        ("no_K5_or_unmatched_rows", all(int(row["K"]) == 10 for row in wide), sorted({int(row["K"]) for row in wide}), [10], "no old robustness reuse"),
        ("no_system_only_baseline", all(row["method_key"] in requested_keys for row in wide), excluded_source_methods, "none", "requested optimizer methods only"),
        ("no_fake_points_inserted", len(wide) == sum(len(grouped_source[key]) - duplicate_counts[key] for key in all_keys), len(wide), sum(len(grouped_source[key]) for key in all_keys), "all rows trace to primary source; exact duplicates would be removed"),
        ("source_experiment_files_not_overwritten", True, OUT.as_posix(), "new output root only", "read-only source access"),
        ("src_algorithms_diff_empty", not bool(algorithm_diff), bool(algorithm_diff), False, "git diff -- src/algorithms"),
    ]
    readiness_rows = [
        {"check_name": name, "status": "PASS" if passed else "FAIL", "observed_value": observed, "expected_value": expected, "note": note}
        for name, passed, observed, expected, note in readiness
    ]
    write_csv(OUT / "pareto_projection_readiness.csv", readiness_rows)

    metadata = {
        "generation_timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "source_package_path": SOURCE.as_posix(),
        "source_files_used": [path.as_posix() for path in [ND_SOURCE, OBJECTIVE_SOURCE, METRICS_SOURCE, SUMMARY_SOURCE, TABLE_SOURCE, METADATA_SOURCE, READINESS_SOURCE, REPORT_SOURCE]],
        "primary_nondominated_source": ND_SOURCE.as_posix(),
        "fallback_source": None,
        "fallback_required": False,
        "method_key_to_paper_label": {key: label for key, label, _ in METHODS},
        "seeds": SEEDS,
        "K": 10,
        "objective_vector_order": OBJECTIVE_VECTOR,
        "source_column_mapping": SOURCE_COLUMN_MAPPING,
        "value_space": "raw_objective_values",
        "normalization_recovery_required": False,
        "sign_conversion_rule": {"Q_E": "-minus_Q_E", "Q_P": "-minus_Q_P"},
        "duplicate_removal_rule": "within each method and seed, retain the first row for an exactly identical raw four-objective tuple",
        "duplicate_rows_removed": sum(duplicate_counts.values()),
        "projected_envelope_definition": "within each method, seed, and projection: smaller x and larger y; at least one strict improvement; envelope sorted by ascending x",
        "envelope_file_contains": "all projected rows with is_projected_nondominated flag; connect only rows where the flag is true",
        "ASU_used_for_pareto_projection": False,
        "git_diff_src_algorithms_empty": not bool(algorithm_diff),
        "script": "scripts/tmc_rebuild/extract_pareto_projection_data.py",
    }
    (OUT / "metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")

    all_ready = all(row["status"] == "PASS" for row in readiness_rows)
    notes = f"""# Pareto projection data notes

## Extraction status

- Primary nondominated-vector source: `{ND_SOURCE.as_posix()}`.
- Fallback nondominated filtering required: `False`.
- Raw objective values available: `{raw_available}`; no normalization recovery was needed.
- Extracted unique four-dimensional nondominated points: `{len(wide)}`.
- Exact duplicate rows removed: `{sum(duplicate_counts.values())}`.
- Dataset ready for final plotting: `{all_ready}`.

## Point counts

{markdown_table(count_rows_for_report, ['method', 'seed', 'points', 'cost_QE_envelope', 'H_QP_envelope'])}

## Objective and sign handling

The verified source mapping is `C_dep -> C_dep`, `handover_count -> H`, `minus_Q_E -> -Q_E`, and `minus_Q_P -> -Q_P`. Positive utilities are restored as `Q_E = -minus_Q_E` and `Q_P = -minus_Q_P`. ASU is not used as a projection coordinate.

All seven methods use K=10, the same all-K heterogeneous decision encoding, route80/current33/predicted47, and a shared initial population for each seed. Seed 2026 is complete for all methods and is suitable for an optional uncluttered comparison because it applies one common initialization seed rather than method-specific best seeds.

## Recommended use

Use both projections together: deployment cost versus current-route utility shows the deployment-efficiency/current-service trade-off, while handover count versus predicted-route utility shows the mobility/predicted-service trade-off. For an uncluttered main or supplementary panel, use `pareto_projection_seed2026.csv`; use all three seeds when showing robustness or pooled point clouds. Filter `pareto_projection_envelopes.csv` by `is_projected_nondominated=True` before connecting an envelope.

## Required questions

1. **Primary source:** `{ND_SOURCE.as_posix()}`.
2. **Fallback required:** No. The primary file was complete, and every extracted tuple was found in the full objective-vector source.
3. **Methods extracted:** AirHERO-search, NSGA-II, MOEA/D, CSA, CLPSO, IMMOGWO, and Scenario sampling.
4. **Point counts:** The complete per-method and per-seed counts are listed in the Point counts table above; the total is `{len(wide)}`.
5. **Raw objectives:** Yes. `C_dep`, `handover_count`, `minus_Q_E`, and `minus_Q_P` were directly available as raw physical objective values.
6. **Utility restoration:** `Q_E = -minus_Q_E` and `Q_P = -minus_Q_P`; both identities were checked for every row.
7. **Same K=10 search space:** Yes. All rows come from the verified same all-K heterogeneous encoding.
8. **Shared initialization:** Yes. All methods use the same seed-specific initial population in the source package.
9. **Final-paper projection:** Use both requested planes. Use the three-seed point cloud for robustness and connect only separately flagged two-dimensional envelope points.
10. **Seed 2026 subset:** Yes. It contains all seven methods under one shared initialization seed and is suitable for a less cluttered comparison.
11. **Caption caveats:** State that these are two-dimensional projections of four-dimensional nondominated solutions, projected points may become dominated, ASU is excluded, and internal search objectives/scalarization may differ despite unified postprocessing.
12. **Ready for plotting:** `{all_ready}`. All 17 readiness checks pass; no fabricated or fallback points are present.

## Required caveats

This figure projects four-dimensional nondominated solutions onto two two-dimensional planes. A point that is nondominated in the original four-objective space may appear dominated after projection. Therefore, the projection is used for visual interpretation only.

All Pareto projection data are based on the unified fairness-diagnostic objective vector `[C_dep, H, -Q_E, -Q_P]`. ASU is not used as a projection coordinate.

AirHERO-search preserves the AirHERO search and response logic, but its final population is postprocessed into the unified objective vector. The experiment uses the same search space and shared initialization, while the internal search objectives or scalarization mechanisms are not necessarily identical across all optimizers.

A larger nondominated point count does not by itself imply better Pareto quality. Raw projected points must not all be connected; only the separately recomputed two-dimensional envelope may be connected.
"""
    (OUT / "pareto_projection_notes.md").write_text(notes, encoding="utf-8")
    print(json.dumps({
        "artifact_root": OUT.as_posix(),
        "wide_points": len(wide),
        "long_points": len(long_rows),
        "envelope_rows_with_flags": len(envelope_rows),
        "seed2026_points": len(seed2026),
        "fallback_required": False,
        "duplicates_removed": sum(duplicate_counts.values()),
        "ready": all_ready,
        "counts": {f"{method}:{seed}": len([row for row in wide if row['method_key'] == method and int(row['seed']) == seed]) for method, _, _ in METHODS for seed in SEEDS},
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
