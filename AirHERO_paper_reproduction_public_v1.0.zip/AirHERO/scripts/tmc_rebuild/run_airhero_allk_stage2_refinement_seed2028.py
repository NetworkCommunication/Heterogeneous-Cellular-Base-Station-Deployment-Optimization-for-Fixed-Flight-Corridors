"""Run exploratory AirHERO all-K Stage-II refinement for seed 2028."""
from __future__ import annotations

import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.tmc_rebuild.airhero_allk_stage2_refinement_common import failure_row, run_seed


if __name__ == "__main__":
    try:
        print(json.dumps(run_seed(2028), ensure_ascii=False, indent=2))
    except Exception as exc:  # keep exploratory package auditable
        print(json.dumps(failure_row(2028, exc), ensure_ascii=False, indent=2))
        raise
