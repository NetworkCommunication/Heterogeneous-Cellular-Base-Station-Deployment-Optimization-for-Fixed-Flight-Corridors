"""Launch the three exploratory AirHERO all-K refinement seed scripts."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
ROOT = REPO_ROOT / os.environ.get("AIRHERO_ALLK_OUTPUT_ROOT", "artifacts/tmc_rebuild/airhero_allk_stage2_refinement_v1_zmax50")
SCRIPTS = [
    "scripts/tmc_rebuild/run_airhero_allk_stage2_refinement_seed2026.py",
    "scripts/tmc_rebuild/run_airhero_allk_stage2_refinement_seed2027.py",
    "scripts/tmc_rebuild/run_airhero_allk_stage2_refinement_seed2028.py",
]


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    started = time.time()
    procs = []
    for script in SCRIPTS:
        seed = Path(script).stem.rsplit("seed", 1)[-1]
        stdout_path = ROOT / f"seed_{seed}_stdout.log"
        stderr_path = ROOT / f"seed_{seed}_stderr.log"
        stdout = stdout_path.open("w", encoding="utf-8")
        stderr = stderr_path.open("w", encoding="utf-8")
        env = os.environ.copy()
        env["AIRHERO_ALLK_OUTPUT_ROOT"] = str(ROOT.relative_to(REPO_ROOT))
        proc = subprocess.Popen(
            [sys.executable, script],
            cwd=REPO_ROOT,
            stdout=stdout,
            stderr=stderr,
            text=True,
            env=env,
        )
        procs.append((script, seed, proc, stdout, stderr, stdout_path, stderr_path))
    rows = []
    for script, seed, proc, stdout, stderr, stdout_path, stderr_path in procs:
        code = proc.wait()
        stdout.close()
        stderr.close()
        rows.append(
            {
                "script": script,
                "seed": int(seed),
                "returncode": int(code),
                "stdout_log": stdout_path.as_posix(),
                "stderr_log": stderr_path.as_posix(),
            }
        )
    summary = {"artifact_root": ROOT.as_posix(), "elapsed_seconds": time.time() - started, "runs": rows}
    (ROOT / "parallel_launcher_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
