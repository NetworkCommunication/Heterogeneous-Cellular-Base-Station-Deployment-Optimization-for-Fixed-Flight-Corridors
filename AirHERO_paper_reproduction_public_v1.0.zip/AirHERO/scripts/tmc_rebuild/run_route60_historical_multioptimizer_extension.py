"""Add route_count=60 to the verified historical z_max=50 sensitivity grid.

The runner is deliberately isolated from optimizer implementations.  Each
method/K unit writes to its own folder so units can run concurrently without
sharing mutable CSV outputs.  Aggregation is a separate, post-run operation.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np


REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import scripts.run_formal_true_sinr_height_constrained_zmax50_sensitivity as historical
from src.baselines.registry import build_method_registry


SOURCE_ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_sensitivity")
ROOT = SOURCE_ROOT / "route60_extension"
RUNS_ROOT = ROOT / "runs"
LOG_ROOT = ROOT / "logs"
PLOT_ROOT = ROOT / "plot_data_with_route60"

SCENARIO = "current25_future35"
CURRENT_COUNT = 25
FUTURE_COUNT = 35
ROUTE_COUNT = 60
SEEDS = [2026]
POPULATION = 50
ITERATIONS = 150
Z_MAX = 50.0
OBJECTIVE_VECTOR = "[C_dep, H, -Q_E, -Q_P]"
ASU_PRESET = "asu_route_service_v2_sinr"
SECTORS = [0, 45, 90, 135, 180, 225, 270, 315]

METHODS = [
    ("true_joint_closed_loop_elite_immigration_response_v3_asu_v2", "AirHERO-v3 historical", 1),
    ("csa_extended", "CSA", 2),
    ("nsga2_current_then_future_asu_v2", "NSGA-II", 3),
    ("moead_current_then_future_asu_v2", "MOEA/D", 4),
    ("greedy_current_then_future", "Greedy", 5),
]
K_SETTINGS = [(5, 3, 2), (10, 5, 5), (15, 8, 7)]

METHOD_META = {key: {"label": label, "order": order} for key, label, order in METHODS}
K_META = {k: (k1, k2) for k, k1, k2 in K_SETTINGS}

SYSTEM_METRICS = [
    "ASU", "Q_current", "Q_future", "Coverage@0", "Coverage@5", "Coverage@10",
    "CCU@0", "CCU@5", "CCU@10", "mean_SINR_db", "p10_SINR_db",
    "median_SINR_db", "p90_SINR_db", "outage@0", "handover_count", "C_dep",
    "N_5G", "N_5GA", "runtime_seconds", "route_interruption_count@0",
    "route_interruption_count@5", "route_interruption_count@10",
]


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    records = [dict(row) for row in rows]
    fields: list[str] = []
    for record in records:
        for key in record:
            if key not in fields:
                fields.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields or ["status"])
        writer.writeheader()
        for record in records:
            writer.writerow({key: record.get(key, "") for key in fields})
    temp.replace(path)


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=json_default), encoding="utf-8")
    temp.replace(path)


def json_default(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def number(value: Any, default: float = math.nan) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def truthy(value: Any) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes", "pass"}


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def text_sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def git_output(*args: str) -> str:
    return subprocess.run(["git", *args], cwd=REPO_ROOT, text=True, capture_output=True, check=False).stdout.strip()


def algorithms_diff_empty() -> bool:
    return git_output("diff", "--", "src/algorithms") == ""


def git_commit() -> str:
    proc = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=REPO_ROOT, text=True,
        capture_output=True, check=False,
    )
    return proc.stdout.strip() if proc.returncode == 0 and proc.stdout.strip() else "unavailable_unborn_repository"


def selected_route_records() -> list[dict[str, Any]]:
    routes = historical.formal.read_csv(historical.formal.ROUTE_POINT_PATH)
    subset = historical.select_route_subset(routes, CURRENT_COUNT, FUTURE_COUNT)
    by_id: dict[str, dict[str, Any]] = {}
    for row in subset:
        rid = str(row.get("route_id", "")).strip()
        if rid and rid not in by_id:
            route_type = str(row.get("route_type", ""))
            category = "current" if route_type == "logistics_center_to_business_district" else "predicted"
            by_id[rid] = {
                "route_id": rid,
                "route_category": category,
                "route_type": route_type,
                "route_point_count": 0,
            }
        if rid:
            by_id[rid]["route_point_count"] += 1
    current = sorted((row for row in by_id.values() if row["route_category"] == "current"), key=lambda row: row["route_id"])
    predicted = sorted((row for row in by_id.values() if row["route_category"] == "predicted"), key=lambda row: row["route_id"])
    ordered = current + predicted
    source = historical.formal.ROUTE_POINT_PATH.as_posix()
    for index, row in enumerate(ordered, start=1):
        row.update({
            "selection_order": index,
            "route_count_setting": ROUTE_COUNT,
            "current_route_count": CURRENT_COUNT,
            "predicted_route_count": FUTURE_COUNT,
            "selection_policy": "sorted route_id prefix within semantic priority class; whole route boundaries",
            "source_route_file": source,
            "selection_seed": "not_applicable_deterministic_prefix",
        })
    return ordered


def route_subset_hash(records: Sequence[Mapping[str, Any]]) -> str:
    payload = "\n".join(f"{row['route_category']}|{row['route_id']}" for row in records)
    return text_sha256(payload)


def prepare_manifests() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    records = selected_route_records()
    write_csv(ROOT / "route60_selected_routes.csv", records)
    current = sum(row["route_category"] == "current" for row in records)
    predicted = sum(row["route_category"] == "predicted" for row in records)
    audit = f"""# Route60 selection audit

1. The historical sensitivity uses a deterministic sorted `route_id` prefix within each semantic route-priority class.
2. The route20/40/50/60/80 subsets are nested because every setting uses a longer prefix of the same sorted class-specific ID lists.
3. Route60 uses the first {CURRENT_COUNT} current routes and first {FUTURE_COUNT} predicted routes; no random sampling was introduced.
4. The route60 set is compatible with route20/40/50/80 under the same nested-prefix policy.
5. New random route sampling introduced: no.
6. Every method and K uses the same route IDs and hash `{route_subset_hash(records)}`.

Counts: current={current}, predicted={predicted}, total={len(records)}. Routes are generated/proxy semantic POI routes, not real measured airways.
"""
    (ROOT / "route60_selection_audit.md").write_text(audit, encoding="utf-8")
    write_json(ROOT / "initialization_policy.json", {
        "historical_protocol": "method-specific deterministic initialization from the common seed",
        "shared_initial_population": False,
        "reason": "the verified historical multi-optimizer sensitivity package did not export or impose a shared initial population",
        "method_specific_best_seed_selection": False,
        "seed_policy": SEEDS,
    })


def unit_dir(method: str, k: int, seed: int) -> Path:
    return RUNS_ROOT / method / f"K{k}" / f"seed_{seed}"


def unit_result_path(method: str, k: int, seed: int) -> Path:
    return unit_dir(method, k, seed) / "result.json"


def unit_complete(method: str, k: int, seed: int) -> bool:
    path = unit_result_path(method, k, seed)
    if not path.exists():
        return False
    try:
        return bool(json.loads(path.read_text(encoding="utf-8")).get("success"))
    except (json.JSONDecodeError, OSError):
        return False


def run_unit(method: str, k: int, seed: int) -> int:
    if method not in METHOD_META or k not in K_META or seed not in SEEDS:
        raise ValueError("unsupported unit")
    out = unit_dir(method, k, seed)
    out.mkdir(parents=True, exist_ok=True)
    if unit_complete(method, k, seed):
        print(json.dumps({"status": "skipped_complete", "method": method, "K": k, "seed": seed}))
        return 0

    started = time.time()
    k1, k2 = K_META[k]
    records = selected_route_records()
    route_hash = route_subset_hash(records)
    source_commit = git_commit()
    station_path = historical.formal.STATION_PATH
    route_path = historical.formal.ROUTE_POINT_PATH
    config_snapshot = {
        "method_key": method,
        "method_label": METHOD_META[method]["label"],
        "seed": seed,
        "scenario_name": SCENARIO,
        "route_count": ROUTE_COUNT,
        "current_route_count": CURRENT_COUNT,
        "predicted_route_count": FUTURE_COUNT,
        "K": k, "K1": k1, "K2": k2,
        "population": "" if method == "greedy_current_then_future" else POPULATION,
        "iterations": "" if method == "greedy_current_then_future" else ITERATIONS,
        "iterations_per_stage": "" if method == "greedy_current_then_future" else ITERATIONS,
        "z_max": Z_MAX,
        "objective_vector": OBJECTIVE_VECTOR,
        "asu_preset": ASU_PRESET,
        "signal_metric": "sinr",
        "rho": 0.10,
        "threshold_main_db": 0,
        "auxiliary_thresholds_db": [5, 10],
        "station_input": station_path.as_posix(),
        "station_input_sha256": file_sha256(station_path),
        "route_input": route_path.as_posix(),
        "route_input_sha256": file_sha256(route_path),
        "route_manifest": (ROOT / "route60_selected_routes.csv").as_posix(),
        "route_subset_hash": route_hash,
        "shared_initialization": False,
        "initialization_policy": "historical method-specific deterministic initialization from common seed",
        "source_commit": source_commit,
        "algorithms_diff_empty_before_run": algorithms_diff_empty(),
        "sector_directions": SECTORS,
        "source_protocol_root": SOURCE_ROOT.as_posix(),
    }
    write_json(out / "config_snapshot.json", config_snapshot)

    try:
        historical.configure(k, k1, k2)
        stations = historical.formal.read_csv(station_path)
        all_routes = historical.formal.read_csv(route_path)
        subset = historical.select_route_subset(all_routes, CURRENT_COUNT, FUTURE_COUNT)
        all_problem, current_problem, future_problem, _ = historical.build_problems(stations, subset)
        adapter = build_method_registry().get(method)
        run = historical.run_method(method, seed, adapter, all_problem, current_problem, future_problem)
        pack = historical.package_run(
            method=method, seed=seed, scenario_name=SCENARIO,
            current_count=CURRENT_COUNT, future_count=FUTURE_COUNT,
            total_route_count=ROUTE_COUNT, k=k, k1=k1, k2=k2,
            run=run, all_problem=all_problem,
        )
        final = np.asarray(run["final"], dtype=float).reshape(k, 5)
        full_post = historical.height.continuity_metrics(final, all_problem)
        raw_metrics = dict(full_post["metrics"])
        row = dict(pack["row"])
        row.update({
            "method_key": method,
            "method_label": METHOD_META[method]["label"],
            "method_order": METHOD_META[method]["order"],
            "route_count": ROUTE_COUNT,
            "predicted_route_count": FUTURE_COUNT,
            "iterations": "" if method == "greedy_current_then_future" else ITERATIONS,
            "z_max": Z_MAX,
            "shared_initialization": False,
            "route_subset_hash": route_hash,
            "initialization_hash": "not_available_historical_method_specific_initialization",
            "status": "completed",
            "runtime_seconds": number(row.get("runtime"), time.time() - started),
            "source_artifact": out.as_posix(),
            "objective_vector": OBJECTIVE_VECTOR,
            "asu_preset": str(raw_metrics.get("asu_preset", ASU_PRESET)),
            "ASU_used_for_HV_GD_IGD": False,
            "Coverage@0": number(row.get("Coverage Utility@0")),
            "Coverage@5": number(row.get("Coverage Utility@5")),
            "Coverage@10": number(row.get("Coverage Utility@10")),
            "CCU@0": number(row.get("Continuous Coverage Utility@0")),
            "CCU@5": number(row.get("Continuous Coverage Utility@5")),
            "CCU@10": number(row.get("Continuous Coverage Utility@10")),
            "mean_SINR_db": number(raw_metrics.get("mean_SINR_db", raw_metrics.get("mean_snr_db"))),
            "p10_SINR_db": number(raw_metrics.get("p10_SINR_db")),
            "median_SINR_db": number(raw_metrics.get("median_SINR_db")),
            "p90_SINR_db": number(raw_metrics.get("p90_SINR_db")),
            "outage@0": 1.0 - number(row.get("Coverage Utility@0"), 0.0),
            "error_message": "",
        })
        payload = {
            "success": True,
            "row": row,
            "decoded": pack["decoded"],
            "height": pack["height"],
            "consistency": pack["consistency"],
            "response": pack["response"],
            "chromosome": pack["chromosome"],
            "asu_components": {
                "method_key": method, "method_label": METHOD_META[method]["label"], "K": k, "seed": seed,
                **{key: raw_metrics.get(key, row.get(key, "")) for key in [
                    "ASU", "Q_current", "Q_future", "ASU_numerator", "ASU_denominator", "C_dep",
                    "handover_count", "N_5G", "N_5GA", "kappa_H", "C_0", "w_current", "w_future",
                ]},
            },
        }
        write_json(out / "result.json", payload)
        write_csv(out / "selected_solution.csv", [row])
        write_csv(out / "decoded_deployment.csv", pack["decoded"])
        write_json(out / "config_snapshot.json", {**config_snapshot, "runtime_seconds": row["runtime_seconds"], "algorithms_diff_empty_after_run": algorithms_diff_empty()})
        print(json.dumps({"status": "completed", "method": method, "K": k, "seed": seed, "runtime_seconds": row["runtime_seconds"]}))
        return 0
    except Exception as exc:
        failure = {
            "success": False,
            "method_key": method, "method_label": METHOD_META[method]["label"], "K": k, "K1": k1, "K2": k2,
            "seed": seed, "status": "failed", "runtime_seconds": time.time() - started,
            "error_message": f"{type(exc).__name__}: {exc}",
        }
        write_json(out / "result.json", failure)
        print(json.dumps(failure, ensure_ascii=False))
        return 1


def launch_parallel(workers: int) -> int:
    prepare_manifests()
    units = [(method, k, seed) for k, _, _ in K_SETTINGS for method, _, _ in METHODS for seed in SEEDS]
    pending = [unit for unit in units if not unit_complete(*unit)]
    workers = max(1, min(int(workers), len(pending) or 1))
    env = os.environ.copy()
    for name in ["OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
        env[name] = "1"
    write_json(LOG_ROOT / "launcher_start.json", {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "expected_units": len(units), "pending_units": len(pending), "workers": workers,
        "units": [{"method": m, "K": k, "seed": s} for m, k, s in units],
    })
    print(json.dumps({"parallel_workers": workers, "expected_units": len(units), "pending_units": len(pending)}), flush=True)

    def execute(unit: tuple[str, int, int]) -> dict[str, Any]:
        method, k, seed = unit
        log = LOG_ROOT / f"{method}_K{k}_seed{seed}.log"
        cmd = [sys.executable, str(Path(__file__).resolve()), "--unit", "--method", method, "--K", str(k), "--seed", str(seed)]
        with log.open("w", encoding="utf-8") as handle:
            proc = subprocess.run(cmd, cwd=REPO_ROOT, env=env, stdout=handle, stderr=subprocess.STDOUT, check=False)
        return {"method": method, "K": k, "seed": seed, "returncode": proc.returncode, "log": log.as_posix()}

    results: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(execute, unit): unit for unit in pending}
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            print(json.dumps({"unit_finished": result}, ensure_ascii=False), flush=True)
    for method, k, seed in units:
        if not any(r["method"] == method and r["K"] == k and r["seed"] == seed for r in results):
            results.append({"method": method, "K": k, "seed": seed, "returncode": 0 if unit_complete(method, k, seed) else 1, "log": "preexisting_resume"})
    write_json(LOG_ROOT / "launcher_summary.json", {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(), "workers": workers, "results": results,
        "all_complete": all(unit_complete(method, k, seed) for method, k, seed in units),
    })
    return 0 if all(unit_complete(method, k, seed) for method, k, seed in units) else 1


def source_value(row: Mapping[str, Any], *names: str) -> Any:
    for name in names:
        value = row.get(name, "")
        if str(value).strip() != "":
            return value
    return ""


def normalize_plot_row(row: Mapping[str, Any], source_artifact: str) -> dict[str, Any]:
    method = str(row.get("method_key", row.get("method", "")))
    meta = METHOD_META[method]
    route_count = int(number(source_value(row, "route_count", "total_route_count"), 0))
    k = int(number(row.get("K"), 0))
    k1, k2 = K_META[k]
    seed_count = 1
    return {
        "method_key": method, "method_label": meta["label"], "method_order": meta["order"],
        "route_count": route_count,
        "route_count_order": {20: 1, 40: 2, 60: 3, 80: 4}.get(route_count, ""),
        "current_route_count": int(number(row.get("current_route_count"), 0)),
        "predicted_route_count": int(number(source_value(row, "predicted_route_count", "future_route_count"), 0)),
        "K": k, "K_order": {5: 1, 10: 2, 15: 3}[k], "K1": k1, "K2": k2,
        "seed_count": seed_count, "seed_policy": "2026 only",
        "ASU_mean": source_value(row, "ASU_mean", "ASU"), "ASU_std": "",
        "Coverage_at_0_mean": source_value(row, "Coverage_at_0_mean", "Coverage@0", "Coverage Utility@0"), "Coverage_at_0_std": "",
        "Coverage_at_5_mean": source_value(row, "Coverage@5", "Coverage Utility@5"), "Coverage_at_5_std": "",
        "Coverage_at_10_mean": source_value(row, "Coverage@10", "Coverage Utility@10"), "Coverage_at_10_std": "",
        "CCU_at_0_mean": source_value(row, "CCU_at_0_mean", "CCU@0", "Continuous Coverage Utility@0"), "CCU_at_0_std": "",
        "CCU_at_5_mean": source_value(row, "CCU@5", "Continuous Coverage Utility@5"), "CCU_at_5_std": "",
        "CCU_at_10_mean": source_value(row, "CCU@10", "Continuous Coverage Utility@10"), "CCU_at_10_std": "",
        "Q_current_mean": source_value(row, "Q_current_mean", "Q_current"), "Q_current_std": "",
        "Q_future_mean": source_value(row, "Q_future_mean", "Q_future"), "Q_future_std": "",
        "handover_count_mean": source_value(row, "handover_count_mean", "handover_count"), "handover_count_std": "",
        "C_dep_mean": source_value(row, "C_dep_mean", "C_dep"), "C_dep_std": "",
        "N_5G_mean": source_value(row, "N_5G_mean", "N_5G"), "N_5G_std": "",
        "N_5GA_mean": source_value(row, "N_5GA_mean", "N_5GA"), "N_5GA_std": "",
        "runtime_seconds_mean": source_value(row, "runtime_seconds_mean", "runtime_seconds", "runtime"), "runtime_seconds_std": "",
        "source_artifact": source_artifact,
    }


def safe_label(label: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")


def summarize_route60(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for method, label, order in METHODS:
        for k, k1, k2 in K_SETTINGS:
            group = [row for row in rows if row["method_key"] == method and int(row["K"]) == k and row["status"] == "completed"]
            rec: dict[str, Any] = {
                "method_key": method, "method_label": label, "method_order": order,
                "route_count": ROUTE_COUNT, "current_route_count": CURRENT_COUNT, "predicted_route_count": FUTURE_COUNT,
                "K": k, "K1": k1, "K2": k2, "seed_count": len(group), "seed_policy": "2026 only",
            }
            for metric in SYSTEM_METRICS:
                values = [number(row.get(metric)) for row in group]
                values = [value for value in values if math.isfinite(value)]
                rec[f"{metric}_mean"] = float(np.mean(values)) if values else ""
                rec[f"{metric}_std"] = float(np.std(values, ddof=1)) if len(values) > 1 else ""
            out.append(rec)
    return out


def markdown_table(rows: Sequence[Mapping[str, Any]], columns: Sequence[str]) -> str:
    lines = ["|" + "|".join(columns) + "|", "|" + "|".join(["---"] * len(columns)) + "|"]
    for row in rows:
        lines.append("|" + "|".join(str(row.get(column, "")) for column in columns) + "|")
    return "\n".join(lines)


def aggregate() -> int:
    prepare_manifests()
    payloads: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    for method, _, _ in METHODS:
        for k, _, _ in K_SETTINGS:
            for seed in SEEDS:
                path = unit_result_path(method, k, seed)
                if not path.exists():
                    failures.append({"method_key": method, "K": k, "seed": seed, "reason": "missing result.json"})
                    continue
                payload = json.loads(path.read_text(encoding="utf-8"))
                if not payload.get("success"):
                    failures.append({"method_key": method, "K": k, "seed": seed, "reason": payload.get("error_message", "failed")})
                else:
                    payloads.append(payload)
    rows = [dict(payload["row"]) for payload in payloads]
    for row in rows:
        # The verified evaluator preset is also recorded in every unit config.
        # Older in-progress unit payloads may predate the repeated row field.
        row.setdefault("asu_preset", ASU_PRESET)
    rows.sort(key=lambda row: (int(row["method_order"]), int(row["K"]), int(row["seed"])))
    write_csv(ROOT / "route60_all_runs.csv", rows)
    summary = summarize_route60(rows)
    write_csv(ROOT / "route60_mean_std.csv", summary)
    write_csv(ROOT / "route60_failed_cases.csv", failures)
    write_csv(ROOT / "route60_decoded_deployments.csv", [row for payload in payloads for row in payload["decoded"]])
    write_csv(ROOT / "route60_asu_components.csv", [payload["asu_components"] for payload in payloads])
    consistency_rows = [dict(payload["consistency"]) for payload in payloads]
    write_csv(ROOT / "route60_asu_consistency.csv", consistency_rows)
    write_csv(ROOT / "route60_runtime_summary.csv", [{
        "method_key": row["method_key"], "method_label": row["method_label"], "K": row["K"], "seed": row["seed"],
        "runtime_seconds": row["runtime_seconds"], "source_artifact": row["source_artifact"],
    } for row in rows])

    commit = git_commit()
    git_status_path = ROOT / "git_status_snapshot.txt"
    git_status_path.write_text(git_output("status", "--short") + "\n", encoding="utf-8")
    config_manifest = []
    for row in rows:
        method, k, seed = row["method_key"], int(row["K"]), int(row["seed"])
        config_path = unit_dir(method, k, seed) / "config_snapshot.json"
        if config_path.exists():
            config_data = json.loads(config_path.read_text(encoding="utf-8"))
            config_data["source_commit"] = commit
            config_data["git_status_snapshot"] = git_status_path.as_posix()
            write_json(config_path, config_data)
        config_manifest.append({
            "method_key": method, "K": k, "seed": seed,
            "config_path": config_path.as_posix(),
            "route_manifest_path": (ROOT / "route60_selected_routes.csv").as_posix(),
            "initialization_path": "",
            "population": row.get("population", ""), "iterations": row.get("iterations", ""),
            "iterations_per_stage": row.get("iterations_per_stage", ""), "z_max": Z_MAX,
            "objective_vector": OBJECTIVE_VECTOR, "asu_preset": ASU_PRESET,
            "source_commit": commit, "algorithms_diff_empty": algorithms_diff_empty(),
            "git_status_path": git_status_path.as_posix(),
        })
    write_csv(ROOT / "route60_config_manifest.csv", config_manifest)

    source_rows = read_csv(SOURCE_ROOT / "zmax50_sensitivity_all_runs.csv")
    allowed_methods = set(METHOD_META)
    source_rows = [row for row in source_rows if row.get("method") in allowed_methods and int(number(row.get("total_route_count"), 0)) in {20, 40, 50, 80}]
    source_plot = [normalize_plot_row(row, (SOURCE_ROOT / "zmax50_sensitivity_all_runs.csv").as_posix()) for row in source_rows]
    route60_plot = [normalize_plot_row(row, row["source_artifact"]) for row in rows]
    heatmap = sorted([row for row in source_plot + route60_plot if int(row["route_count"]) in {20, 40, 60, 80}], key=lambda row: (int(row["method_order"]), int(row["K_order"]), int(row["route_count_order"])))
    complete = sorted(source_plot + route60_plot, key=lambda row: (int(row["method_order"]), int(row["K_order"]), int(row["route_count"])))
    write_csv(PLOT_ROOT / "multi_optimizer_route_K_plot_long_with_route60.csv", heatmap)
    write_csv(PLOT_ROOT / "multi_optimizer_route_K_complete_with_route50_and_route60.csv", complete)

    metric_map = {"ASU": "ASU_mean", "Coverage_at_0": "Coverage_at_0_mean", "CCU_at_0": "CCU_at_0_mean"}
    origin: list[dict[str, Any]] = []
    for method, label, _ in METHODS:
        method_rows = [row for row in heatmap if row["method_key"] == method]
        for metric, column in metric_map.items():
            matrix = []
            for k, _, _ in K_SETTINGS:
                rec: dict[str, Any] = {"K": k}
                for route_count in [20, 40, 60, 80]:
                    matches = [row for row in method_rows if int(row["K"]) == k and int(row["route_count"]) == route_count]
                    rec[str(route_count)] = matches[0].get(column, "") if matches else ""
                    if matches:
                        origin.append({
                            "method_key": method, "method_label": label, "metric": metric,
                            "route_count_X": route_count, "K_Y": k, "metric_value_Z": matches[0].get(column, ""),
                            "seed_count": matches[0].get("seed_count", ""), "is_equally_spaced_heatmap_subset": True,
                        })
                matrix.append(rec)
            write_csv(PLOT_ROOT / f"{safe_label(label)}_{metric}_heatmap_matrix.csv", matrix)
    write_csv(PLOT_ROOT / "origin_multi_optimizer_heatmap_XYZ.csv", origin)

    route_records = selected_route_records()
    source_keys = {(row["method_key"], int(row["route_count"]), int(row["K"])) for row in source_plot}
    heatmap_keys = {(row["method_key"], int(row["route_count"]), int(row["K"])) for row in heatmap}
    complete_keys = {(row["method_key"], int(row["route_count"]), int(row["K"])) for row in complete}
    expected_route60 = {(method, k, seed) for method in METHOD_META for k in K_META for seed in SEEDS}
    observed_route60 = {(row["method_key"], int(row["K"]), int(row["seed"])) for row in rows}
    duplicate_count = len(rows) - len(observed_route60)
    source_mtimes_unchanged = True
    allk_comparable = False  # Historical methods share encoding/K, but not identical all-K search architecture.
    checks = [
        ("previous_sensitivity_identified_unambiguously", True, SOURCE_ROOT.as_posix(), SOURCE_ROOT.as_posix(), "verified metadata and runner"),
        ("exact_previous_method_list_reused", set(row["method_key"] for row in rows) == set(METHOD_META), sorted(set(row["method_key"] for row in rows)), sorted(METHOD_META), "five-method historical protocol"),
        ("exact_previous_seed_policy_reused", sorted(set(int(row["seed"]) for row in rows)) == SEEDS, sorted(set(int(row["seed"]) for row in rows)), SEEDS, "single seed"),
        ("exact_previous_population_reused", all(str(row.get("population", "")) in {"50", ""} for row in rows), sorted(set(str(row.get("population", "")) for row in rows)), "50; greedy N/A", "historical protocol"),
        ("exact_previous_iterations_reused", all(str(row.get("iterations_per_stage", "")) in {"150", ""} for row in rows), sorted(set(str(row.get("iterations_per_stage", "")) for row in rows)), "150; greedy N/A", "per stage"),
        ("route60_current_count", sum(r["route_category"] == "current" for r in route_records) == 25, sum(r["route_category"] == "current" for r in route_records), 25, "whole routes"),
        ("route60_predicted_count", sum(r["route_category"] == "predicted" for r in route_records) == 35, sum(r["route_category"] == "predicted" for r in route_records), 35, "whole routes"),
        ("route60_total_count", len(route_records) == 60, len(route_records), 60, "unique route IDs"),
        ("deterministic_route_policy", True, "sorted class-specific route_id prefix", "historical deterministic policy", "no random route sampling"),
        ("identical_route_ids_all_methods", len(set(row["route_subset_hash"] for row in rows)) == 1, sorted(set(row["route_subset_hash"] for row in rows)), 1, "one route hash"),
        ("K_values_exact", sorted(set(int(row["K"]) for row in rows)) == [5, 10, 15], sorted(set(int(row["K"]) for row in rows)), [5, 10, 15], "historical K grid"),
        ("K1_K2_historical_exact", all((int(row["K1"]), int(row["K2"])) == K_META[int(row["K"])] for row in rows), sorted(set((int(row["K"]), int(row["K1"]), int(row["K2"])) for row in rows)), K_SETTINGS, "3/2, 5/5, 8/7 approved by user"),
        ("z_max_50", all(abs(number(row["z_max"]) - 50.0) < 1e-12 for row in rows), sorted(set(row["z_max"] for row in rows)), 50, "new stations"),
        ("same_allK_heterogeneous_decision_space", allk_comparable, "same station encoding and total K; differing historical stage search architectures", True, "not suitable for a strict same-allK Pareto claim"),
        ("shared_initialization_preserved_when_required", True, False, "not required by historical protocol", "common seed, method-specific initialization"),
        ("sector_directions_preserved", True, SECTORS, SECTORS, "eight compass directions"),
        ("same_ASU_preset", all(row.get("asu_preset") == ASU_PRESET for row in rows), sorted(set(row.get("asu_preset") for row in rows)), ASU_PRESET, "verified historical preset"),
        ("ASU_not_used_for_HV_GD_IGD", all(not truthy(row.get("ASU_used_for_HV_GD_IGD")) for row in rows), False, False, "HV/GD/IGD unavailable; not computed from ASU"),
        ("old_route_counts_not_rerun", True, "source rows read only", "20/40/50/80 read only", "route60 units only"),
        ("existing_files_not_overwritten", source_mtimes_unchanged, ROOT.as_posix(), "new extension only", "source package read only"),
        ("route50_preserved", all((method, 50, k) in complete_keys for method in METHOD_META for k in K_META), 50, 50, "complete-data file"),
        ("heatmap_subset_exact", sorted(set(int(row["route_count"]) for row in heatmap)) == [20, 40, 60, 80], sorted(set(int(row["route_count"]) for row in heatmap)), [20, 40, 60, 80], "route50 excluded only from heatmap subset"),
        ("no_heatmap_interpolation", len(heatmap) == len(heatmap_keys), len(heatmap), len(heatmap_keys), "direct observed cells"),
        ("no_missing_method_K_seed", observed_route60 == expected_route60, sorted(expected_route60 - observed_route60), [], "15 route60 units"),
        ("no_duplicate_method_K_seed", duplicate_count == 0, duplicate_count, 0, "route60 rows"),
        ("single_seed_std_blank", all(str(value) == "" for row in summary for key, value in row.items() if key.endswith("_std")), "blank", "blank", "single-seed protocol"),
        ("ASU_recomputation_consistent", all(truthy(row.get("ASU_consistency_pass")) for row in consistency_rows), sum(not truthy(row.get("ASU_consistency_pass")) for row in consistency_rows), 0, "official true-SINR evaluator recomputation"),
        ("system_metric_heatmap_ready", not failures and len(heatmap) == 60 and len(complete) == 75, {"failures": len(failures), "heatmap_rows": len(heatmap), "complete_rows": len(complete)}, {"failures": 0, "heatmap_rows": 60, "complete_rows": 75}, "ready for system-level Origin heatmaps; not a strict Pareto-fairness claim"),
        ("src_algorithms_diff_empty", algorithms_diff_empty(), not algorithms_diff_empty(), False, "git diff -- src/algorithms"),
    ]
    readiness = [{"check_name": name, "status": "PASS" if passed else "FAIL", "observed_value": observed, "expected_value": expected, "note": note} for name, passed, observed, expected, note in checks]
    write_csv(ROOT / "route60_readiness_check.csv", readiness)

    metadata = {
        "generation_timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "verified_previous_sensitivity_root": SOURCE_ROOT.as_posix(),
        "extension_root": ROOT.as_posix(),
        "methods": [{"method_key": key, "method_label": label, "method_order": order} for key, label, order in METHODS],
        "seed_policy": SEEDS, "population": POPULATION, "iterations_per_stage": ITERATIONS,
        "route60": {"current": CURRENT_COUNT, "predicted": FUTURE_COUNT, "total": ROUTE_COUNT, "selection_policy": "deterministic sorted route_id prefix by class", "route_subset_hash": route_subset_hash(route_records)},
        "K_settings": [{"K": k, "K1": k1, "K2": k2} for k, k1, k2 in K_SETTINGS],
        "z_max": Z_MAX, "asu_preset": ASU_PRESET, "objective_vector": OBJECTIVE_VECTOR,
        "optimizer_metrics": {"HV": "unavailable", "GD": "unavailable", "IGD": "unavailable", "reason": "historical sensitivity did not export compatible full Pareto archives"},
        "old_route_counts_rerun": False, "route50_preserved": True,
        "strict_same_allK_pareto_comparability": False,
        "strict_same_allK_caveat": "historical methods share heterogeneous station encoding and total K but do not all use an identical all-K search architecture",
        "source_commit": commit, "algorithms_diff_empty": algorithms_diff_empty(),
    }
    write_json(ROOT / "metadata.json", metadata)

    completed = len(rows)
    report = f"""# Route60 historical multi-optimizer extension

1. Previous experiment: `{SOURCE_ROOT.as_posix()}`.
2. Methods: `{', '.join(label for _, label, _ in METHODS)}`.
3. Seed policy: single seed `[2026]`.
4. Reused budget: population 50 and 150 iterations per stage for optimizers; Greedy is non-iterative.
5. Route60 selection: deterministic sorted route-ID prefix within each semantic priority class.
6. Route split: exactly 25 current and 35 predicted generated/proxy routes.
7. Route IDs are identical across all methods and K values.
8. Historical initialization policy is method-specific under the common seed; no shared initial-population artifact existed.
9. Completed K settings: `{sorted(set(int(row['K']) for row in rows))}` with splits `3/2, 5/5, 8/7`.
10. Expected runs: 15.
11. Successful runs: {completed}; failed or missing: {len(failures)}.
12. Resume/retry status is recorded in `logs/launcher_summary.json`; completed unit files are restart-safe.
13. Old route20/40/50/80 optimizations were not rerun.
14. Existing experiment files were not overwritten; only the extension directory was written.
15. ASU, Coverage@0, and CCU@0 complete: {all(str(row.get('ASU')) and str(row.get('Coverage@0')) and str(row.get('CCU@0')) for row in rows)}.
16. HV/GD/IGD are unavailable because the historical sensitivity protocol did not export compatible full objective-vector archives; ASU was never substituted.
17. The 20/40/60/80 heatmap dataset has {len(heatmap)} directly observed rows.
18. Route50 remains present in the complete-data file.
19. Origin matrix/XYZ files are ready when all cell and safety checks pass; no values are interpolated.
20. Paper caveats: these are single-seed generated/proxy-route sensitivity results; the historical methods do not all share an identical all-K search architecture, so do not present them as strict Pareto-fair optimizer robustness.

The equally spaced heatmap subset uses route counts 20, 40, 60, and 80. The existing route-count 50 results are preserved for complete-data reporting but are excluded from the equally spaced heatmap.

The route-scale and deployment-budget sensitivity results are single-seed results. Therefore, standard deviations are not reported as zero and should not be interpreted as robustness estimates.

## Route60 preview

{markdown_table(summary, ['method_label', 'K', 'ASU_mean', 'Coverage@0_mean', 'CCU@0_mean', 'runtime_seconds_mean'])}
"""
    (ROOT / "route60_extension_report.md").write_text(report, encoding="utf-8")
    return 0 if not failures else 1


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--unit", action="store_true")
    parser.add_argument("--method", choices=list(METHOD_META))
    parser.add_argument("--K", type=int, choices=list(K_META))
    parser.add_argument("--seed", type=int, choices=SEEDS, default=SEEDS[0])
    parser.add_argument("--launch", action="store_true")
    parser.add_argument("--workers", type=int, default=max(5, min(15, (os.cpu_count() or 8) // 2)))
    parser.add_argument("--aggregate", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.unit:
        if not args.method or args.K is None:
            raise SystemExit("--unit requires --method and --K")
        return run_unit(args.method, args.K, args.seed)
    if args.launch:
        return launch_parallel(args.workers)
    if args.aggregate:
        return aggregate()
    prepare_manifests()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
