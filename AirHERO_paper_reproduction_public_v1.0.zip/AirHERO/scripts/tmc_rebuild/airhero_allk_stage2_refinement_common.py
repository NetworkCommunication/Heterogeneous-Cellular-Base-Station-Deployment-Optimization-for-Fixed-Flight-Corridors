"""Exploratory AirHERO all-K Stage-II refinement runner.

This module is intentionally additive. It reuses the frozen AirHERO
response-v3 optimization loop but replaces only the Stage-II initialization in
the current Python process so that Stage-II can refine all K new stations.
"""
from __future__ import annotations

import copy
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_height_constrained_zmax50 as zmax
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
import scripts.run_true_joint_response_v3_closed_loop_diagnostic_K15 as closed_loop
from src.experiments.asu_route_service_v2_sinr import evaluate_with_existing_context_sinr_asu_v2
from src.experiments.strict_current_future_context_wrapper import _append_stage1_context


METHOD_KEY = "airhero_allk_stage2_refinement_v1"
PAPER_NAME = "AirHERO-AllKRefine"
ROOT = Path(os.environ.get("AIRHERO_ALLK_OUTPUT_ROOT", "artifacts/tmc_rebuild/airhero_allk_stage2_refinement_v1_zmax50"))
SEEDS = [2026, 2027, 2028]
K, K1, K2 = 10, 5, 5
POPULATION, ITERATIONS = 50, 150
Z_MAX = 50.0
SECTORS = [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]
FORMAL_AIRHERO = "true_joint_closed_loop_elite_immigration_response_v3_asu_v2"


def _json_safe(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {str(key): _json_safe(val) for key, val in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return value


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_json_safe(dict(payload)), indent=2, ensure_ascii=False), encoding="utf-8")


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def configure_modules(seed: int) -> None:
    """Pin shared formal modules to the requested K10/z_max=50 setting."""
    for module in (formal, true_formal, closed_loop, zmax):
        module.K = K
        module.K1 = K1
        module.K2 = K2
        module.POPULATION = POPULATION
        module.ITERATIONS = ITERATIONS
    closed_loop.SEED = int(seed)
    zmax.Z_MAX = Z_MAX


def build_problems() -> Tuple[Any, Any, Any, Dict[str, Any]]:
    """Load existing formal route/station artifacts without regenerating them."""
    stations = formal.read_csv(formal.STATION_PATH)
    routes = formal.read_csv(formal.ROUTE_POINT_PATH)
    all_problem, current_problem, future_problem, meta = formal.build_problems(stations, routes)
    for problem in (all_problem, current_problem, future_problem):
        true_formal.apply_true_sinr_config(problem.config)
        problem.config["route_point_rows"] = routes
        zmax.apply_height_constraint(problem)
    return all_problem, current_problem, future_problem, meta


def _weak_future_points(stage1_best: np.ndarray, future_problem: Any) -> np.ndarray:
    """Find low-service future route points under original existing + Stage-I context."""
    future_context = copy.deepcopy(future_problem)
    _append_stage1_context(future_context.config, np.asarray(stage1_best, dtype=float).reshape(K1, 5))
    empty_new = np.zeros((0, 5), dtype=float)
    sinr_db = zmax.point_sinr_db(empty_new, future_context)
    points = np.asarray(future_context.test_points[:, :3], dtype=float)
    if points.size == 0:
        return np.zeros((0, 3), dtype=float)
    order = np.argsort(np.asarray(sinr_db, dtype=float), kind="stable")
    # Keep enough anchors to avoid repeatedly seeding the same future point.
    return points[order[: max(4 * K2, K2)]].copy()


def _future_anchor_seed(
    rng: np.random.Generator,
    weak_points: np.ndarray,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
    jitter_m: float,
) -> np.ndarray:
    if weak_points.size == 0:
        anchors = rng.uniform(min_pos[:3], max_pos[:3], size=(K2, 3))
    else:
        ids = rng.choice(np.arange(weak_points.shape[0]), size=K2, replace=weak_points.shape[0] < K2)
        anchors = weak_points[ids].copy()
        anchors[:, :2] += rng.normal(0.0, jitter_m, size=(K2, 2))
        anchors[:, 2] += rng.normal(0.0, 5.0, size=K2)
    anchors = np.clip(anchors, min_pos[:3][None, :], max_pos[:3][None, :])
    stations = np.zeros((K2, 5), dtype=float)
    stations[:, :3] = anchors
    stations[:, 3] = (rng.random(K2) < 0.70).astype(float)
    for idx in range(K2):
        if int(round(stations[idx, 3])) == 1 and weak_points.size:
            stations[idx, 4] = closed_loop.v3diag.nearest_sector_index_toward(stations[idx], weak_points)
        else:
            stations[idx, 4] = 0.0
    return stations


def _perturb_stage1(
    stage1_best: np.ndarray,
    rng: np.random.Generator,
    min_pos: np.ndarray,
    max_pos: np.ndarray,
) -> np.ndarray:
    out = np.asarray(stage1_best, dtype=float).reshape(K1, 5).copy()
    out[:, :2] += rng.normal(0.0, 90.0, size=(K1, 2))
    out[:, 2] += rng.normal(0.0, 5.0, size=K1)
    type_mut = rng.random(K1) < 0.15
    sector_mut = rng.random(K1) < 0.25
    out[type_mut, 3] = 1.0 - np.round(out[type_mut, 3])
    out[sector_mut, 4] = rng.integers(0, len(SECTORS), size=int(np.sum(sector_mut)))
    out[:, :3] = np.clip(out[:, :3], min_pos[:3][None, :], max_pos[:3][None, :])
    out[:, 3] = np.clip(np.round(out[:, 3]), 0, 1)
    out[:, 4] = np.where(out[:, 3] > 0.5, np.clip(np.round(out[:, 4]), 0, len(SECTORS) - 1), 0)
    return out


def _make_stage2_initializer(
    stage1_best: np.ndarray,
    future_problem: Any,
    original_initializer: Any,
) -> Any:
    weak_points = _weak_future_points(stage1_best, future_problem)
    stage1_seed = np.asarray(stage1_best, dtype=float).reshape(K1, 5).copy()

    def seeded_init(problem: Any, cfg: Dict[str, Any], rng: np.random.Generator, pop_size: int, k: int, min_pos: np.ndarray, max_pos: np.ndarray):
        if int(k) != K:
            raise ValueError(f"{METHOD_KEY} Stage-II expects all-K dimension {K}, got {k}")
        random_particles, summary = original_initializer(problem, cfg, rng, pop_size, k, min_pos, max_pos)
        particles = np.asarray(random_particles, dtype=float).copy()
        group_counts = {
            "p1_plus_future_anchors": int(math.floor(pop_size * 0.25)),
            "perturbed_p1_plus_future_anchors": int(math.floor(pop_size * 0.25)),
            "p1_plus_perturbed_future_anchors": int(math.floor(pop_size * 0.25)),
        }
        used = sum(group_counts.values())
        group_counts["random_valid_allK"] = int(pop_size - used)
        cursor = 0
        p1_exact = stage1_seed.copy()
        for group, count in group_counts.items():
            for _ in range(count):
                if group == "p1_plus_future_anchors":
                    p1 = p1_exact.copy()
                    p2 = _future_anchor_seed(rng, weak_points, min_pos, max_pos, jitter_m=120.0)
                elif group == "perturbed_p1_plus_future_anchors":
                    p1 = _perturb_stage1(p1_exact, rng, min_pos, max_pos)
                    p2 = _future_anchor_seed(rng, weak_points, min_pos, max_pos, jitter_m=140.0)
                elif group == "p1_plus_perturbed_future_anchors":
                    p1 = p1_exact.copy()
                    p2 = _future_anchor_seed(rng, weak_points, min_pos, max_pos, jitter_m=280.0)
                else:
                    cursor += 1
                    continue
                particles[cursor] = np.vstack([p1, p2])
                cursor += 1
        particles = closed_loop.v2_module._repair_particles(particles, problem, cfg, rng, min_pos, max_pos)
        exact_prefix = int(np.sum(np.all(np.isclose(particles[:, :K1, :], p1_exact[None, :, :], atol=1e-8), axis=(1, 2))))
        mix_rows = [
            {
                "stage": f"{METHOD_KEY}_stage2_allK",
                "initialization_group": key,
                "particle_count": value,
                "stage2_jointly_optimizes_all_K": True,
                "first_K1_slots_initialized_from_stage1": key != "random_valid_allK",
                "future_low_service_anchor_count": int(weak_points.shape[0]),
                "exact_stage1_prefix_particle_count_after_repair": exact_prefix,
            }
            for key, value in group_counts.items()
        ]
        return particles, list(summary) + mix_rows

    return seeded_init


def _objective_rows(stage2: Any, seed: int) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    objectives = np.asarray(stage2.objective_vectors, dtype=float)
    for idx, vec in enumerate(objectives):
        rows.append(
            {
                "method_key": METHOD_KEY,
                "seed": seed,
                "candidate_index": idx,
                "objective_0": float(vec[0]) if vec.size > 0 else "",
                "objective_1": float(vec[1]) if vec.size > 1 else "",
                "objective_2": float(vec[2]) if vec.size > 2 else "",
                "objective_3": float(vec[3]) if vec.size > 3 else "",
                "objective_4": float(vec[4]) if vec.size > 4 else "",
            }
        )
    return rows


def _target_objective_rows(stage2: Any, problem: Any, seed: int) -> List[Dict[str, Any]]:
    """Export the paper diagnostic objective vector [C_dep, H, -Q_c, -Q_f]."""
    decisions = np.asarray(stage2.decision_variables, dtype=float)
    if decisions.size == 0:
        return []
    if decisions.ndim != 3:
        decisions = decisions.reshape(-1, K, 5)
    packed = evaluate_with_existing_context_sinr_asu_v2(
        decisions=decisions,
        problem=problem,
        config=problem.config,
        method_name=f"{METHOD_KEY}_target_objectives",
    )
    rows: List[Dict[str, Any]] = []
    for idx, metric in enumerate(packed.metrics):
        q_current = _as_float(metric.get("Q_current"))
        q_future = _as_float(metric.get("Q_future"))
        c_dep = _as_float(metric.get("C_dep"))
        handover = _as_float(metric.get("handover_count"))
        rows.append(
            {
                "method_key": METHOD_KEY,
                "paper_facing_name": PAPER_NAME,
                "seed": seed,
                "candidate_index": idx,
                "C_dep": c_dep,
                "handover_count": handover,
                "minus_Q_current": -q_current,
                "minus_Q_future": -q_future,
                "ASU_auxiliary": _as_float(metric.get("ASU")),
                "Q_current": q_current,
                "Q_future": q_future,
                "ASU_used_for_HV_GD_IGD": False,
                "decision_vector_json": json.dumps(decisions[idx].reshape(-1).tolist()),
            }
        )
    return rows


def run_seed(seed: int) -> Dict[str, Any]:
    """Run one exploratory seed and write the seed-local artifact package."""
    if int(seed) not in SEEDS:
        raise ValueError(f"unsupported seed {seed}; expected one of {SEEDS}")
    configure_modules(seed)
    seed_root = ROOT / f"seed_{seed}"
    seed_root.mkdir(parents=True, exist_ok=True)
    all_problem, current_problem, future_problem, meta = build_problems()
    started = time.time()

    adapter = closed_loop.ClosedLoopResponseAdapter(FORMAL_AIRHERO)
    stage1_cfg = formal.stage_config(current_problem.config, K1, stage=f"{METHOD_KEY}_stage1_current_exact_airhero")
    true_formal.apply_true_sinr_config(stage1_cfg)
    stage1 = adapter.run(current_problem, seed=seed, config=stage1_cfg)
    stage1_best = formal.best_decision(stage1, K1)
    stage1_best, stage1_height_repairs = zmax.repair_height(stage1_best, current_problem.config)

    stage2_cfg = formal.stage_config(all_problem.config, K, stage=f"{METHOD_KEY}_stage2_allK_current_future_refinement")
    true_formal.apply_true_sinr_config(stage2_cfg)
    original_init = closed_loop.v2_module._initialize_population
    closed_loop.v2_module._initialize_population = _make_stage2_initializer(stage1_best, future_problem, original_init)  # type: ignore[assignment]
    try:
        stage2 = closed_loop.closed_loop_stage_run(all_problem, seed + 1009, stage2_cfg, FORMAL_AIRHERO)
    finally:
        closed_loop.v2_module._initialize_population = original_init  # type: ignore[assignment]
    stage2.method_name = METHOD_KEY
    stage2.logs["method_key"] = METHOD_KEY
    stage2.logs["paper_facing_name"] = PAPER_NAME
    stage2.logs["base_response_code_path"] = FORMAL_AIRHERO

    final = formal.best_decision(stage2, K)
    final, stage2_height_repairs = zmax.repair_height(final, all_problem.config)
    runtime = float(time.time() - started)
    post = zmax.continuity_metrics(final, all_problem)
    metrics = dict(post["metrics"])
    repeated = zmax.continuity_metrics(final, all_problem)["metrics"]
    asu_delta = abs(_as_float(metrics.get("ASU")) - _as_float(repeated.get("ASU")))
    height = zmax.height_metrics(final)
    if not height["height_constraint_compliant"]:
        raise RuntimeError("final all-K deployment violates z_max=50 m")
    response = closed_loop.closed_loop_response_summary(stage1, stage2)
    deployment_hash = zmax.hash_decision(final)
    decoded = zmax.decode_rows(final, METHOD_KEY, seed, K1)
    for row in decoded:
        row["paper_facing_name"] = PAPER_NAME
        row["station_source"] = (
            "stage1_slot_refined_by_allK_stage2" if int(row["station_id"]) <= K1 else "future_anchor_slot_refined_by_allK_stage2"
        )
        row["stage2_allK_mutable"] = True

    result_row: Dict[str, Any] = {
        "method_key": METHOD_KEY,
        "paper_facing_name": PAPER_NAME,
        "seed": seed,
        "success": True,
        "K": K,
        "K1": K1,
        "K2": K2,
        "ASU": _as_float(metrics.get("ASU")),
        "Q_current": _as_float(metrics.get("Q_current")),
        "Q_future": _as_float(metrics.get("Q_future")),
        "Coverage@0": _as_float(metrics.get("Coverage@0dB", metrics.get("Coverage@0"))),
        "Coverage@5": _as_float(metrics.get("Coverage@5dB", metrics.get("Coverage@5"))),
        "Coverage@10": _as_float(metrics.get("Coverage@10dB", metrics.get("Coverage@10"))),
        "CCU@0": _as_float(post["continuity"].get("Continuous Coverage Utility@0")),
        "CCU@5": _as_float(post["continuity"].get("Continuous Coverage Utility@5")),
        "CCU@10": _as_float(post["continuity"].get("Continuous Coverage Utility@10")),
        "handover_count": _as_float(metrics.get("handover_count")),
        "route_interruption_count@0": _as_float(post["continuity"].get("route_interruption_count@0")),
        "route_interruption_count@5": _as_float(post["continuity"].get("route_interruption_count@5")),
        "route_interruption_count@10": _as_float(post["continuity"].get("route_interruption_count@10")),
        "C_dep": _as_float(metrics.get("C_dep")),
        "N_5G": int(_as_float(metrics.get("N_5G"))),
        "N_5GA": int(_as_float(metrics.get("N_5GA"))),
        "runtime_seconds": runtime,
        "height_violation_count": int(np.count_nonzero(np.asarray(final)[:, 2] > Z_MAX + 1e-9)),
        "height_repair_count": int(stage1_height_repairs + stage2_height_repairs),
        "asu_recompute_mismatch": bool(asu_delta > 1e-9),
        "asu_recompute_absolute_delta": asu_delta,
        "selected_deployment_hash": deployment_hash,
        "stage1_modified_by_stage2": bool(not np.allclose(final[:K1], stage1_best, atol=1e-8, rtol=0.0)),
        "output_folder": seed_root.as_posix(),
        "error_message": "",
        "station_data_label": "route-agnostic simulated/proxy existing infrastructure; not real operator base-station records",
        "route_data_label": "generated/proxy semantic POI route points; not real measured airways",
        **response,
    }

    zmax.write_csv(seed_root / "decoded_deployment.csv", decoded)
    zmax.write_csv(seed_root / "asu_components.csv", [{"method_key": METHOD_KEY, "seed": seed, **metrics}])
    zmax.write_csv(seed_root / "service_metrics.csv", [{"method_key": METHOD_KEY, "seed": seed, **result_row, **post["continuity"]}])
    zmax.write_csv(seed_root / "runtime_summary.csv", [{"method_key": METHOD_KEY, "seed": seed, "runtime_seconds": runtime, "stage1_runtime_seconds": stage1.runtime_seconds, "stage2_runtime_seconds": stage2.runtime_seconds}])
    zmax.write_csv(seed_root / "response_summary.csv", [{"method_key": METHOD_KEY, "seed": seed, **response}])
    zmax.write_csv(seed_root / "stagnation_score_trace.csv", [{**dict(row), "method_key": METHOD_KEY, "seed": seed} for row in stage2.logs.get("stagnation_score_trace", [])])
    zmax.write_csv(seed_root / "response_action_log.csv", [{**dict(row), "method_key": METHOD_KEY, "seed": seed} for row in stage2.logs.get("response_action_log", [])])
    zmax.write_csv(seed_root / "stage_seed_initialization_summary.csv", [{**dict(row), "method_key": METHOD_KEY, "seed": seed} for row in stage2.logs.get("stage1_seed_summary", [])])
    zmax.write_csv(seed_root / "objective_vectors.csv", _objective_rows(stage2, seed))
    zmax.write_csv(seed_root / "target_objective_vectors.csv", _target_objective_rows(stage2, all_problem, seed))
    zmax.write_csv(seed_root / "objective_final_consistency.csv", [{"method_key": METHOD_KEY, "seed": seed, "stored_ASU": result_row["ASU"], "recomputed_ASU": _as_float(repeated.get("ASU")), "absolute_delta": asu_delta, "pass": asu_delta <= 1e-9}])
    zmax.write_csv(seed_root / "height_constraint_audit.csv", [{"method_key": METHOD_KEY, "seed": seed, "z_max": Z_MAX, **height}])
    zmax.write_csv(seed_root / "seed_result.csv", [result_row])

    snapshot = {
        "method_key": METHOD_KEY,
        "paper_facing_name": PAPER_NAME,
        "exploratory_only": True,
        "base_stage1_method": FORMAL_AIRHERO,
        "base_response_code_path": FORMAL_AIRHERO,
        "stage2_problem": "all-K current+future refinement",
        "K": K,
        "K1": K1,
        "K2": K2,
        "seed": seed,
        "population": POPULATION,
        "iterations_per_stage": ITERATIONS,
        "z_max_m": Z_MAX,
        "station_artifact": formal.STATION_PATH.as_posix(),
        "route_artifact": formal.ROUTE_POINT_PATH.as_posix(),
        "input_meta": meta,
        "signal_metric": "sinr",
        "optimization_signal_metric": "sinr",
        "response_v3_reused_without_modifying_frozen_method": True,
    }
    _write_json(seed_root / "config_snapshot.json", snapshot)
    _write_json(seed_root / "method_metadata.json", {**snapshot, "final_result": result_row})
    _write_json(seed_root / "seed_result.json", result_row)
    return result_row


def failure_row(seed: int, exc: BaseException) -> Dict[str, Any]:
    seed_root = ROOT / f"seed_{seed}"
    seed_root.mkdir(parents=True, exist_ok=True)
    row = {
        "method_key": METHOD_KEY,
        "paper_facing_name": PAPER_NAME,
        "seed": seed,
        "success": False,
        "output_folder": seed_root.as_posix(),
        "error_message": f"{type(exc).__name__}: {exc}",
    }
    zmax.write_csv(seed_root / "seed_result.csv", [row])
    _write_json(seed_root / "seed_result.json", row)
    return row


def load_seed_results() -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for seed in SEEDS:
        path = ROOT / f"seed_{seed}" / "seed_result.json"
        if path.exists():
            rows.append(json.loads(path.read_text(encoding="utf-8")))
    return rows


def mean_std(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    metrics = [
        "ASU", "Q_current", "Q_future", "Coverage@0", "Coverage@5", "Coverage@10",
        "CCU@0", "CCU@5", "CCU@10", "handover_count", "route_interruption_count@0",
        "C_dep", "runtime_seconds", "N_5G", "N_5GA",
    ]
    good = [row for row in rows if str(row.get("success", "")).lower() == "true" or row.get("success") is True]
    summary: Dict[str, Any] = {"method_key": METHOD_KEY, "paper_facing_name": PAPER_NAME, "n": len(good)}
    for metric in metrics:
        values = [_as_float(row.get(metric), math.nan) for row in good]
        values = [value for value in values if not math.isnan(value)]
        if values:
            summary[f"{metric}_mean"] = float(np.mean(values))
            summary[f"{metric}_std"] = float(np.std(values, ddof=1)) if len(values) > 1 else 0.0
    return [summary]
