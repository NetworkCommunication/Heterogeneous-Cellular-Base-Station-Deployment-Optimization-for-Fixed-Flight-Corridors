"""Run AirHERO all-K main-candidate main-system seeds in a new output root."""
from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ["AIRHERO_ALLK_OUTPUT_ROOT"] = "artifacts/tmc_rebuild/airhero_allk_main_candidate_zmax50/01_main_system"

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.tmc_rebuild.run_airhero_allk_stage2_refinement_parallel import main


if __name__ == "__main__":
    main()
