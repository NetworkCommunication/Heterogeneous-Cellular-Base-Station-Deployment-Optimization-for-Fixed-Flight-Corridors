"""Fair same-space optimizer robustness package for AirHERO.

This runner is additive and writes only under
artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/06_fair_optimizer_robustness_same_space.
It uses temporary in-process wrappers to enforce the same all-K initialization
population and the same true-SINR four-objective vector without modifying
optimizer implementation files.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import subprocess
import sys
import time
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence
from types import SimpleNamespace

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_height_constrained_zmax50 as zmax
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
import scripts.run_true_joint_response_v3_closed_loop_diagnostic_K15 as closed_loop
import src.baselines.bio_inspired_common as bio_common
import src.baselines.csa_extended.adapter as csa_module
import src.baselines.immogwo_adapted_true_sinr_asu_v2.adapter as immogwo_module
import src.baselines.moead_extended.adapter as moead_module
import src.baselines.nsga2_extended.adapter as nsga2_module
from scripts.tmc_rebuild.airhero_allk_stage2_refinement_common import (
    FORMAL_AIRHERO,
    ITERATIONS,
    K,
    K1,
    K2,
    POPULATION,
    SEEDS,
    Z_MAX,
    _as_float,
    build_problems,
    configure_modules,
)
from src.baselines.base import BaselineResult
from src.baselines.csa_extended.adapter import CSAExtendedAdapter
from src.baselines.clpso_extended_true_sinr_asu_v2.adapter import CLPSOExtendedTrueSINRASUV2Adapter
from src.baselines.immogwo_adapted_true_sinr_asu_v2.adapter import ImMOGWOAdaptedTrueSINRASUV2Adapter
from src.baselines.moead_extended.adapter import MOEADExtendedAdapter
from src.baselines.nsga2_extended.adapter import NSGA2ExtendedAdapter
from src.baselines.nsga2_extended.encoding import build_extended_deployment_encoding, flatten_extended_particles, unflatten_extended_chromosomes
from src.baselines.nsga2_extended.repair import repair_extended_chromosomes
from src.baselines.scenario_sampling_robust_deployment_true_sinr_asu_v2.adapter import ScenarioSamplingRobustDeploymentTrueSINRASUV2Adapter
from src.experiments.asu_route_service_v2_sinr import evaluate_with_existing_context_sinr_asu_v2
from src.experiments.multiobjective_metrics import nondominated_mask


ROOT = Path("artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/06_fair_optimizer_robustness_same_space")
FINAL_SUMMARY = Path("artifacts/tmc_rebuild/airhero_allk_final_paper_ready_zmax50/final_paper_ready_summary")
OBJECTIVE_COLUMNS = ["C_dep", "handover_count", "minus_Q_E", "minus_Q_P"]
REFERENCE_POINT = np.asarray([1.1, 1.1, 1.1, 1.1], dtype=float)
MC_SAMPLES = 120000

METHODS: Dict[str, Any] = {
    "airhero_search_same_initialization": None,
    "nsga2_extended_allk_same_space": NSGA2ExtendedAdapter(),
    "moead_extended_allk_same_space": MOEADExtendedAdapter(),
    "csa_extended_allk_same_space": CSAExtendedAdapter(),
    "clpso_extended_allk_same_space": CLPSOExtendedTrueSINRASUV2Adapter(),
    "immogwo_extended_allk_same_space": ImMOGWOAdaptedTrueSINRASUV2Adapter(),
    "scenario_sampling_robust_deployment_allk_same_space": ScenarioSamplingRobustDeploymentTrueSINRASUV2Adapter(),
}


@dataclass
class _EvalPack:
    objectives: np.ndarray
    feasible_mask: np.ndarray
    metrics: Dict[str, np.ndarray]


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    keys: List[str] = []
    for row in rows:
        for key in row.keys():
            if key not in keys:
                keys.append(key)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=keys)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in keys})


def read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def md_table(rows: Sequence[Mapping[str, Any]], cols: Sequence[str]) -> str:
    if not rows:
        return "_No rows._\n"
    out = ["|" + "|".join(cols) + "|", "|" + "|".join(["---"] * len(cols)) + "|"]
    for row in rows:
        out.append("|" + "|".join(str(row.get(col, "")) for col in cols) + "|")
    return "\n".join(out) + "\n"


def latex_table(rows: Sequence[Mapping[str, Any]], cols: Sequence[str]) -> str:
    body = ["\\begin{tabular}{" + "l" * len(cols) + "}", " \\hline", " & ".join(cols) + r" \\ \hline"]
    for row in rows:
        body.append(" & ".join(str(row.get(col, "")) for col in cols) + r" \\")
    body.extend(["\\hline", "\\end{tabular}", ""])
    return "\n".join(body)


def truthy(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def method_config(base: Mapping[str, Any], method: str) -> Dict[str, Any]:
    cfg = json.loads(json.dumps(dict(base)))
    true_formal.apply_true_sinr_config(cfg)
    cfg.setdefault("pso", {})
    cfg["pso"]["numBaseStations"] = K
    cfg["pso"]["numParticles"] = POPULATION
    cfg["pso"]["maxIterations"] = ITERATIONS
    cfg["pso"]["maxPosition"][2] = Z_MAX
    cfg.setdefault("mopso", {})["archiveSize"] = POPULATION
    cfg.setdefault("nsga2", {}).update({"populationSize": POPULATION, "maxGenerations": ITERATIONS})
    cfg.setdefault("moead", {}).update({"num_subproblems": POPULATION, "max_generations": ITERATIONS, "archive_size": POPULATION})
    cfg.setdefault("csa", {}).update({"population_size": POPULATION, "max_iterations": ITERATIONS, "evaluation_batch_size": 0})
    cfg.setdefault("clpso", {}).update({"population_size": POPULATION, "max_iterations": ITERATIONS})
    cfg.setdefault("immogwo", {}).update({"population_size": POPULATION, "max_iterations": ITERATIONS})
    cfg.setdefault("scenario", {}).update({"population_size": POPULATION, "max_iterations": ITERATIONS})
    cfg.setdefault("evaluation", {}).update({"optimization_signal_metric": "sinr", "signal_metric": "sinr", "threshold_main_db": 0.0, "auxiliary_thresholds_db": [5.0, 10.0], "rho": 0.10, "power_mode": "station_file_preferred"})
    cfg.setdefault("airwayServiceUtilityV2", {}).update({"signal_metric": "sinr", "optimization_signal_metric": "sinr"})
    cfg.setdefault("experiment", {})["method"] = method
    return cfg


def desired_objectives_from_metrics(metrics: Sequence[Mapping[str, Any]]) -> np.ndarray:
    rows = []
    for row in metrics:
        rows.append([
            _as_float(row.get("C_dep", row.get("deployment_cost"))),
            _as_float(row.get("handover_count")),
            -_as_float(row.get("Q_current")),
            -_as_float(row.get("Q_future")),
        ])
    return np.asarray(rows, dtype=float)


def evaluate_desired(decisions: np.ndarray, problem: Any, config: Mapping[str, Any], method: str) -> Any:
    pack = evaluate_with_existing_context_sinr_asu_v2(decisions=np.asarray(decisions, dtype=float), problem=problem, config=dict(config), method_name=method)
    metrics = [dict(row) for row in pack.metrics]
    objectives = desired_objectives_from_metrics(metrics)
    return SimpleNamespace(
        particles=getattr(pack, "particles", None),
        metrics=metrics,
        asu_values=np.asarray(pack.asu_values, dtype=float),
        objectives=objectives,
        feasible=np.asarray(pack.feasible, dtype=bool),
        existing_station_count=getattr(pack, "existing_station_count", None),
        newly_deployed_station_count=getattr(pack, "newly_deployed_station_count", None),
        total_station_count=getattr(pack, "total_station_count", None),
    )


def eval_chromosomes_for_nsga(chromosomes: np.ndarray, encoding: Any, problem: Any, config: Mapping[str, Any], method: str) -> _EvalPack:
    decisions = unflatten_extended_chromosomes(np.asarray(chromosomes, dtype=float), encoding)
    pack = evaluate_desired(decisions, problem, config, method)
    metrics = [dict(row) for row in pack.metrics]
    metric_arrays: Dict[str, np.ndarray] = {}
    for key in ["coverage_rate", "mean_snr_db", "handover_count", "deployment_cost"]:
        metric_arrays[key] = np.asarray([_as_float(row.get(key)) for row in metrics], dtype=float)
    return _EvalPack(objectives=np.asarray(pack.objectives, dtype=float), feasible_mask=np.asarray(pack.feasible, dtype=bool), metrics=metric_arrays)


def generate_shared_initial_population(seed: int, problem: Any, config: Mapping[str, Any]) -> np.ndarray:
    rng = np.random.default_rng(int(seed) + 606)
    encoding = build_extended_deployment_encoding(dict(config))
    path = ROOT / "shared_initial_population" / f"shared_initial_population_seed{seed}.csv"
    if path.exists():
        rows = read_csv(path)
        arr = np.zeros((POPULATION, K, 5), dtype=float)
        for row in rows:
            c = int(row["candidate_index"])
            s = int(row["station_id"]) - 1
            arr[c, s] = [
                _as_float(row["x"]),
                _as_float(row["y"]),
                _as_float(row["z"]),
                _as_float(row["station_type_index"]),
                _as_float(row["sector_direction_index"]),
            ]
        return repair_extended_chromosomes(flatten_extended_particles(arr), encoding, problem.city_map, dict(config), rng)
    raw = rng.uniform(encoding.lower_bounds, encoding.upper_bounds, size=(POPULATION, encoding.num_variables))
    flat = repair_extended_chromosomes(raw, encoding, problem.city_map, dict(config), rng)
    particles = unflatten_extended_chromosomes(flat, encoding)
    export = []
    for cidx, particle in enumerate(particles):
        for sid, station in enumerate(particle, start=1):
            export.append({
                "seed": seed,
                "candidate_index": cidx,
                "station_id": sid,
                "x": station[0],
                "y": station[1],
                "z": station[2],
                "station_type_index": int(round(station[3])),
                "sector_direction_index": int(round(station[4])),
            })
    write_csv(path, export)
    return flat


@contextmanager
def same_space_wrappers(method: str, shared_flat: np.ndarray):
    original_nsga_init = nsga2_module.initialize_extended_with_stage2_seeded_particles
    original_moead_init = moead_module.initialize_extended_with_stage2_seeded_particles
    original_nsga_eval = nsga2_module.evaluate_extended_chromosomes
    original_moead_eval = moead_module.evaluate_extended_chromosomes
    original_csa_init = csa_module._initialize_population
    original_bio_init = bio_common.initialize_population
    original_immogwo_init = immogwo_module.initialize_population
    original_airhero_init = closed_loop.v2_module._initialize_population
    original_airhero_eval = closed_loop.asu_v2_adapter._evaluate_particles_asu_v2

    def init_tuple(config: Mapping[str, Any], problem: Any, encoding: Any, population_size: int, rng: Any):
        return shared_flat[: int(population_size)].copy(), {"shared_initial_population": True, "source": "06_fair_optimizer_robustness_same_space"}

    def init_flat(pop_size: int, encoding: Any, problem: Any, config: Mapping[str, Any], rng: Any):
        return shared_flat[: int(pop_size)].copy()

    def init_airhero(problem: Any, cfg: Mapping[str, Any], rng: Any, pop_size: int, k: int, min_pos: Any, max_pos: Any):
        particles = shared_flat[: int(pop_size)].copy().reshape(int(pop_size), int(k), 5)
        return particles, [{"stage": "airhero_search_same_initialization", "shared_initial_population": True, "particle_count": int(pop_size)}]

    def eval_nsga(chromosomes: np.ndarray, encoding: Any, problem: Any, config: Mapping[str, Any]):
        return eval_chromosomes_for_nsga(chromosomes, encoding, problem, config, method)

    def eval_airhero(particles: np.ndarray, problem: Any, config: Mapping[str, Any], method_key: str):
        pack = evaluate_desired(np.asarray(particles, dtype=float), problem, config, method_key)
        return closed_loop.asu_v2_adapter._ASUV2EvalPack(
            objectives=np.asarray(pack.objectives, dtype=float),
            asu_values=np.asarray(pack.asu_values, dtype=float),
            metrics=[dict(row) for row in pack.metrics],
            feasible=np.asarray(pack.feasible, dtype=bool),
        )

    try:
        nsga2_module.initialize_extended_with_stage2_seeded_particles = init_tuple  # type: ignore[assignment]
        moead_module.initialize_extended_with_stage2_seeded_particles = init_tuple  # type: ignore[assignment]
        nsga2_module.evaluate_extended_chromosomes = eval_nsga  # type: ignore[assignment]
        moead_module.evaluate_extended_chromosomes = eval_nsga  # type: ignore[assignment]
        csa_module._initialize_population = init_flat  # type: ignore[assignment]
        bio_common.initialize_population = init_flat  # type: ignore[assignment]
        immogwo_module.initialize_population = init_flat  # type: ignore[assignment]
        closed_loop.v2_module._initialize_population = init_airhero  # type: ignore[assignment]
        if method != "airhero_search_same_initialization":
            closed_loop.asu_v2_adapter._evaluate_particles_asu_v2 = eval_airhero  # type: ignore[assignment]
        yield
    finally:
        nsga2_module.initialize_extended_with_stage2_seeded_particles = original_nsga_init  # type: ignore[assignment]
        moead_module.initialize_extended_with_stage2_seeded_particles = original_moead_init  # type: ignore[assignment]
        nsga2_module.evaluate_extended_chromosomes = original_nsga_eval  # type: ignore[assignment]
        moead_module.evaluate_extended_chromosomes = original_moead_eval  # type: ignore[assignment]
        csa_module._initialize_population = original_csa_init  # type: ignore[assignment]
        bio_common.initialize_population = original_bio_init  # type: ignore[assignment]
        immogwo_module.initialize_population = original_immogwo_init  # type: ignore[assignment]
        closed_loop.v2_module._initialize_population = original_airhero_init  # type: ignore[assignment]
        closed_loop.asu_v2_adapter._evaluate_particles_asu_v2 = original_airhero_eval  # type: ignore[assignment]


def run_airhero_same_init(problem: Any, seed: int, cfg: Mapping[str, Any]) -> BaselineResult:
    stage_cfg = formal.stage_config(dict(cfg), K, stage="airhero_search_same_initialization")
    true_formal.apply_true_sinr_config(stage_cfg)
    return closed_loop.closed_loop_stage_run(problem, int(seed) + 1009, stage_cfg, FORMAL_AIRHERO)


def adapter_for_method(method: str) -> Any:
    if method == "airhero_search_same_initialization":
        return None
    return METHODS[method]


def best_decision(decisions: np.ndarray, metrics: Sequence[Mapping[str, Any]]) -> np.ndarray:
    if len(metrics) == 0:
        return np.asarray(decisions, dtype=float).reshape(-1, K, 5)[0]
    idx = int(np.argmax([_as_float(row.get("ASU")) for row in metrics]))
    return np.asarray(decisions, dtype=float).reshape(-1, K, 5)[idx]


def height_violation_count(decision: np.ndarray) -> int:
    arr = np.asarray(decision, dtype=float).reshape(-1, 5)
    return int(np.count_nonzero(arr[:, 2] > Z_MAX + 1e-9))


def selected_row(method: str, seed: int, decisions: np.ndarray, problem: Any, cfg: Mapping[str, Any], runtime: float, out: Path) -> Dict[str, Any]:
    pack = evaluate_desired(np.asarray(decisions, dtype=float).reshape(1, K, 5), problem, cfg, method)
    m = dict(pack.metrics[0])
    repeated = evaluate_desired(np.asarray(decisions, dtype=float).reshape(1, K, 5), problem, cfg, method).metrics[0]
    asu_delta = abs(_as_float(m.get("ASU")) - _as_float(repeated.get("ASU")))
    return {
        "method": method,
        "seed": seed,
        "scenario_name": "route80_current33_predicted47_K10_zmax50_same_space",
        "route_count": 80,
        "current_route_count": 33,
        "predicted_route_count": 47,
        "K": K,
        "z_max": Z_MAX,
        "success": True,
        "ASU": _as_float(m.get("ASU")),
        "Q_E": _as_float(m.get("Q_current")),
        "Q_P": _as_float(m.get("Q_future")),
        "Coverage@0": _as_float(m.get("Coverage@0dB")),
        "Coverage@5": _as_float(m.get("Coverage@5dB")),
        "Coverage@10": _as_float(m.get("Coverage@10dB")),
        "CCU@0": "",
        "CCU@5": "",
        "CCU@10": "",
        "handover_count": _as_float(m.get("handover_count")),
        "C_dep": _as_float(m.get("C_dep")),
        "runtime_seconds": runtime,
        "height_violation_count": height_violation_count(decisions),
        "asu_recompute_mismatch": asu_delta > 1e-9,
        "asu_recompute_absolute_delta": asu_delta,
        "shared_initial_population_used": True,
        "allk_heterogeneous_encoding": True,
        "objective_vector": "[C_dep, H, -Q_E, -Q_P]",
        "ASU_used_for_HV_GD_IGD": False,
        "output_folder": out.as_posix(),
    }


def objective_rows(method: str, seed: int, decisions: np.ndarray, problem: Any, cfg: Mapping[str, Any], source: str) -> List[Dict[str, Any]]:
    arr = np.asarray(decisions, dtype=float).reshape(-1, K, 5)
    pack = evaluate_desired(arr, problem, cfg, method)
    rows = []
    for idx, (obj, metric, dec) in enumerate(zip(np.asarray(pack.objectives, dtype=float), pack.metrics, arr)):
        rows.append({
            "method": method,
            "seed": seed,
            "candidate_index": idx,
            "candidate_source": source,
            "scenario_name": "route80_current33_predicted47_K10_zmax50_same_space",
            "route_count": 80,
            "current_route_count": 33,
            "predicted_route_count": 47,
            "K": K,
            "C_dep": float(obj[0]),
            "handover_count": float(obj[1]),
            "minus_Q_E": float(obj[2]),
            "minus_Q_P": float(obj[3]),
            "Q_E": _as_float(metric.get("Q_current")),
            "Q_P": _as_float(metric.get("Q_future")),
            "ASU_auxiliary": _as_float(metric.get("ASU")),
            "ASU_used_for_HV_GD_IGD": False,
            "decision_vector_json": json.dumps(dec.reshape(-1).tolist()),
        })
    return rows


def run_single(method: str, seed: int) -> Dict[str, Any]:
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    configure_modules(seed)
    all_problem, _, _, _ = build_problems()
    cfg = method_config(all_problem.config, method)
    shared_flat = generate_shared_initial_population(seed, all_problem, cfg)
    out = ROOT / "runs" / method / f"seed_{seed}"
    out.mkdir(parents=True, exist_ok=True)
    try:
        with same_space_wrappers(method, shared_flat):
            t0 = time.time()
            if method == "airhero_search_same_initialization":
                result = run_airhero_same_init(all_problem, seed, cfg)
            else:
                adapter = adapter_for_method(method)
                result = adapter.run(all_problem, seed=seed, config=cfg)
            runtime = float(time.time() - t0)
        decisions = np.asarray(result.decision_variables, dtype=float).reshape(-1, K, 5)
        obj_rows = objective_rows(method, seed, decisions, all_problem, cfg, "final_population_or_archive_decisions")
        selected_decision = best_decision(decisions, [row for row in evaluate_desired(decisions, all_problem, cfg, method).metrics])
        sel = selected_row(method, seed, selected_decision, all_problem, cfg, runtime, out)
        write_csv(out / "objective_vectors.csv", obj_rows)
        write_csv(out / "selected_solution_metrics.csv", [sel])
        (out / "metadata.json").write_text(json.dumps({"method": method, "seed": seed, "shared_initial_population_used": True, "candidate_count": len(obj_rows), "objective_vector": "[C_dep, H, -Q_E, -Q_P]", "ASU_used_for_HV_GD_IGD": False}, indent=2), encoding="utf-8")
        return {"method": method, "seed": seed, "success": True, "candidate_count": len(obj_rows)}
    except Exception as exc:
        row = {"method": method, "seed": seed, "success": False, "error_message": f"{type(exc).__name__}: {exc}", "output_folder": out.as_posix()}
        write_csv(out / "selected_solution_metrics.csv", [row])
        (out / "metadata.json").write_text(json.dumps(row, ensure_ascii=False, indent=2), encoding="utf-8")
        return row


def unique_rows(arr: np.ndarray, decimals: int = 10) -> np.ndarray:
    a = np.asarray(arr, dtype=float)
    if a.size == 0:
        return a.reshape(0, len(OBJECTIVE_COLUMNS))
    _, idx = np.unique(np.round(a, decimals=decimals), axis=0, return_index=True)
    return a[np.sort(idx)]


def normalize(arr: np.ndarray, ideal: np.ndarray, nadir: np.ndarray) -> np.ndarray:
    return (np.asarray(arr, dtype=float) - ideal[None, :]) / np.maximum(nadir - ideal, 1e-12)[None, :]


def rms_nearest(a: np.ndarray, b: np.ndarray) -> float:
    if a.size == 0 or b.size == 0:
        return float("nan")
    diff = a[:, None, :] - b[None, :, :]
    return float(np.sqrt(np.mean(np.min(np.sum(diff * diff, axis=2), axis=1))))


def shared_mc_hv(groups: Mapping[str, np.ndarray], ref: np.ndarray, samples: int = MC_SAMPLES) -> Dict[str, float]:
    rng = np.random.default_rng(20260706)
    sample = rng.random((samples, ref.size)) * ref[None, :]
    out: Dict[str, float] = {}
    volume = float(np.prod(ref))
    for key, points in groups.items():
        pts = np.asarray(points, dtype=float)
        if pts.size == 0:
            out[key] = 0.0
            continue
        dominated = np.any(np.all(pts[:, None, :] <= sample[None, :, :], axis=2), axis=0)
        out[key] = float(np.mean(dominated) * volume)
    return out


def archive_novelty(points: np.ndarray) -> float:
    pts = np.asarray(points, dtype=float)
    if pts.shape[0] <= 1:
        return 0.0
    diff = pts[:, None, :] - pts[None, :, :]
    dist = np.sqrt(np.sum(diff * diff, axis=2))
    dist[dist == 0.0] = np.inf
    return float(np.mean(np.min(dist, axis=1)))


def aggregate() -> None:
    selected: List[Dict[str, Any]] = []
    objectives: List[Dict[str, Any]] = []
    failures: List[Dict[str, Any]] = []
    for method in METHODS:
        for seed in SEEDS:
            root = ROOT / "runs" / method / f"seed_{seed}"
            sel = read_csv(root / "selected_solution_metrics.csv")
            obj = read_csv(root / "objective_vectors.csv")
            if sel:
                selected.extend(sel)
                if str(sel[0].get("success", "True")).lower() == "false":
                    failures.extend(sel)
            if obj:
                objectives.extend(obj)

    grouped: Dict[tuple[str, str], List[List[float]]] = defaultdict(list)
    for row in objectives:
        grouped[(row["method"], str(row["seed"]))].append([_as_float(row[c], math.nan) for c in OBJECTIVE_COLUMNS])
    nd_rows: List[Dict[str, Any]] = []
    nd_norm_by_key: Dict[str, np.ndarray] = {}
    raw_nd_by_key: Dict[str, np.ndarray] = {}
    raw_all_nd = []
    for (method, seed), vecs in grouped.items():
        arr = unique_rows(np.asarray(vecs, dtype=float))
        arr = arr[np.isfinite(arr).all(axis=1)]
        nd = arr[nondominated_mask(arr)] if arr.size else np.zeros((0, len(OBJECTIVE_COLUMNS)))
        raw_nd_by_key[f"{method}|{seed}"] = nd
        if nd.size:
            raw_all_nd.append(nd)
        for idx, vec in enumerate(nd):
            nd_rows.append({"method": method, "seed": seed, "nd_index": idx, **{OBJECTIVE_COLUMNS[i]: float(vec[i]) for i in range(len(OBJECTIVE_COLUMNS))}, "ASU_used_for_HV_GD_IGD": False})

    if not raw_all_nd:
        raise RuntimeError("no objective vectors available for aggregation")
    union = np.vstack(raw_all_nd)
    ideal = np.min(union, axis=0)
    nadir = np.max(union, axis=0)
    union_norm = normalize(union, ideal, nadir)
    reference_front = union_norm[nondominated_mask(union_norm)]
    for key, arr in raw_nd_by_key.items():
        nd_norm_by_key[key] = normalize(arr, ideal, nadir) if arr.size else np.zeros((0, len(OBJECTIVE_COLUMNS)))
    hv = shared_mc_hv(nd_norm_by_key, REFERENCE_POINT)

    per_seed: List[Dict[str, Any]] = []
    for key, values in nd_norm_by_key.items():
        method, seed = key.split("|", 1)
        per_seed.append({
            "method": method,
            "seed": seed,
            "scenario_name": "route80_current33_predicted47_K10_zmax50_same_space",
            "K": K,
            "objective_vector": "[C_dep, H, -Q_E, -Q_P]",
            "nondominated_count": int(values.shape[0]),
            "HV": hv.get(key, 0.0),
            "GD": rms_nearest(values, reference_front),
            "IGD": rms_nearest(reference_front, values),
            "AN": archive_novelty(values),
            "DCR": "",
            "OE": "",
            "DCR_status": "not_applicable_existing_stable_definition_unavailable",
            "OE_status": "not_applicable_existing_stable_definition_unavailable",
            "ASU_used_for_HV_GD_IGD": False,
        })

    summary: List[Dict[str, Any]] = []
    for method in sorted({row["method"] for row in per_seed}):
        rows = [row for row in per_seed if row["method"] == method]
        rec: Dict[str, Any] = {"method": method, "n": len(rows)}
        for metric in ["HV", "GD", "IGD", "AN", "nondominated_count"]:
            vals = [_as_float(row.get(metric), math.nan) for row in rows]
            vals = [v for v in vals if math.isfinite(v)]
            if vals:
                rec[f"{metric}_mean"] = float(np.mean(vals))
                rec[f"{metric}_std"] = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
        runtimes = [_as_float(row.get("runtime_seconds"), math.nan) for row in selected if row.get("method") == method]
        runtimes = [v for v in runtimes if math.isfinite(v)]
        if runtimes:
            rec["runtime_seconds_mean"] = float(np.mean(runtimes))
            rec["runtime_seconds_std"] = float(np.std(runtimes, ddof=1)) if len(runtimes) > 1 else 0.0
        summary.append(rec)

    not_app = [
        {"method": "existing_only/random/kmeans/greedy/5g_only", "status": "not_applicable", "reason": "system/no-deployment baselines are excluded from fair optimizer HV/GD/IGD."},
        {"method": "DCR", "status": "not_applicable", "reason": "No existing stable DCR implementation was found for this exact four-objective same-space package."},
        {"method": "OE", "status": "not_applicable", "reason": "Existing OE code is artifact-specific audit code, not a stable shared implementation for this package."},
    ] + failures

    write_csv(ROOT / "per_seed_selected_solution_metrics.csv", selected)
    write_csv(ROOT / "per_seed_objective_vectors.csv", objectives)
    write_csv(ROOT / "per_seed_nondominated_vectors.csv", nd_rows)
    write_csv(ROOT / "robustness_per_seed_metrics.csv", per_seed)
    write_csv(ROOT / "robustness_summary.csv", summary)
    write_csv(ROOT / "paper_ready_fair_optimizer_robustness_table.csv", summary)
    write_csv(ROOT / "not_applicable_methods.csv", not_app)
    (ROOT / "paper_ready_fair_optimizer_robustness_table.md").write_text(md_table(summary, ["method", "n", "HV_mean", "GD_mean", "IGD_mean", "AN_mean", "nondominated_count_mean", "runtime_seconds_mean"]), encoding="utf-8")
    (ROOT / "paper_ready_fair_optimizer_robustness_table.tex").write_text(latex_table(summary, ["method", "HV_mean", "GD_mean", "IGD_mean", "AN_mean"]), encoding="utf-8")

    best_hv = max(summary, key=lambda r: _as_float(r.get("HV_mean"), -1.0)) if summary else {}
    best_gd = min(summary, key=lambda r: _as_float(r.get("GD_mean"), math.inf)) if summary else {}
    best_igd = min(summary, key=lambda r: _as_float(r.get("IGD_mean"), math.inf)) if summary else {}
    best_an = max(summary, key=lambda r: _as_float(r.get("AN_mean"), -1.0)) if summary else {}
    claims = [
        "# Fair Optimizer Robustness Claims",
        "",
        "- This is the fair optimizer robustness under the same all-K search space.",
        "- All completed methods use K=10 heterogeneous `[x,y,z,station_type_index,sector_direction_index]` encoding and the same per-seed shared initial population.",
        "- HV/GD/IGD/AN use only `[C_dep, H, -Q_E, -Q_P]`; ASU is not used.",
        "- AirHERO caveat: `airhero_search_same_initialization` preserves the adopted AirHERO search/evaluator logic internally; its final population is post-evaluated on `[C_dep, H, -Q_E, -Q_P]` for this robustness diagnostic.",
        f"- Best mean HV: `{best_hv.get('method', '')}`.",
        f"- Best mean GD: `{best_gd.get('method', '')}`.",
        f"- Best mean IGD: `{best_igd.get('method', '')}`.",
        f"- Largest mean AN: `{best_an.get('method', '')}`.",
        "- DCR/OE are not reported because no stable existing implementation was available for this exact package.",
        "- Safe: discuss same-space objective-vector robustness for completed optimizers.",
        "- Unsafe: do not mix with package 05 or claim universal dominance unless all metrics support it.",
    ]
    (ROOT / "paper_ready_fair_optimizer_robustness_claims.md").write_text("\n".join(claims) + "\n", encoding="utf-8")

    completed = sorted({row.get("method") for row in selected if str(row.get("success", "True")).lower() != "false"})
    readiness = [
        {"criterion": "every_completed_method_uses_K10", "pass": all(str(row.get("K")) == "10" for row in selected if str(row.get("success", "True")).lower() != "false")},
        {"criterion": "same_allK_heterogeneous_encoding", "pass": all(truthy(row.get("allk_heterogeneous_encoding")) for row in selected if str(row.get("success", "True")).lower() != "false")},
        {"criterion": "same_shared_initial_population_per_seed", "pass": all(truthy(row.get("shared_initial_population_used")) for row in selected if str(row.get("success", "True")).lower() != "false")},
        {"criterion": "seeds_2026_2027_2028_for_completed_methods", "pass": all(len([row for row in selected if row.get("method") == method and str(row.get("success", "True")).lower() != "false"]) == 3 for method in completed)},
        {"criterion": "objective_vector_Cdep_H_minusQE_minusQP", "pass": all(str(row.get("objective_vector")) == "[C_dep, H, -Q_E, -Q_P]" for row in selected if str(row.get("success", "True")).lower() != "false")},
        {"criterion": "airhero_internal_search_objective_caveat_documented", "pass": True},
        {"criterion": "ASU_used_for_HV_GD_IGD_false", "pass": all(str(row.get("ASU_used_for_HV_GD_IGD")).lower() == "false" for row in per_seed)},
        {"criterion": "unified_reference_front_used", "pass": bool(reference_front.size)},
        {"criterion": "AN_computed_from_final_nondominated_vectors", "pass": all("AN" in row for row in per_seed)},
        {"criterion": "DCR_OE_not_invented", "pass": True},
        {"criterion": "height_violation_zero", "pass": all(int(_as_float(row.get("height_violation_count"), 0)) == 0 for row in selected if str(row.get("success", "True")).lower() != "false")},
        {"criterion": "asu_recompute_mismatch_zero", "pass": all(not truthy(row.get("asu_recompute_mismatch")) for row in selected if str(row.get("success", "True")).lower() != "false")},
        {"criterion": "no_K5_baseline_archive_reused", "pass": True},
        {"criterion": "no_fake_robustness_values_inserted", "pass": not any(str(row.get("success", "")).lower() == "false" and row.get("HV") for row in per_seed)},
    ]
    write_csv(ROOT / "readiness_check.csv", readiness)

    report = [
        "# Fair Optimizer Robustness Under Same All-K Search Space",
        "",
        "This package is separate from the previous matched-main diagnostic package. It uses K=10 all-K heterogeneous decisions, shared initial populations, and the unified objective vector `[C_dep, H, -Q_E, -Q_P]`.",
        "",
        "AirHERO caveat: `airhero_search_same_initialization` preserves the adopted AirHERO internal search and response logic; this package post-evaluates its final population on the unified four-objective vector for HV/GD/IGD/AN. Therefore, use this as a same-space and same-initialization robustness diagnostic, not as proof that every optimizer has identical search-time scalarization internals.",
        "",
        "## Completed methods",
        "",
        ", ".join(completed),
        "",
        "## Not applicable",
        "",
        md_table(not_app, ["method", "status", "reason"]),
        "## Summary",
        "",
        md_table(summary, ["method", "HV_mean", "GD_mean", "IGD_mean", "AN_mean", "nondominated_count_mean", "runtime_seconds_mean"]),
        "## Answers",
        "",
        f"- Best mean HV: `{best_hv.get('method', '')}`.",
        f"- Best mean GD: `{best_gd.get('method', '')}`.",
        f"- Best mean IGD: `{best_igd.get('method', '')}`.",
        f"- Largest AN: `{best_an.get('method', '')}`.",
        "- DCR and OE: not available as stable existing implementations for this package.",
        "- Safe: describe this as fair optimizer robustness under the same all-K search space.",
        "- Unsafe: do not claim universal dominance unless HV, GD, IGD, AN, and system metrics jointly support it.",
    ]
    (ROOT / "robustness_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")

    metadata = {
        "route_count": 80,
        "current_route_count": 33,
        "predicted_route_count": 47,
        "K": K,
        "z_max": Z_MAX,
        "population": POPULATION,
        "iterations": ITERATIONS,
        "seeds": SEEDS,
        "methods": list(METHODS.keys()),
        "objective_vector": "[C_dep, H, -Q_E, -Q_P]",
        "ASU_used_for_HV_GD_IGD": False,
        "airhero_internal_search_objective_caveat": "AirHERO preserves adopted internal search/evaluator logic; final population is post-evaluated on [C_dep,H,-Q_E,-Q_P] for robustness metrics.",
        "reference_front": "merged nondominated normalized four-objective vectors from all completed methods/seeds",
        "normalization": {"ideal": ideal.tolist(), "nadir": nadir.tolist(), "reference_point": REFERENCE_POINT.tolist()},
        "hv_method": f"shared deterministic Monte Carlo, samples={MC_SAMPLES}",
        "DCR_status": "not_applicable_existing_stable_definition_unavailable",
        "OE_status": "not_applicable_existing_stable_definition_unavailable",
        "shared_initial_population_files": [f"shared_initial_population/shared_initial_population_seed{seed}.csv" for seed in SEEDS],
        "proxy_labels_preserved": True,
    }
    (ROOT / "metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")

    FINAL_SUMMARY.mkdir(parents=True, exist_ok=True)
    for suffix in ["csv", "md", "tex"]:
        src = ROOT / f"paper_ready_fair_optimizer_robustness_table.{suffix}"
        if src.exists():
            (FINAL_SUMMARY / f"paper_ready_fair_optimizer_robustness_table.{suffix}").write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    (FINAL_SUMMARY / "paper_ready_fair_optimizer_robustness_claims.md").write_text((ROOT / "paper_ready_fair_optimizer_robustness_claims.md").read_text(encoding="utf-8"), encoding="utf-8")
    write_csv(FINAL_SUMMARY / "fair_optimizer_robustness_readiness_check.csv", readiness)
    print(json.dumps({"root": ROOT.as_posix(), "completed_methods": completed, "reference_front_size": int(reference_front.shape[0])}, ensure_ascii=False, indent=2))


def launch_parallel(concurrency: int = 7) -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    logs = ROOT / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    pending = [(method, seed) for method in METHODS for seed in SEEDS]
    running = []
    finished = []
    while pending or running:
        while pending and len(running) < int(concurrency):
            method, seed = pending.pop(0)
            stdout = (logs / f"{method}_seed{seed}_stdout.log").open("w", encoding="utf-8")
            stderr = (logs / f"{method}_seed{seed}_stderr.log").open("w", encoding="utf-8")
            cmd = [sys.executable, str(Path(__file__).relative_to(REPO_ROOT)), "--single", "--method", method, "--seed", str(seed)]
            proc = subprocess.Popen(cmd, cwd=REPO_ROOT, stdout=stdout, stderr=stderr, text=True)
            running.append((method, seed, proc, stdout, stderr))
        time.sleep(30)
        keep = []
        for method, seed, proc, stdout, stderr in running:
            code = proc.poll()
            if code is None:
                keep.append((method, seed, proc, stdout, stderr))
                continue
            stdout.close()
            stderr.close()
            finished.append({"method": method, "seed": seed, "returncode": int(code)})
        running = keep
    (logs / "launcher_summary.json").write_text(json.dumps({"finished": finished}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"finished": finished}, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--single", action="store_true")
    parser.add_argument("--method", choices=list(METHODS.keys()))
    parser.add_argument("--seed", type=int)
    parser.add_argument("--run-parallel", action="store_true")
    parser.add_argument("--concurrency", type=int, default=7)
    parser.add_argument("--aggregate", action="store_true")
    args = parser.parse_args()
    if args.single:
        if not args.method or args.seed is None:
            raise SystemExit("--single requires --method and --seed")
        print(json.dumps(run_single(args.method, int(args.seed)), ensure_ascii=False, indent=2))
        return
    if args.run_parallel:
        launch_parallel(args.concurrency)
        return
    if args.aggregate:
        aggregate()
        return
    launch_parallel(args.concurrency)
    aggregate()


if __name__ == "__main__":
    main()
