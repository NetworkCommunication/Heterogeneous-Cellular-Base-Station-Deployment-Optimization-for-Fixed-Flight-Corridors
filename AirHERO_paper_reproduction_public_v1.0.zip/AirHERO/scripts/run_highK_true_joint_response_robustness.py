from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault(
    "MPLCONFIGDIR",
    str((REPO_ROOT / "artifacts/tmc_rebuild/true_joint_response_robustness_highK/_mplcache").resolve()),
)
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
import src.baselines.proposed_search_expansion_response_v2.adapter as v2_module
from scripts.run_true_sinr_true_joint_refinement_diagnostic import (
    component_fields,
    objective_row,
)
from src.algorithms.particle_encoding import decode_particle_solution
from src.baselines.registry import build_method_registry
from src.experiments.asu_route_service_v2_sinr import (
    ASU_ROUTE_SERVICE_V2_SINR,
    evaluate_with_existing_context_sinr_asu_v2,
)


ROOT = Path("artifacts/tmc_rebuild/true_joint_response_robustness_highK")
K15_ROOT = ROOT / "K15"

ENABLED = "true_joint_refinement_v2_asu_v2"
DISABLED = "true_joint_without_response_v2_asu_v2"
ENABLED_ADAPTER = "proposed_method_search_expansion_response_v2_asu_v2"
DISABLED_ADAPTER = "v2_without_search_expansion_response_asu_v2"

SEEDS = [2026, 2027, 2028]
K = 15
K1 = 8
K2 = 7
POPULATION = 50
ITERATIONS = 150
SINR_RHO = 0.10
SECTOR_AZIMUTHS = [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]

SUMMARY_METRICS = [
    "ASU",
    "Q_current",
    "Q_future",
    "ASU_numerator",
    "ASU_denominator",
    "denominator",
    "C_dep",
    "handover_count",
    "Coverage@0dB",
    "Coverage@5dB",
    "Coverage@10dB",
    "current_Coverage@0dB",
    "future_Coverage@0dB",
    "current_Coverage@5dB",
    "future_Coverage@5dB",
    "current_Coverage@10dB",
    "future_Coverage@10dB",
    "outage@0dB",
    "mean_SINR_db",
    "N_5G",
    "N_5GA",
    "stage1_5G_count",
    "stage1_5GA_count",
    "stage2_5G_count",
    "stage2_5GA_count",
    "runtime",
    "response_count",
    "mild_response_count",
    "moderate_response_count",
    "severe_response_count",
    "response_restart_count",
    "other_restart_count",
    "pbest_preservation_count",
]


def main() -> None:
    configure()
    K15_ROOT.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    stations = formal.read_csv(formal.STATION_PATH)
    routes = formal.read_csv(formal.ROUTE_POINT_PATH)
    all_problem, current_problem, _, meta = formal.build_problems(stations, routes)
    for problem in [all_problem, current_problem]:
        true_formal.apply_true_sinr_config(problem.config)
        force_true_sinr_metadata(problem.config)

    registry = build_method_registry()
    tables = load_tables()
    completed = {
        (row.get("method", ""), str(row.get("seed", "")))
        for row in tables["status"]
        if row.get("status") == "completed"
    }

    for method, adapter_key, force_zero in [
        (ENABLED, ENABLED_ADAPTER, False),
        (DISABLED, DISABLED_ADAPTER, True),
    ]:
        adapter = registry.get(adapter_key)
        registered = adapter is not None
        implemented = bool(getattr(adapter, "implemented", False)) if registered else False
        for seed in SEEDS:
            if (method, str(seed)) in completed:
                continue
            remove_previous_attempt(tables, method, seed)
            status = {
                "method": method,
                "adapter_key": adapter_key,
                "seed": seed,
                "K": K,
                "K1": K1,
                "K2": K2,
                "registered": registered,
                "implemented": implemented,
                "status": "pending",
                "reason": "",
            }
            if not registered or not implemented:
                status["status"] = "failed"
                status["reason"] = "method adapter not registered or not implemented"
                tables["status"].append(status)
                tables["failed"].append(dict(status))
                write_all(tables, meta, time.time() - t0)
                continue
            try:
                run = run_true_joint_variant(
                    adapter=adapter,
                    method=method,
                    seed=int(seed),
                    current_problem=current_problem,
                    all_problem=all_problem,
                    force_response_zero=force_zero,
                )
                for key, value in run.items():
                    if key in {"decoded", "iteration_trace", "event_trace"}:
                        tables[key].extend(value)
                    else:
                        tables[key].append(value)
                status["status"] = "completed"
            except Exception as exc:  # pragma: no cover - diagnostic runner records failures.
                status["status"] = "failed"
                status["reason"] = f"{type(exc).__name__}: {exc}"
                tables["failed"].append(dict(status))
            tables["status"].append(status)
            write_all(tables, meta, time.time() - t0)

    write_all(tables, meta, time.time() - t0)
    print(
        json.dumps(
            {
                "artifact_root": K15_ROOT.as_posix(),
                "completed_runs": len([r for r in tables["status"] if r.get("status") == "completed"]),
                "failed_runs": len(tables["failed"]),
            },
            indent=2,
        )
    )


def configure() -> None:
    for module in [formal, true_formal]:
        module.K = K
        module.K1 = K1
        module.K2 = K2
        module.POPULATION = POPULATION
        module.ITERATIONS = ITERATIONS


def force_true_sinr_metadata(config: Dict[str, Any]) -> None:
    config["asu_preset"] = ASU_ROUTE_SERVICE_V2_SINR
    config["optimization_signal_metric"] = "sinr"
    config.setdefault("airwayServiceUtility", {})["asu_preset"] = ASU_ROUTE_SERVICE_V2_SINR
    config.setdefault("airwayServiceUtilityV2", {}).update(
        {
            "signal_metric": "sinr",
            "optimization_signal_metric": "sinr",
            "w_current": 0.5,
            "w_future": 0.5,
            "C_5G": 1.0,
            "C_5GA": 1.35,
            "kappa_H": 0.01,
            "C_0": 1.0,
        }
    )
    config.setdefault("evaluation", {}).update(
        {
            "signal_metric": "sinr",
            "optimization_signal_metric": "sinr",
            "threshold_main_db": 0.0,
            "auxiliary_thresholds_db": [5.0, 10.0],
            "rho": SINR_RHO,
            "power_mode": "station_file_preferred",
        }
    )
    config.setdefault("heterogeneousDeployment", {}).setdefault("stationTypes", [])
    for station_type in config["heterogeneousDeployment"].get("stationTypes", []):
        if station_type.get("name") == "5GA":
            station_type["coverageBoostDb"] = 9.0
            station_type["txPowerOffsetDb"] = 4.0
            station_type["capacityUnits"] = 3.0
            station_type["deploymentCost"] = 1.35
            station_type["cost"] = 1.35
        elif station_type.get("name") == "5G":
            station_type["deploymentCost"] = 1.0
            station_type["cost"] = 1.0


def run_true_joint_variant(
    *,
    adapter: Any,
    method: str,
    seed: int,
    current_problem: Any,
    all_problem: Any,
    force_response_zero: bool,
) -> Dict[str, Any]:
    t0 = time.time()
    s1_cfg = formal.stage_config(current_problem.config, K1, stage=f"{method}_current")
    true_formal.apply_true_sinr_config(s1_cfg)
    force_true_sinr_metadata(s1_cfg)
    stage1 = adapter.run(current_problem, seed=seed, config=s1_cfg)
    stage1_best = formal.best_decision(stage1, K1)

    s2_cfg = formal.stage_config(all_problem.config, K, stage=f"{method}_true_joint_all_routes")
    true_formal.apply_true_sinr_config(s2_cfg)
    force_true_sinr_metadata(s2_cfg)
    original_init = v2_module._initialize_population
    init_records: List[Dict[str, Any]] = []

    def seeded_init(problem: Any, cfg: Dict[str, Any], rng: np.random.Generator, pop_size: int, k: int, min_pos: np.ndarray, max_pos: np.ndarray):
        particles, summary = original_init(problem, cfg, rng, pop_size, k, min_pos, max_pos)
        s1 = np.asarray(stage1_best, dtype=float).reshape(K1, 5)
        for p_idx in range(pop_size):
            particles[p_idx, :K1, :] = s1
            if p_idx > 0:
                particles[p_idx, :K1, :3] += rng.normal(0.0, 45.0, size=(K1, 3))
        particles = v2_module._repair_particles(particles, problem, cfg, rng, min_pos, max_pos)
        exact = int(np.sum(np.all(np.isclose(particles[:, :K1, :], s1[None, :, :], atol=1e-9), axis=(1, 2))))
        init_records.append(
            {
                "stage2_population": int(pop_size),
                "stage2_k": int(k),
                "exact_stage1_seed_particle_count": exact,
                "stage1_seeded_initialization": True,
                "stage2_jointly_optimizes_all_K": True,
            }
        )
        return particles, list(summary) + init_records[-1:]

    try:
        v2_module._initialize_population = seeded_init  # type: ignore[assignment]
        stage2 = adapter.run(all_problem, seed=seed + 1009, config=s2_cfg)
    finally:
        v2_module._initialize_population = original_init  # type: ignore[assignment]

    final = formal.best_decision(stage2, K)
    runtime = float(time.time() - t0)
    eval_pack = evaluate_with_existing_context_sinr_asu_v2(
        decisions=final.reshape(1, K, 5),
        problem=all_problem,
        config=all_problem.config,
        method_name=method,
    )
    row = dict(eval_pack.metrics[0])
    deployment_hash = hash_particle(final)
    stage1_counts = formal.station_type_counts(stage1_best)
    final_stage1_counts = formal.station_type_counts(final[:K1])
    final_stage2_counts = formal.station_type_counts(final[K1:])
    response = response_summary(stage1, stage2, force_zero=force_response_zero)
    modified = not np.allclose(final[:K1], stage1_best, atol=1e-8, rtol=0.0)
    consistency = objective_final_consistency(method, seed, final, all_problem, row)

    run_row = {
        "method": method,
        "seed": seed,
        "K": K,
        "K1": K1,
        "K2": K2,
        **row,
        "numerator": row.get("ASU_numerator", ""),
        "denominator": row.get("ASU_denominator", row.get("denominator", "")),
        "Coverage@0": row.get("Coverage@0dB", ""),
        "Coverage@5": row.get("Coverage@5dB", ""),
        "Coverage@10": row.get("Coverage@10dB", ""),
        "runtime": runtime,
        "population": POPULATION,
        "iterations_per_stage": ITERATIONS,
        "stage1_5G_count": stage1_counts[0],
        "stage1_5GA_count": stage1_counts[1],
        "stage2_5G_count": final_stage2_counts[0],
        "stage2_5GA_count": final_stage2_counts[1],
        "response_restart_count": response.get("restart_count", 0),
        "other_restart_count": 0,
        "optimization_signal_metric": "sinr",
        "rho": row.get("rho", SINR_RHO),
        "objective_final_consistency_flag": bool(consistency["numerically_close"]),
        "selected_deployment_hash": deployment_hash,
        "deployment_hash": deployment_hash,
        "stage1_modified_in_stage2_flag": bool(modified),
        "station_data_label": "route-agnostic simulated/proxy existing infrastructure; not real operator base-station records",
        "route_data_label": "generated/proxy semantic POI route points; not real measured airways",
        "single_fidelity_true_sinr": True,
        "sinr_multi_fidelity": False,
        **response,
    }
    decoded = decoded_rows(final, all_problem.config, method, seed, row, deployment_hash, stage1_best)
    station_row = station_summary_row(method, seed, decoded, row, stage1_counts, final_stage1_counts, final_stage2_counts, deployment_hash, modified)
    return {
        "all_runs": run_row,
        "asu_components": {"method": method, "seed": seed, "K": K, "K1": K1, "K2": K2, **component_fields(row)},
        "station_summary": station_row,
        "runtime_summary": {
            "method": method,
            "seed": seed,
            "K": K,
            "K1": K1,
            "K2": K2,
            "runtime": runtime,
            "stage1_runtime_seconds": stage1.runtime_seconds,
            "stage2_runtime_seconds": stage2.runtime_seconds,
            "population": POPULATION,
            "iterations_per_stage": ITERATIONS,
            "approximate_evaluations": 2 * POPULATION * (ITERATIONS + 1),
        },
        "response_summary": {"method": method, "seed": seed, "K": K, "K1": K1, "K2": K2, **response},
        "decoded": decoded,
        "best_chromosomes": {
            "method": method,
            "seed": seed,
            "K": K,
            "K1": K1,
            "K2": K2,
            "deployment_hash": deployment_hash,
            "stage1_seed_chromosome_json": json.dumps(stage1_best.reshape(-1).tolist()),
            "stage2_joint_chromosome_json": json.dumps(final.reshape(-1).tolist()),
            "final_chromosome_json": json.dumps(final.reshape(-1).tolist()),
            "ASU_of_selected_solution": row.get("ASU", ""),
        },
        "best_solution_objectives": objective_row(method, seed, row, eval_pack, deployment_hash),
        "objective_final_consistency": {
            "method": method,
            "seed": seed,
            "K": K,
            "stage2_chromosome_station_count": int(final.shape[0]),
            "stage2_chromosome_length_values": int(final.size),
            "stage2_chromosome_represents_K_stations": bool(final.shape == (K, 5)),
            "final_selected_from_stage2_K_station_chromosome": True,
            "stage2_jointly_optimizes_all_K_stations": True,
            "stage2_initialization_includes_stage1_derived": bool(init_records and init_records[-1].get("stage1_seeded_initialization")),
            "exact_stage1_seed_particle_count": init_records[-1].get("exact_stage1_seed_particle_count", "") if init_records else "",
            "optimization_signal_metric": "sinr",
            "rho": row.get("rho", ""),
            "rho_is_0_10": abs(float(row.get("rho", 0.0)) - SINR_RHO) < 1e-12,
            "C_5GA": row.get("C_5GA", 1.35),
            "C_5GA_is_1_35": abs(float(row.get("C_5GA", 1.35)) - 1.35) < 1e-12,
            "threshold_main_db": row.get("threshold_main_db", 0.0),
            "threshold_main_db_is_0": abs(float(row.get("threshold_main_db", 0.0))) < 1e-12,
            **consistency,
        },
        "iteration_trace": iteration_trace_rows(method, seed, stage1, stage2, row, deployment_hash),
        "event_trace": event_trace_rows(method, seed, stage1, stage2, force_zero=force_response_zero),
        "best_solution_timing": best_solution_timing_row(method, seed, stage1, stage2, row, deployment_hash),
    }


def response_summary(stage1: Any, stage2: Any, *, force_zero: bool) -> Dict[str, Any]:
    def s(key: str) -> int:
        return int(stage1.logs.get(key, 0) or 0) + int(stage2.logs.get(key, 0) or 0)

    out = {
        "response_count": s("response_count") or s("trigger_count"),
        "mild_response_count": s("mild_response_count"),
        "moderate_response_count": s("moderate_response_count"),
        "severe_response_count": s("severe_response_count"),
        "restart_count": s("restart_count"),
        "response_restart_count": s("response_restart_count") or s("restart_count"),
        "other_restart_count": s("other_restart_count"),
        "pbest_preservation_count": s("pbest_preservation_count") or s("pbest_preserved_count"),
        "response_action_count": s("response_action_count"),
        "trigger_count": s("trigger_count"),
        "stage1_response_count": int(stage1.logs.get("response_count", stage1.logs.get("trigger_count", 0)) or 0),
        "stage2_response_count": int(stage2.logs.get("response_count", stage2.logs.get("trigger_count", 0)) or 0),
    }
    if force_zero:
        out["stagnation_trigger_count_logged"] = out["trigger_count"]
        for key in [
            "response_count",
            "mild_response_count",
            "moderate_response_count",
            "severe_response_count",
            "restart_count",
            "response_restart_count",
            "pbest_preservation_count",
            "response_action_count",
            "stage1_response_count",
            "stage2_response_count",
        ]:
            out[key] = 0
    return out


def decoded_rows(
    final: np.ndarray,
    config: Dict[str, Any],
    method: str,
    seed: int,
    metric_row: Dict[str, Any],
    deployment_hash: str,
    stage1_seed: np.ndarray,
) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for item in decode_particle_solution(np.asarray(final, dtype=float).reshape(K, 5), config):
        station_id = int(item["station_id"])
        stage = "stage1_derived_joint_refined" if station_id <= K1 else "stage2_added_joint_refined"
        row = dict(item)
        row.update(
            {
                "method": method,
                "seed": seed,
                "K": K,
                "K1": K1,
                "K2": K2,
                "stage": stage,
                "station_source": stage,
                "deployment_hash": deployment_hash,
                "ASU_of_selected_solution": metric_row.get("ASU", ""),
                "Q_current": metric_row.get("Q_current", ""),
                "Q_future": metric_row.get("Q_future", ""),
                "Coverage@0": metric_row.get("Coverage@0dB", ""),
                "Coverage@5": metric_row.get("Coverage@5dB", ""),
                "Coverage@10": metric_row.get("Coverage@10dB", ""),
                "current_Coverage@0": metric_row.get("current_Coverage@0dB", ""),
                "future_Coverage@0": metric_row.get("future_Coverage@0dB", ""),
                "handover_count": metric_row.get("handover_count", ""),
                "C_dep": metric_row.get("C_dep", ""),
                "denominator": metric_row.get("denominator", metric_row.get("ASU_denominator", "")),
            }
        )
        if station_id <= K1:
            before = stage1_seed[station_id - 1]
            after = final[station_id - 1]
            row["stage1_seed_x"] = before[0]
            row["stage1_seed_y"] = before[1]
            row["stage1_seed_z"] = before[2]
            row["stage1_seed_station_type_index"] = before[3]
            row["stage1_seed_sector_direction_index"] = before[4]
            row["delta_from_stage1_seed_norm"] = float(np.linalg.norm(after - before))
        out.append(row)
    return out


def station_summary_row(
    method: str,
    seed: int,
    decoded: Sequence[Dict[str, Any]],
    metric_row: Dict[str, Any],
    stage1_initial_counts: tuple[int, int],
    final_stage1_counts: tuple[int, int],
    final_stage2_counts: tuple[int, int],
    deployment_hash: str,
    modified: bool,
) -> Dict[str, Any]:
    sectors = [sf(r.get("sector_azimuth_deg", r.get("sector_direction", ""))) for r in decoded if str(r.get("station_type", "")).upper() == "5GA"]
    return {
        "method": method,
        "seed": seed,
        "K": K,
        "K1": K1,
        "K2": K2,
        "selected_5G_count": metric_row.get("N_5G", ""),
        "selected_5GA_count": metric_row.get("N_5GA", ""),
        "stage1_initial_5G_count": stage1_initial_counts[0],
        "stage1_initial_5GA_count": stage1_initial_counts[1],
        "stage1_final_5G_count": final_stage1_counts[0],
        "stage1_final_5GA_count": final_stage1_counts[1],
        "stage2_5G_count": final_stage2_counts[0],
        "stage2_5GA_count": final_stage2_counts[1],
        "stage1_modified_in_stage2_flag": bool(modified),
        "sector_directions_5GA": ";".join(str(v) for v in sectors),
        "valid_5GA_sector_directions": all(any(abs(v - s) < 1e-9 for s in SECTOR_AZIMUTHS) for v in sectors),
        "all_station_count_exactly_K": len(decoded) == K,
        "deployment_hash": deployment_hash,
    }


def iteration_trace_rows(method: str, seed: int, stage1: Any, stage2: Any, final_row: Dict[str, Any], deployment_hash: str) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for stage_name, stage in [("stage1_current", stage1), ("stage2_true_joint_all_routes", stage2)]:
        action_by_iter = action_lookup(stage.logs.get("response_action_log", []))
        for item in stage.logs.get("stagnation_score_trace", []) or []:
            iteration = int(float(item.get("iteration", 0) or 0))
            action = action_by_iter.get(iteration, {})
            rows.append(
                {
                    "method": method,
                    "seed": seed,
                    "K": K,
                    "stage": stage_name,
                    "iteration": iteration,
                    "current_best_ASU": "unavailable",
                    "current_best_Coverage@0": "unavailable",
                    "current_best_Coverage@5": "unavailable",
                    "current_best_Coverage@10": "unavailable",
                    "current_best_Q_current": "unavailable",
                    "current_best_Q_future": "unavailable",
                    "current_best_N_5G": "unavailable",
                    "current_best_N_5GA": "unavailable",
                    "current_best_deployment_hash": "unavailable",
                    "global_best_ASU_so_far": "unavailable",
                    "response_triggered": bool(item.get("trigger_flag", False)),
                    "response_type": item.get("trigger_level", "none"),
                    "response_action": item.get("response_action", "none"),
                    "response_affected_particle_count": action.get("sparse_injection_count", action.get("particles_restarted", "unavailable")),
                    "whether_global_best_improved_after_response": "unavailable",
                    "whether_response_changed_final_selected_solution": "unavailable",
                    "archive_best_ASU": "unavailable",
                    "pbest_best_ASU": "unavailable",
                    "archive_size": item.get("nondominated_count", ""),
                    "pbest_preservation_count": action.get("pbest_preserved_count", ""),
                    "final_solution_originated_from_response_modified_candidate": "unavailable",
                    "final_ASU": final_row.get("ASU", ""),
                    "final_deployment_hash": deployment_hash,
                    **{k: v for k, v in item.items() if k not in {"iteration"}},
                }
            )
    return rows


def event_trace_rows(method: str, seed: int, stage1: Any, stage2: Any, *, force_zero: bool) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for stage_name, stage in [("stage1_current", stage1), ("stage2_true_joint_all_routes", stage2)]:
        for item in stage.logs.get("response_action_log", []) or []:
            row = {"method": method, "seed": seed, "K": K, "stage": stage_name, "event_kind": "response_action", **item}
            if force_zero:
                row["counted_as_response_action"] = False
                row["disabled_control_note"] = "detector may log disabled_control, but response actions are disabled and counters are exported as zero"
            else:
                row["counted_as_response_action"] = item.get("response_action", "none") not in {"none", "disabled_control"}
            rows.append(row)
        for item in stage.logs.get("response_acceptance_log", []) or []:
            rows.append({"method": method, "seed": seed, "K": K, "stage": stage_name, "event_kind": "response_acceptance", **item})
    return rows


def best_solution_timing_row(method: str, seed: int, stage1: Any, stage2: Any, final_row: Dict[str, Any], deployment_hash: str) -> Dict[str, Any]:
    events = []
    after_gt_before = False
    for stage_name, stage in [("stage1_current", stage1), ("stage2_true_joint_all_routes", stage2)]:
        for item in stage.logs.get("response_action_log", []) or []:
            events.append(f"{stage_name}:{item.get('iteration')}:{item.get('severity')}:{item.get('response_action')}")
        for item in stage.logs.get("response_acceptance_log", []) or []:
            before = sf(item.get("before_ASU_auxiliary"))
            after = sf(item.get("after_ASU_auxiliary"))
            if math.isfinite(before) and math.isfinite(after) and after > before + 1e-12:
                after_gt_before = True
    return {
        "method": method,
        "seed": seed,
        "K": K,
        "final_ASU": final_row.get("ASU", ""),
        "final_deployment_hash": deployment_hash,
        "final_best_ASU_first_iteration": "unavailable",
        "response_event_iterations": ";".join(events) if events else "",
        "final_best_found_before_first_response": "unavailable",
        "response_occurred_only_after_convergence": "unavailable",
        "any_response_event_improved_ASU_auxiliary_window": after_gt_before if events else "not_applicable_or_unavailable",
        "any_response_event_improved_global_best_ASU": "unavailable",
        "trace_limitation": "optimizer logs expose stagnation dynamics and response action/acceptance logs, but not per-iteration global-best ASU provenance",
    }


def action_lookup(rows: Sequence[Dict[str, Any]]) -> Dict[int, Dict[str, Any]]:
    out: Dict[int, Dict[str, Any]] = {}
    for row in rows or []:
        try:
            out[int(float(row.get("iteration", -1)))] = dict(row)
        except Exception:
            pass
    return out


def objective_final_consistency(method: str, seed: int, final: np.ndarray, problem: Any, final_row: Dict[str, Any]) -> Dict[str, Any]:
    check = evaluate_with_existing_context_sinr_asu_v2(
        decisions=final.reshape(1, K, 5),
        problem=problem,
        config=problem.config,
        method_name=f"{method}_objective_final_consistency",
    )
    row = dict(check.metrics[0])
    keys = ["ASU", "Q_current", "Q_future", "ASU_numerator", "ASU_denominator", "Coverage@0dB", "Coverage@5dB", "Coverage@10dB", "C_dep", "handover_count"]
    out: Dict[str, Any] = {}
    max_abs = 0.0
    for key in keys:
        delta = abs(sf(row.get(key)) - sf(final_row.get(key)))
        out[f"optimization_{key}"] = row.get(key, "")
        out[f"final_{key}"] = final_row.get(key, "")
        out[f"abs_delta_{key}"] = delta
        max_abs = max(max_abs, delta)
    out["max_abs_delta"] = max_abs
    out["numerically_close"] = max_abs < 1e-9
    return out


def write_all(tables: Dict[str, List[Dict[str, Any]]], meta: Dict[str, Any], elapsed: float) -> None:
    write_csv(K15_ROOT / "highK_response_all_runs.csv", tables["all_runs"])
    write_csv(K15_ROOT / "highK_response_asu_components.csv", tables["asu_components"])
    write_csv(K15_ROOT / "highK_response_station_summary.csv", tables["station_summary"])
    write_csv(K15_ROOT / "highK_response_runtime_summary.csv", tables["runtime_summary"])
    write_csv(K15_ROOT / "highK_response_response_summary.csv", tables["response_summary"])
    write_csv(K15_ROOT / "highK_response_method_status.csv", tables["status"])
    write_csv(K15_ROOT / "highK_response_failed_runs.csv", tables["failed"])
    write_csv(K15_ROOT / "highK_response_decoded_deployments.csv", tables["decoded"])
    write_csv(K15_ROOT / "highK_response_best_chromosomes.csv", tables["best_chromosomes"])
    write_csv(K15_ROOT / "highK_response_best_solution_objectives.csv", tables["best_solution_objectives"])
    write_csv(K15_ROOT / "highK_response_iteration_trace.csv", tables["iteration_trace"])
    write_csv(K15_ROOT / "highK_response_event_trace.csv", tables["event_trace"])
    write_csv(K15_ROOT / "highK_response_best_solution_timing.csv", tables["best_solution_timing"])
    write_csv(K15_ROOT / "highK_response_objective_final_consistency.csv", tables["objective_final_consistency"])
    mean = mean_std(tables["all_runs"], ["method"], SUMMARY_METRICS)
    delta_rows, delta_mean = delta_tables(tables["all_runs"])
    write_csv(K15_ROOT / "highK_response_mean_std.csv", mean)
    write_csv(K15_ROOT / "highK_response_delta_by_seed.csv", delta_rows)
    write_csv(K15_ROOT / "highK_response_delta_mean.csv", delta_mean)
    write_json(K15_ROOT / "highK_response_metadata.json", metadata(meta, elapsed))
    plot_outputs(tables, mean, delta_rows)
    write_reports(tables, mean, delta_rows, delta_mean, meta, elapsed)


def delta_tables(rows: Sequence[Dict[str, Any]]) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    metrics = [
        "ASU",
        "Q_current",
        "Q_future",
        "Coverage@0dB",
        "Coverage@5dB",
        "Coverage@10dB",
        "current_Coverage@0dB",
        "future_Coverage@0dB",
        "C_dep",
        "handover_count",
        "N_5GA",
        "runtime",
    ]
    out: List[Dict[str, Any]] = []
    for seed in SEEDS:
        enabled = find_row(rows, ENABLED, seed)
        disabled = find_row(rows, DISABLED, seed)
        if not enabled or not disabled:
            continue
        row: Dict[str, Any] = {"seed": seed, "delta_definition": "response_enabled_minus_disabled"}
        for metric in metrics:
            row[f"enabled_{metric}"] = enabled.get(metric, "")
            row[f"disabled_{metric}"] = disabled.get(metric, "")
            row[f"delta_{metric}"] = sf(enabled.get(metric)) - sf(disabled.get(metric))
        row["enabled_deployment_hash"] = enabled.get("selected_deployment_hash", enabled.get("deployment_hash", ""))
        row["disabled_deployment_hash"] = disabled.get("selected_deployment_hash", disabled.get("deployment_hash", ""))
        row["deployment_hash_identical"] = row["enabled_deployment_hash"] == row["disabled_deployment_hash"]
        out.append(row)
    mean_row: Dict[str, Any] = {"delta_definition": "response_enabled_minus_disabled", "n": len(out)}
    for metric in metrics:
        vals = [sf(r.get(f"delta_{metric}")) for r in out]
        if vals:
            mean_row[f"delta_{metric}_mean"] = float(np.mean(vals))
            mean_row[f"delta_{metric}_std"] = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
    return out, [mean_row]


def plot_outputs(tables: Dict[str, List[Dict[str, Any]]], mean: Sequence[Dict[str, Any]], delta_rows: Sequence[Dict[str, Any]]) -> None:
    if not mean:
        return
    labels = [str(r.get("method")) for r in mean]
    for metric, filename, ylabel in [
        ("ASU_mean", "ASU_enabled_vs_disabled.png", "ASU"),
        ("Coverage@0dB_mean", "Coverage0_enabled_vs_disabled.png", "Coverage@0dB"),
        ("Coverage@5dB_mean", "Coverage5_enabled_vs_disabled.png", "Coverage@5dB"),
        ("Coverage@10dB_mean", "Coverage10_enabled_vs_disabled.png", "Coverage@10dB"),
        ("runtime_mean", "runtime_enabled_vs_disabled.png", "runtime seconds"),
    ]:
        bar(K15_ROOT / filename, labels, [sf(r.get(metric)) for r in mean], ylabel)
    grouped(
        K15_ROOT / "Q_current_future_enabled_vs_disabled.png",
        labels,
        [[sf(r.get("Q_current_mean")) for r in mean], [sf(r.get("Q_future_mean")) for r in mean]],
        ["Q_current", "Q_future"],
        "Q",
    )
    bar(K15_ROOT / "ASU_delta_by_seed.png", [str(r.get("seed")) for r in delta_rows], [sf(r.get("delta_ASU")) for r in delta_rows], "enabled - disabled ASU")
    bar(K15_ROOT / "Coverage10_delta_by_seed.png", [str(r.get("seed")) for r in delta_rows], [sf(r.get("delta_Coverage@10dB")) for r in delta_rows], "enabled - disabled Coverage@10")
    response_rows = tables["response_summary"]
    seed_labels = [str(seed) for seed in SEEDS]
    grouped(
        K15_ROOT / "response_count_by_seed.png",
        seed_labels,
        [
            [sf(find_row(response_rows, ENABLED, seed).get("response_count")) for seed in SEEDS],
            [sf(find_row(response_rows, DISABLED, seed).get("response_count")) for seed in SEEDS],
        ],
        ["enabled", "disabled"],
        "response count",
    )
    plot_best_trace(tables["iteration_trace"])
    plot_event_timing(tables["event_trace"])


def plot_best_trace(rows: Sequence[Dict[str, Any]]) -> None:
    plt.figure(figsize=(10, 4))
    usable = [r for r in rows if str(r.get("global_best_ASU_so_far", "")) not in {"", "unavailable"}]
    if usable:
        for key in sorted({(r.get("method"), r.get("seed"), r.get("stage")) for r in usable}):
            subset = [r for r in usable if (r.get("method"), r.get("seed"), r.get("stage")) == key]
            subset = sorted(subset, key=lambda r: sf(r.get("iteration")))
            plt.plot([sf(r.get("iteration")) for r in subset], [sf(r.get("global_best_ASU_so_far")) for r in subset], label=f"{key[0]}:{key[1]}:{key[2]}", linewidth=0.8)
        plt.legend(fontsize=6)
        plt.ylabel("global best ASU")
    else:
        plt.text(0.5, 0.5, "Per-iteration best ASU unavailable in optimizer logs", ha="center", va="center")
        plt.axis("off")
    plt.tight_layout()
    plt.savefig(K15_ROOT / "best_ASU_trace_by_seed.png", dpi=180)
    plt.close()


def plot_event_timing(rows: Sequence[Dict[str, Any]]) -> None:
    action_rows = [r for r in rows if r.get("event_kind") == "response_action" and r.get("response_action") not in {"none", ""}]
    plt.figure(figsize=(9, 4))
    if action_rows:
        y_labels = []
        y_values = []
        x_values = []
        colors = []
        for row in action_rows:
            label = f"{row.get('method')}:{row.get('seed')}:{row.get('stage')}"
            if label not in y_labels:
                y_labels.append(label)
            y_values.append(y_labels.index(label))
            x_values.append(sf(row.get("iteration")))
            colors.append("tab:orange" if row.get("response_action") == "disabled_control" else "tab:blue")
        plt.scatter(x_values, y_values, c=colors)
        plt.yticks(range(len(y_labels)), y_labels, fontsize=6)
        plt.xlabel("iteration")
        plt.ylabel("run/stage")
    else:
        plt.text(0.5, 0.5, "No response event timing available", ha="center", va="center")
        plt.axis("off")
    plt.tight_layout()
    plt.savefig(K15_ROOT / "response_event_timing_by_seed.png", dpi=180)
    plt.close()


def write_reports(
    tables: Dict[str, List[Dict[str, Any]]],
    mean: Sequence[Dict[str, Any]],
    delta_rows: Sequence[Dict[str, Any]],
    delta_mean: Sequence[Dict[str, Any]],
    meta: Dict[str, Any],
    elapsed: float,
) -> None:
    enabled = find_mean(mean, ENABLED)
    disabled = find_mean(mean, DISABLED)
    delta = delta_mean[0] if delta_mean else {}
    identity = all(str(row.get("deployment_hash_identical")) == "True" for row in delta_rows) if delta_rows else False
    trace_best_available = any(str(r.get("global_best_ASU_so_far", "")) not in {"", "unavailable"} for r in tables["iteration_trace"])
    event_available = bool(tables["event_trace"])
    response_improves_asu = sf(delta.get("delta_ASU_mean")) > 1e-12
    response_improves_cov0 = sf(delta.get("delta_Coverage@0dB_mean")) > 1e-12
    response_improves_cov5 = sf(delta.get("delta_Coverage@5dB_mean")) > 1e-12
    response_improves_cov10 = sf(delta.get("delta_Coverage@10dB_mean")) > 1e-12
    report = f"""# High-K True-Joint Response Robustness Diagnostic

This is a high-K response robustness diagnostic, not the main K=10 formal result. It uses true Stage-II joint refinement, single-fidelity true SINR optimization, and generated/proxy data labels.

## Setting

- K/K1/K2: `{K}/{K1}/{K2}`
- seeds: `{SEEDS}`
- population: `{POPULATION}`
- iterations per stage: `{ITERATIONS}`
- station artifact: `{formal.STATION_PATH.as_posix()}`
- route artifact: `{formal.ROUTE_POINT_PATH.as_posix()}`
- ASU preset: `{ASU_ROUTE_SERVICE_V2_SINR}`
- optimization_signal_metric: `sinr`
- rho: `{SINR_RHO}`
- threshold_main_db: `0`
- auxiliary_thresholds_db: `[5, 10]`

## Mean/Std

{md_table(mean)}

## Delta Mean

{md_table(delta_mean)}

## Required Answers

1. Does response improve ASU at K=15? `{response_improves_asu}`; mean delta `{sf(delta.get('delta_ASU_mean')):+.9f}`.
2. Does response improve Coverage@0/5/10 at K=15? `{response_improves_cov0}` / `{response_improves_cov5}` / `{response_improves_cov10}`.
3. Does response mainly affect current or future routes? Delta current Coverage@0 `{sf(delta.get('delta_current_Coverage@0dB_mean')):+.9f}`, future Coverage@0 `{sf(delta.get('delta_future_Coverage@0dB_mean')):+.9f}`.
4. Does response change station-type composition? Delta N_5GA `{sf(delta.get('delta_N_5GA_mean')):+.9f}`.
5. Does response reduce outage? Delta Coverage@0 `{sf(delta.get('delta_Coverage@0dB_mean')):+.9f}` implies outage delta `{-sf(delta.get('delta_Coverage@0dB_mean')):+.9f}`.
6. Does response change handover? Delta handover `{sf(delta.get('delta_handover_count_mean')):+.9f}`.
7. Does response cause runtime overhead? Delta runtime `{sf(delta.get('delta_runtime_mean')):+.3f}` seconds.
8. Are enabled and disabled deployments identical? `{identity}` by selected deployment hash.
9. If different, is the difference meaningful? See `highK_response_delta_by_seed.csv`; differences are meaningful only if system metrics change consistently.
10. Did final best ASU appear before or after response events? `unavailable`; per-iteration global-best ASU provenance is not exposed.
11. Did any response event improve global best ASU? `unavailable`; response acceptance logs expose before/after auxiliary snapshots but not global-best provenance.
12. Is response useful only as a robustness mechanism? `{not response_improves_asu}` for this K=15 mean result.
13. Should K=20 response diagnostic be run next? `{response_improves_asu or response_improves_cov0 or response_improves_cov10}`; if K=15 shows no final benefit, K=20 should be optional and run only if the paper needs larger-scale robustness evidence.
14. Safe claims are listed in `highK_response_paper_guidance.md`.
15. Unsupported claims are listed in `highK_response_paper_guidance.md`.

## Status

{md_table(tables['status'])}
"""
    (K15_ROOT / "highK_response_report.md").write_text(report, encoding="utf-8")
    (K15_ROOT / "highK_response_delta_report.md").write_text(
        "# High-K Response Delta Report\n\n"
        + md_table(delta_rows)
        + "\n\n## Delta Mean\n\n"
        + md_table(delta_mean)
        + "\n",
        encoding="utf-8",
    )
    (K15_ROOT / "highK_response_trace_report.md").write_text(
        f"""# High-K Response Trace Report

- iteration trace rows: `{len(tables['iteration_trace'])}`
- event trace rows: `{len(tables['event_trace'])}`
- per-iteration stagnation/search-dynamics trace available: `{len(tables['iteration_trace']) > 0}`
- per-iteration global-best ASU trace available: `{trace_best_available}`
- response event timing available: `{event_available}`

The v2 adapter exposes `stagnation_score_trace`, `response_action_log`, and `response_acceptance_log`. It does not expose per-iteration global-best ASU provenance, pbest-best ASU, or final-solution-origin tracking, so those fields are marked as `unavailable` rather than inferred.
""",
        encoding="utf-8",
    )
    consistency_ok = bool(tables["objective_final_consistency"]) and all(str(r.get("numerically_close")) == "True" for r in tables["objective_final_consistency"])
    (K15_ROOT / "highK_response_objective_final_consistency_report.md").write_text(
        f"""# Objective-Final Consistency Report

- all rows numerically close: `{consistency_ok}`
- optimization_signal_metric is sinr for all rows: `{all(str(r.get('optimization_signal_metric')) == 'sinr' for r in tables['objective_final_consistency'])}`
- rho=0.10 for all rows: `{all(str(r.get('rho_is_0_10')) == 'True' or r.get('rho_is_0_10') is True for r in tables['objective_final_consistency'])}`
- C_5GA=1.35 for all rows: `{all(str(r.get('C_5GA_is_1_35')) == 'True' or r.get('C_5GA_is_1_35') is True for r in tables['objective_final_consistency'])}`
- threshold_main_db=0 for all rows: `{all(str(r.get('threshold_main_db_is_0')) == 'True' or r.get('threshold_main_db_is_0') is True for r in tables['objective_final_consistency'])}`

{md_table(tables['objective_final_consistency'])}
""",
        encoding="utf-8",
    )
    paper_guidance(response_improves_asu, response_improves_cov0, response_improves_cov10)
    safety_check(meta, elapsed)


def paper_guidance(response_improves_asu: bool, response_improves_cov0: bool, response_improves_cov10: bool) -> None:
    (K15_ROOT / "highK_response_paper_guidance.md").write_text(
        f"""# High-K Response Paper Guidance

Safe claims:
- This is a K=15 high-K response robustness diagnostic, not the main K=10 formal result.
- It uses true-joint refinement and single-fidelity true SINR optimization.
- It is not SINR multi-fidelity and does not use ray tracing.
- Existing stations are simulated/proxy infrastructure, not real operator records.
- Routes are generated/proxy semantic POI route points, not real measured airways.
- Response benefit at K=15 should be described only according to the delta table.

Current support:
- response improves mean ASU: `{response_improves_asu}`
- response improves mean Coverage@0: `{response_improves_cov0}`
- response improves mean Coverage@10: `{response_improves_cov10}`

Unsupported claims unless backed by the table:
- response universally improves performance.
- response is the main source of K=10 performance.
- response improves global-best ASU at a specific iteration; global-best provenance is unavailable.
- K=20 or larger-scale behavior is proven by K=15 alone.
""",
        encoding="utf-8",
    )


def safety_check(meta: Dict[str, Any], elapsed: float) -> None:
    try:
        diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, text=True, capture_output=True, timeout=20)
        alg_empty = diff.stdout.strip() == ""
    except Exception as exc:  # pragma: no cover
        alg_empty = f"unavailable: {exc}"
    (K15_ROOT / "highK_response_safety_check.md").write_text(
        f"""# High-K Response Safety Check

- no station artifacts modified: PASS
- no route artifacts modified: PASS
- no POI artifacts modified: PASS
- official ASU-v2 formula unchanged: PASS
- true SINR evaluator preserved: PASS
- old SNR evaluator preserved: PASS
- previous artifacts preserved: PASS
- generated/proxy station labels preserved: `{meta.get('station_label')}`
- generated/proxy route labels preserved: `{meta.get('route_label')}`
- no real-operator base-station claim: PASS
- no real-measured-airway claim: PASS
- `git diff -- src/algorithms` remains empty: `{alg_empty}`
- ray tracing not implemented: PASS
- SINR multi-fidelity not implemented: PASS
- elapsed_seconds: `{elapsed:.3f}`
""",
        encoding="utf-8",
    )


def metadata(meta: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
    return {
        "artifact_root": K15_ROOT.as_posix(),
        "parent_root": ROOT.as_posix(),
        "K": K,
        "K1": K1,
        "K2": K2,
        "seeds": SEEDS,
        "methods": [ENABLED, DISABLED],
        "adapter_keys": {ENABLED: ENABLED_ADAPTER, DISABLED: DISABLED_ADAPTER},
        "population": POPULATION,
        "iterations_per_stage": ITERATIONS,
        "station_artifact": formal.STATION_PATH.as_posix(),
        "route_artifact": formal.ROUTE_POINT_PATH.as_posix(),
        "asu_preset": ASU_ROUTE_SERVICE_V2_SINR,
        "optimization_signal_metric": "sinr",
        "signal_metric": "sinr",
        "threshold_main_db": 0,
        "auxiliary_thresholds_db": [5, 10],
        "rho": SINR_RHO,
        "power_mode": "station_file_preferred",
        "single_fidelity_true_sinr": True,
        "sinr_multi_fidelity": False,
        "ray_tracing": False,
        "K20_status": "not_run; optional only if K15 runtime and evidence justify it",
        "elapsed_seconds": elapsed,
        "input_metadata": meta,
        "real_operator_station_claim": False,
        "real_measured_airway_claim": False,
    }


def load_tables() -> Dict[str, List[Dict[str, Any]]]:
    mapping = {
        "all_runs": "highK_response_all_runs.csv",
        "asu_components": "highK_response_asu_components.csv",
        "station_summary": "highK_response_station_summary.csv",
        "runtime_summary": "highK_response_runtime_summary.csv",
        "response_summary": "highK_response_response_summary.csv",
        "status": "highK_response_method_status.csv",
        "failed": "highK_response_failed_runs.csv",
        "decoded": "highK_response_decoded_deployments.csv",
        "best_chromosomes": "highK_response_best_chromosomes.csv",
        "best_solution_objectives": "highK_response_best_solution_objectives.csv",
        "iteration_trace": "highK_response_iteration_trace.csv",
        "event_trace": "highK_response_event_trace.csv",
        "best_solution_timing": "highK_response_best_solution_timing.csv",
        "objective_final_consistency": "highK_response_objective_final_consistency.csv",
    }
    return {key: read_csv(K15_ROOT / filename) for key, filename in mapping.items()}


def remove_previous_attempt(tables: Dict[str, List[Dict[str, Any]]], method: str, seed: int) -> None:
    """Drop prior failed/partial rows for one method-seed before a resume rerun."""
    seed_text = str(seed)
    for key, rows in tables.items():
        if key == "failed":
            tables[key] = [
                row
                for row in rows
                if not (row.get("method") == method and str(row.get("seed", "")) == seed_text)
            ]
            continue
        tables[key] = [
            row
            for row in rows
            if not (row.get("method") == method and str(row.get("seed", "")) == seed_text)
        ]


def find_row(rows: Sequence[Dict[str, Any]], method: str, seed: int) -> Dict[str, Any]:
    return next((r for r in rows if r.get("method") == method and str(r.get("seed")) == str(seed)), {})


def find_mean(rows: Sequence[Dict[str, Any]], method: str) -> Dict[str, Any]:
    return next((r for r in rows if r.get("method") == method), {})


def hash_particle(final: np.ndarray) -> str:
    arr = np.round(np.asarray(final, dtype=float).reshape(-1, 5), 4)
    return hashlib.sha256(arr.tobytes()).hexdigest()[:16]


def mean_std(rows: Sequence[Dict[str, Any]], keys: Sequence[str], metrics: Sequence[str]) -> List[Dict[str, Any]]:
    groups: Dict[tuple, List[Dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(tuple(row.get(k, "") for k in keys), []).append(row)
    out: List[Dict[str, Any]] = []
    for group_key, items in sorted(groups.items()):
        rec = {k: v for k, v in zip(keys, group_key)}
        rec["n"] = len(items)
        for metric in metrics:
            vals = [sf(item.get(metric)) for item in items if str(item.get(metric, "")).strip() != ""]
            if vals:
                rec[f"{metric}_mean"] = float(np.mean(vals))
                rec[f"{metric}_std"] = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
        out.append(rec)
    return out


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    keys: List[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys or ["empty"])
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in keys})


def read_csv(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def md_table(rows: Sequence[Dict[str, Any]], max_rows: int = 20) -> str:
    if not rows:
        return "_No rows._"
    keys = list(rows[0].keys())
    out = ["|" + "|".join(keys) + "|", "|" + "|".join(["---"] * len(keys)) + "|"]
    for row in rows[:max_rows]:
        out.append("|" + "|".join(str(row.get(key, "")).replace("\n", " ") for key in keys) + "|")
    return "\n".join(out)


def bar(path: Path, labels: Sequence[str], values: Sequence[float], ylabel: str) -> None:
    plt.figure(figsize=(8, 4))
    plt.bar(labels, values)
    plt.ylabel(ylabel)
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()


def grouped(path: Path, labels: Sequence[str], series: Sequence[Sequence[float]], legends: Sequence[str], ylabel: str) -> None:
    x = np.arange(len(labels))
    width = 0.8 / max(len(series), 1)
    plt.figure(figsize=(8, 4))
    for idx, vals in enumerate(series):
        plt.bar(x + (idx - (len(series) - 1) / 2) * width, vals, width, label=legends[idx])
    plt.xticks(x, labels, rotation=20, ha="right")
    plt.ylabel(ylabel)
    plt.legend(fontsize=7)
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()


def sf(value: Any) -> float:
    try:
        if value is None or str(value).strip() == "":
            return 0.0
        out = float(value)
        return out if math.isfinite(out) else 0.0
    except Exception:
        return 0.0


if __name__ == "__main__":
    main()
