"""Formal K10 true-SINR deployment comparison with new-station height <= 50 m.

This is an additive experiment runner.  It leaves the original unconstrained
formal packages untouched and applies one shared decision-space repair rule to
every newly deployed station: ``z = clip(z, z_min, 50 m)``.
"""
from __future__ import annotations

import copy
import csv
import argparse
import gc
import hashlib
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
os.environ.setdefault("MPLCONFIGDIR", str((REPO_ROOT / "artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50/_mplcache").resolve()))
# A single formal method-seed unit is CPU-heavy but independent.  Limiting BLAS
# worker pools avoids retaining unnecessary per-thread workspaces across stages.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
import scripts.run_true_joint_response_v3_closed_loop_diagnostic_K15 as closed_loop
from src.baselines.registry import build_method_registry
from src.experiments.asu_route_service_v2_sinr import evaluate_with_existing_context_sinr_asu_v2
from src.experiments.evaluation_consistency import _station_file_preferred_plan, existing_station_particle
from src.experiments.strict_current_future_context_wrapper import _append_stage1_context, run_strict_current_future
from src.propagation.a2g_probabilistic import compute_population_per_bs_rx_power_a2g_dbm


ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50")
UNCONSTRAINED_ROOT = Path(
    "artifacts/tmc_rebuild/formal_K10_true_sinr_top_journal_baselines_and_coverage_utility/final_system_level_integration"
)
METHODS = [
    "existing_only",
    "random_current_then_future",
    "kmeans_current_then_future",
    "greedy_current_then_future",
    "csa_extended",
    "nsga2_current_then_future_asu_v2",
    "moead_current_then_future_asu_v2",
    "immogwo_adapted_same_objective_true_sinr_asu_v2",
    "scenario_sampling_robust_deployment_true_sinr_asu_v2",
    "true_joint_closed_loop_elite_immigration_response_v3_asu_v2",
]
SYSTEM_METHODS = set(METHODS[:4])
PROPOSED = METHODS[-1]
SEEDS = [2026, 2027, 2028]
K, K1, K2 = 10, 5, 5
POPULATION, ITERATIONS = 50, 150
Z_MAX = 50.0
SECTOR_AZIMUTHS = [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]

METRICS = [
    "ASU", "Q_current", "Q_future", "Coverage Utility@0", "Coverage Utility@5", "Coverage Utility@10",
    "Continuous Coverage Utility@0", "Continuous Coverage Utility@5", "Continuous Coverage Utility@10",
    "route_interruption_count@0", "route_interruption_count@5", "route_interruption_count@10",
    "mean_route_interruption_count@0", "mean_route_interruption_count@5", "mean_route_interruption_count@10",
    "handover_count", "C_dep", "N_5G", "N_5GA", "runtime", "max_new_station_height", "mean_new_station_height",
]


def read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    records = [dict(row) for row in rows]
    keys: List[str] = []
    for record in records:
        for key in record:
            if key not in keys:
                keys.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys or ["empty"])
        writer.writeheader()
        for record in records:
            writer.writerow({key: record.get(key, "") for key in keys})


def number(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def configure_modules() -> None:
    for module in (formal, true_formal, closed_loop):
        module.K = K
        module.K1 = K1
        module.K2 = K2
        module.POPULATION = POPULATION
        module.ITERATIONS = ITERATIONS


def apply_height_constraint(problem: Any) -> None:
    """Apply the shared z bound to a problem configuration without touching data."""
    pso = problem.config.setdefault("pso", {})
    minimum = np.asarray(pso.get("minPosition", [0.0, 0.0, 20.0]), dtype=float)
    maximum = np.asarray(pso.get("maxPosition", [problem.city_map.size_x, problem.city_map.size_y, 120.0]), dtype=float)
    if minimum.shape[0] < 3 or maximum.shape[0] < 3:
        raise ValueError("pso minPosition/maxPosition must contain x, y, z")
    if minimum[2] > Z_MAX:
        raise ValueError(f"configuration conflict: z_min={minimum[2]} m exceeds z_max={Z_MAX} m")
    maximum[2] = Z_MAX
    pso["minPosition"] = minimum.tolist()
    pso["maxPosition"] = maximum.tolist()
    problem.config["newStationHeightConstraint"] = {
        "enabled": True,
        "z_min_m": float(minimum[2]),
        "z_max_m": Z_MAX,
        "shared_repair_rule": "clip candidate and decoded new-station z to [z_min_m, z_max_m]",
        "applies_to": "new deployment decisions only; original simulated/proxy existing stations unchanged",
    }
    problem.config.setdefault("csa", {}).update(
        {
            "evaluation_batch_size": 1,
            "memory_safe_gc_interval": 1,
            "memory_mitigation": "true-SINR candidates evaluated one at a time; GC after each CSA iteration",
        }
    )


def repair_height(decision: np.ndarray, config: Mapping[str, Any]) -> tuple[np.ndarray, int]:
    """Shared final repair for all methods, including heuristic and optimizer outputs."""
    arr = np.asarray(decision, dtype=float).reshape(-1, 5).copy()
    if not arr.size:
        return arr, 0
    z_min = float(config["pso"]["minPosition"][2])
    before = arr[:, 2].copy()
    arr[:, 2] = np.clip(arr[:, 2], z_min, Z_MAX)
    return arr, int(np.count_nonzero(np.abs(before - arr[:, 2]) > 1e-9))


def height_metrics(decision: np.ndarray) -> Dict[str, Any]:
    arr = np.asarray(decision, dtype=float).reshape(-1, 5)
    if not arr.size:
        return {
            "new_station_count": 0, "max_new_station_height": "", "mean_new_station_height": "",
            "percentage_new_station_height_gt_50": 0.0, "percentage_new_station_height_gt_80": 0.0,
            "percentage_new_station_height_gt_100": 0.0, "height_constraint_compliant": True,
        }
    z = arr[:, 2]
    return {
        "new_station_count": int(arr.shape[0]), "max_new_station_height": float(np.max(z)),
        "mean_new_station_height": float(np.mean(z)), "percentage_new_station_height_gt_50": float(np.mean(z > 50.0)),
        "percentage_new_station_height_gt_80": float(np.mean(z > 80.0)),
        "percentage_new_station_height_gt_100": float(np.mean(z > 100.0)),
        "height_constraint_compliant": bool(np.all(z <= Z_MAX + 1e-9)),
    }


def strict_system_deployment(method: str, seed: int, current_problem: Any, future_problem: Any) -> tuple[np.ndarray, np.ndarray, np.ndarray, str]:
    """Build a heuristic deployment while giving Stage-II the Stage-I context."""
    rng = np.random.default_rng(seed)
    if method == "random_current_then_future":
        p1 = formal_system.random_particle(current_problem, K1, rng, current_problem.test_points)
    elif method == "kmeans_current_then_future":
        p1 = formal_system.kmeans_particle(current_problem, K1, rng)
    elif method == "greedy_current_then_future":
        p1 = formal_system.greedy_particle(current_problem, K1, rng)
    else:
        raise KeyError(method)
    p1, _ = repair_height(p1, current_problem.config)
    future_with_context = copy.deepcopy(future_problem)
    _append_stage1_context(future_with_context.config, p1)
    if method == "random_current_then_future":
        p2 = formal_system.random_particle(future_with_context, K2, rng, future_with_context.test_points)
        rule = "random current-to-future; Stage-II context includes original existing plus Stage-I new stations"
    elif method == "kmeans_current_then_future":
        p2 = formal_system.kmeans_particle(future_with_context, K2, rng)
        rule = "KMeans current-to-future; Stage-II context includes original existing plus Stage-I new stations"
    else:
        p2 = formal_system.greedy_particle(future_with_context, K2, rng)
        rule = "greedy weak-SINR current-to-future; Stage-II weak-point service/interference context includes Stage-I"
    p2, _ = repair_height(p2, future_with_context.config)
    return p1, p2, np.vstack([p1, p2]), rule


# The prior formal runner provides the system baseline construction utilities only.
import scripts.run_formal_K10_true_sinr_system_optimizer_baselines_closed_loop_v3 as formal_system


def continuity_metrics(decision: np.ndarray, problem: Any) -> Dict[str, Any]:
    """Compute adjacency-only continuity and interruption metrics within route IDs."""
    final = np.asarray(decision, dtype=float).reshape(-1, 5)
    if final.size:
        packed = evaluate_with_existing_context_sinr_asu_v2(
            decisions=final[None, :, :], problem=problem, config=problem.config, method_name="postprocess"
        )
        metric = dict(packed.metrics[0])
    else:
        # The population evaluator intentionally returns no rows for [1, 0, 5].
        # Reuse the established final true-SINR existing-only evaluator instead.
        metric = dict(formal_system.evaluate_true_sinr(final, problem, "existing_only_postprocess"))
    sinr_db = point_sinr_db(final, problem)
    rows = list(problem.config.get("route_point_rows", []))
    route_ids = list(problem.config.get("routePointMetadata", {}).get("route_ids", []))
    point_indices = list(problem.config.get("routePointMetadata", {}).get("point_indices", []))
    priorities = list(problem.config.get("routePointMetadata", {}).get("priority_labels", []))
    grouped: Dict[str, List[int]] = {}
    for index, route_id in enumerate(route_ids):
        grouped.setdefault(str(route_id), []).append(index)
    out: Dict[str, Any] = {}
    for threshold in (0, 5, 10):
        utilities: List[float] = []
        interruptions: List[int] = []
        current_utilities: List[float] = []
        future_utilities: List[float] = []
        current_interruptions: List[int] = []
        future_interruptions: List[int] = []
        for _, indices in grouped.items():
            ordered = sorted(indices, key=lambda item: point_indices[item])
            if len(ordered) < 2:
                continue
            covered = sinr_db[np.asarray(ordered, dtype=int)] >= float(threshold)
            utility = float(np.mean(covered[:-1] & covered[1:]))
            interruption = int(np.sum(covered[:-1] != covered[1:]))
            utilities.append(utility)
            interruptions.append(interruption)
            priority = str(priorities[ordered[0]]).strip().lower() if priorities else ""
            if priority == "current":
                current_utilities.append(utility)
                current_interruptions.append(interruption)
            else:
                future_utilities.append(utility)
                future_interruptions.append(interruption)
        out[f"Continuous Coverage Utility@{threshold}"] = float(np.mean(utilities)) if utilities else 0.0
        out[f"current Continuous Coverage Utility@{threshold}"] = float(np.mean(current_utilities)) if current_utilities else 0.0
        out[f"future Continuous Coverage Utility@{threshold}"] = float(np.mean(future_utilities)) if future_utilities else 0.0
        out[f"route_interruption_count@{threshold}"] = int(sum(interruptions))
        out[f"mean_route_interruption_count@{threshold}"] = float(np.mean(interruptions)) if interruptions else 0.0
        out[f"current route_interruption_count@{threshold}"] = int(sum(current_interruptions))
        out[f"future route_interruption_count@{threshold}"] = int(sum(future_interruptions))
    return {"metrics": metric, "continuity": out, "route_rows_available": len(rows), "route_boundary_only": True}


def point_sinr_db(decision: np.ndarray, problem: Any) -> np.ndarray:
    """Recompute the final per-point SINR under the official evaluator setting."""
    new = np.asarray(decision, dtype=float).reshape(-1, 5)
    existing = existing_station_particle(problem.config, target_dims=5)
    combined = np.vstack([existing, new]) if new.size else existing.copy()
    plan = _station_file_preferred_plan(problem.config, combined, existing_count=existing.shape[0])
    rx_dbm, _ = compute_population_per_bs_rx_power_a2g_dbm(
        positions=combined[None, :, :3], test_points=problem.test_points, channel_params=problem.channel_params,
        tx_power_offsets_db=plan.tx_power_offsets_db, coverage_boost_db=plan.coverage_boost_db,
        path_loss_offsets_db=plan.path_loss_offsets_db, sector_station_mask=plan.sector_station_mask,
        sector_azimuths_deg=plan.sector_azimuths_deg, sector_beamwidth_deg=plan.sector_beamwidth_deg,
        outside_sector_mode=plan.outside_sector_mode, side_lobe_attenuation_db=plan.side_lobe_attenuation_db,
    )
    rx = np.asarray(rx_dbm[0], dtype=float)
    power_mw = np.power(10.0, rx / 10.0)
    serving = np.argmax(rx, axis=0)
    point_index = np.arange(rx.shape[1])
    serving_mw = power_mw[serving, point_index]
    interference_mw = np.maximum(np.sum(power_mw, axis=0) - serving_mw, 0.0)
    noise_mw = 10.0 ** (float(problem.channel_params.get("noisePower", -90.0)) / 10.0)
    sinr = serving_mw / np.maximum(noise_mw + 0.10 * interference_mw, 1e-30)
    return 10.0 * np.log10(np.maximum(sinr, 1e-30))


def decode_rows(decision: np.ndarray, method: str, seed: int, stage1_count: int) -> List[Dict[str, Any]]:
    arr = np.asarray(decision, dtype=float).reshape(-1, 5)
    rows: List[Dict[str, Any]] = []
    for index, station in enumerate(arr, start=1):
        type_index = int(np.clip(round(float(station[3])), 0, 1))
        sector_index = int(np.clip(round(float(station[4])), 0, len(SECTOR_AZIMUTHS) - 1))
        rows.append({
            "method": method, "seed": seed, "station_id": index,
            "station_source": "stage1_current_priority" if index <= stage1_count else "stage2_future_priority",
            "x": float(station[0]), "y": float(station[1]), "z": float(station[2]),
            "station_type": "5GA" if type_index == 1 else "5G", "station_type_index": type_index,
            "sector_direction_index": sector_index, "sector_direction": SECTOR_AZIMUTHS[sector_index] if type_index else 0.0,
        })
    return rows


def hash_decision(decision: np.ndarray) -> str:
    return hashlib.sha256(np.round(np.asarray(decision, dtype=float), 8).tobytes()).hexdigest()[:16]


def run_optimizer(method: str, seed: int, registry: Mapping[str, Any], current_problem: Any, future_problem: Any, all_problem: Any) -> Dict[str, Any]:
    if method == PROPOSED:
        adapter = closed_loop.ClosedLoopResponseAdapter(PROPOSED)
    elif method == "immogwo_adapted_same_objective_true_sinr_asu_v2":
        adapter = registry["immogwo_adapted_true_sinr_asu_v2"]
    else:
        adapter = registry[method]
    started = time.time()
    run = run_strict_current_future(adapter, method, seed, current_problem, future_problem, all_problem, K1, K2)
    final, clipped = repair_height(run["final"], all_problem.config)
    run["final"] = final
    run["height_repair_count"] = clipped
    run["runtime"] = float(time.time() - started)
    return run


def run_one(method: str, seed: int, registry: Mapping[str, Any], all_problem: Any, current_problem: Any, future_problem: Any) -> Dict[str, Any]:
    started = time.time()
    if method == "existing_only":
        final = np.zeros((0, 5), dtype=float)
        context = {
            "original_existing_station_count": len(all_problem.config["heterogeneousDeployment"].get("existingStations", [])),
            "stage1_new_station_count": 0, "stage2_context_station_count": "not_applicable",
            "stage2_context_includes_original_existing_flag": "not_applicable",
            "stage2_context_includes_stage1_new_flag": "not_applicable", "final_new_station_count": 0,
            "final_C_dep_excludes_original_existing_flag": True, "strict_current_future_context": "not_applicable",
        }
        stage1 = stage2 = None
        rule = "no-deployment reference; height constraint is not applicable"
        repair_count = 0
    elif method in SYSTEM_METHODS:
        p1, p2, final, rule = strict_system_deployment(method, seed, current_problem, future_problem)
        final, repair_count = repair_height(final, all_problem.config)
        stage1 = p1
        stage2 = p2
        context = {
            "original_existing_station_count": len(all_problem.config["heterogeneousDeployment"].get("existingStations", [])),
            "stage1_new_station_count": K1, "stage2_context_station_count": len(all_problem.config["heterogeneousDeployment"].get("existingStations", [])) + K1,
            "stage2_context_includes_original_existing_flag": True, "stage2_context_includes_stage1_new_flag": True,
            "final_new_station_count": K, "final_C_dep_counts_stage1_new_flag": True,
            "final_C_dep_counts_stage2_new_flag": True, "final_C_dep_excludes_original_existing_flag": True,
            "strict_current_future_context": True,
        }
    else:
        packed = run_optimizer(method, seed, registry, current_problem, future_problem, all_problem)
        final = packed["final"]
        repair_count = packed["height_repair_count"]
        stage1, stage2 = packed["stage1"], packed["stage2"]
        context = dict(packed["context_audit"])
        context["strict_current_future_context"] = True
        rule = "strict current-to-future optimizer wrapper"
    post = continuity_metrics(final, all_problem)
    metrics = post["metrics"]
    # A second final evaluator call is solely the stated consistency check.
    repeated = continuity_metrics(final, all_problem)["metrics"]
    consistency_delta = abs(number(metrics.get("ASU")) - number(repeated.get("ASU")))
    h_metrics = height_metrics(final)
    if not h_metrics["height_constraint_compliant"]:
        raise RuntimeError("final decoded deployment violates z_max=50 m after shared repair")
    response = formal.response_summary(stage1, stage2) if hasattr(stage1, "logs") and hasattr(stage2, "logs") else {"response_count": 0, "mild_response_count": 0, "moderate_response_count": 0, "severe_response_count": 0, "restart_count": 0, "pbest_preservation_count": 0}
    runtime = float(time.time() - started)
    row = {
        "method": method, "seed": seed, "K": K, "K1": K1, "K2": K2,
        "ASU": number(metrics.get("ASU")), "Q_current": number(metrics.get("Q_current")), "Q_future": number(metrics.get("Q_future")),
        "Coverage Utility@0": number(metrics.get("Coverage@0dB", metrics.get("Coverage@0"))),
        "Coverage Utility@5": number(metrics.get("Coverage@5dB", metrics.get("Coverage@5"))),
        "Coverage Utility@10": number(metrics.get("Coverage@10dB", metrics.get("Coverage@10"))),
        "handover_count": number(metrics.get("handover_count")), "C_dep": number(metrics.get("C_dep")),
        "N_5G": int(number(metrics.get("N_5G"))), "N_5GA": int(number(metrics.get("N_5GA"))), "runtime": runtime,
        "population": POPULATION, "iterations_per_stage": ITERATIONS, "optimization_signal_metric": "sinr",
        "signal_metric": "sinr", "rho": 0.10, "threshold_main_db": 0, "auxiliary_thresholds_db": "5;10",
        "deployment_hash": hash_decision(final), "shared_height_repair_count": repair_count,
        "station_data_label": "route-agnostic simulated/proxy existing infrastructure; not real operator base-station records",
        "route_data_label": "generated/proxy semantic POI route points; not real measured airways",
        **post["continuity"], **h_metrics,
    }
    if method == "immogwo_adapted_same_objective_true_sinr_asu_v2":
        row.update({"adapter_key": "immogwo_adapted_true_sinr_asu_v2", "objective_variant": "same_objective", "objective_vector": "[C_dep, handover_count, -Q_current, -Q_future]", "selection_metric": "official true-SINR ASU-v2", "old_scalar_asu_version_used_for_formal": False, "adaptation_status": "adapted; same-objective baseline"})
    elif method == "scenario_sampling_robust_deployment_true_sinr_asu_v2":
        row["adaptation_status"] = "scenario-sampling-inspired robust deployment baseline; not same-objective optimizer"
    elif method == PROPOSED:
        row["adaptation_status"] = "frozen proposed method, executed by strict current-to-future wrapper"
    return {
        "row": row, "decision": final, "context": {"method": method, "seed": seed, **context},
        "stage": {"method": method, "seed": seed, "stage_rule": rule, "K1": 0 if method == "existing_only" else K1, "K2": 0 if method == "existing_only" else K2, "strict_current_future_context": context.get("strict_current_future_context")},
        "components": {"method": method, "seed": seed, **{key: metrics.get(key, "") for key in ["ASU", "Q_current", "Q_future", "numerator", "denominator", "C_dep", "handover_count", "N_5G", "N_5GA", "signal_metric", "rho", "threshold_main_db"]}},
        "coverage": {"method": method, "seed": seed, **{f"Coverage Utility@{level}": row[f"Coverage Utility@{level}"] for level in (0, 5, 10)}},
        "continuous": {"method": method, "seed": seed, **post["continuity"]},
        "interruption": {"method": method, "seed": seed, **{key: value for key, value in post["continuity"].items() if "interruption" in key}},
        "runtime": {"method": method, "seed": seed, "runtime": runtime, "population": POPULATION if method not in SYSTEM_METHODS else "", "iterations_per_stage": ITERATIONS if method not in SYSTEM_METHODS else ""},
        "height": {"method": method, "seed": seed, "z_min": all_problem.config["pso"]["minPosition"][2], "z_max": Z_MAX, "shared_height_repair_count": repair_count, **h_metrics},
        "consistency": {"method": method, "seed": seed, "stored_final_ASU": row["ASU"], "recomputed_true_SINR_ASU": number(repeated.get("ASU")), "absolute_delta": consistency_delta, "ASU_consistency_pass": consistency_delta <= 1e-9, "final_deployment_traceable": True},
        "response": {"method": method, "seed": seed, **response},
        "chromosome": {"method": method, "seed": seed, "deployment_hash": row["deployment_hash"], "final_chromosome_json": json.dumps(final.reshape(-1).tolist())},
    }


def existing_pairs(rows: Sequence[Mapping[str, Any]]) -> set[tuple[str, int]]:
    out: set[tuple[str, int]] = set()
    for row in rows:
        try:
            out.add((str(row.get("method", "")), int(float(row.get("seed", -1)))))
        except (TypeError, ValueError):
            pass
    return out


def mean_std(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for method in METHODS:
        members = [row for row in rows if row.get("method") == method]
        record: Dict[str, Any] = {"method": method, "n": len(members)}
        for metric in METRICS:
            values = [number(row.get(metric), math.nan) for row in members]
            values = [value for value in values if not math.isnan(value)]
            if values:
                record[f"{metric}_mean"] = float(np.mean(values))
                record[f"{metric}_std"] = float(np.std(values, ddof=1)) if len(values) > 1 else 0.0
        out.append(record)
    return out


def rank_deployments(summary: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    deployment = [dict(row) for row in summary if row["method"] != "existing_only"]
    fields = ["ASU_mean", "Coverage Utility@0_mean", "Coverage Utility@5_mean", "Coverage Utility@10_mean", "Q_current_mean", "Q_future_mean"]
    for field in fields:
        ranked = sorted(deployment, key=lambda item: number(item.get(field), -math.inf), reverse=True)
        for rank, row in enumerate(ranked, start=1):
            row[f"rank_{field[:-5]}"] = rank
    return deployment


def top_journal(summary: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    wanted = ["immogwo_adapted_same_objective_true_sinr_asu_v2", "scenario_sampling_robust_deployment_true_sinr_asu_v2", PROPOSED]
    return [dict(row) for row in summary if row.get("method") in wanted]


def comparison_with_unconstrained(summary: Sequence[Mapping[str, Any]]) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    old = {row.get("method", ""): row for row in read_csv(UNCONSTRAINED_ROOT / "final_system_level_comparison_mean_std.csv")}
    comparison: List[Dict[str, Any]] = []
    relative: List[Dict[str, Any]] = []
    mappings = {
        "ASU": "ASU", "Coverage Utility@0": "Point-wise Coverage Utility@0", "Coverage Utility@5": "Point-wise Coverage Utility@5",
        "Coverage Utility@10": "Point-wise Coverage Utility@10", "Continuous Coverage Utility@0": "Continuous Coverage Utility@0",
        "Continuous Coverage Utility@5": "Continuous Coverage Utility@5", "Continuous Coverage Utility@10": "Continuous Coverage Utility@10",
        "route_interruption_count@0": "route_interruption_count@0", "route_interruption_count@5": "route_interruption_count@5",
        "route_interruption_count@10": "route_interruption_count@10", "handover_count": "handover_count", "C_dep": "C_dep", "runtime": "runtime",
    }
    for row in summary:
        method = str(row["method"])
        prior = old.get(method, {})
        record: Dict[str, Any] = {"method": method, "unconstrained_available": bool(prior), "zmax50_mean_new_station_height": row.get("mean_new_station_height_mean", ""), "zmax50_max_new_station_height": row.get("max_new_station_height_mean", "")}
        change: Dict[str, Any] = {"method": method}
        for new_metric, old_metric in mappings.items():
            new_value = number(row.get(f"{new_metric}_mean"), math.nan)
            old_value = number(prior.get(f"{old_metric}_mean"), math.nan)
            record[f"zmax50_{new_metric}"] = new_value if not math.isnan(new_value) else ""
            record[f"unconstrained_{new_metric}"] = old_value if not math.isnan(old_value) else ""
            delta = new_value - old_value if not math.isnan(new_value) and not math.isnan(old_value) else math.nan
            change[f"delta_{new_metric}"] = delta if not math.isnan(delta) else ""
            change[f"relative_change_pct_{new_metric}"] = (100.0 * delta / abs(old_value)) if not math.isnan(delta) and abs(old_value) > 1e-12 else ""
        comparison.append(record)
        relative.append(change)
    return comparison, relative


def plot_bars(summary: Sequence[Mapping[str, Any]], comparison: Sequence[Mapping[str, Any]], height_rows: Sequence[Mapping[str, Any]]) -> None:
    labels = [str(row["method"]) for row in summary]
    def bar(field: str, filename: str, title: str) -> None:
        values = [number(row.get(f"{field}_mean")) for row in summary]
        fig, axis = plt.subplots(figsize=(12, 4.8)); axis.bar(np.arange(len(labels)), values)
        axis.set_xticks(np.arange(len(labels))); axis.set_xticklabels(labels, rotation=35, ha="right", fontsize=7)
        axis.set_ylabel(field); axis.set_title(title); axis.grid(axis="y", alpha=0.25); fig.tight_layout(); fig.savefig(ROOT / filename, dpi=220); plt.close(fig)
    bar("ASU", "zmax50_ASU_by_method.png", "z_max=50 m ASU-v2")
    bar("Coverage Utility@0", "zmax50_CoverageUtility0_by_method.png", "z_max=50 m Coverage Utility @0 dB")
    bar("Continuous Coverage Utility@0", "zmax50_ContinuousCoverageUtility0_by_method.png", "z_max=50 m Continuous Coverage Utility @0 dB")
    bar("route_interruption_count@0", "zmax50_route_interruption0_by_method.png", "z_max=50 m route interruptions @0 dB")
    bar("runtime", "zmax50_runtime_by_method.png", "z_max=50 m runtime")
    height_labels = [row["method"] for row in summary if row["method"] != "existing_only"]
    height_values = [[number(item.get("mean_new_station_height")) for item in height_rows if item.get("method") == method] for method in height_labels]
    fig, axis = plt.subplots(figsize=(12, 4.8)); axis.boxplot(height_values, labels=height_labels, showmeans=True); axis.set_ylim(0, Z_MAX + 5); axis.set_xticklabels(height_labels, rotation=35, ha="right", fontsize=7); axis.set_title("Mean new-station height by method and seed"); fig.tight_layout(); fig.savefig(ROOT / "zmax50_new_station_height_boxplot_by_method.png", dpi=220); plt.close(fig)
    for field, filename, title in [
        ("ASU", "zmax50_vs_unconstrained_ASU_by_method.png", "ASU: z_max=50 vs unconstrained"),
        ("Coverage Utility@0", "zmax50_vs_unconstrained_CoverageUtility0_by_method.png", "Coverage Utility @0: z_max=50 vs unconstrained"),
        ("Continuous Coverage Utility@0", "zmax50_vs_unconstrained_ContinuousCoverageUtility0_by_method.png", "Continuous Coverage Utility @0: z_max=50 vs unconstrained"),
    ]:
        valid = [row for row in comparison if row.get("unconstrained_available")]
        x = np.arange(len(valid)); constrained = [number(row.get(f"zmax50_{field}")) for row in valid]; prior = [number(row.get(f"unconstrained_{field}")) for row in valid]
        fig, axis = plt.subplots(figsize=(12, 4.8)); axis.bar(x - .18, prior, .36, label="unconstrained"); axis.bar(x + .18, constrained, .36, label="z_max=50")
        axis.set_xticks(x); axis.set_xticklabels([row["method"] for row in valid], rotation=35, ha="right", fontsize=7); axis.set_title(title); axis.legend(); axis.grid(axis="y", alpha=.25); fig.tight_layout(); fig.savefig(ROOT / filename, dpi=220); plt.close(fig)
    valid = [row for row in comparison if row.get("unconstrained_available") and row["method"] != "existing_only"]
    fig, axis = plt.subplots(figsize=(12, 4.8)); x = np.arange(len(valid)); prior = [number(row.get("unconstrained_mean_new_station_height")) for row in valid]; constrained = [number(row.get("zmax50_mean_new_station_height")) for row in valid]
    axis.bar(x - .18, prior, .36, label="unconstrained"); axis.bar(x + .18, constrained, .36, label="z_max=50"); axis.axhline(Z_MAX, color="red", linestyle="--", label="50 m cap")
    axis.set_xticks(x); axis.set_xticklabels([row["method"] for row in valid], rotation=35, ha="right", fontsize=7); axis.set_title("Mean new-station height"); axis.legend(); axis.grid(axis="y", alpha=.25); fig.tight_layout(); fig.savefig(ROOT / "zmax50_vs_unconstrained_height_by_method.png", dpi=220); plt.close(fig)


def write_reports(rows: Sequence[Mapping[str, Any]], summary: Sequence[Mapping[str, Any]], failures: Sequence[Mapping[str, Any]], height: Sequence[Mapping[str, Any]], comparison: Sequence[Mapping[str, Any]]) -> None:
    deployment = [row for row in summary if row["method"] != "existing_only"]
    proposed = next((row for row in deployment if row["method"] == PROPOSED), {})
    best = max(deployment, key=lambda row: number(row.get("ASU_mean"))) if deployment else {}
    all_compliant = all(str(row.get("height_constraint_compliant")) in {"True", "true", "1"} for row in height)
    all_consistent = all(abs(number(row.get("ASU_consistency_delta"))) <= 1e-9 for row in rows)
    report = f"""# K10 true-SINR height-constrained deployment report

- New-station decision bound: `z <= {Z_MAX:g} m`; original existing stations were read unchanged.
- Completed method-seed units: `{len(rows)}` / `{len(METHODS) * len(SEEDS)}`; failed: `{len(failures)}`.
- Height compliant after the shared clipping rule: `{all_compliant}`.
- Final true-SINR ASU consistency: `{all_consistent}`.
- Highest deployment-method mean ASU: `{best.get('method', '')}`.
- Proposed mean ASU: `{proposed.get('ASU_mean', '')}`.

The original existing stations remain route-agnostic simulated/proxy infrastructure. Routes remain generated/proxy semantic POI route points. Existing-only is a no-deployment reference; the height constraint does not apply to it. Continuous coverage and route interruptions are computed only between adjacent ordered points belonging to the same route ID.
"""
    (ROOT / "height_constrained_zmax50_report.md").write_text(report, encoding="utf-8")
    proposed_best = best.get("method") == PROPOSED
    guidance = f"""# Paper guidance: z_max=50 m variant

Safe claims:
- All newly deployed stations are constrained to an antenna installation height no larger than 50 m.
- The same height decision bound and final repair are used for every deployment method.
- Existing stations are route-agnostic simulated/proxy infrastructure and remain unchanged.
- The deployment represents ground infrastructure with constrained antenna installation height.
- All methods use the same final true-SINR ASU-v2 evaluator.

Current result-dependent statement: proposed ranks first among deployment methods by mean ASU: `{proposed_best}`.

Unsafe claims:
- Existing stations are real operator base stations.
- Routes are real measured UAV routes.
- All stations in the full scenario are below 50 m; only new stations are constrained.
- The constrained and unconstrained experiments are the same experiment.
- The result proves universal real-world feasibility.
"""
    (ROOT / "height_constrained_zmax50_paper_guidance.md").write_text(guidance, encoding="utf-8")
    comparison_note = "# z_max=50 m versus unconstrained guidance\n\nThe two packages are distinct variants. Use this comparison to quantify the consequence of limiting only newly deployed-station antenna heights. Treat the earlier unconstrained package as an elevated-height auxiliary variant if the height-constrained package remains complete, compliant, and scientifically adequate.\n"
    (ROOT / "zmax50_vs_unconstrained_paper_guidance.md").write_text(comparison_note, encoding="utf-8")
    algorithm_diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, capture_output=True, text=True, check=False).stdout.strip()
    safety = f"""# Safety check

- Previous unconstrained package overwritten: PASS (new output root only).
- Frozen proposed algorithm modified: PASS (no algorithm-file change by this runner).
- `git diff -- src/algorithms` empty: `{not bool(algorithm_diff)}`.
- ASU-v2 formula changed: PASS (false).
- Original station/route/POI artifacts regenerated: PASS (false; read only).
- New station height compliance: `{all_compliant}`.
- Smoke result promoted: PASS (false).
- Adapted/inspired labels retained: PASS.
- Generated/proxy labels retained: PASS.
"""
    (ROOT / "height_constrained_zmax50_safety_check.md").write_text(safety, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--method", choices=METHODS, help="run/resume one method only")
    parser.add_argument("--seed", type=int, choices=SEEDS, help="run/resume one seed only")
    args = parser.parse_args()
    if args.seed is not None and args.method is None:
        parser.error("--seed requires --method")
    ROOT.mkdir(parents=True, exist_ok=True)
    configure_modules()
    stations = formal.read_csv(formal.STATION_PATH)
    routes = formal.read_csv(formal.ROUTE_POINT_PATH)
    all_problem, current_problem, future_problem, meta = formal.build_problems(stations, routes)
    for problem in (all_problem, current_problem, future_problem):
        true_formal.apply_true_sinr_config(problem.config)
        problem.config["route_point_rows"] = routes
        problem.config.setdefault("immogwo", {}).update({"population_size": POPULATION, "max_iterations": ITERATIONS})
        problem.config.setdefault("scenario", {}).update({"population_size": POPULATION, "max_iterations": ITERATIONS})
        apply_height_constraint(problem)
    snapshot = {
        "variant": "formal K10 true-SINR height constrained", "K": K, "K1": K1, "K2": K2, "seeds": SEEDS,
        "population": POPULATION, "iterations_per_stage": ITERATIONS, "new_station_z_min_m": all_problem.config["pso"]["minPosition"][2],
        "new_station_z_max_m": Z_MAX, "shared_height_repair_rule": all_problem.config["newStationHeightConstraint"]["shared_repair_rule"],
        "signal_metric": "sinr", "optimization_signal_metric": "sinr", "threshold_main_db": 0, "auxiliary_thresholds_db": [5, 10], "rho": .10,
        "power_mode": "station_file_preferred", "C_5G": 1.0, "C_5GA": 1.35, "kappa_H": .01, "C_0": 1.0, "w_current": .5, "w_future": .5,
        "station_artifact": formal.STATION_PATH.as_posix(), "route_artifact": formal.ROUTE_POINT_PATH.as_posix(), "input_meta": meta,
        "csa_memory_mitigation": all_problem.config["csa"].get("memory_mitigation"), "csa_evaluation_batch_size": 1,
    }
    (ROOT / "config_snapshot.json").write_text(json.dumps(snapshot, indent=2, ensure_ascii=False), encoding="utf-8")
    rows = [dict(row) for row in read_csv(ROOT / "per_seed_results.csv")]
    decoded = [dict(row) for row in read_csv(ROOT / "decoded_deployments.csv")]
    stages = [dict(row) for row in read_csv(ROOT / "stage_summary.csv")]
    contexts = [dict(row) for row in read_csv(ROOT / "context_audit.csv")]
    components = [dict(row) for row in read_csv(ROOT / "asu_components.csv")]
    coverage = [dict(row) for row in read_csv(ROOT / "coverage_utility.csv")]
    continuous = [dict(row) for row in read_csv(ROOT / "continuous_coverage_utility.csv")]
    interruption = [dict(row) for row in read_csv(ROOT / "route_interruption.csv")]
    runtimes = [dict(row) for row in read_csv(ROOT / "runtime_summary.csv")]
    heights = [dict(row) for row in read_csv(ROOT / "height_constraint_audit.csv")]
    consistency = [dict(row) for row in read_csv(ROOT / "objective_final_consistency.csv")]
    responses = [dict(row) for row in read_csv(ROOT / "response_summary.csv")]
    chromosomes = [dict(row) for row in read_csv(ROOT / "best_chromosomes.csv")]
    failures = [dict(row) for row in read_csv(ROOT / "height_constrained_zmax50_failed_cases.csv")]
    completed = existing_pairs(rows)
    # Failures from an earlier interrupted attempt are not carried into the
    # final package when the same method-seed has a successful record.
    failures = [row for row in failures if (str(row.get("method", "")), int(number(row.get("seed"), -1))) not in completed]
    registry = build_method_registry()
    selected_methods = [args.method] if args.method else METHODS
    selected_seeds = [args.seed] if args.seed is not None else SEEDS
    for method in selected_methods:
        for seed in selected_seeds:
            if (method, seed) in completed:
                continue
            failures = [row for row in failures if not (row.get("method") == method and int(number(row.get("seed"), -1)) == seed)]
            try:
                record = run_one(method, seed, registry, all_problem, current_problem, future_problem)
                rows.append(record["row"]); decoded.extend(decode_rows(record["decision"], method, seed, 0 if method == "existing_only" else K1))
                stages.append(record["stage"]); contexts.append(record["context"]); components.append(record["components"]); coverage.append(record["coverage"])
                continuous.append(record["continuous"]); interruption.append(record["interruption"]); runtimes.append(record["runtime"])
                heights.append(record["height"]); consistency.append(record["consistency"]); responses.append(record["response"]); chromosomes.append(record["chromosome"])
            except Exception as exc:  # Record a failure and continue so the formal package remains auditable.
                failures.append({"method": method, "seed": seed, "reason": f"{type(exc).__name__}: {exc}"})
            write_csv(ROOT / "per_seed_results.csv", rows)
            write_csv(ROOT / "decoded_deployments.csv", decoded)
            write_csv(ROOT / "stage_summary.csv", stages)
            write_csv(ROOT / "context_audit.csv", contexts)
            write_csv(ROOT / "asu_components.csv", components)
            write_csv(ROOT / "coverage_utility.csv", coverage)
            write_csv(ROOT / "continuous_coverage_utility.csv", continuous)
            write_csv(ROOT / "route_interruption.csv", interruption)
            write_csv(ROOT / "runtime_summary.csv", runtimes)
            write_csv(ROOT / "height_constraint_audit.csv", heights)
            write_csv(ROOT / "objective_final_consistency.csv", consistency)
            write_csv(ROOT / "response_summary.csv", responses)
            write_csv(ROOT / "best_chromosomes.csv", chromosomes)
            write_csv(ROOT / "height_constrained_zmax50_failed_cases.csv", failures)
            gc.collect()
    summary = mean_std(rows)
    ranking = rank_deployments(summary)
    top = top_journal(summary)
    comparison, relative = comparison_with_unconstrained(summary)
    status = [{"method": method, "seed": seed, "status": "completed" if (method, seed) in existing_pairs(rows) else "failed"} for method in METHODS for seed in SEEDS]
    write_csv(ROOT / "height_constrained_zmax50_all_runs.csv", rows)
    write_csv(ROOT / "height_constrained_zmax50_mean_std.csv", summary)
    write_csv(ROOT / "height_constrained_zmax50_system_level_comparison.csv", summary)
    write_csv(ROOT / "height_constrained_zmax50_deployment_ranking_excluding_existing.csv", ranking)
    write_csv(ROOT / "height_constrained_zmax50_top_journal_comparison.csv", top)
    write_csv(ROOT / "height_constrained_zmax50_relative_improvement.csv", relative)
    write_csv(ROOT / "height_constrained_zmax50_height_audit.csv", heights)
    write_csv(ROOT / "height_constrained_zmax50_asu_consistency.csv", consistency)
    write_csv(ROOT / "height_constrained_zmax50_method_status.csv", status)
    write_csv(ROOT / "zmax50_vs_unconstrained_mean_std_comparison.csv", comparison)
    write_csv(ROOT / "zmax50_vs_unconstrained_relative_change.csv", relative)
    (ROOT / "metadata.json").write_text(json.dumps({**snapshot, "methods": METHODS, "completed_method_seed_count": len(rows), "strict_current_future_context": True}, indent=2, ensure_ascii=False), encoding="utf-8")
    plot_bars(summary, comparison, heights)
    write_reports(rows, summary, failures, heights, comparison)
    print(json.dumps({"artifact_root": ROOT.as_posix(), "completed": len(rows), "failed": failures}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
