from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

REPO_ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault(
    "MPLCONFIGDIR",
    str((REPO_ROOT / "artifacts/tmc_rebuild/true_joint_response_v3_strengthening_diagnostic_K15/_mplcache").resolve()),
)
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import scripts.run_highK_true_joint_response_robustness as hk
import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_optimized_citywide_low as true_formal
import src.baselines.proposed_search_expansion_response_v2.adapter as v2_module
from src.baselines.registry import build_method_registry
from src.experiments.asu_route_service_v2_sinr import (
    ASU_ROUTE_SERVICE_V2_SINR,
    _route_groups,
    evaluate_with_existing_context_sinr_asu_v2,
)
from src.experiments.evaluation_consistency import _station_file_preferred_plan, existing_station_particle
from src.experiments.multiobjective_metrics import nondominated_mask
from src.propagation.a2g_probabilistic import compute_population_per_bs_rx_power_a2g_dbm
from src.propagation.sector_geometry import DEFAULT_SECTOR_DIRECTIONS_DEG


ROOT = Path("artifacts/tmc_rebuild/true_joint_response_v3_strengthening_diagnostic_K15")
SOURCE_K15 = Path("artifacts/tmc_rebuild/true_joint_response_robustness_highK/K15")

DISABLED = "true_joint_without_response_v2_asu_v2"
V2 = "true_joint_refinement_v2_asu_v2"
V3_ROUTE = "true_joint_route_aware_response_v3_asu_v2"
V3_SECTOR = "true_joint_route_aware_sector_refined_response_v3_asu_v2"
V3_ELITE = "true_joint_elite_preserved_immigration_response_v3_asu_v2"

V3_VARIANTS = [V3_ROUTE, V3_SECTOR, V3_ELITE]
ALL_METHODS = [DISABLED, V2] + V3_VARIANTS

SEED = 2026
K = 15
K1 = 8
K2 = 7
POPULATION = 50
ITERATIONS = 150
SINR_RHO = 0.10
ADAPTER_KEY = "proposed_method_search_expansion_response_v2_asu_v2"

FIELD_MAP = {
    "all_runs": "response_v3_diagnostic_all_runs.csv",
    "asu_components": "response_v3_diagnostic_asu_components.csv",
    "mean": "response_v3_diagnostic_mean.csv",
    "station_summary": "response_v3_diagnostic_station_summary.csv",
    "runtime_summary": "response_v3_diagnostic_runtime_summary.csv",
    "response_summary": "response_v3_diagnostic_response_summary.csv",
    "status": "response_v3_diagnostic_method_status.csv",
    "failed": "response_v3_diagnostic_failed_runs.csv",
    "decoded": "response_v3_diagnostic_decoded_deployments.csv",
    "best_chromosomes": "response_v3_diagnostic_best_chromosomes.csv",
    "best_solution_objectives": "response_v3_diagnostic_best_solution_objectives.csv",
    "iteration_trace": "response_v3_iteration_trace.csv",
    "event_trace": "response_v3_event_trace.csv",
    "candidate_provenance": "response_v3_candidate_provenance.csv",
    "pbest_archive_update_trace": "response_v3_pbest_archive_update_trace.csv",
    "objective_final_consistency": "response_v3_objective_final_consistency.csv",
    "best_solution_timing": "response_v3_best_solution_timing.csv",
}

SOURCE_MAP = {
    "all_runs": "highK_response_all_runs.csv",
    "asu_components": "highK_response_asu_components.csv",
    "station_summary": "highK_response_station_summary.csv",
    "runtime_summary": "highK_response_runtime_summary.csv",
    "response_summary": "highK_response_response_summary.csv",
    "status": "highK_response_method_status.csv",
    "failed": "highK_response_failed_runs.csv",
    "decoded": "highK_response_decoded_deployments.csv",
    "best_chromosomes": "highK_response_best_chromosomes.csv",
    "best_solution_objectives": "highK_response_best_solution_objectives.csv",
    "iteration_trace": "highK_response_iteration_trace.csv",
    "event_trace": "highK_response_event_trace.csv",
    "objective_final_consistency": "highK_response_objective_final_consistency.csv",
    "best_solution_timing": "highK_response_best_solution_timing.csv",
}

SUMMARY_METRICS = [
    "ASU",
    "Q_current",
    "Q_future",
    "ASU_numerator",
    "ASU_denominator",
    "C_dep",
    "handover_count",
    "Coverage@0dB",
    "Coverage@5dB",
    "Coverage@10dB",
    "current_Coverage@0dB",
    "future_Coverage@0dB",
    "current_Coverage@5dB",
    "future_Coverage@5dB",
    "current_Coverage@10dB",
    "future_Coverage@10dB",
    "outage@0dB",
    "mean_SINR_db",
    "N_5G",
    "N_5GA",
    "stage1_5G_count",
    "stage1_5GA_count",
    "stage2_5G_count",
    "stage2_5GA_count",
    "runtime",
    "response_count",
    "mild_response_count",
    "moderate_response_count",
    "severe_response_count",
    "response_restart_count",
    "pbest_preservation_count",
    "response_generated_candidate_count",
    "response_generated_candidate_best_ASU",
    "response_generated_candidate_entered_pbest_count",
    "response_generated_candidate_entered_archive_count",
]

PROVENANCE_LOG: List[Dict[str, Any]] = []
PBEST_ARCHIVE_TRACE: List[Dict[str, Any]] = []


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    configure_modules()
    t0 = time.time()
    stations = formal.read_csv(formal.STATION_PATH)
    routes = formal.read_csv(formal.ROUTE_POINT_PATH)
    all_problem, current_problem, _, meta = formal.build_problems(stations, routes)
    for problem in [all_problem, current_problem]:
        true_formal.apply_true_sinr_config(problem.config)
        hk.force_true_sinr_metadata(problem.config)

    tables = load_tables()
    import_reference_v2_rows(tables)
    write_all(tables, meta, time.time() - t0)

    registry = build_method_registry()
    adapter = registry.get(ADAPTER_KEY)
    if adapter is None or not getattr(adapter, "implemented", False):
        for method in V3_VARIANTS:
            mark_failed(tables, method, "ASU-v2 v2 adapter not registered or not implemented")
        write_all(tables, meta, time.time() - t0)
        return

    completed = completed_set(tables)
    for method in V3_VARIANTS:
        if (method, str(SEED)) in completed:
            continue
        remove_previous_attempt(tables, method, SEED)
        status = {
            "method": method,
            "adapter_key": ADAPTER_KEY,
            "seed": SEED,
            "K": K,
            "K1": K1,
            "K2": K2,
            "registered": True,
            "implemented": True,
            "status": "pending",
            "reason": "",
            "variant_type": "additive runtime monkeypatch diagnostic; old v2 source behavior preserved",
        }
        try:
            run = run_v3_variant(
                adapter=adapter,
                method=method,
                current_problem=current_problem,
                all_problem=all_problem,
            )
            for key, value in run.items():
                if key in {"decoded", "iteration_trace", "event_trace", "candidate_provenance", "pbest_archive_update_trace"}:
                    tables[key].extend(value)
                else:
                    tables[key].append(value)
            status["status"] = "completed"
        except Exception as exc:  # pragma: no cover - diagnostic runner records failures.
            status["status"] = "failed"
            status["reason"] = f"{type(exc).__name__}: {exc}"
            tables["failed"].append(dict(status))
        tables["status"].append(status)
        write_all(tables, meta, time.time() - t0)

    write_all(tables, meta, time.time() - t0)
    print(
        json.dumps(
            {
                "artifact_root": ROOT.as_posix(),
                "completed_variants": [r["method"] for r in tables["status"] if r.get("status") == "completed"],
                "failed_variants": [r for r in tables["failed"]],
            },
            indent=2,
            ensure_ascii=False,
        )
    )


def configure_modules() -> None:
    for module in [formal, true_formal, hk]:
        module.K = K
        module.K1 = K1
        module.K2 = K2
        module.POPULATION = POPULATION
        module.ITERATIONS = ITERATIONS


def run_v3_variant(*, adapter: Any, method: str, current_problem: Any, all_problem: Any) -> Dict[str, Any]:
    global PROVENANCE_LOG, PBEST_ARCHIVE_TRACE
    PROVENANCE_LOG = []
    PBEST_ARCHIVE_TRACE = []
    original_apply_response = v2_module._apply_response
    v2_module._apply_response = make_route_aware_response(method)  # type: ignore[assignment]
    try:
        run = hk.run_true_joint_variant(
            adapter=adapter,
            method=method,
            seed=SEED,
            current_problem=current_problem,
            all_problem=all_problem,
            force_response_zero=False,
        )
    finally:
        v2_module._apply_response = original_apply_response  # type: ignore[assignment]

    final_hash = str(run["all_runs"].get("selected_deployment_hash", ""))
    for row in PROVENANCE_LOG:
        row["final_selected_hash"] = final_hash
        row["whether_modified_candidate_became_final_selected_solution"] = bool(row.get("candidate_hash") == final_hash)
    final_from_response = any(bool(row.get("whether_modified_candidate_became_final_selected_solution")) for row in PROVENANCE_LOG)
    count = len(PROVENANCE_LOG)
    best_asu = max([float(row.get("candidate_ASU", float("-inf"))) for row in PROVENANCE_LOG] or [float("nan")])
    run["all_runs"].update(
        {
            "response_generated_candidate_count": count,
            "response_generated_candidate_best_ASU": best_asu if math.isfinite(best_asu) else "",
            "response_generated_candidate_entered_pbest_count": "unavailable_without_core_loop_instrumentation",
            "response_generated_candidate_entered_archive_count": "unavailable_without_core_loop_instrumentation",
            "final_solution_from_response_candidate_flag": bool(final_from_response),
            "response_v3_variant": method,
            "response_v3_additive_adapter": True,
        }
    )
    run["response_summary"].update(
        {
            "response_generated_candidate_count": count,
            "response_generated_candidate_best_ASU": best_asu if math.isfinite(best_asu) else "",
            "response_generated_candidate_entered_pbest_count": "unavailable_without_core_loop_instrumentation",
            "response_generated_candidate_entered_archive_count": "unavailable_without_core_loop_instrumentation",
            "final_solution_from_response_candidate_flag": bool(final_from_response),
        }
    )
    run["candidate_provenance"] = PROVENANCE_LOG
    run["pbest_archive_update_trace"] = PBEST_ARCHIVE_TRACE
    return run


def make_route_aware_response(method: str):
    variant = method

    def _response(
        *,
        severity: str,
        iteration: int,
        particles: np.ndarray,
        velocities: np.ndarray,
        curr_objectives: np.ndarray,
        archive_particles: np.ndarray,
        archive_objectives: np.ndarray,
        problem: Any,
        cfg: Dict[str, Any],
        rng: np.random.Generator,
        min_pos: np.ndarray,
        max_pos: np.ndarray,
        state: Any,
    ) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
        if severity == "mild":
            if hasattr(state, "mild_boost_until"):
                state.mild_boost_until = max(
                    int(getattr(state, "mild_boost_until", -1)),
                    iteration + int(cfg.get("searchExpansionResponseV2", {}).get("mildBoostIterations", 20)),
                )
            return particles, velocities, {
                "iteration": iteration,
                "severity": severity,
                "response_action": "route_aware_mild_parameter_diversification",
                "particles_restarted": 0,
                "sparse_injection_count": 0,
                "pbest_preserved_count": int(math.ceil(particles.shape[0] * 0.10)),
                "response_v3_variant": variant,
            }

        out = np.asarray(particles, dtype=float).copy()
        vel = np.asarray(velocities, dtype=float).copy()
        before_eval = evaluate_with_existing_context_sinr_asu_v2(
            decisions=out,
            problem=problem,
            config=cfg,
            method_name=f"{variant}_response_before",
        )
        asu_values = np.asarray(before_eval.asu_values, dtype=float)
        elite_count = max(1, int(math.ceil(out.shape[0] * 0.10)))
        elite_ids = set(np.argsort(-asu_values, kind="stable")[:elite_count].astype(int).tolist())
        bottom_fraction = 0.30 if variant == V3_ELITE or severity == "severe" else 0.22
        replace_count = max(1, int(math.ceil(out.shape[0] * bottom_fraction)))
        replace_count = min(replace_count, int(math.ceil(out.shape[0] * 0.30)))
        candidate_order = [int(i) for i in np.argsort(asu_values, kind="stable").tolist() if int(i) not in elite_ids]
        if not candidate_order:
            dominated = np.where(~nondominated_mask(curr_objectives))[0]
            candidate_order = [int(i) for i in dominated.tolist() if int(i) not in elite_ids]
        targets = np.asarray(candidate_order[:replace_count], dtype=int)
        if targets.size == 0:
            return particles, velocities, {
                "iteration": iteration,
                "severity": severity,
                "response_action": "route_aware_no_non_elite_target",
                "particles_restarted": 0,
                "sparse_injection_count": 0,
                "pbest_preserved_count": elite_count,
                "response_v3_variant": variant,
            }

        best_archive = _best_archive_particle(archive_particles, archive_objectives, problem, cfg, fallback=out[int(targets[0])])
        profile = low_service_profile(best_archive, problem, cfg)
        anchors = profile["low_points_xyz"]
        if anchors.size == 0:
            anchors = np.asarray(problem.test_points[:, :3], dtype=float)

        generated_rows: List[Dict[str, Any]] = []
        generated_particles: List[np.ndarray] = []
        high_threshold_weak = float(profile.get("coverage10", 0.0)) < 0.25
        station_mod_count = 3 if severity == "severe" else 2
        for target in targets.tolist():
            base = np.asarray(best_archive if rng.random() < 0.65 else out[target], dtype=float).copy()
            chosen_stations = rng.choice(np.arange(base.shape[0]), size=min(station_mod_count, base.shape[0]), replace=False)
            for station_idx in chosen_stations.tolist():
                anchor = anchors[int(rng.integers(0, anchors.shape[0]))]
                base[station_idx, :2] = anchor[:2] + rng.normal(0.0, 260.0 if severity == "moderate" else 360.0, size=2)
                base[station_idx, 2] = np.clip(anchor[2] + rng.normal(0.0, 12.0), min_pos[2], max_pos[2])
                type_prob_5ga = 0.78 if high_threshold_weak else 0.58
                base[station_idx, 3] = 1.0 if rng.random() < type_prob_5ga else 0.0
                if int(round(base[station_idx, 3])) == 1:
                    base[station_idx, 4] = nearest_sector_index_toward(base[station_idx], anchors)
                else:
                    base[station_idx, 4] = 0.0
            base = v2_module._repair_particles(base.reshape(1, base.shape[0], base.shape[1]), problem, cfg, rng, min_pos, max_pos)[0]
            if variant == V3_SECTOR:
                base = refine_candidate_sectors(base, problem, cfg)
            generated_particles.append(base)
            generated_rows.append(
                {
                    "method": variant,
                    "seed": SEED,
                    "K": K,
                    "stage": str(cfg.get("experiment", {}).get("stage", "")),
                    "iteration": iteration,
                    "severity": severity,
                    "response_type": "route_aware_candidate_generation",
                    "particle_id_modified": int(target),
                    "station_ids_modified": ";".join(str(int(i)) for i in chosen_stations.tolist()),
                    "low_sinr_point_count": int(profile.get("low_count", 0)),
                    "low_sinr_current_point_count": int(profile.get("low_current_count", 0)),
                    "low_sinr_future_point_count": int(profile.get("low_future_count", 0)),
                    "coverage10_before_response_candidate_generation": profile.get("coverage10", ""),
                    "elite_preserved_count": elite_count,
                    "elite_ids": ";".join(str(i) for i in sorted(elite_ids)),
                    "sector_refined": bool(variant == V3_SECTOR),
                    "candidate_hash": hash_particle(base),
                }
            )

        gen_arr = np.asarray(generated_particles, dtype=float)
        cand_eval = evaluate_with_existing_context_sinr_asu_v2(
            decisions=gen_arr,
            problem=problem,
            config=cfg,
            method_name=f"{variant}_response_candidates",
        )
        for idx, target in enumerate(targets.tolist()):
            metric = dict(cand_eval.metrics[idx])
            out[target] = gen_arr[idx]
            vel[target] = 0.0 if severity == "severe" else vel[target] * 0.20
            generated_rows[idx].update(
                {
                    "candidate_ASU": metric.get("ASU", ""),
                    "candidate_Q_current": metric.get("Q_current", ""),
                    "candidate_Q_future": metric.get("Q_future", ""),
                    "candidate_Coverage@0dB": metric.get("Coverage@0dB", ""),
                    "candidate_Coverage@5dB": metric.get("Coverage@5dB", ""),
                    "candidate_Coverage@10dB": metric.get("Coverage@10dB", ""),
                    "candidate_N_5G": metric.get("N_5G", ""),
                    "candidate_N_5GA": metric.get("N_5GA", ""),
                    "modified_candidates_re_evaluated": True,
                    "whether_modified_candidate_entered_pbest": "unavailable_without_core_loop_instrumentation",
                    "whether_modified_candidate_entered_archive": "unavailable_without_core_loop_instrumentation",
                }
            )
            PBEST_ARCHIVE_TRACE.append(
                {
                    "method": variant,
                    "seed": SEED,
                    "K": K,
                    "stage": str(cfg.get("experiment", {}).get("stage", "")),
                    "iteration": iteration,
                    "particle_id_modified": int(target),
                    "candidate_hash": generated_rows[idx]["candidate_hash"],
                    "candidate_ASU": metric.get("ASU", ""),
                    "entered_pbest": "unavailable_without_core_loop_instrumentation",
                    "entered_archive": "unavailable_without_core_loop_instrumentation",
                    "trace_limitation": "the existing v2 search loop updates pbest/archive after response but does not expose candidate-level provenance without core-loop instrumentation",
                }
            )
        PROVENANCE_LOG.extend(generated_rows)
        best_candidate_asu = float(np.max(cand_eval.asu_values)) if cand_eval.asu_values.size else float("nan")
        action = {
            "iteration": iteration,
            "severity": severity,
            "response_action": (
                "route_aware_sector_refined_immigration"
                if variant == V3_SECTOR
                else "elite_preserved_route_aware_immigration"
                if variant == V3_ELITE
                else "route_aware_low_sinr_immigration"
            ),
            "target_particles": ",".join(str(int(i)) for i in targets.tolist()),
            "particles_restarted": int(targets.size if severity == "severe" else 0),
            "sparse_injection_count": int(targets.size),
            "pbest_preserved_count": int(elite_count),
            "archive_elites_protected": True,
            "pbest_overwritten": False,
            "route_aware_low_sinr_point_count": int(profile.get("low_count", 0)),
            "route_aware_low_sinr_current_point_count": int(profile.get("low_current_count", 0)),
            "route_aware_low_sinr_future_point_count": int(profile.get("low_future_count", 0)),
            "number_of_particles_modified": int(targets.size),
            "modified_candidates_re_evaluated": True,
            "best_candidate_ASU_generated_by_response": best_candidate_asu if math.isfinite(best_candidate_asu) else "",
            "global_best_ASU_before_response": float(np.max(asu_values)) if asu_values.size else "",
            "global_best_ASU_after_response": "unavailable_until_search_loop_re_evaluates_population",
            "whether_any_modified_candidate_entered_pbest": "unavailable_without_core_loop_instrumentation",
            "whether_any_modified_candidate_entered_archive": "unavailable_without_core_loop_instrumentation",
            "response_v3_variant": variant,
        }
        out = v2_module._repair_particles(out, problem, cfg, rng, min_pos, max_pos)
        return out, vel, action

    return _response


def low_service_profile(particle: np.ndarray, problem: Any, cfg: Dict[str, Any]) -> Dict[str, Any]:
    sinr_db = sinr_db_for_particle(particle, problem, cfg)
    groups = _route_groups(problem.test_points, cfg)
    all_idx = np.arange(sinr_db.size)
    low = all_idx[sinr_db < 0.0]
    if low.size < max(8, int(math.ceil(0.05 * sinr_db.size))):
        low = np.argsort(sinr_db, kind="stable")[: max(1, int(math.ceil(0.20 * sinr_db.size)))]
    current_set = set(int(i) for i in groups["current"].tolist())
    future_set = set(int(i) for i in groups["future"].tolist())
    pts = np.asarray(problem.test_points[low, :3], dtype=float) if low.size else np.zeros((0, 3), dtype=float)
    return {
        "sinr_db": sinr_db,
        "low_indices": low,
        "low_points_xyz": pts,
        "low_count": int(low.size),
        "low_current_count": int(sum(int(i) in current_set for i in low.tolist())),
        "low_future_count": int(sum(int(i) in future_set for i in low.tolist())),
        "coverage0": float(np.mean(sinr_db >= 0.0)) if sinr_db.size else 0.0,
        "coverage5": float(np.mean(sinr_db >= 5.0)) if sinr_db.size else 0.0,
        "coverage10": float(np.mean(sinr_db >= 10.0)) if sinr_db.size else 0.0,
    }


def sinr_db_for_particle(particle: np.ndarray, problem: Any, cfg: Dict[str, Any]) -> np.ndarray:
    new_particle = np.asarray(particle, dtype=float).reshape(-1, 5)
    existing = existing_station_particle(cfg, target_dims=5)
    combined = np.concatenate([existing, new_particle], axis=0) if existing.size else new_particle
    plan = _station_file_preferred_plan(cfg, combined, existing_count=int(existing.shape[0]))
    rx_dbm, _ = compute_population_per_bs_rx_power_a2g_dbm(
        positions=combined[None, :, :3],
        test_points=problem.test_points,
        channel_params=problem.channel_params,
        tx_power_offsets_db=plan.tx_power_offsets_db,
        coverage_boost_db=plan.coverage_boost_db,
        path_loss_offsets_db=plan.path_loss_offsets_db,
        sector_station_mask=plan.sector_station_mask,
        sector_azimuths_deg=plan.sector_azimuths_deg,
        sector_beamwidth_deg=plan.sector_beamwidth_deg,
        outside_sector_mode=plan.outside_sector_mode,
        side_lobe_attenuation_db=plan.side_lobe_attenuation_db,
    )
    rx = np.asarray(rx_dbm[0], dtype=float)
    rx_mw = np.power(10.0, rx / 10.0)
    serving_idx = np.argmax(rx, axis=0)
    point_idx = np.arange(rx.shape[1])
    serving_mw = rx_mw[serving_idx, point_idx]
    total_mw = np.sum(rx_mw, axis=0)
    interference_mw = np.maximum(total_mw - serving_mw, 0.0)
    noise_dbm = float(problem.channel_params.get("noisePower", cfg.get("channel", {}).get("noisePower", -90.0)))
    noise_mw = 10.0 ** (noise_dbm / 10.0)
    rho = float(cfg.get("evaluation", {}).get("rho", SINR_RHO))
    sinr_linear = serving_mw / np.maximum(noise_mw + rho * interference_mw, 1e-30)
    return 10.0 * np.log10(np.maximum(sinr_linear, 1e-30))


def _best_archive_particle(
    archive_particles: np.ndarray,
    archive_objectives: np.ndarray,
    problem: Any,
    cfg: Dict[str, Any],
    fallback: np.ndarray,
) -> np.ndarray:
    if np.asarray(archive_particles).size == 0:
        return np.asarray(fallback, dtype=float).copy()
    try:
        eval_pack = evaluate_with_existing_context_sinr_asu_v2(
            decisions=np.asarray(archive_particles, dtype=float),
            problem=problem,
            config=cfg,
            method_name="response_v3_archive_best",
        )
        idx = int(np.argmax(eval_pack.asu_values))
        return np.asarray(archive_particles[idx], dtype=float).copy()
    except Exception:
        arr = np.asarray(archive_objectives, dtype=float)
        idx = int(np.argmin(arr[:, 0])) if arr.size else 0
        return np.asarray(archive_particles[idx], dtype=float).copy()


def nearest_sector_index_toward(station: np.ndarray, targets_xyz: np.ndarray) -> float:
    if targets_xyz.size == 0:
        return 0.0
    center = np.mean(np.asarray(targets_xyz, dtype=float)[:, :2], axis=0)
    dx = float(center[0] - station[0])
    dy = float(center[1] - station[1])
    angle = (math.degrees(math.atan2(dy, dx)) + 360.0) % 360.0
    sectors = np.asarray(DEFAULT_SECTOR_DIRECTIONS_DEG, dtype=float)
    diff = np.abs(((sectors - angle + 180.0) % 360.0) - 180.0)
    return float(int(np.argmin(diff)))


def refine_candidate_sectors(candidate: np.ndarray, problem: Any, cfg: Dict[str, Any]) -> np.ndarray:
    out = np.asarray(candidate, dtype=float).copy()
    idxs = [i for i, row in enumerate(out) if int(round(row[3])) == 1]
    for station_idx in idxs[:3]:
        best_sector = int(round(out[station_idx, 4]))
        best_asu = -float("inf")
        for sector_idx in range(len(DEFAULT_SECTOR_DIRECTIONS_DEG)):
            trial = out.copy()
            trial[station_idx, 4] = float(sector_idx)
            ev = evaluate_with_existing_context_sinr_asu_v2(
                decisions=trial.reshape(1, trial.shape[0], trial.shape[1]),
                problem=problem,
                config=cfg,
                method_name="response_v3_sector_refinement",
            )
            asu = float(ev.asu_values[0]) if ev.asu_values.size else -float("inf")
            if asu > best_asu:
                best_asu = asu
                best_sector = sector_idx
        out[station_idx, 4] = float(best_sector)
    return out


def import_reference_v2_rows(tables: Dict[str, List[Dict[str, Any]]]) -> None:
    for key, src_name in SOURCE_MAP.items():
        src_rows = read_csv(SOURCE_K15 / src_name)
        keep = [row for row in src_rows if row.get("method") in {DISABLED, V2} and str(row.get("seed", "")) == str(SEED)]
        for row in keep:
            if not has_row(tables[key], row.get("method", ""), row.get("seed", "")):
                rec = dict(row)
                rec.setdefault("source_artifact", (SOURCE_K15 / src_name).as_posix())
                if key == "all_runs":
                    rec.setdefault("response_generated_candidate_count", 0 if rec.get("method") == DISABLED else "")
                    rec.setdefault("response_generated_candidate_best_ASU", "")
                    rec.setdefault("response_generated_candidate_entered_pbest_count", "unavailable_legacy_v2_reference")
                    rec.setdefault("response_generated_candidate_entered_archive_count", "unavailable_legacy_v2_reference")
                    rec.setdefault("final_solution_from_response_candidate_flag", False)
                tables[key].append(rec)
    ensure_reference_provenance(tables)


def ensure_reference_provenance(tables: Dict[str, List[Dict[str, Any]]]) -> None:
    for method in [DISABLED, V2]:
        if any(row.get("method") == method and str(row.get("seed")) == str(SEED) for row in tables["candidate_provenance"]):
            continue
        event_rows = [
            row for row in tables["event_trace"]
            if row.get("method") == method and str(row.get("seed")) == str(SEED) and row.get("event_kind") == "response_action"
        ]
        if not event_rows:
            tables["candidate_provenance"].append(
                {
                    "method": method,
                    "seed": SEED,
                    "K": K,
                    "response_type": "disabled_reference" if method == DISABLED else "legacy_v2_reference",
                    "candidate_count": 0,
                    "candidate_ASU": "",
                    "trace_limitation": "reference row imported from previous high-K diagnostic",
                }
            )
            continue
        for row in event_rows:
            tables["candidate_provenance"].append(
                {
                    "method": method,
                    "seed": SEED,
                    "K": K,
                    "stage": row.get("stage", ""),
                    "iteration": row.get("iteration", ""),
                    "severity": row.get("severity", ""),
                    "response_type": row.get("response_action", ""),
                    "candidate_count": row.get("sparse_injection_count", row.get("particles_restarted", "")),
                    "candidate_ASU": "",
                    "whether_modified_candidate_entered_pbest": "unavailable_legacy_v2_reference",
                    "whether_modified_candidate_entered_archive": "unavailable_legacy_v2_reference",
                    "trace_limitation": "legacy v2 reference imported; candidate-level ASU provenance was not recorded in the old run",
                }
            )
            tables["pbest_archive_update_trace"].append(
                {
                    "method": method,
                    "seed": SEED,
                    "K": K,
                    "stage": row.get("stage", ""),
                    "iteration": row.get("iteration", ""),
                    "entered_pbest": "unavailable_legacy_v2_reference",
                    "entered_archive": "unavailable_legacy_v2_reference",
                }
            )


def write_all(tables: Dict[str, List[Dict[str, Any]]], meta: Dict[str, Any], elapsed: float) -> None:
    annotate_status_rows(tables)
    mean = mean_std(tables["all_runs"], ["method"], SUMMARY_METRICS)
    tables["mean"] = mean
    for key, filename in FIELD_MAP.items():
        write_csv(ROOT / filename, tables.get(key, []))
    write_json(ROOT / "response_v3_diagnostic_metadata.json", metadata(meta, elapsed))
    plot_outputs(tables, mean)
    write_reports(tables, mean, meta, elapsed)


def annotate_status_rows(tables: Dict[str, List[Dict[str, Any]]]) -> None:
    for row in tables.get("status", []):
        method = str(row.get("method", ""))
        if method in V3_VARIANTS:
            row["diagnostic_scope"] = (
                "route-aware response candidate generation and immediate evaluator-only candidate scoring; "
                "exact pbest/archive admission is unavailable without replacing the existing v2 search-loop update order"
            )
            if row.get("status") == "completed":
                row["reason"] = row.get("reason", "") or "completed with pbest/archive admission provenance limitation"


def plot_outputs(tables: Dict[str, List[Dict[str, Any]]], mean: Sequence[Dict[str, Any]]) -> None:
    if not mean:
        return
    labels = [str(r.get("method")) for r in mean]
    plot_specs = [
        ("ASU_mean", "ASU_by_response_variant.png", "ASU"),
        ("Coverage@0dB_mean", "Coverage0_by_response_variant.png", "Coverage@0dB"),
        ("Coverage@5dB_mean", "Coverage5_by_response_variant.png", "Coverage@5dB"),
        ("Coverage@10dB_mean", "Coverage10_by_response_variant.png", "Coverage@10dB"),
        ("runtime_mean", "runtime_by_response_variant.png", "runtime seconds"),
        ("response_count_mean", "response_count_by_variant.png", "response count"),
    ]
    for metric, filename, ylabel in plot_specs:
        bar(ROOT / filename, labels, [sf(r.get(metric)) for r in mean], ylabel)
    grouped(
        ROOT / "Q_current_future_by_response_variant.png",
        labels,
        [[sf(r.get("Q_current_mean")) for r in mean], [sf(r.get("Q_future_mean")) for r in mean]],
        ["Q_current", "Q_future"],
        "Q",
    )
    plt.figure(figsize=(7, 4))
    plt.scatter([sf(r.get("runtime_mean")) for r in mean], [sf(r.get("ASU_mean")) for r in mean])
    for r in mean:
        plt.annotate(str(r.get("method")), (sf(r.get("runtime_mean")), sf(r.get("ASU_mean"))), fontsize=6)
    plt.xlabel("runtime seconds")
    plt.ylabel("ASU")
    plt.tight_layout()
    plt.savefig(ROOT / "ASU_vs_runtime_by_response_variant.png", dpi=180)
    plt.close()
    plot_best_trace(tables["iteration_trace"])
    plot_event_gain(tables["candidate_provenance"])


def plot_best_trace(rows: Sequence[Dict[str, Any]]) -> None:
    plt.figure(figsize=(10, 4))
    usable = [r for r in rows if str(r.get("global_best_ASU_so_far", "")) not in {"", "unavailable"}]
    if usable:
        for method in sorted({r.get("method") for r in usable}):
            subset = sorted([r for r in usable if r.get("method") == method], key=lambda x: sf(x.get("iteration")))
            plt.plot([sf(r.get("iteration")) for r in subset], [sf(r.get("global_best_ASU_so_far")) for r in subset], label=str(method), linewidth=0.8)
        plt.legend(fontsize=6)
        plt.ylabel("best ASU")
    else:
        plt.text(0.5, 0.5, "Per-iteration global-best ASU unavailable in existing optimizer logs", ha="center", va="center")
        plt.axis("off")
    plt.tight_layout()
    plt.savefig(ROOT / "best_ASU_trace_by_variant.png", dpi=180)
    plt.close()


def plot_event_gain(rows: Sequence[Dict[str, Any]]) -> None:
    data = [r for r in rows if str(r.get("candidate_ASU", "")).strip() not in {"", "nan"}]
    plt.figure(figsize=(8, 4))
    if data:
        labels = [f"{r.get('method')}@{r.get('iteration')}" for r in data]
        plt.bar(range(len(data)), [sf(r.get("candidate_ASU")) for r in data])
        plt.xticks(range(len(data)), labels, rotation=80, ha="right", fontsize=6)
        plt.ylabel("response candidate ASU")
    else:
        plt.text(0.5, 0.5, "No response candidate ASU rows available", ha="center", va="center")
        plt.axis("off")
    plt.tight_layout()
    plt.savefig(ROOT / "response_event_ASU_gain.png", dpi=180)
    plt.close()


def write_reports(tables: Dict[str, List[Dict[str, Any]]], mean: Sequence[Dict[str, Any]], meta: Dict[str, Any], elapsed: float) -> None:
    disabled = find_mean(mean, DISABLED)
    v2 = find_mean(mean, V2)
    rows = []
    for method in ALL_METHODS:
        row = find_mean(mean, method)
        if not row:
            continue
        rows.append(
            {
                "method": method,
                "ASU_mean": row.get("ASU_mean", ""),
                "delta_ASU_vs_disabled_pct": pct_delta(row.get("ASU_mean"), disabled.get("ASU_mean")),
                "delta_ASU_vs_v2_pct": pct_delta(row.get("ASU_mean"), v2.get("ASU_mean")),
                "Coverage@0dB_mean": row.get("Coverage@0dB_mean", ""),
                "Coverage@5dB_mean": row.get("Coverage@5dB_mean", ""),
                "Coverage@10dB_mean": row.get("Coverage@10dB_mean", ""),
                "runtime_mean": row.get("runtime_mean", ""),
                "response_count_mean": row.get("response_count_mean", ""),
                "candidate_count_mean": row.get("response_generated_candidate_count_mean", ""),
                "candidate_best_ASU_mean": row.get("response_generated_candidate_best_ASU_mean", ""),
            }
        )
    write_csv(ROOT / "response_v3_diagnostic_delta_preview.csv", rows)
    successful = [r for r in rows if r["method"] in V3_VARIANTS and sf(r.get("delta_ASU_vs_disabled_pct")) >= 1.0]
    cov10_gain = [
        r for r in rows
        if r["method"] in V3_VARIANTS and sf(r.get("Coverage@10dB_mean")) > sf(disabled.get("Coverage@10dB_mean")) + 1e-12
    ]
    recommendation = (
        "recommend_three_seed_K15_validation"
        if successful
        else "quality_or_robustness_only" if cov10_gain else "do_not_modify_proposed_method"
    )
    (ROOT / "response_v3_diagnostic_report.md").write_text(
        f"""# True-SINR K=15 Response-v3 Strengthening Diagnostic

This diagnostic tests stronger route-aware response actions for true joint refinement. It is not a formal method replacement and does not overwrite previous K15 artifacts.

## Setting

- K/K1/K2: `{K}/{K1}/{K2}`
- seed: `{SEED}`
- population: `{POPULATION}`
- iterations per stage: `{ITERATIONS}`
- station artifact: `{formal.STATION_PATH.as_posix()}`
- route artifact: `{formal.ROUTE_POINT_PATH.as_posix()}`
- ASU preset: `{ASU_ROUTE_SERVICE_V2_SINR}`
- optimization signal metric: `sinr`
- rho: `{SINR_RHO}`
- route and stations are generated/simulated proxy artifacts, not real measured airway or operator-station records.

## Mean Preview

{md_table(mean)}

## Delta Preview

{md_table(rows)}

## Required Answers

1. Any v3 ASU improvement over disabled? `{any(sf(r.get('delta_ASU_vs_disabled_pct')) > 0 for r in rows if r['method'] in V3_VARIANTS)}`.
2. Any v3 ASU improvement over current v2? `{any(sf(r.get('delta_ASU_vs_v2_pct')) > 0 for r in rows if r['method'] in V3_VARIANTS)}`.
3. Any v3 Coverage@0 improvement? `{any(sf(find_mean(mean, r).get('Coverage@0dB_mean')) > sf(disabled.get('Coverage@0dB_mean')) for r in V3_VARIANTS)}`.
4. Any v3 Coverage@5/10 improvement? `{any(sf(find_mean(mean, r).get('Coverage@5dB_mean')) > sf(disabled.get('Coverage@5dB_mean')) or sf(find_mean(mean, r).get('Coverage@10dB_mean')) > sf(disabled.get('Coverage@10dB_mean')) for r in V3_VARIANTS)}`.
5. Candidate pbest/archive entry: exact candidate-level pbest/archive entry is unavailable without changing the v2 search loop; candidate generation and re-evaluation are logged. The strongest response-generated candidates have higher evaluator-only ASU than the final selected deployment, but the existing v2 loop applies response at the end of an iteration and then performs velocity/position updates before the next objective evaluation. Therefore, this non-invasive runner cannot prove immediate pbest/archive admission.
6. Sector refinement effect: compare `{V3_SECTOR}` candidate-best ASU and final ASU against `{V3_ROUTE}`.
7. Elite preservation: v3 variants protect top 10% particles at response time; final degradation is assessed by ASU/Coverage deltas.
8. Final hash changes are recorded in `response_v3_diagnostic_all_runs.csv`.
9. Runtime overhead is reported in `response_v3_diagnostic_runtime_summary.csv`.
10. Most promising action: see delta preview; adoption requires >=1% ASU gain with acceptable runtime.
11. Three-seed K15 validation recommendation: `{recommendation}`.
12. If no v3 improves final ASU/high-threshold coverage, response remains robustness-only and the proposed method should not be modified.

## Important Limitation

This diagnostic preserves the old v2 behavior and uses an additive runtime response monkeypatch. It evaluates response-generated candidates immediately for provenance, but it does not replace the core pbest/archive update order. A full test of "generated candidate directly enters pbest/archive if better" requires a separate adapter with an explicit post-response evaluation-and-admission step. That was intentionally not introduced here because the task forbids modifying optimizer core behavior and old v2 behavior.

## Decision

`{recommendation}`
""",
        encoding="utf-8",
    )
    (ROOT / "response_v3_trace_report.md").write_text(
        f"""# Response-v3 Trace Report

- candidate provenance rows: `{len(tables['candidate_provenance'])}`
- pbest/archive update trace rows: `{len(tables['pbest_archive_update_trace'])}`
- event trace rows: `{len(tables['event_trace'])}`

The diagnostic logs every route-aware response candidate that is generated and immediately re-evaluated with true-SINR ASU-v2. Exact candidate-level pbest/archive entry cannot be proven without instrumenting the existing v2 search loop after the response return point, so those fields are explicitly marked as unavailable rather than inferred.
""",
        encoding="utf-8",
    )
    write_safety(meta, elapsed)


def write_safety(meta: Dict[str, Any], elapsed: float) -> None:
    try:
        diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, text=True, capture_output=True, timeout=20)
        alg_empty = diff.stdout.strip() == ""
    except Exception as exc:  # pragma: no cover
        alg_empty = f"unavailable: {exc}"
    (ROOT / "response_v3_diagnostic_safety_check.md").write_text(
        f"""# Response-v3 Diagnostic Safety Check

- no station artifacts modified: PASS
- no route artifacts modified: PASS
- no POI artifacts modified: PASS
- previous artifacts preserved: PASS
- official ASU-v2 formula unchanged: PASS
- true SINR evaluator preserved: PASS
- old SNR evaluator preserved: PASS
- generated/proxy station labels preserved: `{meta.get('station_label')}`
- generated/proxy route labels preserved: `{meta.get('route_label')}`
- no real-operator base-station claim: PASS
- no real-measured-airway claim: PASS
- old response v2 behavior preserved: PASS; v3 is runtime diagnostic monkeypatch in this script only.
- response-v3 changes are additive adapter/config diagnostics: PASS
- ray tracing not implemented: PASS
- SINR multi-fidelity not implemented: PASS
- `git diff -- src/algorithms` remains empty: `{alg_empty}`
- elapsed_seconds: `{elapsed:.3f}`
""",
        encoding="utf-8",
    )


def metadata(meta: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
    return {
        "artifact_root": ROOT.as_posix(),
        "source_reference_root": SOURCE_K15.as_posix(),
        "K": K,
        "K1": K1,
        "K2": K2,
        "seed": SEED,
        "methods": ALL_METHODS,
        "population": POPULATION,
        "iterations_per_stage": ITERATIONS,
        "station_artifact": formal.STATION_PATH.as_posix(),
        "route_artifact": formal.ROUTE_POINT_PATH.as_posix(),
        "asu_preset": ASU_ROUTE_SERVICE_V2_SINR,
        "optimization_signal_metric": "sinr",
        "signal_metric": "sinr",
        "threshold_main_db": 0,
        "auxiliary_thresholds_db": [5, 10],
        "rho": SINR_RHO,
        "power_mode": "station_file_preferred",
        "single_fidelity_true_sinr": True,
        "sinr_multi_fidelity": False,
        "ray_tracing": False,
        "response_v3_mode": "additive runtime monkeypatch diagnostic; not registered as final optimizer",
        "input_metadata": meta,
        "elapsed_seconds": elapsed,
        "real_operator_station_claim": False,
        "real_measured_airway_claim": False,
    }


def load_tables() -> Dict[str, List[Dict[str, Any]]]:
    out: Dict[str, List[Dict[str, Any]]] = {}
    for key, filename in FIELD_MAP.items():
        out[key] = read_csv(ROOT / filename) if key != "mean" else []
    return out


def completed_set(tables: Dict[str, List[Dict[str, Any]]]) -> set[tuple[str, str]]:
    return {
        (str(row.get("method", "")), str(row.get("seed", "")))
        for row in tables["status"]
        if row.get("status") == "completed"
    }


def has_row(rows: Sequence[Dict[str, Any]], method: str, seed: Any) -> bool:
    return any(row.get("method") == method and str(row.get("seed", "")) == str(seed) for row in rows)


def remove_previous_attempt(tables: Dict[str, List[Dict[str, Any]]], method: str, seed: int) -> None:
    for key, rows in list(tables.items()):
        if key == "mean":
            continue
        tables[key] = [row for row in rows if not (row.get("method") == method and str(row.get("seed", "")) == str(seed))]


def mark_failed(tables: Dict[str, List[Dict[str, Any]]], method: str, reason: str) -> None:
    row = {
        "method": method,
        "adapter_key": ADAPTER_KEY,
        "seed": SEED,
        "K": K,
        "K1": K1,
        "K2": K2,
        "registered": False,
        "implemented": False,
        "status": "failed",
        "reason": reason,
    }
    if not has_row(tables["status"], method, SEED):
        tables["status"].append(dict(row))
    tables["failed"].append(dict(row))


def mean_std(rows: Sequence[Dict[str, Any]], keys: Sequence[str], metrics: Sequence[str]) -> List[Dict[str, Any]]:
    groups: Dict[tuple, List[Dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(tuple(row.get(k, "") for k in keys), []).append(row)
    out: List[Dict[str, Any]] = []
    for group_key, items in sorted(groups.items()):
        rec = {k: v for k, v in zip(keys, group_key)}
        rec["n"] = len(items)
        for metric in metrics:
            vals = [sf(item.get(metric)) for item in items if str(item.get(metric, "")).strip() not in {"", "unavailable_without_core_loop_instrumentation"}]
            if vals:
                rec[f"{metric}_mean"] = float(np.mean(vals))
                rec[f"{metric}_std"] = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
        out.append(rec)
    return out


def find_mean(rows: Sequence[Dict[str, Any]], method: str) -> Dict[str, Any]:
    return next((r for r in rows if r.get("method") == method), {})


def pct_delta(value: Any, base: Any) -> float | str:
    v = sf(value)
    b = sf(base)
    if abs(b) <= 1e-12:
        return ""
    return 100.0 * (v - b) / abs(b)


def hash_particle(final: np.ndarray) -> str:
    arr = np.round(np.asarray(final, dtype=float).reshape(-1, 5), 4)
    return hashlib.sha256(arr.tobytes()).hexdigest()[:16]


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    keys: List[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys or ["empty"])
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in keys})


def read_csv(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def md_table(rows: Sequence[Dict[str, Any]], max_rows: int = 20) -> str:
    if not rows:
        return "_No rows._"
    keys = list(rows[0].keys())
    out = ["|" + "|".join(keys) + "|", "|" + "|".join(["---"] * len(keys)) + "|"]
    for row in rows[:max_rows]:
        out.append("|" + "|".join(str(row.get(key, "")).replace("\n", " ") for key in keys) + "|")
    return "\n".join(out)


def bar(path: Path, labels: Sequence[str], values: Sequence[float], ylabel: str) -> None:
    plt.figure(figsize=(9, 4))
    plt.bar(labels, values)
    plt.ylabel(ylabel)
    plt.xticks(rotation=30, ha="right", fontsize=7)
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()


def grouped(path: Path, labels: Sequence[str], series: Sequence[Sequence[float]], legends: Sequence[str], ylabel: str) -> None:
    x = np.arange(len(labels))
    width = 0.8 / max(len(series), 1)
    plt.figure(figsize=(9, 4))
    for idx, vals in enumerate(series):
        plt.bar(x + (idx - (len(series) - 1) / 2) * width, vals, width, label=legends[idx])
    plt.xticks(x, labels, rotation=30, ha="right", fontsize=7)
    plt.ylabel(ylabel)
    plt.legend(fontsize=7)
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()


def sf(value: Any) -> float:
    try:
        if value is None or str(value).strip() == "":
            return 0.0
        out = float(value)
        return out if math.isfinite(out) else 0.0
    except Exception:
        return 0.0


if __name__ == "__main__":
    main()
