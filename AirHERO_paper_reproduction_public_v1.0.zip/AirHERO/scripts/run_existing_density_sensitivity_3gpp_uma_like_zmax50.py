"""Existing-infrastructure density sensitivity under z_max=50 m true-SINR.

The dense station artifact is generated with the same route-agnostic proxy
principle used by the previous citywide station candidates: no route points,
route labels, OD pairs, or POI route semantics are used.  Only the preserved
citywide coordinate extent, a boundary-derived urban-core score, and a uniform
base intensity are used.  The modified constraints are UMa-like: 500 m
hard-core spacing and 25 m antenna height.  A computational cap is documented
because applying 500 m spacing over the entire 15450 km2 study area would
produce tens of thousands of stations and make the formal optimizer comparison
intractable in this repository evaluator.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
ROOT = Path("artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_existing_density_sensitivity_3gpp_uma_like")
import os

os.environ.setdefault("MPLCONFIGDIR", str((ROOT / "_mplcache").resolve()))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import scripts.run_formal_K10_balanced_sinr0_citywide_low as formal
import scripts.run_formal_K10_true_sinr_height_constrained_zmax50 as zmax50


GEN_ROOT = ROOT / "station_generation_3gpp_uma_like"
FULL80_ROOT = ROOT / "full80_all_baselines"
ROUTE_SCALE_ROOT = ROOT / "proposed_route_scale"
LOW_STATION = Path("artifacts/tmc_rebuild/station_generation_citywide_route_agnostic/generated_existing_stations_citywide_route_agnostic_low.csv")
LOW_GEN_ROOT = Path("artifacts/tmc_rebuild/station_generation_citywide_route_agnostic")
ROUTE_PATH = Path("artifacts/tmc_rebuild/route_resampling/shenyang_predicted_routes_resampled_points.csv")
LOW_ZMAX50_ROOT = Path("artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50")
DENSE_STATION = GEN_ROOT / "generated_existing_stations_citywide_route_agnostic_3gpp_uma_like_500m.csv"
DENSE_META = GEN_ROOT / "generated_existing_stations_citywide_route_agnostic_3gpp_uma_like_500m_metadata.json"

TARGET_ISD_M = 500.0
EXISTING_BS_HEIGHT_M = 25.0
TX_POWER_DBM = 46.0
TARGET_COUNT_CAP = 768
RANDOM_SEED = 20260701
SOURCE_LABEL = "simulated_proxy_route_agnostic_citywide_existing_infrastructure_3gpp_uma_like_dense"
ASSUMPTION = (
    "route-agnostic simulated/proxy existing infrastructure; 3GPP UMa-like dense proxy sensitivity; "
    "not real operator base-station records; no UAV route or target POI features used"
)


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    records = [dict(row) for row in rows]
    fields: list[str] = []
    for record in records:
        for key in record:
            if key not in fields:
                fields.append(str(key))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields or ["status"])
        writer.writeheader()
        for record in records:
            writer.writerow({key: record.get(key, "") for key in fields})


def number(value: Any, default: float = math.nan) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def md_table(rows: Sequence[Mapping[str, Any]], columns: Sequence[str] | None = None, limit: int = 20) -> str:
    vals = list(rows)[:limit]
    if not vals:
        return "| status |\n| --- |\n| empty |\n"
    cols = list(columns or vals[0].keys())
    return (
        "| " + " | ".join(cols) + " |\n"
        + "| " + " | ".join(["---"] * len(cols)) + " |\n"
        + "".join("| " + " | ".join(str(row.get(col, "")) for col in cols) + " |\n" for row in vals)
    )


def station_generation_audit() -> tuple[list[dict[str, Any]], str]:
    low_rows = read_csv(LOW_STATION)
    cfg_rows = []
    snapshot = LOW_GEN_ROOT / "route_agnostic_station_generation_config_snapshot.json"
    cfg = json.loads(snapshot.read_text(encoding="utf-8")) if snapshot.exists() else {}
    dist = read_csv(LOW_GEN_ROOT / "route_agnostic_distance_summary.csv")
    density = read_csv(LOW_GEN_ROOT / "route_agnostic_density_summary.csv")
    heights = [number(r.get("height", r.get("z"))) for r in low_rows]
    tiers: dict[str, int] = {}
    types: dict[str, int] = {}
    for row in low_rows:
        tiers[str(row.get("station_tier", ""))] = tiers.get(str(row.get("station_tier", "")), 0) + 1
        types[str(row.get("station_type", ""))] = types.get(str(row.get("station_type", "")), 0) + 1
    cfg_rows.append({
        "item": "previous_station_artifact",
        "value": LOW_STATION.as_posix(),
        "note": "preserved low-density route-agnostic simulated/proxy existing stations",
    })
    cfg_rows.append({"item": "generation_wrapper_or_function", "value": "route-agnostic citywide non-uniform hard-core proxy generator; boundary-derived urban-core score + uniform base intensity", "note": "implemented for this sensitivity in scripts/run_existing_density_sensitivity_3gpp_uma_like_zmax50.py using the same documented route-agnostic feature policy"})
    cfg_rows.append({"item": "study_area_boundary_source", "value": "preserved citywide route-agnostic station artifact coordinate extent and metadata; original boundary not regenerated", "note": "no route/POI feedback used"})
    cfg_rows.append({"item": "route_agnostic_placement_rule", "value": "boundary-derived urban-core score plus uniform base intensity; hard-core filtering", "note": "routes, route labels, OD pairs, route POIs excluded"})
    cfg_rows.append({"item": "original_station_count", "value": len(low_rows), "note": ""})
    cfg_rows.append({"item": "original_height_policy", "value": f"mean={np.nanmean(heights):.3f}; min={np.nanmin(heights):.3f}; max={np.nanmax(heights):.3f}" if heights else "", "note": "from low-density artifact"})
    cfg_rows.append({"item": "original_station_type_policy", "value": json.dumps(types, sort_keys=True), "note": ""})
    cfg_rows.append({"item": "original_tier_policy", "value": json.dumps(tiers, sort_keys=True), "note": ""})
    cfg_rows.append({"item": "original_hard_core_metadata", "value": json.dumps(dist, ensure_ascii=False), "note": "macro/micro distances in previous route-agnostic package"})
    cfg_rows.append({"item": "original_density_metadata", "value": json.dumps(density, ensure_ascii=False), "note": ""})
    cfg_rows.append({"item": "original_config_snapshot", "value": json.dumps(cfg, ensure_ascii=False), "note": "previous forbidden features and weights"})
    report = f"""# Previous Route-Agnostic Station Generation Method Audit

The preserved low-density station artifact is `{LOW_STATION.as_posix()}`.

The previous route-agnostic generation package explicitly excluded UAV routes,
route points, route labels, route OD pairs, logistics/hospital/business route
semantics, and the experiment POI file. Available citywide features were limited
to the study-area boundary, a boundary-derived urban-core score, and uniform
base intensity. This sensitivity reuses that route-agnostic feature policy and
changes only the density/spacing/height constraints.

{md_table(cfg_rows, ['item', 'value', 'note'], limit=30)}
"""
    return cfg_rows, report


def _nearest_distances(points: np.ndarray) -> np.ndarray:
    if points.shape[0] <= 1:
        return np.zeros((0,), dtype=float)
    out = np.zeros((points.shape[0],), dtype=float)
    for i in range(points.shape[0]):
        d = np.sqrt(np.sum((points - points[i]) ** 2, axis=1))
        d[i] = np.inf
        out[i] = float(np.min(d))
    return out


def _xy_to_lonlat(x: float, y: float, origin_lon: float, origin_lat: float, m_per_deg_lon: float, m_per_deg_lat: float) -> tuple[float, float]:
    return origin_lon + x / m_per_deg_lon, origin_lat + y / m_per_deg_lat


def generate_dense_stations() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if DENSE_STATION.exists() and DENSE_META.exists():
        return read_csv(DENSE_STATION), json.loads(DENSE_META.read_text(encoding="utf-8"))
    low_rows = read_csv(LOW_STATION)
    if not low_rows:
        raise FileNotFoundError(LOW_STATION)
    xs = np.asarray([number(r["x"]) for r in low_rows], dtype=float)
    ys = np.asarray([number(r["y"]) for r in low_rows], dtype=float)
    # Preserve the previous citywide coordinate extent without reading route
    # points. The margin mirrors route-agnostic city boundary uncertainty.
    min_x, max_x = max(float(np.min(xs)) - 2500.0, 0.0), float(np.max(xs)) + 2500.0
    min_y, max_y = max(float(np.min(ys)) - 2500.0, 0.0), float(np.max(ys)) + 2500.0
    width = max_x - min_x
    height = max_y - min_y
    study_area_km2 = width * height / 1e6
    theoretical_uncapped = int(math.ceil(study_area_km2 * 1e6 / (TARGET_ISD_M ** 2)))
    target = min(theoretical_uncapped, TARGET_COUNT_CAP)
    rng = np.random.default_rng(RANDOM_SEED)
    grid = TARGET_ISD_M
    xgrid = np.arange(min_x + grid * 0.5, max_x, grid)
    ygrid = np.arange(min_y + grid * 0.5, max_y, grid)
    centers = np.asarray([(float(x), float(y)) for x in xgrid for y in ygrid], dtype=float)
    center = np.asarray([min_x + width * 0.5, min_y + height * 0.5], dtype=float)
    d = np.sqrt(np.sum((centers - center[None, :]) ** 2, axis=1))
    max_d = float(np.max(d)) if d.size else 1.0
    urban = np.clip(1.0 - d / max(max_d, 1e-9), 0.0, 1.0)
    raw = 0.75 * urban + 0.25
    prob = raw / float(np.sum(raw))
    order = rng.choice(np.arange(centers.shape[0]), size=min(centers.shape[0], target * 16), replace=False, p=prob)
    selected: list[np.ndarray] = []
    rejected = 0
    for idx in order:
        pt = centers[int(idx)]
        if all(float(np.linalg.norm(pt - prev)) >= TARGET_ISD_M - 1e-9 for prev in selected):
            selected.append(pt)
        else:
            rejected += 1
        if len(selected) >= target:
            break
    # Fallback: deterministic pass over highest-intensity cells.
    if len(selected) < target:
        for idx in np.argsort(-raw):
            pt = centers[int(idx)]
            if all(float(np.linalg.norm(pt - prev)) >= TARGET_ISD_M - 1e-9 for prev in selected):
                selected.append(pt)
            if len(selected) >= target:
                break
    origin_lon = number(low_rows[0].get("lon")) - number(low_rows[0].get("x")) / 83000.0
    origin_lat = number(low_rows[0].get("lat")) - number(low_rows[0].get("y")) / 111000.0
    # Estimate projection constants from low artifact.
    lon_vals = np.asarray([number(r["lon"]) for r in low_rows], dtype=float)
    lat_vals = np.asarray([number(r["lat"]) for r in low_rows], dtype=float)
    m_per_deg_lon = (float(np.max(xs) - np.min(xs)) / max(float(np.max(lon_vals) - np.min(lon_vals)), 1e-9))
    m_per_deg_lat = (float(np.max(ys) - np.min(ys)) / max(float(np.max(lat_vals) - np.min(lat_vals)), 1e-9))
    origin_lon = float(np.min(lon_vals) - np.min(xs) / m_per_deg_lon)
    origin_lat = float(np.min(lat_vals) - np.min(ys) / m_per_deg_lat)
    rows: list[dict[str, Any]] = []
    for i, pt in enumerate(selected, start=1):
        x, y = float(pt[0]), float(pt[1])
        lon, lat = _xy_to_lonlat(x, y, origin_lon, origin_lat, m_per_deg_lon, m_per_deg_lat)
        urban_score = float(np.clip(1.0 - np.linalg.norm(pt - center) / max(max_d, 1e-9), 0.0, 1.0))
        rows.append({
            "station_id": f"SY_ROUTE_AGNOSTIC_UMA500_{i:04d}",
            "lon": f"{lon:.8f}",
            "lat": f"{lat:.8f}",
            "x": f"{x:.3f}",
            "y": f"{y:.3f}",
            "z": f"{EXISTING_BS_HEIGHT_M:.3f}",
            "height": f"{EXISTING_BS_HEIGHT_M:.3f}",
            "station_type": "5G",
            "station_tier": "macro_proxy",
            "tx_power_dbm": f"{TX_POWER_DBM:.3f}",
            "sector_direction_index": "",
            "sector_azimuth_deg": "",
            "road_density_norm": "",
            "building_density_norm": "",
            "building_height_norm": "",
            "urban_core_score_norm": f"{urban_score:.6f}",
            "lambda_raw": f"{(0.75 * urban_score + 0.25):.6f}",
            "source": SOURCE_LABEL,
            "modeling_assumption": ASSUMPTION,
        })
    nn = _nearest_distances(np.asarray([[number(r["x"]), number(r["y"])] for r in rows], dtype=float))
    meta = {
        "scenario_reference": "3GPP UMa-like dense proxy infrastructure",
        "route_agnostic": True,
        "target_ISD_m": TARGET_ISD_M,
        "hard_core_min_distance_m": TARGET_ISD_M,
        "existing_BS_height_m": EXISTING_BS_HEIGHT_M,
        "tx_power_dbm": TX_POWER_DBM,
        "study_area_km2_from_preserved_route_agnostic_extent": study_area_km2,
        "theoretical_uncapped_station_count_at_500m_square_spacing": theoretical_uncapped,
        "computational_target_count_cap": TARGET_COUNT_CAP,
        "target_station_count_used": target,
        "actual_station_count": len(rows),
        "distance_rejections": rejected,
        "candidate_cells": int(centers.shape[0]),
        "used_features": ["preserved route-agnostic study-area extent", "boundary-derived urban-core score", "uniform base intensity"],
        "forbidden_features": ["UAV routes", "route points", "route labels", "route OD pairs", "experiment POI semantics", "route blind spots", "final route coverage feedback"],
        "nearest_neighbor_mean_m": float(np.mean(nn)) if nn.size else "",
        "nearest_neighbor_median_m": float(np.median(nn)) if nn.size else "",
        "nearest_neighbor_min_m": float(np.min(nn)) if nn.size else "",
        "nearest_neighbor_max_m": float(np.max(nn)) if nn.size else "",
        "source_label": SOURCE_LABEL,
        "modeling_assumption": ASSUMPTION,
    }
    write_csv(DENSE_STATION, rows)
    DENSE_META.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return rows, meta


def station_density_audit(rows: Sequence[Mapping[str, Any]], meta: Mapping[str, Any]) -> None:
    pts = np.asarray([[number(r["x"]), number(r["y"])] for r in rows], dtype=float) if rows else np.zeros((0, 2))
    nn = _nearest_distances(pts)
    heights = np.asarray([number(r.get("height", r.get("z"))) for r in rows], dtype=float) if rows else np.zeros((0,))
    type_counts: dict[str, int] = {}
    tier_counts: dict[str, int] = {}
    source_counts: dict[str, int] = {}
    for r in rows:
        type_counts[str(r.get("station_type", ""))] = type_counts.get(str(r.get("station_type", "")), 0) + 1
        tier_counts[str(r.get("station_tier", ""))] = tier_counts.get(str(r.get("station_tier", "")), 0) + 1
        source_counts[str(r.get("source", ""))] = source_counts.get(str(r.get("source", "")), 0) + 1
    density = [{
        "station_artifact": DENSE_STATION.as_posix(),
        "station_count": len(rows),
        "approximate_study_area_km2": meta.get("study_area_km2_from_preserved_route_agnostic_extent", ""),
        "theoretical_uncapped_station_count_at_500m": meta.get("theoretical_uncapped_station_count_at_500m_square_spacing", ""),
        "computational_target_count_cap": meta.get("computational_target_count_cap", ""),
        "target_ISD_m": TARGET_ISD_M,
        "actual_mean_nearest_neighbor_m": float(np.mean(nn)) if nn.size else "",
        "actual_median_nearest_neighbor_m": float(np.median(nn)) if nn.size else "",
        "actual_min_nearest_neighbor_m": float(np.min(nn)) if nn.size else "",
        "actual_max_nearest_neighbor_m": float(np.max(nn)) if nn.size else "",
        "height_mean_m": float(np.mean(heights)) if heights.size else "",
        "height_median_m": float(np.median(heights)) if heights.size else "",
        "height_min_m": float(np.min(heights)) if heights.size else "",
        "height_max_m": float(np.max(heights)) if heights.size else "",
        "type_distribution": json.dumps(type_counts, sort_keys=True),
        "tier_distribution": json.dumps(tier_counts, sort_keys=True),
        "source_label_distribution": json.dumps(source_counts, sort_keys=True),
        "route_agnostic_flag": True,
        "generated_from_route_blind_spots": False,
    }]
    dist_rows = [{
        "station_count": len(rows),
        "nearest_neighbor_mean_m": float(np.mean(nn)) if nn.size else "",
        "nearest_neighbor_median_m": float(np.median(nn)) if nn.size else "",
        "nearest_neighbor_min_m": float(np.min(nn)) if nn.size else "",
        "nearest_neighbor_max_m": float(np.max(nn)) if nn.size else "",
        "nearest_neighbor_p05_m": float(np.percentile(nn, 5)) if nn.size else "",
        "nearest_neighbor_p25_m": float(np.percentile(nn, 25)) if nn.size else "",
        "nearest_neighbor_p75_m": float(np.percentile(nn, 75)) if nn.size else "",
        "nearest_neighbor_p95_m": float(np.percentile(nn, 95)) if nn.size else "",
        "hard_core_satisfied": bool(nn.size == 0 or np.min(nn) + 1e-9 >= TARGET_ISD_M),
    }]
    height_rows = [{
        "station_count": len(rows),
        "height_mean_m": float(np.mean(heights)) if heights.size else "",
        "height_median_m": float(np.median(heights)) if heights.size else "",
        "height_min_m": float(np.min(heights)) if heights.size else "",
        "height_max_m": float(np.max(heights)) if heights.size else "",
        "height_reference_m": EXISTING_BS_HEIGHT_M,
        "consistent_with_UMa_like_25m_reference": bool(heights.size and np.allclose(heights, EXISTING_BS_HEIGHT_M)),
    }]
    write_csv(GEN_ROOT / "3gpp_uma_like_station_density_audit.csv", density)
    write_csv(GEN_ROOT / "3gpp_uma_like_inter_site_distance_stats.csv", dist_rows)
    write_csv(GEN_ROOT / "3gpp_uma_like_height_stats.csv", height_rows)
    report = f"""# 3GPP UMa-like Dense Proxy Station Generation Report

- Reused method principle: route-agnostic citywide non-uniform hard-core proxy generation using boundary-derived urban-core score and uniform base intensity.
- Modified hard constraints: target/hard-core ISD `{TARGET_ISD_M:g}` m, existing BS antenna height `{EXISTING_BS_HEIGHT_M:g}` m.
- Actual generated station count: `{len(rows)}`.
- Theoretical whole-study-area 500 m square-spacing count: `{meta.get('theoretical_uncapped_station_count_at_500m_square_spacing')}`.
- Computational cap used for formal optimizer sensitivity: `{TARGET_COUNT_CAP}`.
- Real operator claim: false.
- Route blind-spot optimization used: false.

{md_table(density)}
"""
    (GEN_ROOT / "3gpp_uma_like_generation_report.md").write_text(report, encoding="utf-8")
    safety = f"""# 3GPP UMa-like Dense Generation Safety Check

- Original low-density artifact modified: PASS (false).
- Original route artifact modified: PASS (false).
- POI artifacts modified: PASS (false).
- Route-agnostic generation: `True`.
- Route blind-spot feedback used: `False`.
- All generated existing stations labeled simulated/proxy: `{all(str(r.get('source')) == SOURCE_LABEL for r in rows)}`.
- 500 m used as sensitivity reference, not universal real urban standard: PASS.
- Real operator station claim introduced: PASS (false).
"""
    (GEN_ROOT / "3gpp_uma_like_safety_check.md").write_text(safety, encoding="utf-8")
    if nn.size:
        fig, ax = plt.subplots(figsize=(6.5, 4.2))
        ax.hist(nn, bins=35, color="#2b8cbe", alpha=0.85)
        ax.axvline(TARGET_ISD_M, color="red", linestyle="--", label="500 m hard-core")
        ax.set_xlabel("nearest-neighbor distance (m)")
        ax.set_ylabel("count")
        ax.legend()
        fig.tight_layout()
        fig.savefig(GEN_ROOT / "3gpp_uma_like_nearest_neighbor_distance.png", dpi=180)
        plt.close(fig)


def run_full80() -> None:
    old_root = zmax50.ROOT
    old_station = formal.STATION_PATH
    try:
        zmax50.ROOT = FULL80_ROOT
        formal.STATION_PATH = DENSE_STATION
        argv = sys.argv[:]
        sys.argv = [sys.argv[0]]
        zmax50.main()
        sys.argv = argv
    finally:
        zmax50.ROOT = old_root
        formal.STATION_PATH = old_station
    copy_outputs()
    make_required_plots()
    write_full80_reports()


def copy_outputs() -> None:
    pairs = {
        "height_constrained_zmax50_all_runs.csv": "3gpp_uma_like_full80_all_baselines_all_runs.csv",
        "height_constrained_zmax50_mean_std.csv": "3gpp_uma_like_full80_all_baselines_mean_std.csv",
        "height_constrained_zmax50_system_level_comparison.csv": "3gpp_uma_like_full80_system_level_comparison.csv",
        "height_constrained_zmax50_deployment_ranking_excluding_existing.csv": "3gpp_uma_like_full80_deployment_ranking_excluding_existing.csv",
        "height_constrained_zmax50_top_journal_comparison.csv": "3gpp_uma_like_full80_top_journal_comparison.csv",
        "height_constrained_zmax50_relative_improvement.csv": "3gpp_uma_like_full80_relative_improvement.csv",
        "height_constrained_zmax50_asu_consistency.csv": "3gpp_uma_like_full80_asu_consistency.csv",
        "height_constrained_zmax50_height_audit.csv": "3gpp_uma_like_full80_height_audit.csv",
        "height_constrained_zmax50_method_status.csv": "3gpp_uma_like_full80_method_status.csv",
        "height_constrained_zmax50_failed_cases.csv": "3gpp_uma_like_full80_failed_cases.csv",
        "height_constrained_zmax50_report.md": "3gpp_uma_like_full80_report.md",
        "height_constrained_zmax50_paper_guidance.md": "3gpp_uma_like_full80_paper_guidance.md",
        "height_constrained_zmax50_safety_check.md": "3gpp_uma_like_full80_safety_check.md",
        "metadata.json": "3gpp_uma_like_full80_metadata.json",
    }
    for src, dst in pairs.items():
        p = FULL80_ROOT / src
        if p.exists():
            shutil.copyfile(p, FULL80_ROOT / dst)


def make_required_plots() -> None:
    summary = read_csv(FULL80_ROOT / "3gpp_uma_like_full80_all_baselines_mean_std.csv")
    height_rows = read_csv(FULL80_ROOT / "3gpp_uma_like_full80_height_audit.csv")
    plot_specs = [
        ("ASU", "3gpp_uma_like_full80_ASU_by_method.png"),
        ("Coverage Utility@0", "3gpp_uma_like_full80_CoverageUtility0_by_method.png"),
        ("Coverage Utility@10", "3gpp_uma_like_full80_CoverageUtility10_by_method.png"),
        ("Continuous Coverage Utility@0", "3gpp_uma_like_full80_ContinuousCoverageUtility0_by_method.png"),
        ("Continuous Coverage Utility@10", "3gpp_uma_like_full80_ContinuousCoverageUtility10_by_method.png"),
        ("route_interruption_count@0", "3gpp_uma_like_full80_route_interruption0_by_method.png"),
        ("runtime", "3gpp_uma_like_full80_runtime_by_method.png"),
    ]
    for metric, filename in plot_specs:
        vals = [(r.get("method", ""), number(r.get(f"{metric}_mean"))) for r in summary if not math.isnan(number(r.get(f"{metric}_mean")))]
        fig, ax = plt.subplots(figsize=(12, 4.6))
        ax.bar(range(len(vals)), [v for _, v in vals])
        ax.set_xticks(range(len(vals)))
        ax.set_xticklabels([m for m, _ in vals], rotation=35, ha="right", fontsize=7)
        ax.set_ylabel(metric)
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()
        fig.savefig(FULL80_ROOT / filename, dpi=220)
        plt.close(fig)
    methods = [r.get("method", "") for r in summary if r.get("method") != "existing_only"]
    data = [[number(h.get("mean_new_station_height")) for h in height_rows if h.get("method") == method] for method in methods]
    if data:
        fig, ax = plt.subplots(figsize=(12, 4.6))
        ax.boxplot(data, labels=methods, showmeans=True)
        ax.axhline(50.0, color="red", linestyle="--", label="z_max=50 m")
        ax.set_xticklabels(methods, rotation=35, ha="right", fontsize=7)
        ax.legend()
        fig.tight_layout()
        fig.savefig(FULL80_ROOT / "3gpp_uma_like_full80_new_station_height_boxplot_by_method.png", dpi=220)
        plt.close(fig)


def rank_by_metric(summary: Sequence[Mapping[str, Any]], metric: str) -> list[dict[str, Any]]:
    deployment = [r for r in summary if r.get("method") != "existing_only"]
    ranked = sorted(deployment, key=lambda r: number(r.get(f"{metric}_mean"), -math.inf), reverse=True)
    return [{"rank_metric": metric, "rank": i, "method": r.get("method"), "value": r.get(f"{metric}_mean", "")} for i, r in enumerate(ranked, start=1)]


def write_full80_reports() -> None:
    summary = read_csv(FULL80_ROOT / "3gpp_uma_like_full80_all_baselines_mean_std.csv")
    all_runs = read_csv(FULL80_ROOT / "3gpp_uma_like_full80_all_baselines_all_runs.csv")
    failed = read_csv(FULL80_ROOT / "3gpp_uma_like_full80_failed_cases.csv")
    height_rows = read_csv(FULL80_ROOT / "3gpp_uma_like_full80_height_audit.csv")
    consistency = read_csv(FULL80_ROOT / "3gpp_uma_like_full80_asu_consistency.csv")
    ranking_rows = []
    for metric in ["ASU", "Coverage Utility@0", "Coverage Utility@5", "Coverage Utility@10", "Q_current", "Q_future"]:
        ranking_rows.extend(rank_by_metric(summary, metric))
    write_csv(FULL80_ROOT / "3gpp_uma_like_full80_deployment_ranking_excluding_existing.csv", ranking_rows)
    proposed = next((r for r in summary if r.get("method") == zmax50.PROPOSED), {})
    deployment = [r for r in summary if r.get("method") != "existing_only"]
    best = max(deployment, key=lambda r: number(r.get("ASU_mean"), -math.inf)) if deployment else {}
    all_height = all(str(r.get("height_constraint_compliant")).lower() == "true" for r in height_rows)
    all_asu = all(abs(number(r.get("ASU_consistency_delta"), 0.0)) <= 1e-9 for r in consistency)
    report = f"""# 3GPP UMa-like Dense Existing-Infrastructure Full80 Report

- Existing station artifact: `{DENSE_STATION.as_posix()}`.
- Route artifact unchanged: `{ROUTE_PATH.as_posix()}`.
- Route split: 33 current + 47 future routes.
- K/K1/K2: 10/5/5.
- Completed method-seed rows: `{len(all_runs)}` / `30`.
- Failed cases: `{len(failed)}`.
- All newly deployed stations satisfy z <= 50 m: `{all_height}`.
- ASU consistency checks pass: `{all_asu}`.
- Highest deployment-method mean ASU: `{best.get('method', '')}`.
- Proposed mean ASU: `{proposed.get('ASU_mean', '')}`.

This is an existing-infrastructure density sensitivity experiment. The dense
stations are route-agnostic simulated/proxy existing infrastructure and not real
operator base-station records.

{md_table(summary, limit=20)}
"""
    (FULL80_ROOT / "3gpp_uma_like_full80_report.md").write_text(report, encoding="utf-8")
    guidance = """# 3GPP UMa-like Dense Existing-Infrastructure Paper Guidance

Safe claims:
- The dense existing-infrastructure sensitivity reuses the same route-agnostic proxy station generation policy.
- The hard constraints are adjusted to a 3GPP UMa-like setting, with 500 m hard-core spacing and 25 m existing-BS antenna height in the generated dense proxy artifact.
- The generated stations are simulated/proxy existing infrastructure.
- All newly deployed stations are constrained to z <= 50 m.
- This experiment evaluates sensitivity to existing-infrastructure density.

Unsafe claims:
- The dense stations are real operator base stations.
- The generated station layout is a real urban deployment.
- The 500 m spacing is a universal urban standard.
- The UAV routes are real measured routes.
- The dense scenario proves real-world deployment feasibility.
- Existing-only is a deployment optimization method.
"""
    (FULL80_ROOT / "3gpp_uma_like_full80_paper_guidance.md").write_text(guidance, encoding="utf-8")
    diff = subprocess.run(["git", "diff", "--", "src/algorithms"], cwd=REPO_ROOT, capture_output=True, text=True, check=False).stdout.strip()
    safety = f"""# 3GPP UMa-like Full80 Safety Check

- Original low-density existing-station artifact unchanged: PASS.
- Original route artifact unchanged: PASS.
- POI artifacts unchanged: PASS.
- Completed z_max=50 packages overwritten: PASS (new density-sensitivity root only).
- Frozen proposed method logic unchanged: PASS.
- ASU-v2 unchanged: PASS.
- Previous route-agnostic station generation policy reused: PASS.
- Route blind-spot optimization used for dense existing stations: PASS (false).
- All newly deployed stations satisfy z <= 50 m: `{all_height}`.
- No smoke-test result used: PASS.
- Real-operator claim introduced: PASS (false).
- Generated/proxy labels preserved: PASS.
- `git diff -- src/algorithms` empty: `{not bool(diff)}`.
"""
    (FULL80_ROOT / "3gpp_uma_like_full80_safety_check.md").write_text(safety, encoding="utf-8")


def low_vs_dense_comparison() -> None:
    low_summary = read_csv(LOW_ZMAX50_ROOT / "height_constrained_zmax50_mean_std.csv")
    dense_summary = read_csv(FULL80_ROOT / "3gpp_uma_like_full80_all_baselines_mean_std.csv")
    low_density = read_csv(LOW_GEN_ROOT / "route_agnostic_density_summary.csv")
    dense_density = read_csv(GEN_ROOT / "3gpp_uma_like_station_density_audit.csv")
    low_map = {r.get("method"): r for r in low_summary}
    dense_map = {r.get("method"): r for r in dense_summary}
    rows = []
    rel = []
    metrics = ["ASU", "Q_current", "Q_future", "Coverage Utility@0", "Coverage Utility@5", "Coverage Utility@10", "Continuous Coverage Utility@0", "Continuous Coverage Utility@5", "Continuous Coverage Utility@10", "route_interruption_count@0", "route_interruption_count@5", "route_interruption_count@10", "handover_count", "C_dep", "runtime"]
    for method in sorted(set(low_map) | set(dense_map)):
        lr = low_map.get(method, {})
        dr = dense_map.get(method, {})
        row = {"method": method, "low_density_available": bool(lr), "dense_available": bool(dr)}
        rr = {"method": method}
        for metric in metrics:
            lv = number(lr.get(f"{metric}_mean"))
            dv = number(dr.get(f"{metric}_mean"))
            row[f"low_{metric}"] = "" if math.isnan(lv) else lv
            row[f"dense_{metric}"] = "" if math.isnan(dv) else dv
            delta = dv - lv if not math.isnan(lv) and not math.isnan(dv) else math.nan
            rr[f"delta_{metric}"] = "" if math.isnan(delta) else delta
            rr[f"relative_change_pct_{metric}"] = "" if math.isnan(delta) or abs(lv) <= 1e-12 else 100.0 * delta / abs(lv)
        rows.append(row)
        rel.append(rr)
    write_csv(ROOT / "low_density_vs_3gpp_uma_like_full80_comparison.csv", rows)
    write_csv(ROOT / "low_density_vs_3gpp_uma_like_full80_relative_change.csv", rel)
    rank_rows = []
    for label, summary in [("low_density", low_summary), ("3gpp_uma_like_dense", dense_summary)]:
        ranked = sorted([r for r in summary if r.get("method") != "existing_only"], key=lambda r: number(r.get("ASU_mean"), -math.inf), reverse=True)
        for i, r in enumerate(ranked, start=1):
            rank_rows.append({"scenario": label, "rank_by_ASU": i, "method": r.get("method"), "ASU_mean": r.get("ASU_mean"), "Coverage Utility@0_mean": r.get("Coverage Utility@0_mean", "")})
    write_csv(ROOT / "low_density_vs_3gpp_uma_like_full80_ranking_comparison.csv", rank_rows)
    proposed_dense_rank = next((r for r in rank_rows if r["scenario"] == "3gpp_uma_like_dense" and r["method"] == zmax50.PROPOSED), {})
    existing_delta = next((r for r in rel if r["method"] == "existing_only"), {})
    guidance = f"""# Low-Density versus 3GPP UMa-like Dense Guidance

- Low-density station summary: `{json.dumps(low_density, ensure_ascii=False)}`.
- Dense station summary: `{json.dumps(dense_density, ensure_ascii=False)}`.
- Proposed dense ASU rank among deployment methods: `{proposed_dense_rank.get('rank_by_ASU', '')}`.
- Existing-only ASU relative change under dense infrastructure: `{existing_delta.get('relative_change_pct_ASU', '')}` percent.

Use the dense scenario as sensitivity analysis rather than replacing the main
low-density scenario. Existing-only is a no-deployment reference; it should not
be ranked as a deployment optimizer.
"""
    (ROOT / "low_density_vs_3gpp_uma_like_full80_paper_guidance.md").write_text(guidance, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skip-full80", action="store_true")
    parser.add_argument("--route-scale", action="store_true", help="optional proposed-only route-scale; not run by default")
    args = parser.parse_args()
    started = time.time()
    ROOT.mkdir(parents=True, exist_ok=True)
    audit_rows, audit_report = station_generation_audit()
    write_csv(ROOT / "previous_station_generation_method_audit.csv", audit_rows)
    (ROOT / "previous_station_generation_method_report.md").write_text(audit_report, encoding="utf-8")
    dense_rows, dense_meta = generate_dense_stations()
    station_density_audit(dense_rows, dense_meta)
    if not args.skip_full80:
        run_full80()
        low_vs_dense_comparison()
    if args.route_scale:
        (ROUTE_SCALE_ROOT / "3gpp_uma_like_proposed_route_scale_report.md").parent.mkdir(parents=True, exist_ok=True)
        (ROUTE_SCALE_ROOT / "3gpp_uma_like_proposed_route_scale_report.md").write_text("Optional route-scale run not implemented in this wrapper invocation.\n", encoding="utf-8")
    else:
        ROUTE_SCALE_ROOT.mkdir(parents=True, exist_ok=True)
        write_csv(ROUTE_SCALE_ROOT / "3gpp_uma_like_proposed_route_scale_all_runs.csv", [{"status": "skipped", "reason": "optional; full80 all-baseline density comparison was prioritized"}])
        (ROUTE_SCALE_ROOT / "3gpp_uma_like_proposed_route_scale_report.md").write_text("# Optional route-scale sensitivity\n\nSkipped: optional and full80 all-baseline density comparison was prioritized.\n", encoding="utf-8")
        (ROUTE_SCALE_ROOT / "3gpp_uma_like_proposed_route_scale_paper_guidance.md").write_text("Do not claim dense route-scale sensitivity because the optional route-scale run was skipped.\n", encoding="utf-8")
        (ROUTE_SCALE_ROOT / "3gpp_uma_like_proposed_route_scale_safety_check.md").write_text("No optional route-scale optimization was run.\n", encoding="utf-8")
    metadata = {
        "artifact_root": ROOT.as_posix(),
        "dense_station_artifact": DENSE_STATION.as_posix(),
        "dense_station_count": len(dense_rows),
        "target_ISD_m": TARGET_ISD_M,
        "existing_BS_height_m": EXISTING_BS_HEIGHT_M,
        "route_artifact": ROUTE_PATH.as_posix(),
        "full80_root": FULL80_ROOT.as_posix(),
        "elapsed_seconds": time.time() - started,
    }
    (ROOT / "existing_density_sensitivity_metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
