# Fixed inputs and provenance

The publisher explicitly confirmed on2026-10-28 that the fixed POI/generated-route/map-derived files may be distributed with this public reproduction package. This records the publisher's authorization; upstream attribution and data-license terms remain applicable.

| Input | Path | Content / SHA-256 |
|---|---|---|
| Main existing infrastructure | `artifacts/tmc_rebuild/station_generation_citywide_route_agnostic/generated_existing_stations_citywide_route_agnostic_low.csv` |144 simulated/proxy stations; `6faa8a35392931ac4c0ba41a1fd0f9ccbc387dca1467be8ed25587327201532d`|
| Main corridor samples | `artifacts/tmc_rebuild/route_resampling/shenyang_predicted_routes_resampled_points.csv` |80×30=2400 generated/proxy samples; current33/990, future47/1410; `54a7aa6f7480c5444d8b2ce71af5da141b81c0e6a7a1605d7771ce701a2ef732`|
| Dense existing infrastructure | `artifacts/tmc_rebuild/formal_true_sinr_height_constrained_zmax50_existing_density_sensitivity_3gpp_uma_like/station_generation_3gpp_uma_like/generated_existing_stations_citywide_route_agnostic_3gpp_uma_like_500m.csv` |768 proxy stations; `d4b7477001a46bcef1fade0d48c1f6ef8d12b88c0e9daa9c0614453b34bc9d39`|
| POI / route semantic metadata | `data/real/shenyang/shenyang_pois.csv`, `shenyang_predicted_routes.csv` |Real-map-derived named POIs, some inferred logistics classes; generated routes. The directory name`real` does not mean measured flight routes.|
| Study rectangle | `data/real/shenyang/shenyang_study_area_boundary.geojson` |Configured study-area bounding rectangle, not a complete administrative boundary.|
| Supplement60 | `artifacts/tmc_rebuild/formal_K10_true_sinr_height_constrained_zmax50_sensitivity/route60_extension/route60_selected_routes.csv` |Fixed25current/35predicted route IDs selected from the same source samples;1800points.|

POI source fields identify `gis_osm_*` layers and real-map-derived features. ©OpenStreetMap contributors; see THIRD_PARTY_NOTICES.md for upstream attribution and ODbL links. The exact original province-scale GeoPackage/vendor edition was not present. This package does not invent a download URL or assert that a newer map export is equivalent.

Generated routes start from logistics centers. Current/future classes use logistics→business and logistics→hospital respectively. Source files retain generation labels and selection rules. Existing station inputs are simulated, route-agnostic infrastructure, not real operator data.

Sparse station metadata records seed series20260630/20260631/20260632; dense generation records20260701. Exact sparse/resampling writers were not fully established. Fixed inputs are therefore preserved byte-for-byte: seeds alone are not asserted to regenerate the same data. Replacing them changes the problem instance.

The main numerical runs and supplied checks use the frozen files and need no external GIS. Rebuilding original city/POI/road/building extraction requires the exact original GeoPackage, its layer inventory and a newly recorded file checksum. That GIS reconstruction is outside the self-contained scope of this release. No raw province-scale GeoPackage, QGIS project or manuscript PDF is included.
