# Validation — public release v1.0

Release date:2026-10-28. Status: publicly distributable reproduction-code archive prepared with the publisher's data authorization. **Complete paper experiments were not rerun.** The preserved implementation/results are not changed to force manuscript agreement.

## Executed on the public copy

| Check | Seconds | Exit |
|---|---:|---:|
|public_config|3.395|0|
|public_tests|4.837|0|
|public_smoke|12.697|0|
|public_route60|3.328|0|
|public_historical_arithmetic|0.128|0|
|public_HV_GD_IGD|5.000|0|
|public_extract_candidate|1.755|0|
|public_verify_candidate|1.094|0|
|public_isolated_smoke|14.293|0|
|public_isolated_route60|4.103|0|

Validation subprocesses recorded before this report total50.629s. Archive CRC, SHA-256 and final extraction checks have separate machine-readable receipts alongside the distributed ZIP. The lightweight validation budget is below10minutes; no paper-scale optimization was started.

-24tests pass, including fixed-input, sector encoding, true-SINR evaluator, multiobjective metric and60-supplement checks. Joblib CPU-count detection and scikit-learn's Windows/MKL K-means warnings occurred; no numerical workaround was introduced.
-The full two-stage smoke uses all144stations/2400points,8particles×3iterations/stage andseed2026. ASU=0.08187011740680837. Its decoded stations, sector indices, objective vectors, response summary and height audit are in`artifacts/public_validation/`. No CER event is triggered by this short smoke.
-The60-corridor portable input check passes:25/35routes,1800points,144stations; it performs no optimization. The15successful formal60-units are historical results, not runs performed during packaging.
-Historical summary arithmetic:290checks,289matching; one four-decimal floating rounding edge in MOEA/D Coverage@10 differs by less than5e-17. Source tables are unchanged.
-HV/GD/IGD were recomputed from all7methods×3seeds:63checks, maximum absolute delta0. The empirical reference front and comparisons are in`artifacts/release_front_recheck/`.
-Previous same-input original/copy evaluation checked2400SINR values and all metric/objective fields with zero differences; its compact record is retained in`evidence/source_release_comparison.json`.

Exact portable commands/times are in`artifacts/public_validation/commands.json`; tested versions are in`environment.json` andDEPENDENCIES.md. Subprocesses use`-I -B`, no inheritedPYTHONPATH/PYTHONHOME/AIRHERO values, and local validation caches. The supplied launchers establish their own root and output paths.

## Archive and integrity scope

The final ZIP is checked for CRC and per-file SHA-256, extracted into a new location and checked againstMANIFEST.csv. An extracted candidate also runs with file reads from the original project tree denied. MANIFEST.csv contains repository-relative provenance identifiers; its own bytes are protected by the distributed ZIP SHA-256 sidecar.

Original algorithm/evaluator/metric source, fixed inputs, per-seed numeric results and seeds remain byte-identical copies. One figure metadata field,`script_used`, is changed solely from a private absolute path to its repository-relative script path; all other scientific fields are identical and the change is recorded inMANIFEST.csv. Public documentation and portable launchers are packaging additions. No existing project source/Git state was reset, staged or committed.

Internal Git snapshots, personal machine paths, raw console retry logs, caches, temporary tests, credentials, environments, the stale manuscript PDF and external QGIS project are excluded. Credential/path scans and payload checks are reflected inPUBLIC_CHECKS.json. The full private preparation audit is not included in this public archive.

## Limits retained in this release

No complete50×150×all-seed rerun, clean dependency installation, other-platform validation, original-city GIS rebuild or engineering high-fidelity verification was completed. Current source hashes cannot prove every historical run's source version because no source commit fingerprint was available. Observed feasibility fields are not independent constraint certification. The publisher's accepted implementation conventions, including internal objective dimensions and metric geometry, are described inIMPLEMENTATION_NOTES.md. The60supplement's different initialization and actual25/35split remain explicit.
