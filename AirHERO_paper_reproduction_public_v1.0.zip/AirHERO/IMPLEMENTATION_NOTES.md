# Implementation conventions accepted for this release

The publisher instructed that the following documented differences be retained rather than treated as publication blockers. No algorithm, random-number stream, evaluator or metric was changed. This records a release decision, not a new proof of equivalence.

Historical candidate/exploratory flags in preserved configuration/result files remain as provenance. They do not define the publication status of this public v1.0 archive; RELEASE.json records that status and its limited validation scope.

- Internal search retains five objectives including composite ASU; the paper-facing diagnostic exports four. Dropping a composite dimension is not asserted here to preserve every Pareto ordering.
- Main 5GA beamwidth is120°. The publisher reports revising the manuscript accordingly; no manuscript PDF is distributed in this code release.
- AirHERO-search retains its internal evaluator while alternative adapters use their own four-objective wrapping. The saved post-evaluation protocol and vectors are supplied without asserting a newly verified identical-internal-objective comparison.
- CCU uses adjacent covered sample pairs. Stage-I initialization and metadata grouping, the ground-projected A2G geometry and empty building model are preserved and described in PAPER_CODE_MAP.md.
- The publisher reports correcting the manuscript's ImMOGWO IGD. Raw saved values and metric computations are unchanged.

The confirmed60-corridor supplement is included as its own actual run protocol:25/35split, seed2026, differing Stage-II initialization. It is not substituted into the main50-corridor cell by relabeling. All reported numerical inputs should be traced to the matching saved CSV.

Additional scope limits remain explicit: no historical source commit fingerprint, no full experimental rerun during packaging, no measured operator/UAV data claim, no ray-tracing/high-fidelity main-run claim, and no independently certified feasibility claim from a zero-penalty evaluator. A possible CER decision/evaluation alignment risk identified in source review was not behaviorally fixed or quantified during packaging. The supplied short smoke does not trigger long-run CER.
